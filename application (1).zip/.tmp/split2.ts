import * as ts from 'typescript'
import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const indexPath = path.join(root, 'src/routes/index.tsx')
const cfg = ts.getParsedCommandLineOfConfigFile(path.join(root, 'tsconfig.json'), {}, { ...ts.sys, onUnRecoverableConfigFileDiagnostic: () => {} })!
const program = ts.createProgram([indexPath], cfg.options)
const checker = program.getTypeChecker()
const sf = program.getSourceFile(indexPath)!
const text = sf.text

const home = sf.statements.find((s) => ts.isFunctionDeclaration(s) && s.name?.text === 'Home') as ts.FunctionDeclaration
const body = home.body!
const stmts = [...body.statements]
const returnStmt = stmts[stmts.length - 1]
if (!ts.isReturnStatement(returnStmt)) throw new Error('last statement of Home is not return')

const viewGroups: { file: string; fn: string; views: string[] }[] = [
  { file: 'FindPage', fn: 'FindView', views: ['findBody', 'findView'] },
  { file: 'PipelinePage', fn: 'PipelineView', views: ['pipelineView'] },
  { file: 'DashboardPage', fn: 'DashboardView', views: ['dashboardView'] },
  { file: 'ApplicationsPage', fn: 'ApplicationsView', views: ['applicationsList'] },
  { file: 'EditorPage', fn: 'EditorView', views: ['editorView'] },
  { file: 'ProfilePage', fn: 'ProfileView', views: ['profileView'] },
  { file: 'TrackerPage', fn: 'TrackerView', views: ['trackerView'] },
]
const viewNames = new Set(viewGroups.flatMap((g) => g.views))
const stmtName = (s: ts.Statement) => (ts.isVariableStatement(s) && s.declarationList.declarations.length === 1 ? s.declarationList.declarations[0].name.getText() : '')
const viewStmt = new Map<string, ts.VariableStatement>()
for (const s of stmts) { const n = stmtName(s); if (viewNames.has(n)) viewStmt.set(n, s as ts.VariableStatement) }
for (const n of viewNames) if (!viewStmt.has(n)) throw new Error('view not found: ' + n)

const isFnLike = (n: ts.Node) => ts.isArrowFunction(n) || ts.isFunctionExpression(n) || ts.isFunctionDeclaration(n) || ts.isMethodDeclaration(n) || ts.isConstructorDeclaration(n) || ts.isGetAccessor(n) || ts.isSetAccessor(n)
// If d is a declaration directly in Home's body (not inside a nested function), return its statement.
function homeTopStatement(d: ts.Node): ts.Statement | null {
  let n: ts.Node = d
  while (n.parent && n.parent !== body) {
    if (n !== d && isFnLike(n)) return null
    if (n === d && ts.isParameter(n)) return null
    n = n.parent
  }
  if (!n.parent) return null
  return n as ts.Statement
}

type Use = { home: Set<string>; imps: Map<ts.ImportDeclaration, Set<string>>; ext: Map<string, Set<string>>; typeExt: Set<string> }
function usage(nodes: ts.Node[], exclude: Set<ts.Statement>): Use {
  const u: Use = { home: new Set(), imps: new Map(), ext: new Map(), typeExt: new Set() }
  const visit = (n: ts.Node) => {
    if (ts.isIdentifier(n)) {
      const sym = checker.getSymbolAtLocation(n)
      const d = sym?.declarations?.[0]
      if (d) {
        const dsf = d.getSourceFile()
        if (dsf === sf) {
          const top = homeTopStatement(d)
          if (top) {
            if (!exclude.has(top) || false) {
              const nm = ts.isFunctionDeclaration(d) ? d.name!.text : ts.isVariableDeclaration(d) || ts.isBindingElement(d) ? (d.name as ts.Identifier).getText() : ''
              if (nm && (ts.isFunctionDeclaration(d) || ts.isVariableDeclaration(d) || ts.isBindingElement(d))) u.home.add(nm)
            }
          } else if (ts.isImportSpecifier(d) || ts.isImportClause(d) || ts.isNamespaceImport(d)) {
            let decl: ts.Node = d
            while (decl && !ts.isImportDeclaration(decl)) decl = decl.parent
            const set = u.imps.get(decl as ts.ImportDeclaration) ?? new Set<string>()
            set.add(ts.isImportClause(d) ? d.name!.text : d.getText())
            u.imps.set(decl as ts.ImportDeclaration, set)
          }
        } else if (!dsf.fileName.includes('node_modules') && dsf.fileName.startsWith(path.join(root, 'src'))) {
          const exported = (ts.isFunctionDeclaration(d) && d.name?.text) || ((ts.isVariableDeclaration(d)) && d.name.getText()) || (ts.isTypeAliasDeclaration(d) && d.name.text) || ''
          const topLevel = ts.isFunctionDeclaration(d) ? d.parent === dsf : ts.isVariableDeclaration(d) ? d.parent.parent.parent === dsf : ts.isTypeAliasDeclaration(d) ? d.parent === dsf : false
          if (exported && topLevel && exported === n.text) {
            const set = u.ext.get(dsf.fileName) ?? new Set<string>()
            set.add(exported)
            u.ext.set(dsf.fileName, set)
            if (ts.isTypeAliasDeclaration(d)) u.typeExt.add(exported)
          }
        }
      }
    }
    ts.forEachChild(n, visit)
  }
  nodes.forEach(visit)
  return u
}

function importLines(fromFile: string, u: Use) {
  const lines: string[] = []
  for (const [decl, specs] of u.imps) {
    const mod = (decl.moduleSpecifier as ts.StringLiteral).text
    const clause = decl.importClause!
    const typeOnly = clause.isTypeOnly
    const def = clause.name && specs.has(clause.name.text) ? clause.name.text : ''
    const named = clause.namedBindings && ts.isNamedImports(clause.namedBindings) ? clause.namedBindings.elements.filter((e) => specs.has(e.getText())).map((e) => e.getText()) : []
    const ns = clause.namedBindings && ts.isNamespaceImport(clause.namedBindings) && specs.has(clause.namedBindings.getText()) ? clause.namedBindings.getText() : ''
    const parts = [def, named.length ? `{ ${named.join(', ')} }` : '', ns].filter(Boolean).join(', ')
    if (parts) lines.push(`import ${typeOnly ? 'type ' : ''}${parts} from '${mod}'`)
  }
  for (const [f, names] of u.ext) {
    let rel = path.relative(path.dirname(path.join(root, fromFile)), f).replace(/\.tsx?$/, '')
    if (!rel.startsWith('.')) rel = './' + rel
    lines.push(`import { ${[...names].sort().map((n) => (u.typeExt.has(n) ? 'type ' + n : n)).join(', ')} } from '${rel}'`)
  }
  return lines
}
const full = (s: ts.Node) => text.slice(s.getFullStart(), s.end)

// ---- which statements stay in useHome
const viewStatements = new Set<ts.Statement>([...viewStmt.values()])
const hookStatements = stmts.slice(0, -1).filter((s) => !viewStatements.has(s))

// ---- names needed outside the hook: used by views or by the return statement
const outward = new Set<string>()
for (const g of viewGroups) {
  const u = usage(g.views.map((v) => viewStmt.get(v)!), new Set(g.views.map((v) => viewStmt.get(v)!)))
  u.home.forEach((n) => outward.add(n))
}
const retUse = usage([returnStmt], new Set())
retUse.home.forEach((n) => outward.add(n))
// views may call each other from the return (names like findView): they stay in Home and are not part of the bag
for (const v of viewNames) outward.delete(v)

// ---- write useHome
{
  const u = usage(hookStatements, new Set())
  const header = importLines('src/pages/use-home.tsx', u)
  // declarations in the hook that reference view names would be a problem
  const refsView = hookStatements.filter((s) => { let hit = false; const v = (n: ts.Node) => { if (ts.isIdentifier(n) && viewNames.has(n.text) && !ts.isVariableDeclaration(n.parent)) hit = true; ts.forEachChild(n, v) }; v(s); return hit })
  if (refsView.length) console.log('WARNING: hook statements reference views:', refsView.map((s) => text.slice(s.getStart(), s.getStart() + 60)))
  const out = header.join('\n') + '\n\n// The state and logic behind every page of the portal. The pages in this folder only draw it.\nexport function useHome() {\n' + hookStatements.map(full).join('\n') + '\n  return {\n    ' + [...outward].sort().join(',\n    ') + ',\n  }\n}\n\nexport type HomeState = ReturnType<typeof useHome>\n'
  fs.mkdirSync(path.join(root, 'src/pages'), { recursive: true })
  fs.writeFileSync(path.join(root, 'src/pages/use-home.tsx'), out)
  console.log('wrote use-home with', outward.size, 'names')
}

// ---- write pages
for (const g of viewGroups) {
  const nodes = g.views.map((v) => viewStmt.get(v)!)
  const u = usage(nodes, new Set(nodes))
  u.ext.set(path.join(root, 'src/pages/use-home.tsx'), new Set(['HomeState']))
  u.typeExt.add('HomeState')
  const fileRel = `src/pages/${g.file}.tsx`
  const header = importLines(fileRel, u)
  const names = [...u.home].filter((n) => !viewNames.has(n)).sort()
  const pieces: string[] = []
  g.views.forEach((v, i) => {
    const st = viewStmt.get(v)!
    const decl = st.declarationList.declarations[0]
    const init = decl.initializer!
    if (i < g.views.length - 1) pieces.push('  ' + text.slice(st.getStart(), st.end))
    else {
      if (!ts.isArrowFunction(init)) throw new Error(v + ' is not an arrow function')
      const b = init.body
      const exprText = ts.isParenthesizedExpression(b) ? text.slice(b.expression.getStart(), b.expression.end) : ts.isBlock(b) ? null : text.slice(b.getStart(), b.end)
      if (exprText !== null) pieces.push('  return (\n    ' + exprText + '\n  )')
      else pieces.push('  ' + text.slice(b.getStart() + 1, b.end - 1).trim())
    }
  })
  const out = header.join('\n') + `\n\nexport function ${g.fn}(h: HomeState) {\n  const {\n    ${names.join(',\n    ')},\n  } = h\n` + pieces.join('\n') + '\n}\n'
  fs.writeFileSync(path.join(root, fileRel), out)
  console.log('wrote', fileRel, names.length, 'names')
}

// ---- rewrite index.tsx
{
  const kept: string[] = []
  const idxStmts = [...sf.statements]
  const importsOfIdx: ts.Node[] = []
  const restNodes: ts.Node[] = []
  for (const s of idxStmts) { if (ts.isImportDeclaration(s)) continue; if (s === home) continue; restNodes.push(s) }
  // new Home
  const retNames = [...retUse.home].filter((n) => !viewNames.has(n)).sort()
  const callNames = viewGroups.map((g) => g.views[g.views.length - 1])
  const homeText =
    'function Home() {\n  const h = useHome()\n  const {\n    ' + retNames.join(',\n    ') + ',\n  } = h\n' +
    viewGroups.map((g) => `  const ${g.views[g.views.length - 1]} = () => ${g.fn}(h)`).join('\n') + '\n' + full(returnStmt).replace(/^\n+/, '\n') + '\n}\n'
  // usage in the rest
  const u: Use = usage([...restNodes, returnStmt], new Set())
  const header = importLines('src/routes/index.tsx', u)
  header.push("import { useHome } from '../pages/use-home'")
  for (const g of viewGroups) header.push(`import { ${g.fn} } from '../pages/${g.file}'`)
  const restText = restNodes.map(full).join('\n')
  fs.writeFileSync(indexPath, header.join('\n') + '\n\n' + restText.replace(/^\n+/, '') + '\n' + homeText)
  console.log('rewrote index, Home destructures', retNames.length, 'names')
}
