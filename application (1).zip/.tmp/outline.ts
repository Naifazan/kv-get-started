import * as ts from 'typescript'
import fs from 'node:fs'
const file = process.env.HOME + '/apps/app_SCr7EGOcerPuTO/src/routes/index.tsx'
const src = fs.readFileSync(file, 'utf8')
const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
const lineOf = (pos: number) => sf.getLineAndCharacterOfPosition(pos).line + 1
for (const st of sf.statements) {
  let name = ''
  if (ts.isFunctionDeclaration(st)) name = 'function ' + st.name?.text
  else if (ts.isVariableStatement(st)) name = 'var ' + st.declarationList.declarations.map((d) => d.name.getText()).join(',')
  else if (ts.isTypeAliasDeclaration(st)) name = 'type ' + st.name.text
  else if (ts.isImportDeclaration(st)) name = 'import ' + st.moduleSpecifier.getText()
  else name = ts.SyntaxKind[st.kind]
  console.log(lineOf(st.getStart()), '-', lineOf(st.end), name.slice(0, 90))
}
