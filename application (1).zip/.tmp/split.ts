import * as ts from 'typescript'
import fs from 'node:fs'
import path from 'node:path'

const root = process.cwd()
const indexPath = path.join(root, 'src/routes/index.tsx')
const cfgPath = path.join(root, 'tsconfig.json')
const cfg = ts.getParsedCommandLineOfConfigFile(cfgPath, {}, { ...ts.sys, onUnRecoverableConfigFileDiagnostic: () => {} })!
const program = ts.createProgram([indexPath], cfg.options)
const checker = program.getTypeChecker()
const sf = program.getSourceFile(indexPath)!
const text = sf.text

const groups: Record<string, string[]> = {
  'src/lib/types.ts': 'Fit View VIEWS PipeTab AppStatus STATUSES Project Area areaGov areaLabel areaFilled Inputs emptyInputs Application STAGE_PROB FRAME_FIELDS ELIG_LABEL ELIG_TONE emptyProject Tpl SortState'.split(' '),
  'src/lib/options.ts': 'US_ELIG US_CATS SECTORS EU_LABEL EU27 OTHER_COUNTRIES COUNTRY_OPTIONS GLOBAL_LABEL MIDDLE_EAST_LABEL MENA_LABEL MIDDLE_EAST NORTH_AFRICA REGION_ALIASES REGION_OPTIONS FILTER_COUNTRY_OPTIONS TYPE_OPTIONS normStatus isInvite fmtMoney amountLabel matchesCountry SECTIONS emptyProfile POPULATIONS SDGS GRANT_TYPES_SOUGHT PURPOSES COMPLIANCE SCOPES LANGS csv quickMatch orgBudgetCeiling realism PROFILE_KEYS missingKeys completeness parseDate Q_META FIELD_LABELS'.split(' '),
  'src/lib/text.ts': 'Block parseBlocks clean tidy DocLine docLines sectionPlain escHtml num budgetCheck ganttFrom lineDiff guidanceText fmtDate toB64 fromB64 cmpVal toggleSort'.split(' '),
  'src/lib/files.ts': 'readNeedsFile readFileText readAnyFile fileErrorText readAnyFileRaw parseCsv readGrantTable detectMapping parseMoney parseAmountText cleanDeadline buildImported downloadTemplateCsv IMPORT_FIELDS mergeRemoteApps'.split(' '),
  'src/lib/use-stored.ts': ['useStored'],
  'src/components/ui.tsx': 'Opt MultiSelect Hint Fold Section Gantt RenderBlocks DiffBlocks SortTh List DRow Bullets Steps Pills KV NS known DetailsPanel GrantRow field label primary ghost'.split(' '),
}
const target = new Map<string, string>()
for (const [f, names] of Object.entries(groups)) for (const n of names) target.set(n, f)

type St = { node: ts.Statement; names: string[]; file?: string }
const sts: St[] = []
const importDecls: ts.ImportDeclaration[] = []
const keep: ts.Statement[] = []
for (const node of sf.statements) {
  if (ts.isImportDeclaration(node)) { importDecls.push(node); continue }
  let names: string[] = []
  if (ts.isFunctionDeclaration(node) && node.name) names = [node.name.text]
  else if (ts.isVariableStatement(node)) names = node.declarationList.declarations.map((d) => d.name.getText())
  else if (ts.isTypeAliasDeclaration(node)) names = [node.name.text]
  if (names.length === 1 && (names[0] === 'Home' || names[0] === 'Route')) { keep.push(node); continue }
  if (!names.length) { keep.push(node); continue } // declare global etc.
  const files = new Set(names.map((n) => target.get(n)))
  if (files.size !== 1 || [...files][0] === undefined) throw new Error('No target for ' + names.join(','))
  sts.push({ node, names, file: [...files][0] })
}

const typeNames = new Set<string>()
for (const s of sts) if (ts.isTypeAliasDeclaration(s.node)) typeNames.add(s.names[0])
const topNameFile = new Map<string, string>()
for (const s of sts) for (const n of s.names) topNameFile.set(n, s.file!)

function isTopDecl(d: ts.Declaration) {
  if (ts.isFunctionDeclaration(d)) return d.parent === sf
  if (ts.isVariableDeclaration(d)) return d.parent.parent.parent === sf
  if (ts.isTypeAliasDeclaration(d)) return d.parent === sf
  return false
}

// For a list of nodes: which top-level names and which original imports do they use?
function usage(nodes: ts.Node[]) {
  const tops = new Set<string>()
  const imps = new Map<ts.ImportDeclaration, Set<string>>()
  const visit = (n: ts.Node) => {
    if (ts.isIdentifier(n)) {
      const sym = checker.getSymbolAtLocation(n)
      const d = sym?.declarations?.[0]
      if (d && d.getSourceFile() === sf) {
        if (isTopDecl(d)) {
          const nm = ts.isFunctionDeclaration(d) ? d.name!.text : ts.isVariableDeclaration(d) ? d.name.getText() : (d as ts.TypeAliasDeclaration).name.text
          tops.add(nm)
        } else if (ts.isImportSpecifier(d) || ts.isImportClause(d) || ts.isNamespaceImport(d)) {
          let decl: ts.Node = d
          while (decl && !ts.isImportDeclaration(decl)) decl = decl.parent
          const set = imps.get(decl as ts.ImportDeclaration) ?? new Set<string>()
          set.add(ts.isImportClause(d) ? d.name!.text : d.getText())
          imps.set(decl as ts.ImportDeclaration, set)
        }
      }
    }
    ts.forEachChild(n, visit)
  }
  nodes.forEach(visit)
  return { tops, imps }
}

function importLines(fromFile: string, own: Set<string>, u: ReturnType<typeof usage>) {
  const lines: string[] = []
  // original imports
  for (const [decl, specs] of u.imps) {
    const mod = (decl.moduleSpecifier as ts.StringLiteral).text
    const clause = decl.importClause!
    const typeOnly = clause.isTypeOnly
    const def = clause.name && specs.has(clause.name.text) ? clause.name.text : ''
    const named = clause.namedBindings && ts.isNamedImports(clause.namedBindings) ? clause.namedBindings.elements.filter((e) => specs.has(e.getText())).map((e) => e.getText()) : []
    const ns = clause.namedBindings && ts.isNamespaceImport(clause.namedBindings) && specs.has(clause.namedBindings.getText()) ? clause.namedBindings.getText() : ''
    const parts = [def, named.length ? `{ ${named.join(', ')} }` : '', ns].filter(Boolean).join(', ')
    if (parts) lines.push(`import ${typeOnly ? 'type ' : ''}${parts} from '${mod}'`)
  }
  // moved names
  const byFile = new Map<string, string[]>()
  for (const n of u.tops) { if (own.has(n)) continue; const f = topNameFile.get(n); if (!f) continue; byFile.set(f, [...(byFile.get(f) ?? []), n]) }
  for (const [f, names] of byFile) {
    let rel = path.relative(path.dirname(path.join(root, fromFile)), path.join(root, f)).replace(/\.tsx?$/, '')
    if (!rel.startsWith('.')) rel = './' + rel
    lines.push(`import { ${names.sort().map((n) => (typeNames.has(n) ? 'type ' + n : n)).join(', ')} } from '${rel}'`)
  }
  return lines
}

function stText(s: St) {
  const full = text.slice(s.node.getFullStart(), s.node.end)
  const startOff = s.node.getStart() - s.node.getFullStart()
  return full.slice(0, startOff) + 'export ' + full.slice(startOff)
}

fs.mkdirSync('.tmp/out', { recursive: true })
for (const [file, names] of Object.entries(groups)) {
  const mine = sts.filter((s) => s.file === file)
  const own = new Set(mine.flatMap((s) => s.names))
  const u = usage(mine.map((s) => s.node))
  const header = importLines(file, own, u)
  const body = mine.map(stText).join('\n')
  const out = (header.length ? header.join('\n') + '\n' : '') + '\n' + body.replace(/^\n+/, '') + '\n'
  fs.mkdirSync(path.dirname(path.join(root, file)), { recursive: true })
  fs.writeFileSync(path.join(root, file), out)
  console.log('wrote', file, mine.length, 'statements')
}
// rewrite index
const ku = usage(keep)
const idxOwn = new Set<string>()
const idxImports = importLines('src/routes/index.tsx', idxOwn, ku)
const keepText = keep.map((n) => text.slice(n.getFullStart(), n.end)).join('\n')
fs.writeFileSync(indexPath, idxImports.join('\n') + '\n\n' + keepText.replace(/^\n+/, '') + '\n')
console.log('rewrote index with', idxImports.length, 'imports')
