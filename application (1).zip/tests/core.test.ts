// @ts-nocheck
import { describe, expect, test } from 'bun:test'
import { matchTitle } from '../src/lib/match-title'
import { parseJson } from '../src/server/grants'
import { docIsValid, libraryDigest } from '../src/lib/library-digest'

describe('matchTitle', () => {
  const titles = ['Executive summary', 'Statement of need', 'Goals and SMART objectives', 'Budget summary and justification']
  test('finds the exact title', () => expect(matchTitle(titles, 'Statement of need')).toBe('Statement of need'))
  test('finds a close title', () => expect(matchTitle(titles, 'statement of the need')).toBe('Statement of need'))
  test('returns nothing for an unrelated title', () => expect(matchTitle(titles, 'Zebra crossing')).toBeFalsy())
})

describe('parseJson', () => {
  test('reads normal JSON', () => expect(parseJson('{"a":1}')).toEqual({ a: 1 }))
  test('reads JSON inside prose', () => expect(parseJson('Here you go: {"a":[1,2]} thanks')).toEqual({ a: [1, 2] }))
  test('keeps what is complete when the answer is cut off', () => {
    const r = parseJson('{"items":[{"claim":"62% food insecure","sourced":true},{"claim":"30% stunt')
    expect(r.items[0].claim).toBe('62% food insecure')
  })
})

describe('library', () => {
  const lib: any = { docs: [{ id: '1', name: 'Registration', type: 'Registration certificate', issued: '', expiry: '2000-01-01', link: '', notes: '' }], snippets: [] }
  test('an expired document is not valid', () => expect(docIsValid(lib.docs[0])).toBe(false))
  test('a document with no expiry is valid', () => expect(docIsValid({ ...lib.docs[0], expiry: '' })).toBe(true))
  test('the digest names expired documents', () => expect(libraryDigest(lib)).toContain('EXPIRED'))
})

import { acronymReport, languageReport } from '../src/lib/language'
describe('language checks', () => {
  const secs = [
    { key: 'a', title: 'Summary', text: 'The Monitoring, Evaluation, Accountability and Learning (MEAL) plan guides us. WASH services reach 800 households. The NGO works in Kenya.' },
    { key: 'b', title: 'Activities', text: 'MEAL staff visit each site. WASH committees meet monthly and the WASH kits are replaced yearly.' },
  ]
  test('a defined acronym is accepted', () => expect(acronymReport(secs).find((x) => x.acr === 'MEAL')?.defined).toBe(true))
  test('an acronym used without a definition is flagged', () => expect(acronymReport(secs).find((x) => x.acr === 'WASH')?.defined).toBe(false))
  test('well known acronyms are ignored', () => expect(acronymReport(secs).some((x) => x.acr === 'NGO')).toBe(false))
  test('mixed spelling is found', () => {
    const r = languageReport([{ key: 'a', title: 'A', text: 'We organize the programme for the whole community and we analyse the results with local partners every month for a full year of work, and we report the findings to the county office, the donors and every village committee that takes part in the project.' }])
    expect(r.spelling.mixed).toBe(true)
  })
  test('long sentences are flagged', () => {
    const long = 'We will ' + 'carefully and thoroughly '.repeat(8) + 'train the farmers who live in the villages near the river and who have never had access to any formal agricultural extension services before this project began. ' + 'We will ' + 'carefully and thoroughly '.repeat(8) + 'train the farmers who live in the villages near the river and who have never had access to any formal agricultural extension services before this project began.'
    expect(languageReport([{ key: 'a', title: 'A', text: long }]).sections[0].flags.join(' ')).toContain('over 30 words')
  })
})

import { normStatus as ns, showDate } from '../src/lib/options'
describe('grant dates and status', () => {
  test('showDate writes a readable date and leaves text alone', () => {
    expect(showDate('10/30/2026')).toBe('30 Oct 2026')
    expect(showDate('2026-11-05')).toBe('5 Nov 2026')
    expect(showDate('Rolling')).toBe('Rolling')
  })
  test('a forthcoming call whose date has passed is closed', () => {
    const g: any = { status: 'forthcoming', deadline: '2019-08-27' }
    expect(ns(g)).toBe('closed')
    expect(ns({ status: 'forecasted', deadline: 'No close date listed' } as any)).toBe('forthcoming')
  })
})

import { sortList } from '../src/lib/text'
describe('sortList', () => {
  const rows = [{ n: 'Grant 10', d: 5 }, { n: 'grant 2', d: null }, { n: 'Árbol', d: 1 }, { n: 'Grant 1', d: undefined }]
  test('rows with no value go last whichever way you sort', () => {
    expect(sortList(rows, (r) => r.d, 1).map((r) => r.n)).toEqual(['Árbol', 'Grant 10', 'grant 2', 'Grant 1'])
    expect(sortList(rows, (r) => r.d, -1).map((r) => r.n)).toEqual(['Grant 10', 'Árbol', 'grant 2', 'Grant 1'])
  })
  test('text sorts naturally and ignores case', () => {
    expect(sortList(rows, (r) => r.n, 1).map((r) => r.n)).toEqual(['Árbol', 'Grant 1', 'grant 2', 'Grant 10'])
    expect(sortList(rows, (r) => r.n, -1).map((r) => r.n)).toEqual(['Grant 10', 'grant 2', 'Grant 1', 'Árbol'])
  })
})

import { compose } from '../src/server/fit'
describe('fit score', () => {
  const prof: any = { org: 'X', country: 'Yemen', opCountries: 'Yemen', registered: 'yes', budget: '$25k to $100k', mission: 'girls education health', focus: 'Education, Health', amountMin: '20000', amountMax: '150000' }
  const grant: any = { id: 'g', title: 'Education grants for NGOs', funder: 'F', source: 'S', deadline: 'Rolling', status: 'open', countries: ['Global'], sectors: ['Education'], amountMax: 80000, summary: 'girls education' }
  const verdict: any = { theme: 10, eligibility: 'eligible', reason: 'Direct match', strengths: [], gaps: [], tips: [] }
  test('the parts add up to the score and the same input gives the same score', () => {
    const a = compose(prof, grant, verdict)
    expect(a.breakdown.reduce((t, x) => t + x.points, 0)).toBe(a.score)
    expect(compose(prof, grant, verdict).score).toBe(a.score)
    expect(a.score).toBeGreaterThan(85)
  })
  test('a closed, invitation-only or excluded call is capped', () => {
    expect(compose(prof, { ...grant, deadline: '2020-01-01' }, verdict).score).toBeLessThanOrEqual(15)
    expect(compose(prof, { ...grant, inviteOnly: true }, verdict).score).toBeLessThanOrEqual(35)
    expect(compose(prof, grant, { ...verdict, eligibility: 'ineligible' }).score).toBeLessThanOrEqual(20)
  })
  test('without the AI the score still works and is marked as keyword', () => {
    const f = compose(prof, grant, null)
    expect(f.mode).toBe('keyword')
    expect(f.score).toBeGreaterThan(0)
  })
})
