// @ts-nocheck
import { whop } from '@whop/cli/vite'
import { devtools } from '@tanstack/devtools-vite'

import { tanstackStart } from '@tanstack/react-start/plugin/vite'

import viteReact from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { cloudflare } from '@cloudflare/vite-plugin'

const plugins: any[] = [
  whop({ disableTanstackDevtools: true }),
  devtools(),
  cloudflare({ viteEnvironment: { name: 'ssr' } }),
  tailwindcss(),
  tanstackStart(),
  viteReact(),
]

const config = {
  resolve: { tsconfigPaths: true },
  plugins,
}

export default config
