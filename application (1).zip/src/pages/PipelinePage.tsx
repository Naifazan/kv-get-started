import { showDate } from '../lib/options'
import { FitBreakdown, List, SortTh, field, ghost, primary } from '../components/ui'
import { toggleSort } from '../lib/text'
import { Fragment } from 'react'
import { isInvite } from '../lib/options'
import { type HomeState } from './use-home'

export function PipelineView(h: HomeState) {
  const {
    PIPE_TABS,
    PageHead,
    apps,
    busy,
    fitBulkBusy,
    fitOf,
    fitProgress,
    fitStopRef,
    fits,
    isSaved,
    notesBy,
    openDetails,
    pFit,
    pSort,
    pageOf,
    removeGrant,
    pager,
    pipeOpen,
    pipeRows,
    pipeTab,
    runFit,
    runFitBulk,
    setActiveId,
    setAppOpen,
    setNotesBy,
    setPFit,
    setPSort,
    setPipeOpen,
    setPipeTab,
    setView,
    sortRows,
    startApplication,
    toggleSave,
  } = h
  // Every grant in every stage, once, with no repeats.
  const allGrants = [...new Map(Object.values(pipeRows).flat().filter((r) => r.grant).map((r) => [r.grant!.id, r.grant!])).values()]
  const left = allGrants.filter((g) => !(fits[g.id] && fits[g.id].mode === 'ai')).length
  return (
    <div>
      <PageHead title="Grants pipeline" sub="Every grant you have found, from open calls to applications in progress. Select a stage, run a fit analysis, and move the right grants into applications.">
        <div className="flex flex-wrap gap-3">
          <button className={ghost} disabled={!!busy || fitBulkBusy || allGrants.length === 0} title="Scores every grant in every stage that does not have a fit score yet, in one click." onClick={() => runFitBulk(allGrants)}>
            {fitBulkBusy ? (fitProgress || 'Analyzing...') : left === 0 && allGrants.length > 0 ? 'All grants analyzed' : `Fit analysis for all grants${left ? ` (${left} to do)` : ''}`}
          </button>
          {fitBulkBusy && <button type="button" className="text-sm font-semibold underline" onClick={() => { fitStopRef.current = true }}>Stop</button>}
          <button className={primary} onClick={() => setView('find')}>Find more grants</button>
        </div>
      </PageHead>
      <div role="tablist" aria-label="Pipeline stage" className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {PIPE_TABS.map(([k, t]) => (
          <button key={k} role="tab" aria-selected={pipeTab === k} onClick={() => setPipeTab(k)}
            className={`rounded-card border p-4 text-left transition ${pipeTab === k ? 'border-accent bg-accent text-accent-ink' : 'border-line bg-card hover:border-accent/60'}`}>
            <p className="font-display text-3xl font-semibold tabular-nums">{pipeRows[k].length}</p>
            <p className={`mt-1 text-sm font-semibold ${pipeTab === k ? 'text-accent-ink/85' : 'text-muted'}`}>{t}</p>
          </button>
        ))}
      </div>
      <div className="mt-4 overflow-hidden rounded-card border border-line">
        <div className="flex flex-wrap items-center gap-3 border-b border-line bg-card px-4 py-3 text-xs font-semibold">
          <label className="flex items-center gap-2">Fit score
            <select aria-label="Filter by fit score" className="rounded-full border border-accent/60 bg-white px-3 py-1.5 text-sm font-semibold" value={pFit} onChange={(e) => setPFit(e.target.value as typeof pFit)}>
              <option value="all">All grants</option>
              <option value="80">80 and above</option>
              <option value="60">60 and above</option>
              <option value="low">Below 60</option>
              <option value="analyzed">Analyzed only</option>
              <option value="none">Not analyzed yet</option>
            </select>
          </label>
          <span className="font-normal text-muted">{pFit === 'all' ? 'Run Fit analysis to give each grant a score.' : `Showing ${sortRows(pipeRows[pipeTab]).length} of ${pipeRows[pipeTab].length} in this stage.`}</span>
          {pFit !== 'all' && <button type="button" className="underline" onClick={() => setPFit('all')}>Show all</button>}
        </div>
        <label className="block border-b border-line bg-card px-4 py-3 text-xs font-semibold md:hidden">Sort by
          <select className={`${field} mt-1 py-2`} value={pSort ? `${pSort.k}:${pSort.dir}` : ''} onChange={(e) => { const [k, d] = e.target.value.split(':'); setPSort(k ? { k, dir: Number(d) as 1 | -1 } : null) }}>
            <option value="">Default order</option><option value="name:1">Grant name, A to Z</option><option value="deadline:1">Soonest deadline</option><option value="deadline:-1">Latest deadline</option><option value="amount:-1">Largest amount</option><option value="amount:1">Smallest amount</option><option value="fit:-1">Highest fit score</option><option value="fit:1">Lowest fit score</option><option value="status:1">Status</option>
          </select>
        </label>
        <table className="w-full border-collapse text-sm max-md:block">
          <thead className="max-md:hidden">
            <tr className="bg-ink text-left text-xs tracking-wide text-paper uppercase">
              <SortTh k="name" label="Grant name" sort={pSort} onSort={(k) => setPSort((c) => toggleSort(c, k))} className="px-4" />
              <SortTh k="deadline" label="Deadline" sort={pSort} onSort={(k) => setPSort((c) => toggleSort(c, k))} className="px-4" />
              <SortTh k="amount" label="Amount" sort={pSort} onSort={(k) => setPSort((c) => toggleSort(c, k))} className="px-4" />
              <SortTh k="fit" label="Fit score" sort={pSort} onSort={(k) => setPSort((c) => toggleSort(c, k))} className="px-4" />
              <SortTh k="status" label="Status" sort={pSort} onSort={(k) => setPSort((c) => toggleSort(c, k))} className="px-4" />
              <th scope="col" className="px-4 py-3 text-right text-xs font-semibold tracking-wide uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line bg-white max-md:block">
            {pipeRows[pipeTab].length === 0 ? (
              <tr className="max-md:block"><td colSpan={6} className="px-4 py-6 text-center text-muted max-md:block">
                {pipeTab === 'saved' ? 'No saved grants yet.' : pipeTab === 'applying' ? 'No applications in progress.' : 'Nothing here yet. Search for grants and they appear in the right stage automatically.'}
                <div className="mt-3"><button className={primary} onClick={() => setView('find')}>Find grants</button></div>
              </td></tr>
            ) : pageOf(sortRows(pipeRows[pipeTab]), 'pipe-' + pipeTab).map((r) => {
              const fit = r.grant ? fits[r.grant.id] : undefined
              const isOpen = pipeOpen === r.id
              return (
                <Fragment key={r.id}>
                  <tr className="align-top max-md:block max-md:p-4">
                    <td className="px-4 py-3 max-md:block max-md:px-0 max-md:py-1">
                      {r.grant?.url ? <a href={r.grant.url} target="_blank" rel="noreferrer" className="font-semibold underline decoration-line underline-offset-4 hover:decoration-ink">{r.name}</a> : <span className="font-semibold">{r.name}</span>}
                      <p className="text-xs text-muted">{r.sub}</p>
                    </td>
                    <td data-label="Deadline" className="px-4 py-3 max-md:block max-md:px-0 max-md:py-1 max-md:before:mb-0.5 max-md:before:block max-md:before:text-[11px] max-md:before:font-semibold max-md:before:tracking-wide max-md:before:text-muted max-md:before:uppercase max-md:before:content-[attr(data-label)]">{r.deadline ? showDate(r.deadline) : <span className="text-muted">Not stated</span>}</td>
                    <td data-label="Amount" className="px-4 py-3 tabular-nums max-md:block max-md:px-0 max-md:py-1 max-md:before:mb-0.5 max-md:before:block max-md:before:text-[11px] max-md:before:font-semibold max-md:before:tracking-wide max-md:before:text-muted max-md:before:uppercase max-md:before:content-[attr(data-label)]">{r.amount}</td>
                    <td data-label="Fit score" className="px-4 py-3 tabular-nums max-md:block max-md:px-0 max-md:py-1 max-md:before:mb-0.5 max-md:before:block max-md:before:text-[11px] max-md:before:font-semibold max-md:before:tracking-wide max-md:before:text-muted max-md:before:uppercase max-md:before:content-[attr(data-label)]">
                      {fitOf(r) !== null ? <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${(fitOf(r) as number) >= 80 ? 'bg-green-100 text-green-900' : (fitOf(r) as number) >= 60 ? 'bg-amber-100 text-amber-900' : 'bg-red-100 text-red-900'}`}>{fitOf(r)}/100</span> : <span className="text-xs text-muted">{r.grant ? 'Not analyzed' : 'No grant linked'}</span>}
                    </td>
                    <td data-label="Status" className="px-4 py-3 max-md:block max-md:px-0 max-md:py-1 max-md:before:mb-0.5 max-md:before:block max-md:before:text-[11px] max-md:before:font-semibold max-md:before:tracking-wide max-md:before:text-muted max-md:before:uppercase max-md:before:content-[attr(data-label)]"><span className={`rounded-full px-3 py-1 text-xs font-semibold ${r.tone}`}>{r.status}</span></td>
                    <td className="px-4 py-3 text-right max-md:block max-md:px-0 max-md:pt-3 max-md:text-left"><div className="flex flex-wrap items-center justify-end gap-x-3 gap-y-2 max-md:justify-start">
                      {r.grant && (
                        <button
                          className={`rounded-full border px-3 py-1.5 text-xs font-semibold ${fit ? 'border-accent bg-accent/10 text-accent' : 'border-accent/50 text-accent hover:border-accent hover:bg-accent/10'}`}
                          disabled={busy === 'fit-' + r.grant.id}
                          onClick={() => { if (fit) setPipeOpen(isOpen ? null : r.id); else { setPipeOpen(r.id); runFit(r.grant!) } }}
                        >
                          {busy === 'fit-' + r.grant.id ? 'Analyzing...' : fit ? `Fit ${fit.score}/100` : 'Fit analysis'}
                        </button>
                      )}
                      {r.appId ? (
                        <button className="font-semibold underline" onClick={() => { setActiveId(r.appId!); setAppOpen(true); setView('applications') }}>Open</button>
                      ) : r.grant ? (
                        <>
                          <button className="font-semibold underline" onClick={() => openDetails(r.grant!)}>Details</button>
                          {!isSaved(r.grant.id) && <button className="font-semibold underline" onClick={() => toggleSave(r.grant!)}>Save</button>}
                          <button className="font-semibold text-muted underline" onClick={() => removeGrant(r.grant!)}>Remove</button>
                          {!isInvite(r.grant) && <button className="font-semibold underline" onClick={() => startApplication(r.grant)}>{apps.some((a) => a.grant?.id === r.grant!.id) ? 'Open application' : 'Apply'}</button>}
                        </>
                      ) : null}
                      </div>
                    </td>
                  </tr>
                  {r.grant && isOpen && (
                    <tr className="bg-card max-md:block">
                      <td colSpan={6} className="px-4 py-4 max-md:block">
                        {fit ? (
                          <div className="grid gap-4 md:grid-cols-2">
                            <div>
                              <p className="font-display text-3xl font-semibold">{fit.score}/100 <span className="text-sm font-normal text-muted">fit ({fit.mode === 'ai' ? 'AI analysis' : 'keyword match'})</span></p>
                              {fit.strengths.length > 0 && <List title="Strengths" items={fit.strengths} />}
                              {fit.gaps.length > 0 && <List title="Gaps to check" items={fit.gaps} />}
                              {fit.tips.length > 0 && <List title="Next steps" items={fit.tips} />}
                              <FitBreakdown parts={fit.breakdown} />
                            </div>
                            <div>
                              {isSaved(r.grant.id) && (
                                <label className="block text-xs font-semibold">Your notes
                                  <textarea rows={3} className={`${field} mt-1 py-2 text-sm`} value={notesBy[r.grant.id] ?? ''} placeholder="Contact person, questions, partners needed..." onChange={(e) => setNotesBy({ ...notesBy, [r.grant!.id]: e.target.value })} />
                                </label>
                              )}
                              <div className="mt-3 flex flex-wrap gap-3">
                                <button className={ghost} disabled={busy === 'fit-' + r.grant.id} onClick={() => runFit(r.grant!)}>Re-run fit</button>
                                <button className="text-sm font-semibold underline" onClick={() => removeGrant(r.grant!)}>Remove</button>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <p className="text-sm text-muted">Analyzing how well this grant fits your profile...</p>
                        )}
                      </td>
                    </tr>
                  )}
                </Fragment>
              )
            })}
          </tbody>
        </table>
      </div>
      {pager('pipe-' + pipeTab, pipeRows[pipeTab].length)}
      <p className="mt-3 text-sm text-muted">Open, Upcoming cycle and Invite only cover grants from your searches and links. Invite-only means the funder mostly takes proposals by invitation, so check its page before you spend time. Under application counts applications in Drafting or In review.</p>
    </div>
  )
}
