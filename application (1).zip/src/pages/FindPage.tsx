import { FitBreakdown, GrantRow, Hint, List, MultiSelect, RenderBlocks, SortTh, field, ghost, primary } from '../components/ui'
import { IMPORT_FIELDS, buildImported, downloadTemplateCsv } from '../lib/files'
import { FILTER_COUNTRY_OPTIONS, SECTORS, TYPE_OPTIONS, US_CATS, US_ELIG, amountLabel, completeness, csv, normStatus, parseDate, quickMatch, realism, showDate } from '../lib/options'
import { toggleSort } from '../lib/text'
import { Fragment } from 'react'
import { type HomeState } from './use-home'
import { askConfirm } from '../lib/confirm'
import MenuButton from '../components/MenuButton'
import { ALL_SOURCES, SOURCE_OPTIONS } from '../lib/sources'

export function FindView(h: HomeState) {
  const {
    PageHead,
    aAll,
    aAny,
    aCats,
    aElig,
    aEu,
    aFunder,
    aInstr,
    aNot,
    aPosted,
    aSources,
    addByLink,
    aiInfo,
    importedGrants,
    setImportedGrants,
    aiAsk,
    askBusy,
    askLocked,
    setAskLocked,
    askNote,
    setAskNote,
    aiText,
    setAiText,
    aiUseProfile,
    setAiUseProfile,
    apps,
    busy,
    checkSearches,
    cmpIds,
    fAmax,
    fAmin,
    fCountry,
    fDeadline,
    fSector,
    fSource,
    fStatus,
    fText,
    fType,
    fUnknownAmt,
    fitProgress,
    fitBulkBusy,
    fitStopRef,
    fits,
    hSort,
    hideDead,
    impBusy,
    impDone,
    impHeaders,
    impMap,
    impName,
    impNote,
    impOpen,
    impRows,
    impSaveAll,
    isSaved,
    lib,
    linkBusy,
    linkGrant,
    linkNote,
    linkText,
    linkUrl,
    loadImportFile,
    modes,
    needPaste,
    notes,
    onlyDated,
    open,
    openDetails,
    openSaved,
    pageOf,
    pager,
    profile,
    q,
    refreshMatches,
    results,
    resultsAt,
    runCombined,
    runFit,
    runFitAll,
    runImport,
    runSearch,
    findSimilar,
    saved,
    searches,
    setAAll,
    setAAny,
    setACats,
    setAElig,
    setAEu,
    setAFunder,
    setAInstr,
    setANot,
    setAPosted,
    setASources,
    setFAmax,
    setFAmin,
    setFCountry,
    setFDeadline,
    setFSector,
    setFSource,
    setFStatus,
    setFText,
    setFType,
    setFUnknownAmt,
    setHSort,
    setHideDead,
    setImpMap,
    setImpName,
    setImpOpen,
    setImpRows,
    setImpSaveAll,
    setLinkText,
    setLinkUrl,
    setModes,
    setOnlyDated,
    setOpen,
    setQ,
    setSaved,
    setSearches,
    setSort,
    setSource,
    shownFinal,
    sortedFinal,
    source,
    sources,
    ssBusy,
    startApplication,
    toggleCmp,
    toggleSave,
    webNote,
  } = h
  const findBody = () => (
    <section>
            <form onSubmit={addByLink} className="mb-5 rounded-card border border-dashed border-ink/30 p-4">
              <p className="font-semibold">Found a grant somewhere else? Paste its link</p>
              <p className="mt-1 text-sm text-muted">I'll read the page, save the grant, check how well it fits your organization, and you can write the proposal for it.</p>
              <div className="mt-3 flex flex-col gap-3 md:flex-row">
                <input className={`${field} mt-0 md:flex-1`} placeholder="https://funder.org/grants/open-call" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} />
                <button className={primary} disabled={linkBusy || (!linkUrl.trim() && !linkText.trim())}>{linkBusy ? 'Reading page...' : 'Add and evaluate'}</button>
              </div>
              <details className="mt-3" open={needPaste}>
                <summary className="cursor-pointer text-sm font-semibold">Link not working? Paste the page text instead</summary>
                <textarea rows={5} className={field} value={linkText} onChange={(e) => setLinkText(e.target.value)} placeholder="Copy the grant page text and paste it here" />
              </details>
              {linkNote && <p className="mt-3 text-sm text-accent">{linkNote}</p>}
            </form>
            <div className="mb-5 rounded-card border border-dashed border-ink/30 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-semibold">Have a grants list in Excel or CSV?</p>
                  <p className="mt-1 text-sm text-muted">Import your own funding data. Columns are detected automatically and you can adjust them before importing.</p>
                </div>
                <button className={primary} onClick={() => setImpOpen(!impOpen)}>{impOpen ? 'Hide import' : 'Import from Excel or CSV'}</button>
              </div>
              {impOpen && (
                <div className="mt-4 space-y-4">
                  <div className="flex flex-wrap items-center gap-3">
                    <label className={`${ghost} cursor-pointer`}>
                      {impBusy ? 'Reading file...' : impName ? 'Choose another file' : 'Choose .xlsx or .csv file'}
                      <input type="file" className="hidden" disabled={impBusy} accept=".xlsx,.csv,.tsv,.txt,text/csv"
                        onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) loadImportFile(f) }} />
                    </label>
                    <button type="button" className="text-sm font-semibold underline" onClick={downloadTemplateCsv}>Download a template (.csv)</button>
                  </div>
                  {impRows.length > 0 && (
                    <div className="space-y-4">
                      <p className="text-sm"><span className="font-semibold">{impName}</span>: {impRows.length} row{impRows.length === 1 ? '' : 's'} found. Check how the columns match.</p>
                      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        {IMPORT_FIELDS.map(([k, t]) => (
                          <label key={k} className="text-xs font-semibold">{t}{k === 'title' ? ' (required)' : ''}
                            <select className={`${field} mt-1 py-2`} value={impMap[k] ?? -1} onChange={(e) => setImpMap({ ...impMap, [k]: Number(e.target.value) })}>
                              <option value={-1}>Not in my file</option>
                              {impHeaders.map((h, i) => <option key={i} value={i}>{h || `Column ${i + 1}`}</option>)}
                            </select>
                          </label>
                        ))}
                      </div>
                      <div className="overflow-x-auto rounded-card border border-line">
                        <table className="w-full min-w-[36rem] border-collapse text-xs">
                          <thead><tr className="bg-ink text-left text-paper"><th className="px-3 py-2">Grant name</th><th className="px-3 py-2">Funder</th><th className="px-3 py-2">Deadline</th><th className="px-3 py-2">Amount</th><th className="px-3 py-2">Status</th></tr></thead>
                          <tbody className="divide-y divide-line bg-white">
                            {buildImported(impRows.slice(0, 5), impMap).grants.map((g) => (
                              <tr key={g.id}><td className="px-3 py-2 font-semibold">{g.title}</td><td className="px-3 py-2">{g.funder}</td><td className="px-3 py-2">{showDate(g.deadline)}</td><td className="px-3 py-2">{amountLabel(g) || 'Not stated'}</td><td className="px-3 py-2 capitalize">{normStatus(g)}</td></tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={impSaveAll} onChange={(e) => setImpSaveAll(e.target.checked)} /> Also add every imported grant to my Saved grants</label>
                      <div className="flex flex-wrap gap-3">
                        <button className={primary} onClick={runImport} disabled={impMap.title === undefined || impMap.title < 0}>Import {impRows.length} grants</button>
                        <button className={ghost} onClick={() => { setImpRows([]); setImpName('') }}>Cancel</button>
                      </div>
                    </div>
                  )}
                </div>
              )}
              {impNote && <p className="mt-3 text-sm text-accent">{impNote}</p>}
              {impDone.length > 0 && (() => {
                const left = impDone.filter((g) => !saved.some((x) => x.id === g.id))
                return (
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <button className={primary} disabled={left.length === 0}
                      onClick={() => { setSaved((cur) => [...left, ...cur]); window.whop?.track?.('imported_grants_saved_all') }}>
                      {left.length === 0 ? `All ${impDone.length} imported grants saved ✓` : `Save all ${left.length} imported grant${left.length === 1 ? '' : 's'}`}
                    </button>
                    {left.length === 0 && <button className="text-sm font-semibold underline" onClick={openSaved}>View saved grants</button>}
                  </div>
                )
              })()}
            </div>
            {linkGrant && (
              <ul className="mb-5 divide-y divide-line border-y border-line">
                <GrantRow
                  g={linkGrant}
                  match={quickMatch(linkGrant, profile)}
                  saved={isSaved(linkGrant.id)}
                  onSave={() => toggleSave(linkGrant)}
                  fit={fits[linkGrant.id]}
                  compact
                  open={open === linkGrant.id}
                  loading={busy === 'fit-' + linkGrant.id}
                  onFit={() => (fits[linkGrant.id] && open !== linkGrant.id ? setOpen(linkGrant.id) : runFit(linkGrant))}
                  onDetails={() => openDetails(linkGrant)}
                  onWrite={() => { startApplication(linkGrant) }}
                />
              </ul>
            )}
            <div className="space-y-4">
              <div className="max-w-md text-sm font-semibold"><span>Search methods</span>
                <Hint>Pick one or more. Every method you select runs together and the results are merged without duplicates.</Hint>
                <MultiSelect label="Search methods" placeholder="Pick search methods" value={modes} onChange={setModes} options={[['keyword', 'Keyword search'], ['filters', 'Advanced filters'], ['ai', 'AI search'], ['web', 'Search the internet'], ['profile', 'Profile-based search'], ['imported', 'Imported-files search']]} />
              </div>
              <form onSubmit={runCombined} className="space-y-4">
                {(modes.includes('keyword') || modes.includes('web') || modes.includes('imported')) && (
                  <div className="rounded-card border border-line bg-card p-5">
                    <p className="text-sm font-semibold">{modes.includes('keyword') && modes.includes('web') ? 'Keyword search and internet search' : modes.includes('web') ? 'Internet search' : modes.includes('keyword') ? 'Keyword search' : 'Search words'}</p>
                    <Hint>Type a topic such as water, girls education or climate. Leave it empty to search by your profile focus.</Hint>
                    <div className="mt-2 flex flex-col gap-3 md:flex-row">
                      <input className={`${field} mt-0 md:flex-1`} placeholder="Search by topic, such as education, water, climate, health" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search words" />
                      {modes.includes('keyword') && (
                        <div className="text-xs font-semibold md:w-64"><MultiSelect label="Sources" placeholder="Default sources" value={source} onChange={setSource} options={SOURCE_OPTIONS} /></div>
                      )}
                    </div>
                    {modes.includes('keyword') && source.includes('irs') && <p className="mt-2 text-xs text-muted">US private foundations come from IRS exempt organization records (the same data as the IRS Tax Exempt Organization Search at apps.irs.gov/app/eos). Type a topic to use this source. The records show who the foundation is and how large it is, not what it funds, and many US foundations only fund US organizations or do not take applications. Check each one before you apply.</p>}
                    {modes.includes('web') && <p className="mt-2 text-xs text-muted">Internet search looks beyond the built-in sources for open calls on the wider web. It needs a web search key set up by the site owner.</p>}
                  </div>
                )}
                {modes.includes('filters') && (
                  <div className="space-y-5 rounded-card border border-line bg-card p-5">
                    <p className="text-sm font-semibold">Advanced filters</p>
                <div className="grid gap-4 md:grid-cols-2">
                  <label className="text-xs font-semibold">Must include all of these words<Hint>Every word has to appear in the grant title or description.</Hint>
                    <input className={`${field} mt-1 py-2`} value={aAll} onChange={(e) => setAAll(e.target.value)} placeholder="e.g. girls education" /></label>
                  <label className="text-xs font-semibold">Include at least one of<Hint>A grant is kept if it contains any of these words.</Hint>
                    <input className={`${field} mt-1 py-2`} value={aAny} onChange={(e) => setAAny(e.target.value)} placeholder="e.g. rural, refugee, women" /></label>
                  <label className="text-xs font-semibold">Exclude these words<Hint>Grants containing any of these words are removed.</Hint>
                    <input className={`${field} mt-1 py-2`} value={aNot} onChange={(e) => setANot(e.target.value)} placeholder="e.g. university, procurement" /></label>
                  <label className="text-xs font-semibold">Funder name contains<Hint>Keeps only grants whose funder name includes this text.</Hint>
                    <input className={`${field} mt-1 py-2`} value={aFunder} onChange={(e) => setAFunder(e.target.value)} placeholder="e.g. Health, European" /></label>
                </div>
                <div className="max-w-sm text-xs font-semibold"><span>Sources</span>
                  <MultiSelect label="Sources" placeholder="Pick sources" value={aSources} onChange={setASources} options={SOURCE_OPTIONS} />
                </div>
                {aSources.includes('us') && (
                  <div className="space-y-4 rounded-card border border-line bg-white p-4">
                    <p className="text-sm font-semibold">US federal filters</p>
                    <div className="text-xs font-semibold"><span>Who can apply</span>
                      <MultiSelect label="Who can apply" placeholder="Any applicant type" value={aElig} onChange={setAElig} options={US_ELIG} />
                    </div>
                    <div className="text-xs font-semibold"><span>Funding category</span>
                      <MultiSelect label="Funding category" placeholder="Any category" value={aCats} onChange={setACats} options={US_CATS} />
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="text-xs font-semibold"><span>Funding type</span>
                        <MultiSelect label="Funding type" placeholder="Any funding type" value={aInstr} onChange={setAInstr} options={[['G', 'Grant'], ['CA', 'Cooperative agreement']]} />
                      </div>
                      <label className="text-xs font-semibold">Posted within
                        <select className={`${field} mt-1 py-2`} value={aPosted} onChange={(e) => setAPosted(e.target.value)}>
                          <option value="">Any time</option><option value="7">Last week</option><option value="14">Last 2 weeks</option><option value="28">Last 4 weeks</option><option value="56">Last 8 weeks</option>
                        </select></label>
                    </div>
                  </div>
                )}
                {aSources.includes('eu') && (
                  <div className="max-w-xs text-xs font-semibold"><span>EU call status</span>
                    <MultiSelect label="EU call status" placeholder="Open and forthcoming" value={aEu} onChange={setAEu} options={[['open', 'Open'], ['forthcoming', 'Forthcoming']]} />
                  </div>
                )}
                    <div>
                      <button type="button" className={ghost} onClick={() => { setAAll(''); setAAny(''); setANot(''); setAFunder(''); setAElig([]); setACats([]); setAInstr([]); setAPosted(''); setAEu(['open', 'forthcoming']); setASources(['us', 'eu', 'directory']) }}>Clear advanced filters</button>
                    </div>
                    <p className="text-xs text-muted">Category, eligibility, funding type and posted-date filters apply to US federal grants. The word filters apply to every source.</p>
                  </div>
                )}
                {modes.includes('ai') && (
                  <div className="space-y-3 rounded-card border border-line bg-card p-5">
                    <p className="text-sm font-semibold">AI search</p>
                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <label htmlFor="ai-ask" className="text-sm font-semibold">What are you looking for?</label>
                        <MenuButton
                          className={ghost}
                          label="Write with AI"
                          busy={askBusy}
                          busyLabel="Writing..."
                          groups={[{ items: [
                            { id: 'generate', label: 'Generate from my profile', hint: aiText.trim() ? 'Replaces the text below' : undefined, disabled: !profile.org && !csv(profile.focus).length && !profile.mission && !(profile.fundingNeed ?? '').trim() },
                            { id: 'improve', label: 'Improve with AI', disabled: !aiText.trim() },
                          ] }]}
                          onPick={(id) => { if (id === 'generate') aiAsk('generate'); else aiAsk('improve') }}
                        />
                      </div>
                      <Hint>Say what you do, where, for whom and roughly how much you need. Write it yourself or let AI write or improve it. Leave it empty to use the funding description from your organization profile.</Hint>
                      {aiText.trim() && askLocked ? (
                        <>
                          <div id="ai-ask" className="mt-1 rounded-card border border-line bg-white p-4"><RenderBlocks text={aiText} /></div>
                          <div className="mt-2">
                            <MenuButton
                              className={ghost}
                              label="Edit"
                              groups={[{ items: [{ id: 'edit', label: 'Edit' }, { id: 'clear', label: 'Clear' }] }]}
                              onPick={(id) => {
                                if (id === 'edit') setAskLocked(false)
                                else askConfirm('Clear this text? You can write it again with AI.', { title: 'Clear this text?' }).then((ok) => { if (ok) { setAiText(''); setAskLocked(false); setAskNote('') } })
                              }}
                            />
                          </div>
                        </>
                      ) : (
                        <textarea
                          id="ai-ask"
                          rows={3}
                          className={field}
                          value={aiText}
                          onChange={(e) => setAiText(e.target.value)}
                          autoFocus={!!aiText.trim()}
                          onBlur={() => { if (aiText.trim()) setAskLocked(true) }}
                          placeholder="e.g. Funding for a girls' coding program in rural Kenya, around $50,000 for equipment and teacher training"
                        />
                      )}
                      {askNote && <p className="mt-2 text-sm text-accent">{askNote}</p>}
                    </div>
                    <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={aiUseProfile} onChange={(e) => setAiUseProfile(e.target.checked)} /> Use my organization profile too ({completeness(profile)}% complete)</label>
                    <p className="text-xs text-muted">AI turns your description into several targeted searches across US, EU and global sources, then merges and ranks the results. Always confirm eligibility on the funder's page.</p>
                  </div>
                )}
                {modes.includes('imported') && (
                  <div className="rounded-card border border-line bg-card p-5">
                    <p className="text-sm font-semibold">Imported-files search</p>
                    <p className="mt-1 text-xs text-muted">Searches the grants you brought in from Excel or CSV files, using the search words above. Leave the words empty to list them all. Files you import with Import from Excel or CSV are kept on this device for this search.</p>
                    <p className="mt-2 text-sm"><span className="font-semibold">{importedGrants.length}</span> imported grant{importedGrants.length === 1 ? '' : 's'} kept.{importedGrants.length === 0 && ' Import a file first, then search here.'}</p>
                    {importedGrants.length > 0 && (
                      <button type="button" className={`${ghost} mt-2`} onClick={() => askConfirm(`Remove all ${importedGrants.length} imported grants from this search? Grants you saved to your pipeline stay there.`, { title: 'Clear imported grants?' }).then((ok) => { if (ok) setImportedGrants([]) })}>Clear imported grants</button>
                    )}
                  </div>
                )}
                {modes.includes('profile') && (
                  <div className="rounded-card border border-line bg-card p-5">
                    <p className="text-sm font-semibold">Profile-based search</p>
                    <p className="mt-1 text-xs text-muted">Finds grants that match your organization profile: sectors, countries, populations, funding types, the funding description and the documents in your Library. You do not need to type anything here. Edit the description under The funding you are looking for, in the organization profile. {csv(profile.focus).length || (profile.fundingNeed ?? '').trim() ? '' : 'Pick your sectors in the organization profile first.'}</p>
                  </div>
                )}
                <div className="flex flex-wrap items-center gap-3">
                  <button className={primary} disabled={busy === 'search' || modes.length === 0}>
                    {busy === 'search' ? 'Searching...' : modes.length > 1 ? `Search with ${modes.length} methods` : 'Search'}
                  </button>
                  <button type="button" className={ghost} disabled={!(q.trim() || profile.focus.trim())} title="Save this search and be told when new grants appear" onClick={() => {
                    const kw = q.trim() || csv(profile.focus)[0] || ''
                    if (!kw) return
                    const name = window.prompt('Name this saved search', kw)
                    if (!name) return
                    setSearches((cur) => [...cur, { id: 's' + Date.now().toString(36), name: name.slice(0, 60), keyword: kw, sources: (source.length ? source : ALL_SOURCES) as string[], lastRun: 0, lastIds: [], newCount: 0 }])
                    window.whop?.track?.('search_saved')
                  }}>Save search</button>
                  <button type="button" className={ghost} disabled={busy === 'search' || busy === 'refresh'} onClick={() => refreshMatches(true)} title="Search again now for grants that match your saved organization profile">
                    {busy === 'refresh' ? 'Refreshing...' : 'Refresh now'}
                  </button>
                  <button type="button" className={ghost} disabled={!!busy || fitBulkBusy || shownFinal.length === 0} title="Score how well every grant in the results fits your organization, in one click. If you ticked grants to compare, only those are analyzed." onClick={runFitAll}>
                    {fitBulkBusy ? (fitProgress || 'Analyzing...') : 'Fit analysis for all'}
                  </button>
                  {fitBulkBusy && <button type="button" className="text-sm font-semibold underline" onClick={() => { fitStopRef.current = true }}>Stop</button>}
                  {modes.length === 0 && <span className="text-sm text-muted">Pick at least one search method.</span>}
                </div>
              </form>
              {webNote && <p className="text-sm text-accent">{webNote}</p>}
            </div>
            {aiInfo && (
              <div className="mt-4 rounded-card border border-line p-4 text-sm">
                <p className="font-semibold">{aiInfo.usedAi ? 'How the AI read your request' : 'AI search used'}</p>
                {aiInfo.note && <p className="mt-1 text-muted">{aiInfo.note}</p>}
                <div className="mt-2 flex flex-wrap gap-2">{aiInfo.queries.map((qq) => <span key={qq} className="rounded-full bg-card px-3 py-1 text-xs font-semibold">{qq}</span>)}</div>
              </div>
            )}
            {notes.map((n) => (
              <p key={n} className="mt-3 text-sm text-accent">
                {n}
              </p>
            ))}
            {results && results.length > 0 && (
              <>
              <p className="mt-4 text-xs text-muted">Narrow these results. Every dropdown lets you tick several options. Country follows each funder's stated eligibility, amounts are in USD, and grants with no stated amount are kept unless you untick the box.</p>
              <div className="mt-2 grid gap-3 rounded-card border border-line bg-card p-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="text-xs font-semibold"><span>Grant status</span>
                  <MultiSelect label="Grant status" placeholder="Any status" value={fStatus} onChange={setFStatus} options={[['open', 'Open'], ['forthcoming', 'Forthcoming'], ['rolling', 'Rolling / ongoing'], ['closed', 'Closed'], ['unknown', 'Unknown']]} />
                </div>
                <div className="text-xs font-semibold"><span>Country</span>
                  <MultiSelect label="Country" placeholder="Any country or region" value={fCountry} onChange={setFCountry} options={FILTER_COUNTRY_OPTIONS} search />
                </div>
                <div className="text-xs font-semibold"><span>Grant type</span>
                  <MultiSelect label="Grant type" placeholder="Any type" value={fType} onChange={setFType} options={TYPE_OPTIONS} />
                </div>
                <div className="text-xs font-semibold"><span>Sector</span>
                  <MultiSelect label="Sector" placeholder="Any sector" value={fSector} onChange={setFSector} options={SECTORS} />
                </div>
                <div className="text-xs font-semibold">Grant amount (USD)
                  <div className="mt-1 flex items-center gap-2">
                    <input className={`${field} mt-0 py-2`} inputMode="numeric" placeholder="Min" value={fAmin} onChange={(e) => setFAmin(e.target.value)} aria-label="Minimum amount" />
                    <input className={`${field} mt-0 py-2`} inputMode="numeric" placeholder="Max" value={fAmax} onChange={(e) => setFAmax(e.target.value)} aria-label="Maximum amount" />
                  </div>
                  <label className="mt-1 flex items-center gap-2 font-normal"><input type="checkbox" checked={fUnknownAmt} onChange={(e) => setFUnknownAmt(e.target.checked)} />Include amount not stated</label>
                </div>
                <div className="text-xs font-semibold"><span>Deadline</span>
                  <MultiSelect label="Deadline" placeholder="Any deadline" value={fDeadline} onChange={setFDeadline} options={[['30', 'Within 30 days'], ['90', 'Within 90 days'], ['180', 'Within 6 months'], ['365', 'Within a year'], ['rolling', 'Rolling or unlisted']]} />
                </div>
                <div className="text-xs font-semibold"><span>Source</span>
                  <MultiSelect label="Source" placeholder="All sources" value={fSource} onChange={setFSource} options={sources} />
                </div>
                <label className="text-xs font-semibold">Contains
                  <input className={`${field} mt-1 py-2`} value={fText} onChange={(e) => setFText(e.target.value)} placeholder="word in title" />
                </label>
                <div className="flex flex-col justify-end gap-2 text-xs font-semibold">
                  <label className="flex items-center gap-2"><input type="checkbox" checked={onlyDated} onChange={(e) => setOnlyDated(e.target.checked)} />Has a deadline</label>
                  <label className="flex items-center gap-2"><input type="checkbox" checked={hideDead} onChange={(e) => setHideDead(e.target.checked)} />Hide closed and invite-only</label>
                  <button type="button" className="text-left underline" onClick={() => { setFStatus([]); setFDeadline([]); setFSource([]); setFText(''); setSort('priority'); setOnlyDated(false); setFCountry([]); setFType([]); setFSector([]); setFAmin(''); setFAmax('') }}>Reset filters</button>
                </div>
              </div>
              </>
            )}
            {searches.length > 0 && (
              <div className="mt-4 rounded-card border border-line bg-card p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="text-sm font-semibold">Saved searches</p>
                  <button type="button" className="text-sm font-semibold text-accent underline" disabled={ssBusy} onClick={() => checkSearches()}>{ssBusy ? 'Checking...' : 'Check for new grants'}</button>
                </div>
                <ul className="mt-2 flex flex-wrap gap-2">
                  {searches.map((ss) => (
                    <li key={ss.id} className="inline-flex items-center overflow-hidden rounded-full border border-accent/50 bg-white text-sm">
                      <button type="button" className="px-3 py-1.5 font-semibold text-accent hover:bg-accent/10" title={`Run "${ss.keyword}"`} onClick={() => { setQ(ss.keyword); setSearches((cur) => cur.map((x) => (x.id === ss.id ? { ...x, newCount: 0 } : x))); runSearch(undefined, ss.keyword) }}>
                        {ss.name}{ss.newCount > 0 && <span className="ml-2 rounded-full bg-accent px-2 py-0.5 text-xs text-accent-ink">{ss.newCount} new</span>}
                      </button>
                      <button type="button" aria-label={`Delete saved search ${ss.name}`} className="px-2 py-1.5 text-muted hover:text-ink" onClick={() => setSearches((cur) => cur.filter((x) => x.id !== ss.id))}>×</button>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-xs text-muted">The portal checks these again when you open Find grants, at most every 12 hours, and counts what is new.</p>
              </div>
            )}
            {results && results.length > 0 && <p className="mt-4 text-sm text-muted">Showing {shownFinal.length} of {results.length} results, {hSort ? 'sorted by the column you chose' : 'best to apply for first'}. Click a column heading to sort.{hSort && <> <button type="button" className="underline" onClick={() => setHSort(null)}>Back to best first</button></>}</p>}
            {results && results.length > 0 && pager('find', sortedFinal.length)}
            {results && results.length === 0 && <p className="mt-5 text-muted">No grants found. Try a broader word.</p>}
            <ul className="mt-4 divide-y divide-line border-y border-line lg:hidden">
              {pageOf(sortedFinal, 'find').map((g) => (
                <GrantRow
                  key={g.id}
                  g={g}
                  match={quickMatch(g, profile)}
                  saved={isSaved(g.id)}
                  onSave={() => toggleSave(g)}
                  fit={fits[g.id]}
                  compact
                  open={open === g.id}
                  loading={busy === 'fit-' + g.id}
                  onFit={() => (fits[g.id] && open !== g.id ? setOpen(g.id) : runFit(g))}
                  onDetails={() => openDetails(g)}
                  onWrite={() => {
                    startApplication(g)
                  }}
                >
                  <label className="mt-3 inline-flex items-center gap-2 text-sm"><input type="checkbox" className="size-4" checked={cmpIds.includes(g.id)} disabled={!cmpIds.includes(g.id) && cmpIds.length >= 4} onChange={() => toggleCmp(g.id)} />Compare</label>
                </GrantRow>
              ))}
            </ul>
            {results && results.length > 0 && (
              <div className="mt-4 hidden overflow-hidden rounded-card border border-line bg-white lg:block">
                <table className="w-full table-auto border-collapse text-xs">
                  <caption className="sr-only">Grant search results</caption>
                  <thead>
                    <tr className="bg-ink text-paper">
                      <th scope="col" className="w-10 px-3 py-3 text-left text-xs font-semibold tracking-wide uppercase"><span className="sr-only">Compare</span>Cmp</th>
                      <SortTh k="title" label="Grant and funder" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} />
                      <SortTh k="type" label="Type" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} />
                      <SortTh k="status" label="Status" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} />
                      <SortTh k="deadline" label="Deadline" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} />
                      <SortTh k="award" label="Award" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} />
                      <SortTh k="match" label="Match" sort={hSort} onSort={(k) => setHSort((c) => toggleSort(c, k))} right />
                      <th scope="col" className="px-3 py-3 text-right text-xs font-semibold tracking-wide uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {sortedFinal.length === 0 && <tr><td colSpan={8} className="px-3 py-5 text-center text-muted">No results match these filters.</td></tr>}
                    {pageOf(sortedFinal, 'find').map((g) => {
                      const m = quickMatch(g, profile)
                      const f = fits[g.id]
                      const isOpenFit = open === g.id && !!f
                      const dd = parseDate(g.deadline)
                      const d = dd ? Math.ceil((dd.getTime() - Date.now()) / 864e5) : null
                      return (
                        <Fragment key={g.id}>
                          <tr className="align-top even:bg-paper/60">
                            <td className="px-3 py-3"><input type="checkbox" aria-label={`Compare ${g.title}`} className="size-4" checked={cmpIds.includes(g.id)} disabled={!cmpIds.includes(g.id) && cmpIds.length >= 4} onChange={() => toggleCmp(g.id)} /></td>
                            <td className="max-w-[22rem] px-3 py-3">
                              <p className="font-semibold"><a href={g.url} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4 hover:decoration-ink">{g.title}</a></p>
                              <p className="text-muted">{g.funder} · {g.source}</p>
                              <p className="mt-1 flex flex-wrap gap-1">{realism(g, profile, lib.docs).flags.slice(0, 4).map((x) => <span key={x.text} className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${x.tone === 'bad' ? 'bg-red-100 text-red-900' : x.tone === 'warn' ? 'bg-amber-100 text-amber-900' : 'bg-green-100 text-green-900'}`}>{x.text}</span>)}</p>
                            </td>
                            <td className="px-3 py-3">{g.gtype || <span className="text-muted">Not stated</span>}</td>
                            <td className="px-3 py-3 capitalize">{normStatus(g) === 'forthcoming' ? 'upcoming' : normStatus(g)}</td>
                            <td className="px-3 py-3">
                              <p>{showDate(g.deadline)}</p>
                              {d !== null && <p className={d < 0 ? 'text-muted' : d <= 14 ? 'font-semibold text-red-800' : d <= 45 ? 'text-amber-800' : 'text-green-800'}>{d < 0 ? 'Closed' : d === 0 ? 'Due today' : `${d} days left`}</p>}
                              <p className="text-[11px] text-muted">Checked {new Date(g.checkedAt ?? resultsAt ?? Date.now()).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</p>
                            </td>
                            <td className="px-3 py-3">{amountLabel(g) || <span className="text-muted">Not stated</span>}</td>
                            <td className="px-3 py-3 text-right tabular-nums">{(() => { const sc = f ? f.score : m.score; return <span title={f ? 'AI fit analysis, out of 100' : 'Estimate from your profile'} className={`rounded-full px-2 py-0.5 font-bold ${sc >= 65 ? 'bg-green-100 text-green-900' : sc >= 40 ? 'bg-amber-100 text-amber-900' : 'bg-card text-muted'}`}>{f ? `${f.score}/100` : `${m.score}%`}</span> })()}</td>
                            <td className="px-3 py-3 text-right">
                              <div className="flex flex-col items-end gap-1 font-semibold">
                                <button className="underline" onClick={() => openDetails(g)}>Details</button>
                                <button className="underline" title="Search for funding like this call" onClick={() => findSimilar(g)}>Find similar</button>
                                <button className="underline" onClick={() => toggleSave(g)}>{isSaved(g.id) ? 'Saved ✓' : 'Save'}</button>
                                <button className="underline" disabled={busy === 'fit-' + g.id} onClick={() => (f && open !== g.id ? setOpen(g.id) : runFit(g))}>{busy === 'fit-' + g.id ? 'Analyzing...' : f ? (isOpenFit ? 'Re-run fit' : 'Show fit') : 'Fit analysis'}</button>
                                <button className="rounded-full bg-accent px-3 py-1 text-accent-ink hover:brightness-110" onClick={() => startApplication(g)}>{apps.some((a) => a.grant?.id === g.id) ? 'Open application' : 'Start application'}</button>
                              </div>
                            </td>
                          </tr>
                          {isOpenFit && (
                            <tr className="bg-card">
                              <td colSpan={8} className="px-4 py-4">
                                <p className="font-display text-2xl font-semibold">{f.score}/100 <span className="text-sm font-normal text-muted">fit ({f.mode === 'ai' ? 'AI analysis' : 'keyword match'})</span></p>
                                {f.strengths.length > 0 && <List title="Strengths" items={f.strengths} />}
                                {f.gaps.length > 0 && <List title="Gaps to check" items={f.gaps} />}
                                {f.tips.length > 0 && <List title="Next steps" items={f.tips} />}
                                <FitBreakdown parts={f.breakdown} />
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {results && results.length > 0 && pager('find', sortedFinal.length)}
            {!results && <p className="mt-5 text-muted">Search to see open opportunities from the US, the EU and major global funders.</p>}
    </section>
  )
  return (
    <div>
      <PageHead title="Find grants" sub="Search open calls from the US, the EU and major global funders, or paste a link to any grant page. Evaluate fit, save it, then start an application." />
      {findBody()}
    </div>
  )
}
