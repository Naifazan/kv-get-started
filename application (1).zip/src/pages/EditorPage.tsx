import type { QItem } from '../lib/types'
import { type AppStatus, type Area, STATUSES, areaFilled, areaGov } from '../lib/types'
import { DiffBlocks, Fold, Gantt, Hint, List, RenderBlocks, field, ghost, label, primary } from '../components/ui'
import { budgetCheck, fmtDate, lineDiff, parseBlocks, sectionPlain, tidy } from '../lib/text'
import CopyButton, { copyText } from '../components/CopyButton'
import { askConfirm } from '../lib/confirm'
import { fileErrorText, readAnyFile } from '../lib/files'
import { ALL_COUNTRIES } from '../lib/countries'
import BudgetAids from '../components/BudgetAids'
import MenuButton from '../components/MenuButton'
import ChoiceField from '../components/ChoiceField'
import { measure, unitShort } from '../lib/limits'
import LiveEnd from '../components/LiveEnd'
import { MEAL_TOOLS, REPORT_TEMPLATES } from '../lib/project-docs'
import { Q_META, showDate } from '../lib/options'
import { type HomeState } from './use-home'

export function EditorView(h: HomeState) {
  const {
    qa,
    runTerminologyCheck,
    runLanguageCheck,
    fixAcronymsAI,
    fixTermsAI,
    fixLanguageAI,
    Badge,
    PageHead,
    aiSecs,
    live,
    liveStatus,
    flowLive,
    allProg,
    app,
    applyCards,
    applySuggestion,
    areasKey,
    areasStale,
    auditBusy,
    auditNote,
    bdBusy,
    bdFile,
    bdNote,
    bdPick,
    bdSrc,
    budgetLinesFor,
    budgetLinkWarnings,
    buildReferences,
    busy,
    cancelAi,
    complete,
    contentHash,
    daysLeft,
    doc,
    downloadExcel,
    downloadExtraExcel,
    downloadExtraWord,
    downloadFilledWorkbook,
    downloadPdf,
    downloadWord,
    editing,
    exEditing,
    exportPackage,
    factCoverage,
    facts,
    fiTab,
    fillBudgetWorkbookFrom,
    findGaps,
    fits,
    flashKey,
    frameworkCoverage,
    gapBusy,
    gapNote,
    gaps,
    gdBusy,
    gdNote,
    genProjectDoc,
    hasBudgetSection,
    helpers,
    importBudgetTemplate,
    importGuidance,
    importNeeds,
    editedSince,
    fieldIssues,
    fixOneField,
    fixAllFields,
    fixBusy,
    limitOf,
    suggestChoice,
    choiceBusy,
    generateBudgetLinesBreakdown,
    abBusy,
    importPlan,
    planBusy,
    planNote,
    removePlan,
    importExperience,
    removeExperience,
    expBusy,
    expNote,
    importTemplate,
    inputs,
    makeHelper,
    makeWordBlob,
    meta,
    modal,
    modalBusy,
    modalPanelEl,
    msg,
    needsBusy,
    needsNote,
    online,
    openEligibility,
    openFramework,
    packBusy,
    patch,
    pdBusy,
    pdNote,
    prevTitle,
    profile,
    progressOf,
    project,
    qFlow,
    qSug,
    qualityItems,
    reflectInputs,
    reviewSections,
    runTitles,
    saveOnline,
    saveStatus,
    saving,
    scanSources,
    secMsg,
    secs,
    setAllProg,
    setAppOpen,
    setAuditNote,
    setBdBusy,
    setBdFile,
    setBdNote,
    setBdPick,
    setDoc,
    setEditing,
    setExEditing,
    setFacts,
    setFiTab,
    setGaps,
    setInputs,
    setModal,
    setMsg,
    setPackBusy,
    setPdNote,
    setPrevTitle,
    setProject,
    setQSug,
    setAutoNext,
    setSecMsg,
    setShareOpen,
    setSrcRow,
    setTitleNote,
    setTitleOpts,
    setTpl,
    setTplNote,
    setTplPaste,
    setViewing,
    skipCard,
    snapshotDoc,
    srcBusy,
    srcNote,
    startFlow,
    statusTone,
    stopRef,
    suggestForItem,
    target,
    titleBusy,
    titleNote,
    titleOpts,
    tpl,
    tplBusy,
    tplNote,
    tplPaste,
    viewing,
    wc,
    writeAnswers,
  } = h
  const isChoice = (k: string) => { const t = meta(k)?.type; return !!t && t !== 'text' && t !== 'table' }
  return (
    app && (
    <div>
      <button className="mb-4 text-sm font-semibold underline" onClick={() => setAppOpen(false)}>← All applications</button>
      <PageHead
        title={app.grant?.title ?? (app.project.title || 'Untitled application')}
        sub={app.grant ? `${app.grant.funder} · ${app.grant.source} · Deadline: ${showDate(app.grant.deadline)}` : 'Not linked to a specific grant. Use the default proposal sections or import a funder template.'}
      >
        <div className="flex flex-wrap items-center gap-3">
          {app.grant && <Badge days={daysLeft(app.grant)} />}
          <select aria-label="Application status" className={`rounded-full border-0 px-4 py-2 text-sm font-semibold ${statusTone[app.status]}`} value={app.status} onChange={(e) => patch((a) => ({ ...a, status: e.target.value as AppStatus }))}>
            {STATUSES.map((st) => <option key={st}>{st}</option>)}
          </select>
          <button type="button" className={ghost} onClick={() => setShareOpen(true)}>Share{app.share ? ' (on)' : ''}</button>
        </div>
      </PageHead>
      <p className="-mt-5 mb-5 text-xs text-muted" aria-live="polite">{saveStatus}</p>
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <div className="rounded-card border border-line bg-card p-4"><p className="text-xs font-semibold tracking-wide text-muted uppercase">Progress</p><p className="mt-1 font-display text-3xl font-semibold">{progressOf(app).pct}%</p><p className="text-xs text-muted">{progressOf(app).done} of {progressOf(app).total} sections</p></div>
        <div className="rounded-card border border-line bg-card p-4"><p className="text-xs font-semibold tracking-wide text-muted uppercase">Fit with your profile</p><p className="mt-1 font-display text-3xl font-semibold">{app.grant && fits[app.grant.id] ? `${fits[app.grant.id].score}/100` : 'Not run'}</p></div>
        <div className="rounded-card border border-line bg-card p-4"><p className="text-xs font-semibold tracking-wide text-muted uppercase">Application</p><p className="mt-1 font-display text-2xl font-semibold">Last edited: {fmtDate(app.updated)}</p><p className="text-xs text-muted">Created: {fmtDate(app.created)}</p></div>
      </div>
      <Fold
        className="mb-4"
        boxClass="border-dashed border-ink/30 bg-transparent"
        title={`Funder information ${target ? `for ${target.funder}` : '(no grant selected)'}`}
        hint="The application form, the guidance and the funder's website link. The AI uses them when it writes."
        badge={`${[!!tpl, !!app?.guidance, !!(app?.grantLink ?? app?.grant?.url ?? '').trim()].filter(Boolean).length} of 3 added`}
        keepOpen={tplBusy || gdBusy || modalBusy || !!modal}
      >
                <div role="tablist" aria-label="Funder information" className="mb-3 inline-flex overflow-hidden rounded-full border border-accent/60 text-sm font-semibold">
                  {([['form', 'Application form', !!tpl], ['guidance', 'Guidance', !!app?.guidance], ['link', 'Website link', !!(app?.grantLink ?? app?.grant?.url ?? '').trim()]] as const).map(([k, t, on]) => (
                    <button key={k} type="button" role="tab" aria-selected={fiTab === k} onClick={() => setFiTab(k)} className={`px-4 py-1.5 ${fiTab === k ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{t}{on ? ' ✓' : ''}</button>
                  ))}
                </div>
              {fiTab === 'form' && (
                <div className="mt-3">
              {tpl ? (
                <p className="mt-1 text-sm text-muted">
                  Using the {tpl.name} template with {tpl.sections.length} sections.{' '}
                  <button className="underline" onClick={() => askConfirm('Go back to the default proposal sections? Your text for the funder sections stays saved.', { title: 'Use default sections?', danger: false }).then((ok) => ok && setTpl(null))}>
                    Use default sections
                  </button>
                </p>
              ) : (
                <p className="mt-1 text-sm text-muted">Import the funder's application form to turn its questions into your proposal sections, with the funder's instructions and word limits. Import the grant guidance separately so AI knows the funder's priorities, eligibility and scoring.</p>
              )}
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <label className={`${primary} cursor-pointer`} title="Word, PDF or Excel file with the funder's application form or questions">
                  {tplBusy ? 'Reading template...' : tpl ? 'Replace application template' : 'Import application template'}
                  <input type="file" className="hidden" disabled={tplBusy} accept=".pdf,.docx,.xlsx,.csv,.txt,.md,.html,.htm,.rtf,.json,text/plain,application/pdf"
                    onChange={async (e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) { try { await importTemplate(await readAnyFile(f), f.name) } catch (err) { setTplNote(fileErrorText(err)) } } }} />
                </label>
              </div>
              <div className="mt-3">
                <p className={label}>Or paste the form text</p>
                <textarea rows={5} className={field} value={tplPaste} onChange={(e) => setTplPaste(e.target.value)} placeholder="Paste the funder's questions and guidelines here" />
                <button className={`${ghost} mt-2`} disabled={tplBusy || !tplPaste.trim()} onClick={() => importTemplate(tplPaste, 'Custom template')}>Use pasted text</button>
              </div>
              {tplNote && <p className="mt-3 text-sm text-accent">{tplNote}</p>}
                </div>
              )}
              {fiTab === 'guidance' && (
                <div className="mt-3">
                  <p className="text-sm text-muted">Import the funder's call, guidelines or scoring criteria. The AI reads it and uses it when it writes, improves and reviews your sections.</p>
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                <label className={`${ghost} cursor-pointer ${gdBusy ? 'opacity-60' : ''}`} title="Word, PDF or Excel file with the funder's call, guidelines or scoring criteria. AI analyzes it.">
                  {gdBusy ? 'AI is reading the guidance...' : app?.guidance ? 'Replace grant guidance' : 'Import grant guidance'}
                  <input type="file" className="hidden" disabled={gdBusy} accept=".pdf,.docx,.xlsx,.csv,.txt,.md,.html,.htm,.rtf,.json,text/plain,application/pdf"
                    onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importGuidance(f) }} />
                </label>
                  </div>
                  {gdNote && <p className="mt-3 text-sm text-accent">{gdNote}</p>}
              {app?.guidance && (
                <details className="mt-3 rounded-card border border-line bg-white p-4">
                  <summary className="cursor-pointer text-sm font-semibold">What AI found in the grant guidance{app.guidance.funder ? `: ${app.guidance.funder}` : ''}</summary>
                  <div className="mt-2 text-right"><button type="button" className="text-sm text-muted underline" onClick={() => askConfirm('Remove the analyzed grant guidance from this application?', { title: 'Remove guidance?' }).then((ok) => ok && patch((a) => ({ ...a, guidance: null })))}>Remove</button></div>
                  {app.guidance.summary && <p className="mt-3 text-sm text-muted">{app.guidance.summary}</p>}
                  <div className="mt-3 grid gap-4 md:grid-cols-2">
                    {([['Priorities', app.guidance.priorities], ['Eligibility', app.guidance.eligibility], ['Assessment criteria', app.guidance.criteria], ['Budget rules', app.guidance.budget], ['Format and attachments', app.guidance.format], ['Key dates', app.guidance.dates]] as [string, string[]][]).filter(([, v]) => v.length).map(([t, v]) => <List key={t} title={t} items={v} />)}
                  </div>
                </details>
              )}
                </div>
              )}
              {fiTab === 'link' && (
                <div>
              <div className="mt-3">
                <p className={label}>Grant website link</p>
                <Hint>Copy the link to the funder's call or grant page. Open Analyze on the right and pick a tool. Nothing runs until you press Analyze inside it. The AI reads the guidance, the website page, or both, as you choose.</Hint>
                <div className="mt-1 flex flex-wrap items-stretch gap-2">
                  <input type="url" aria-label="Grant website link" className={`${field} mt-0 min-w-0 flex-1`} placeholder="https://funder.org/call-for-proposals" value={app?.grantLink ?? (app?.grant?.url ?? '')} onChange={(e) => patch((a) => ({ ...a, grantLink: e.target.value }))} />
                  <select
                    aria-label="Analyze"
                    className={`${modal ? primary : ghost} ml-auto cursor-pointer appearance-auto pr-2`}
                    value={modal ?? ''}
                    disabled={!(app?.grantLink ?? app?.grant?.url ?? '').trim() && !app?.guidanceText && !app?.guidance}
                    onChange={(e) => { const v = e.target.value; if (v === 'elig') openEligibility(); else if (v === 'frame') openFramework(); else setModal(null) }}
                  >
                    <option value="">Analyze</option>
                    <option value="elig" className="text-ink">AI eligibility checklist{app?.eligibility?.length ? ` (${app.eligibility.filter((x) => x.status === 'met').length}/${app.eligibility.length} met)` : ''}</option>
                    <option value="frame" className="text-ink">Grant priorities, objectives and budget ceilings{app?.framework ? ` (${Object.values(app.framework.selected).reduce((t, v) => t + (v?.length ?? 0), 0)} selected)` : ''}</option>
                  </select>
                </div>
              </div>
              {modalPanelEl}
                </div>
              )}
      </Fold>
      <section>
            <details open className="group mb-4 rounded-card border border-line bg-card p-5 [&>summary~*]:mt-4">
              <summary className="cursor-pointer list-none">
                <h3 className="font-display text-2xl font-semibold"><span aria-hidden className="mr-2 inline-block text-base text-muted transition-transform group-open:rotate-90">▸</span>Project inputs</h3>
                <p className="mt-1 text-sm text-muted">The AI builds every section from these three inputs and your profile. Specific, factual inputs give specific, credible proposals.</p>
              </summary>

              <div className="grid gap-4 md:grid-cols-3">
              <div className="md:col-span-3">
                <label className={label}>
                  Project title
                  <Hint>A short, specific name for this project. It appears at the top of the proposal. Ask the AI for suggestions, or improve it as your proposal grows.</Hint>
                  <input className={field} value={project.title} onChange={(e) => { setProject({ ...project, title: e.target.value }); setPrevTitle(null) }} />
                </label>
                <div className="mt-2 flex flex-wrap items-center gap-3">
                  <button type="button" className={ghost} disabled={!!titleBusy} onClick={() => runTitles('suggest')}>{titleBusy === 'suggest' ? 'Thinking of titles...' : 'Suggest titles'}</button>
                  <button type="button" className={ghost} disabled={!!titleBusy || !project.title.trim()} onClick={() => runTitles('improve')} title="Sharpens the title using what your proposal says now">{titleBusy === 'improve' ? 'Improving...' : 'AI improve'}</button>
                  {prevTitle !== null && <button type="button" className="text-sm font-semibold underline" onClick={() => { setProject({ ...project, title: prevTitle }); setPrevTitle(null); setTitleNote('Went back to your earlier title.') }}>Undo</button>}
                </div>
                {titleOpts.length > 0 && (
                  <ul role="listbox" aria-label="Suggested titles" className="mt-2 divide-y divide-line overflow-hidden rounded-card border border-line bg-white">
                    {titleOpts.map((t) => (
                      <li key={t}>
                        <button type="button" role="option" aria-selected={project.title === t} className="w-full px-4 py-3 text-left text-sm font-medium hover:bg-accent/10" onClick={() => { setPrevTitle(project.title); setProject({ ...project, title: t }); setTitleOpts([]); setTitleNote('Title set. You can still edit it.') }}>{t}</button>
                      </li>
                    ))}
                  </ul>
                )}
                {titleNote && <p className="mt-2 text-sm text-accent" role="status">{titleNote}</p>}
              </div>
              <label className={label}>
                Amount requested (USD)
                <Hint>The total you will ask this funder for. The budget is scaled to match it.</Hint>
                <input className={field} inputMode="numeric" value={project.amount} onChange={(e) => setProject({ ...project, amount: e.target.value })} />
              </label>
              <label className={label}>
                Duration (months)
                <Hint>How long the project runs. Activities and the timeline fit inside it.</Hint>
                <input className={field} type="number" min={1} value={project.months} onChange={(e) => setProject({ ...project, months: e.target.value })} />
              </label>
              <label className={label}>
                Direct beneficiaries (people)
                <Hint>Fix the key numbers once here. Every section and every generated document uses them exactly.</Hint>
                <input className={field} inputMode="numeric" value={facts.direct} onChange={(e) => setFacts({ direct: e.target.value })} placeholder="e.g. 800" />
              </label>
              <label className={label}>
                Indirect beneficiaries (people)
                <Hint>People who benefit through the direct ones.</Hint>
                <input className={field} inputMode="numeric" value={facts.indirect} onChange={(e) => setFacts({ indirect: e.target.value })} placeholder="e.g. 4,000" />
              </label>
              <label className={`${label} md:col-span-3`}>
                Partners and their roles
                <textarea rows={2} className={field} value={facts.partners} onChange={(e) => setFacts({ partners: e.target.value })} placeholder="e.g. County Agriculture Office (training), Kilifi Farmers Cooperative (field days)" />
              </label>
              <label className={`${label} md:col-span-3`}>
                Key targets to use everywhere (one per line)
                <textarea rows={3} className={field} value={facts.targets} onChange={(e) => setFacts({ targets: e.target.value })} placeholder={'40 farmer trainers trained\n10 demonstration plots\n12 field days'} />
              </label>
              <div className="md:col-span-3">
                {(() => {
                  const fc = factCoverage()
                  return fc.rows.length > 0 && fc.total > 0 ? (
                    <ul className="mt-3 space-y-1 text-xs text-muted" aria-label="Where the key numbers appear">
                      {fc.rows.map((r) => <li key={r.label}>{r.label} ({r.value}) appears in {r.found} of {fc.total} written sections{r.found === 0 ? '. Press the button below to reflect it.' : ''}</li>)}
                    </ul>
                  ) : null
                })()}
              </div>
            </div>

              <div>
                <p className={label}>Planned project information</p>
                <Hint>Import a Word, PDF or Excel file about the project to be written: the idea, objectives, activities, target groups, timeline, partners, expected results and budget. The AI analyzes it and follows it in every section of the proposal.</Hint>
                <div className="mt-2 flex flex-wrap items-center gap-3">
                  <label className={`${ghost} cursor-pointer`}>
                    {planBusy ? 'Analyzing...' : 'Import Word, PDF or Excel file'}
                    <input type="file" className="hidden" disabled={planBusy} accept=".docx,.pdf,.xlsx,.csv,.txt,.md,text/plain,application/pdf" onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importPlan(f) }} />
                  </label>
                </div>
                {planNote && <p className="mt-2 text-sm text-accent" role="status">{planNote}</p>}
                {(app?.planDocs ?? []).length > 0 && (
                  <ul className="mt-3 space-y-2" aria-label="Imported project information">
                    {(app?.planDocs ?? []).map((x) => (
                      <li key={x.id} className="rounded-card border border-line bg-card p-3 text-sm">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-semibold">{x.name} <span className="font-normal text-muted">({x.ai ? 'analyzed by AI' : 'used as text'})</span></span>
                          <button type="button" className="text-sm font-semibold underline" onClick={() => removePlan(x.id)}>Remove</button>
                        </div>
                        <details className="mt-1">
                          <summary className="cursor-pointer text-accent">See the project information the AI will use</summary>
                          <p className="mt-2 whitespace-pre-wrap text-muted">{x.summary}</p>
                        </details>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div>
                <p className={label}>1. Needs assessment</p>
                <Hint>Paste your findings or import the report. Include the problem, who is affected, key numbers with sources and years, root causes and what is missing today. Reviewers fund evidence, not assertions.</Hint>
                <textarea rows={7} className={field} value={inputs.needs} onChange={(e) => setInputs({ needs: e.target.value })} placeholder="e.g. A 2025 household survey of 412 families in Kilifi County found 63% walk more than 2 km for water..." />
                <div className="mt-2 flex flex-wrap items-center gap-3">
                  <label className={`${ghost} cursor-pointer`}>
                    {needsBusy ? 'Working...' : 'Import Word, PDF, Excel or text file'}
                    <input type="file" className="hidden" disabled={needsBusy} accept=".docx,.pdf,.xlsx,.csv,.txt,.md,text/plain,application/pdf" onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importNeeds(f) }} />
                  </label>
                  <span className="text-xs text-muted">{inputs.needs.length.toLocaleString('en-US')} characters. The AI reads the first 1,500 per section, so condense long reports.</span>
                </div>
                {needsNote && <p className="mt-2 text-sm text-accent">{needsNote}</p>}
              </div>

              <div>
                <p className={label}>Previous experience of your organization</p>
                <Hint>Import reports, earlier proposals, project records or results tables (Word, PDF or Excel). The AI extracts the facts and past projects and uses them when it writes every section of this proposal.</Hint>
                <div className="mt-2 flex flex-wrap items-center gap-3">
                  <label className={`${ghost} cursor-pointer`}>
                    {expBusy ? 'Analyzing...' : 'Import previous experience (Word, PDF, Excel)'}
                    <input type="file" className="hidden" disabled={expBusy} accept=".docx,.pdf,.xlsx,.csv,.txt,.md,text/plain,application/pdf" onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importExperience(f) }} />
                  </label>
                </div>
                {expNote && <p className="mt-2 text-sm text-accent" role="status">{expNote}</p>}
                {(app?.experience ?? []).length > 0 && (
                  <ul className="mt-3 space-y-2" aria-label="Imported experience documents">
                    {(app?.experience ?? []).map((x) => (
                      <li key={x.id} className="rounded-card border border-line bg-card p-3 text-sm">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-semibold">{x.name} <span className="font-normal text-muted">({x.ai ? 'analyzed by AI' : 'used as text'})</span></span>
                          <button type="button" className="text-sm font-semibold underline" onClick={() => removeExperience(x.id)}>Remove</button>
                        </div>
                        <details className="mt-1">
                          <summary className="cursor-pointer text-accent">See the facts the AI will use</summary>
                          <p className="mt-2 whitespace-pre-wrap text-muted">{x.summary}</p>
                        </details>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div>
                <p className={label}>2. Planned target areas of the project</p>
                <Hint>List each place where you will work. Pick the country, then add the governorate and the district if they apply.</Hint>
                <div className="mt-2 space-y-2">
                  {inputs.areas.map((a, i) => {
                    const upd = (v: Partial<Area>) => setInputs({ areas: inputs.areas.map((x, j) => { if (j !== i) return x; const m = { ...x, governorate: areaGov(x), district: x.district ?? '', ...v }; return { ...m, name: [m.district, m.governorate].map((t) => (t ?? '').trim()).filter(Boolean).join(', ') } }) })
                    return (
                      <div key={i} className="grid gap-2 md:grid-cols-[1.3fr_1fr_1fr_auto]">
                        <select aria-label="Country" className={`${field} mt-0 py-2`} value={a.country} onChange={(e) => upd({ country: e.target.value })}>
                          <option value="">Country</option>
                          {a.country && !ALL_COUNTRIES.includes(a.country) && <option value={a.country}>{a.country}</option>}
                          {ALL_COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
                        </select>
                        <input aria-label="Governorate or region" className={`${field} mt-0 py-2`} placeholder="Governorate (optional)" value={areaGov(a)} onChange={(e) => upd({ governorate: e.target.value })} />
                        <input aria-label="District" className={`${field} mt-0 py-2`} placeholder="District (optional)" value={a.district ?? ''} onChange={(e) => upd({ district: e.target.value })} />
                        <button type="button" className="min-h-10 rounded-full border border-accent/50 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10" onClick={() => setInputs({ areas: inputs.areas.filter((_, j) => j !== i) })}>Remove</button>
                      </div>
                    )
                  })}
                </div>
                <button type="button" className={`${ghost} mt-2`} onClick={() => setInputs({ areas: [...inputs.areas, { name: '', country: profile.country || '', governorate: '', district: '', beneficiaries: '' }] })}>Add a target area</button>
                {areasStale && (
                  <div role="status" className="mt-3 rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950">
                    <p className="font-semibold">The planned target areas changed after your proposal was written.</p>
                    <p className="mt-1">Press Save and reflect below so the places, beneficiary numbers, activities, timeline, budget and indicators in every section match the new areas.</p>
                    <div className="mt-2 flex flex-wrap items-center gap-3">
                      <button type="button" className="text-sm font-semibold underline" onClick={() => patch((a) => ({ ...a, areasSnap: areasKey }))}>Keep the proposal as it is</button>
                    </div>
                  </div>
                )}
              </div>

              <label className={label}>3. Primary information about the target areas
                <Hint>Write this yourself from what you know on the ground: local conditions, baseline data you collected, community leaders you consulted, existing services, access and security risks, local partners. The AI will not invent anything beyond what you write here.</Hint>
                <textarea rows={6} className={field} value={inputs.primary} onChange={(e) => setInputs({ primary: e.target.value })} placeholder="e.g. We held 6 community meetings in March 2026. The ward chief confirmed the borehole at Ganze has been broken since 2023..." />
              </label>
              <div className="flex flex-wrap items-center gap-3 border-t border-line pt-4">
                <button type="button" className={primary} disabled={!!busy} onClick={reflectInputs}>{allProg || 'Save and reflect'}</button>
                {allProg && <button type="button" className={ghost} onClick={() => { cancelAi(); setAllProg('') }}>Stop</button>}
                <span className="text-xs text-muted">Your inputs are saved as you type. This writes every empty field of the application with AI (yes/no, drop-down and other choice fields get a suggested answer) and updates the fields already written so they reflect your inputs.</span>
              </div>
            </details>
            <p className="mb-4 text-sm text-muted">
              Using your profile: {profile.org || 'no organization name yet'}
              {profile.country ? `, ${profile.country}` : ''}. Your mission, focus and beneficiaries are read from it automatically, so you don't re-enter them here.
            </p>
            <div className="mt-4 flex flex-wrap gap-3">
              {(allProg || busy.startsWith('ai-')) && <button type="button" className={ghost} onClick={() => { cancelAi(); setAllProg('') }}>{allProg || 'Stop'}</button>}
              <MenuButton
                className={`${ghost} cursor-pointer`}
                label="Draft"
                busy={saving}
                busyLabel="Saving..."
                groups={[{ items: [{ id: 'save', label: online?.signedIn ? 'Save draft' : 'Sign in to save draft' }, { id: 'clear', label: 'Clear draft' }] }]}
                onPick={async (v) => {
                  if (v === 'save') saveOnline()
                  else if (v === 'clear') askConfirm('Clear the whole draft?', { title: 'Clear draft?' }).then((ok) => ok && setDoc({}))
                }}
              />
              <MenuButton
                className={`${primary} cursor-pointer`}
                label="Download"
                groups={[{ items: [{ id: 'word', label: 'Word (.docx)' }, { id: 'pdf', label: 'PDF' }] }]}
                onPick={(v) => { if (v === 'word') downloadWord(); else if (v === 'pdf') downloadPdf() }}
              />
            </div>
            {msg && <p className="mt-4 text-sm text-accent">{msg}</p>}
            {frameworkCoverage && (
              <div className="mt-4 rounded-card border border-line bg-card p-4">
                <p className="text-sm font-semibold">Framework coverage in your draft: {frameworkCoverage.covered} of {frameworkCoverage.total} selected items reflected</p>
                {frameworkCoverage.missing.length > 0 ? (
                  <>
                    <p className="mt-1 text-sm text-muted">Not clearly reflected yet. Press AI write or AI improve on the matching section, or mention them yourself:</p>
                    <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{frameworkCoverage.missing.slice(0, 10).map((m) => <li key={m.text}><span className="font-semibold">{m.group}:</span> {m.text}</li>)}{frameworkCoverage.missing.length > 10 && <li className="text-muted">and {frameworkCoverage.missing.length - 10} more</li>}</ul>
                  </>
                ) : <p className="mt-1 text-sm text-muted">Every item you selected appears in the draft.</p>}
              </div>
            )}
            <div className="mt-5 rounded-card border border-line bg-white p-3 text-sm" aria-label="Project at a glance">
              <span className="font-semibold">Project at a glance</span>
              <span className="text-muted"> (change these under Project inputs)</span>
              <p className="mt-1">
                {[project.title || 'Untitled project', project.amount && `$${project.amount} USD`, project.months && `${project.months} months`, (app?.inputs?.areas ?? []).filter(areaFilled).length > 0 && `${(app?.inputs?.areas ?? []).filter(areaFilled).length} planned area${(app?.inputs?.areas ?? []).filter(areaFilled).length === 1 ? '' : 's'}`, facts.direct.trim() && `${facts.direct.trim()} direct beneficiaries`, facts.indirect.trim() && `${facts.indirect.trim()} indirect`, facts.partners.trim() && `${facts.partners.trim().split(/\n|;/).filter(Boolean).length} partner${facts.partners.trim().split(/\n|;/).filter(Boolean).length === 1 ? '' : 's'}`].filter(Boolean).join(' · ')}
              </p>
            </div>
            <div className="mt-5 space-y-5">
              {secs.map(([k, t], i) => (
                <div key={k} id={'sec-' + k} className={`scroll-mt-4 rounded-card transition-shadow ${flashKey === k ? 'ring-2 ring-accent/60 ring-offset-4 ring-offset-paper' : ''}`}>
                  {meta(k)?.group && meta(k)?.group !== (i > 0 ? meta(secs[i - 1][0])?.group : undefined) && <p className="mb-3 border-b border-accent/40 pb-1 text-sm font-semibold tracking-wide text-accent uppercase">{meta(k)?.group}</p>}
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="font-display text-2xl font-semibold">
                      <span className="mr-3 text-accent tabular-nums">{String(i + 1).padStart(2, '0')}</span>
                      {t}
                    </h3>
                    <div className="flex flex-wrap items-center justify-end gap-2">
                      {/budget/i.test(t) && (
                        <label className={`${ghost} cursor-pointer ${bdBusy === k ? 'opacity-60' : ''}`} title="Upload the funder's budget template as Excel, Word or PDF. AI prepares your budget in its structure.">
                          {bdBusy === k ? 'AI is preparing the budget...' : 'Import budget template'}
                          <input type="file" className="hidden" disabled={!!bdBusy || !!busy} accept=".xlsx,.csv,.docx,.pdf,.txt,.md,.html,.htm,.rtf,text/plain,application/pdf"
                            onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importBudgetTemplate(f, k) }} />
                        </label>
                      )}
                      {/budget/i.test(t) && <button type="button" className={ghost} disabled={abBusy || !!busy || !!bdBusy} onClick={generateBudgetLinesBreakdown} title="Downloads one Excel file: a main sheet of the budget categories and one detailed breakdown sheet for every budget line">{abBusy ? 'Preparing breakdown...' : 'Budget lines breakdown'}</button>}
                      {isChoice(k) ? (
                        <button type="button" className={ghost} disabled={!!busy || !!bdBusy || choiceBusy === k} onClick={() => suggestChoice(k, t)}>{choiceBusy === k ? 'Suggesting...' : 'AI suggest answer'}</button>
                      ) : (
                        <button className={ghost} disabled={!!busy || !!bdBusy} onClick={() => complete(k, t)}>
                          {busy === 'ai-' + k ? `Writing... ${aiSecs}s` : doc[k] ? 'AI improve' : 'AI write'}
                        </button>
                      )}
                      {!isChoice(k) && busy === 'ai-' + k && (aiSecs >= 6 || live[k] !== undefined) && <button type="button" className="text-sm font-semibold underline" onClick={cancelAi}>Stop</button>}
                    </div>
                  </div>
                  {/budget/i.test(t) && <details className="mt-3 rounded-card border border-line bg-white p-3 text-sm" open={!!(app?.lineNotes ?? '').trim() || undefined}>
                    <summary className="cursor-pointer font-semibold">How to prepare the Budget lines breakdown <span className="ml-1 text-xs font-normal text-muted">optional instructions for the AI</span></summary>
                    <p className="mt-2 text-xs text-muted">Short instructions for the AI when it breaks each budget line into components, for example the unit rates to use, the documents your donor requires, or the level of detail. The AI follows them but never changes a line's amount.</p>
                    <textarea rows={3} maxLength={800} aria-label="Instructions for the budget lines breakdown" className={`${field} mt-2`} value={app?.lineNotes ?? ''} onChange={(e) => patch((a) => ({ ...a, lineNotes: e.target.value }))} placeholder="e.g. Use government per diem rates. List three quotations for every equipment line. Show salaries by monthly rate and percentage of time." />
                    <p className="mt-1 text-xs text-muted">{(app?.lineNotes ?? '').length} of 800 characters. Applies the next time you press Budget lines breakdown.</p>
                  </details>}
                  {/budget/i.test(t) && bdNote && <p className="mt-2 text-sm text-accent">{bdNote}</p>}
                  {/budget/i.test(t) && <BudgetAids country={profile.country || ''} items={budgetLinesFor(app!.id).map((x) => x.category)} />}
                  {/budget/i.test(t) && ((bdFile || app?.budgetFile) || (doc[k] ?? '').includes('|')) && (
                    <div className="mt-2 flex flex-wrap items-center gap-3">
                      <button className={primary} onClick={() => ((bdFile || app?.budgetFile) ? downloadFilledWorkbook() : downloadExcel(doc[k]))}>Download budget (.xlsx)</button>
                      {(bdFile || app?.budgetFile) && (<span className="text-xs text-muted">Funder's workbook, {(bdFile?.sheets ?? app?.budgetFile?.sheets) ?? 1} sheet{((bdFile?.sheets ?? app?.budgetFile?.sheets) ?? 1) === 1 ? '' : 's'}, original formatting kept</span>)}
                    </div>
                  )}
                  {secMsg[k] && <p role="status" className={`mt-2 rounded-lg px-3 py-2 text-sm font-semibold ${secMsg[k].ok ? 'bg-green-100 text-green-900' : 'bg-red-100 text-red-900'}`}>{secMsg[k].text}</p>}
                  {meta(k)?.guidance && <p className="mt-1 text-sm text-muted">Funder asks: {meta(k)?.guidance}</p>}
                  {isChoice(k) && <ChoiceField id={'q-' + k} type={meta(k)!.type as 'yesno' | 'select' | 'multiselect' | 'number' | 'date'} options={meta(k)?.options ?? []} value={doc[k] ?? ''} explain={meta(k)?.explain} unit={meta(k)?.unit} required={meta(k)?.required} onChange={(v) => setDoc({ ...doc, [k]: v })} />}
                  {!isChoice(k) && live[k] !== undefined && (
                    <div className="mt-3 rounded-card border border-accent/50 bg-white p-4" role="status" aria-label={'Live writing: ' + t}>
                      <p className="mb-2 flex items-center gap-2 text-xs font-semibold tracking-wide text-accent uppercase">
                        <span aria-hidden className="inline-block h-2 w-2 animate-pulse rounded-full bg-accent" />
                        {live[k] ? `Writing live · ${wc(live[k])} words` : liveStatus || 'Thinking about the section...'}
                      </p>
                      {live[k] && <><RenderBlocks text={live[k]} /><LiveEnd /></>}
                    </div>
                  )}
                  {!isChoice(k) && doc[k] && (() => {
                    const lim = limitOf(k)
                    const used = lim ? measure(doc[k], lim.unit) : wc(doc[k])
                    const over = !!lim && used > lim.n
                    return (
                      <p className={`mt-1 text-xs ${over ? 'font-semibold text-red-800' : lim && used > lim.n * 0.95 ? 'font-semibold text-amber-800' : 'text-muted'}`} role={over ? 'alert' : undefined}>
                        {used.toLocaleString('en-US')} {lim ? unitShort(lim.unit) : 'words'}{lim ? ` of ${lim.n.toLocaleString('en-US')} allowed${over ? `. Over the limit by ${(used - lim.n).toLocaleString('en-US')}: shorten it` : ''}` : ''}
                      </p>
                    )
                  })()}
                  {isChoice(k) || live[k] !== undefined ? null : doc[k]?.trim() && !editing[k] ? (
                    <div className="mt-3 rounded-card border border-line bg-white p-4">
                      <RenderBlocks text={doc[k]} />
                      {/timeline|work ?plan|schedule/i.test(t) && <Gantt text={doc[k]} months={Number(project.months) || 12} />}
                      {/budget/i.test(t) && (budgetCheck(parseBlocks(doc[k]), project.amount) ?? []).map((w) => (
                        <p key={w} className="mt-3 text-sm font-semibold text-accent">Check: {w}</p>
                      ))}
                      {/budget/i.test(t) && budgetLinkWarnings(doc[k]).map((w) => <p key={w} className="mt-2 text-sm font-semibold text-amber-800">Check: {w}</p>)}
                      {/budget/i.test(t) && budgetLinkWarnings(doc[k]).map((w) => <p key={w} className="mt-2 text-sm font-semibold text-amber-800">Check: {w}</p>)}
                      <div className="mt-4 flex flex-wrap items-center gap-4">
                        <MenuButton
                          className={ghost}
                          label="Actions"
                          groups={[{ items: [{ id: 'copy', label: 'Copy' }, { id: 'edit', label: 'Edit' }, { id: 'clear', label: 'Clear' }] }]}
                          onPick={(id) => {
                            if (id === 'copy') {
                              copyText(sectionPlain(doc[k])).then(() => { setSecMsg((c) => ({ ...c, [k]: { text: `Copied the text of "${t}".`, ok: true } })); setTimeout(() => setSecMsg((c) => { const x = { ...c }; if (x[k]?.text.startsWith('Copied')) delete x[k]; return x }), 2500) })
                            } else if (id === 'edit') { setEditing({ ...editing, [k]: true }); setViewing({ ...viewing, [k]: false }) }
                            else askConfirm(`Clear the text of "${t}"? You can write it again with AI write.`, { title: 'Clear this section?' }).then((ok) => {
                              if (!ok) return
                              snapshotDoc(`Before clearing: ${t}`)
                              setDoc((d) => ({ ...d, [k]: '' }))
                              setEditing((c) => ({ ...c, [k]: false }))
                              setSecMsg((c) => { const x = { ...c }; delete x[k]; return x })
                            })
                          }}
                        />
                      </div>
                    </div>
                  ) : (
                    <>
                      <textarea
                        rows={6}
                        className={field}
                        value={doc[k] ?? ''}
                        placeholder="Write here, or let AI draft it. Tables use | column | format."
                        onChange={(e) => setDoc({ ...doc, [k]: e.target.value })}
                        autoFocus={!!editing[k]}
                        onFocus={() => { if (!editing[k]) setEditing((c) => ({ ...c, [k]: true })) }}
                        onBlur={() => { if ((doc[k] ?? '').trim()) setEditing((c) => ({ ...c, [k]: false })) }}
                      />
                    </>
                  )}
                </div>
              ))}
              {!hasBudgetSection && (
                <div id="sec-x_budget" className={`scroll-mt-4 rounded-card border-2 border-dashed border-accent/50 p-5 transition-shadow ${flashKey === 'x_budget' ? 'ring-2 ring-accent/60 ring-offset-4 ring-offset-paper' : ''}`}>
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="font-display text-2xl font-semibold"><span className="mr-3 text-accent tabular-nums">{String(secs.length + 1).padStart(2, '0')}</span>Budget</h3>
                    <div className="flex flex-wrap items-center gap-2">
                      <label className={`${primary} cursor-pointer ${bdBusy === 'x_budget' ? 'opacity-60' : ''}`} title="Upload the funder's budget template as Excel, Word or PDF. AI prepares your budget in its structure.">
                        {bdBusy === 'x_budget' ? 'AI is preparing the budget...' : doc['x_budget'] ? 'Replace grant budget template' : 'Import grant budget template'}
                        <input type="file" className="hidden" disabled={!!bdBusy || !!busy} accept=".xlsx,.csv,.docx,.pdf,.txt,.md,.html,.htm,.rtf,text/plain,application/pdf"
                          onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) importBudgetTemplate(f, 'x_budget') }} />
                      </label>
                      <button type="button" className={ghost} disabled={abBusy || !!busy || !!bdBusy} onClick={generateBudgetLinesBreakdown} title="Downloads one Excel file: a main sheet of the budget categories and one detailed breakdown sheet for every budget line">{abBusy ? 'Preparing breakdown...' : 'Budget lines breakdown'}</button>
                      <button type="button" className={ghost} disabled={!!busy || !!bdBusy} onClick={async () => { const had = !!(doc['x_budget'] ?? '').trim(); const ok = await complete('x_budget', 'Budget summary and justification'); if (ok && had && (bdFile || app?.budgetFile)) { setBdFile(null); patch((x) => ({ ...x, budgetFile: null })); setBdNote('The improved budget table no longer matches the filled Excel workbook, so that workbook was removed. Export the improved budget below, or import the funder\'s template again to refill it.') } }}>{busy === 'ai-x_budget' ? `Writing... ${aiSecs}s` : (doc['x_budget'] ?? '').trim() ? 'AI improve' : 'AI draft a budget without a template'}</button>
                      {(doc['x_budget'] ?? '').trim() && busy !== 'ai-x_budget' && !bdBusy && <CopyButton text={sectionPlain(doc['x_budget'])} />}
                      {((doc['x_budget'] ?? '').trim() || bdFile || app?.budgetFile) && <button type="button" className={ghost} disabled={!!busy || !!bdBusy} onClick={() => askConfirm('Clear the budget? The table and the filled Excel file are removed.', { title: 'Clear budget?' }).then((ok) => { if (!ok) return; snapshotDoc('Before clearing the budget'); setDoc((d) => { const n = { ...d }; delete n['x_budget']; return n }); setBdFile(null); patch((x) => ({ ...x, budgetFile: null })); setBdNote(''); setSecMsg((c) => { const n = { ...c }; delete n['x_budget']; return n }) })}>Clear</button>}
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-muted">The funder's application form has no budget section. Import the funder's budget template as an Excel, Word or PDF file. For an Excel file, AI fills in every sheet of the funder's workbook in place, keeping its sheets, divisions, formulas and formatting, and you export one Excel file with the same sheets. For Word or PDF, AI builds a budget table in the template's categories.</p>
                  <details className="mt-3 rounded-card border border-line bg-white p-3 text-sm" open={!!(app?.lineNotes ?? '').trim() || undefined}>
                    <summary className="cursor-pointer font-semibold">How to prepare the Budget lines breakdown <span className="ml-1 text-xs font-normal text-muted">optional instructions for the AI</span></summary>
                    <p className="mt-2 text-xs text-muted">Short instructions for the AI when it breaks each budget line into components, for example the unit rates to use, the documents your donor requires, or the level of detail. The AI follows them but never changes a line's amount.</p>
                    <textarea rows={3} maxLength={800} aria-label="Instructions for the budget lines breakdown" className={`${field} mt-2`} value={app?.lineNotes ?? ''} onChange={(e) => patch((a) => ({ ...a, lineNotes: e.target.value }))} placeholder="e.g. Use government per diem rates. List three quotations for every equipment line. Show salaries by monthly rate and percentage of time." />
                    <p className="mt-1 text-xs text-muted">{(app?.lineNotes ?? '').length} of 800 characters. Applies the next time you press Budget lines breakdown.</p>
                  </details>
                  {secMsg['x_budget'] && <p role="status" className={`mt-2 rounded-lg px-3 py-2 text-sm font-semibold ${secMsg['x_budget'].ok ? 'bg-green-100 text-green-900' : 'bg-red-100 text-red-900'}`}>{secMsg['x_budget'].text}</p>}
                  {bdNote && bdNote !== secMsg['x_budget']?.text && <p className="mt-2 text-sm text-accent">{bdNote}</p>}
                  {bdSrc && bdSrc.sheets.length > 1 && (
                    <div className="mt-3 flex flex-wrap items-end gap-3 rounded-card border border-line bg-white p-3">
                      <label className="block text-xs font-semibold">Main budget sheet of the funder's workbook
                        <select className="mt-1 block w-72 max-w-full rounded-lg border border-line bg-white px-2 py-2 text-sm font-normal" value={bdPick || bdSrc.main} onChange={(e) => setBdPick(e.target.value)}>
                          {bdSrc.sheets.map((n) => <option key={n} value={n}>{n}</option>)}
                        </select>
                      </label>
                      <button type="button" className={ghost} disabled={!!bdBusy || (bdPick || bdSrc.main) === bdSrc.main && !!bdFile} onClick={async () => { const sel = bdPick || bdSrc.main; setBdBusy('x_budget'); setBdNote(''); try { await fillBudgetWorkbookFrom(bdSrc.file, 'x_budget', sel) } catch (e) { setBdNote(fileErrorText(e)) } setBdBusy('') }}>{bdBusy === 'x_budget' ? 'Rebuilding...' : 'Rebuild with this sheet'}</button>
                      <p className="basis-full text-xs text-muted">Chosen automatically as the summary sheet. If it is the wrong one, pick another and rebuild.</p>
                    </div>
                  )}
                  <BudgetAids country={profile.country || ''} items={budgetLinesFor(app!.id).map((x) => x.category)} />
                  {doc['x_budget'] ? (
                    <div className="mt-3 rounded-card border border-line bg-white p-4">
                      <RenderBlocks text={doc['x_budget']} />
                      {(budgetCheck(parseBlocks(doc['x_budget']), project.amount) ?? []).map((w) => <p key={w} className="mt-3 text-sm font-semibold text-accent">Check: {w}</p>)}
                      {budgetLinkWarnings(doc['x_budget']).map((w) => <p key={w} className="mt-2 text-sm font-semibold text-amber-800">Check: {w}</p>)}
                    </div>
                  ) : null}
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <button className={primary} disabled={!(bdFile || app?.budgetFile) && !(doc['x_budget'] ?? '').includes('|')} onClick={() => ((bdFile || app?.budgetFile) ? downloadFilledWorkbook() : downloadExcel(doc['x_budget'], true))}>Download budget (.xlsx)</button>
                    {(bdFile || app?.budgetFile) && <span className="text-xs text-muted">The funder's workbook, {(bdFile?.sheets ?? app?.budgetFile?.sheets) ?? 1} sheet{((bdFile?.sheets ?? app?.budgetFile?.sheets) ?? 1) === 1 ? '' : 's'}, original formatting kept</span>}
                  </div>
                </div>
              )}
            </div>
      </section>
      <Fold className="relative z-30 mt-5" title="Project documents from this proposal" hint="The AI prepares each document from the sections you have written above, so the activities, indicators, targets, timeline and budget match your proposal. Write or update the proposal first, then generate." badge={Object.keys(app?.extras ?? {}).length ? `${Object.keys(app?.extras ?? {}).length} generated` : undefined} keepOpen={!!pdBusy}>
        <details className="mt-4 rounded-card border border-line bg-white p-3 text-sm" open={!!(app?.docNotes ?? '').trim() || undefined}>
          <summary className="cursor-pointer font-semibold">How to prepare these documents <span className="ml-1 text-xs font-normal text-muted">optional instructions for the AI</span></summary>
          <p className="mt-2 text-xs text-muted">Write short instructions that apply to every document you generate here, for example the level of detail, the format your donor uses, the language, or what to emphasise. The AI follows them but never contradicts your proposal.</p>
          <textarea rows={3} maxLength={800} aria-label="Instructions for preparing the project documents" className={`${field} mt-2`} value={app?.docNotes ?? ''} onChange={(e) => patch((a) => ({ ...a, docNotes: e.target.value }))} placeholder="e.g. Use USAID-style wording. Keep the indicators to 10. Add a column for gender-disaggregated data. Write the forms in simple English for enumerators." />
          <p className="mt-1 text-xs text-muted">{(app?.docNotes ?? '').length} of 800 characters. Applies to the next document you generate.</p>
        </details>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <MenuButton
            className={primary}
            label="Generate MEAL forms"
            busy={pdBusy === 'meal' || pdBusy === 'logframe' || pdBusy === 'implementation' || pdBusy === 'matrix' || pdBusy.startsWith('tool:')}
            busyLabel="Preparing..."
            groups={[
              { title: 'Plans', items: [
                { id: 'plan:meal', label: 'MEAL plan', done: !!app?.extras?.meal },
                { id: 'plan:logframe', label: 'Logical framework', done: !!app?.extras?.logframe },
                { id: 'plan:implementation', label: 'Implementation plan', done: !!app?.extras?.implementation },
                { id: 'plan:matrix', label: 'Activities Matrix', done: !!app?.extras?.matrix },
              ] },
              { title: 'Data collection tools', items: MEAL_TOOLS.map((t) => ({ id: t.id, label: t.label, done: !!app?.extras?.['tool:' + t.id] })) },
            ]}
            onPick={(v) => {
              if (v === 'plan:meal') genProjectDoc('meal', 'meal', '', 'MEAL plan')
              else if (v === 'plan:logframe') genProjectDoc('logframe', 'logframe', '', 'Logical framework')
              else if (v === 'plan:implementation') genProjectDoc('implementation', 'implementation', '', 'Implementation plan')
              else if (v === 'plan:matrix') genProjectDoc('matrix', 'matrix', '', 'Activities Matrix')
              else { const t = MEAL_TOOLS.find((x) => x.id === v); if (t) genProjectDoc('tool:' + v, 'tool', v, t.label) }
            }}
          />
          <MenuButton
            className={primary}
            label="Generate reporting templates"
            busy={pdBusy.startsWith('report:')}
            busyLabel="Preparing..."
            groups={[{ items: REPORT_TEMPLATES.map((t) => ({ id: t.id, label: t.label, done: !!app?.extras?.['report:' + t.id] })) }]}
            onPick={(id) => { const t = REPORT_TEMPLATES.find((x) => x.id === id); if (t) genProjectDoc('report:' + id, 'report', id, t.label) }}
          />
        </div>
        {pdBusy && <p className="mt-3 text-sm text-muted" role="status">The AI is preparing the document. This can take up to a minute.</p>}
        {pdNote && !pdBusy && <p className="mt-3 text-sm text-accent" role="status">{pdNote}</p>}
        {Object.entries(app?.extras ?? {}).sort((x, y) => y[1].at - x[1].at).map(([key, x]) => (
          <details key={key} className="mt-4 rounded-card border border-line bg-white p-4">
            <summary className="cursor-pointer text-sm font-semibold">{x.title} <span className="font-normal text-muted">· {fmtDate(x.at)}</span></summary>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              {(x.data || x.text.includes('|')) && <button type="button" className={x.data ? primary : ghost} onClick={() => downloadExtraExcel(key)}>Download Excel (.xlsx)</button>}
              <button type="button" className={ghost} onClick={() => downloadExtraWord(key)}>Download Word (.docx)</button>
              <button type="button" className={ghost} onClick={async () => { await navigator.clipboard.writeText(tidy(x.text)); setPdNote(`Copied the ${x.title.toLowerCase()}.`) }}>Copy text</button>
              <button type="button" className="text-sm text-muted underline" onClick={() => askConfirm(`Remove the ${x.title.toLowerCase()} from this application?`, { title: 'Remove document?' }).then((ok) => ok && patch((a) => { const e = { ...(a.extras ?? {}) }; delete e[key]; return { ...a, extras: e } }))}>Remove</button>
            </div>
            {exEditing[key] || !x.text.trim() ? (
              <textarea
                rows={14}
                className={`${field} mt-3 font-mono text-sm`}
                value={x.text}
                autoFocus={!!exEditing[key]}
                onChange={(e) => patch((a) => ({ ...a, extras: { ...(a.extras ?? {}), [key]: { ...x, text: e.target.value, at: Date.now() } } }))}
                onBlur={() => { if (x.text.trim()) setExEditing((c) => ({ ...c, [key]: false })) }}
              />
            ) : (
              <>
                <div className="mt-3"><RenderBlocks text={x.text} /></div>
<div className="mt-4"><button type="button" className={ghost} onClick={() => setExEditing((c) => ({ ...c, [key]: true }))}>Edit</button></div>
              </>
            )}
          </details>
        ))}
      </Fold>
      <Fold className="mt-5" title="Sources and references" hint="The AI finds every outside statistic in your needs assessment and written sections, and shows whether the text names a source. Fill in the missing ones, then build the references list." badge={app?.sources?.length ? `${app.sources.filter((x) => !x.sourced).length} need a source` : undefined} keepOpen={srcBusy}>
        <div className="flex flex-wrap gap-3">
            <button type="button" className={primary} disabled={srcBusy || !!busy} onClick={scanSources}>{srcBusy ? 'Scanning...' : app?.sources?.length ? 'Scan again' : 'Find statistics and sources'}</button>
            {!!app?.sources?.length && <button type="button" className={ghost} onClick={buildReferences}>{app?.extras?.references ? 'Rebuild references list' : 'Build references list'}</button>}
          </div>
        {srcNote && <p className="mt-3 text-sm text-accent" role="status">{srcNote}</p>}
        {!!app?.sources?.length && (
          <div className="mt-3 overflow-x-auto rounded-card border border-line bg-white">
            <table className="w-full min-w-[40rem] border-collapse text-sm">
              <thead><tr className="bg-card text-left text-xs tracking-wide uppercase"><th className="px-3 py-2">Statistic or fact</th><th className="px-3 py-2">Section</th><th className="px-3 py-2">Source</th><th className="px-3 py-2">Year</th><th className="px-3 py-2">Status</th></tr></thead>
              <tbody className="divide-y divide-line">
                {app.sources.map((x, i) => (
                  <tr key={i} className="align-top">
                    <td className="px-3 py-2">{x.claim}</td>
                    <td className="px-3 py-2 text-muted">{x.section}</td>
                    <td className="px-3 py-2"><input aria-label={`Source for ${x.claim}`} className="w-full rounded-lg border border-line bg-white px-2 py-1" value={x.source} onChange={(e) => setSrcRow(i, { source: e.target.value })} placeholder="Organization, survey or report" /></td>
                    <td className="px-3 py-2"><input aria-label={`Year for ${x.claim}`} className="w-20 rounded-lg border border-line bg-white px-2 py-1" inputMode="numeric" maxLength={4} value={x.year} onChange={(e) => setSrcRow(i, { year: e.target.value.replace(/\D/g, '') })} placeholder="2025" /></td>
                    <td className="px-3 py-2"><span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${x.sourced ? 'bg-green-100 text-green-900' : 'bg-amber-100 text-amber-900'}`}>{x.sourced ? 'Sourced' : 'Needs a source'}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Fold>
      <section className="mt-5 rounded-card border border-line bg-card p-4 md:p-5">
        {(() => {
          const hashNow = contentHash()
          const audit = app?.audit ?? null
          const items: QItem[] = qualityItems().map((i) => ({ ...i, ...Q_META[i.id] }))
          const verdictOf = (i: QItem) => { const v = audit?.results[i.id]; return v && v.status !== 'unknown' ? v : undefined }
          const staleCount = items.filter((i) => { const v = verdictOf(i); return !!v && v.h !== hashNow }).length
          const solvedByFix = (i: QItem) => (!!app?.fixedAt?.[i.id] && (app?.fixedAt?.[i.id] ?? 0) > (audit?.at ?? 0)) || editedSince(i)
          const isDone = (i: QItem) => { if (solvedByFix(i)) return true; const v = verdictOf(i); if (v) return v.status === 'pass' || (i.auto === null && !!app?.quality?.[i.id]); return i.auto !== null ? i.auto : !!app?.quality?.[i.id] }
          const done = items.filter(isDone).length
          const groups = [...new Set(items.map((i) => i.group))]
          const failing = items.filter((i) => i.auto === false)
          const unticked = items.filter((i) => i.auto === null && !app?.quality?.[i.id])
          const ready = app?.ready
          const readyFresh = !!ready && ready.hash === hashNow
          const markReady = () => {
            if (failing.length || unticked.length) return
            const n = (ready?.n ?? 0) + 1
            snapshotDoc(`Ready to submit, version ${n}`)
            patch((a) => ({ ...a, ready: { at: Date.now(), hash: hashNow, n } }))
          }
          const when = (t: number) => `${fmtDate(t)} at ${new Date(t).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`
          return (
            <>
              <Fold
                className="mb-4"
                title="Ready to submit"
                boxClass={readyFresh ? 'border-green-300 bg-green-50 text-green-950' : ready ? 'border-amber-300 bg-amber-50 text-amber-950' : 'border-line bg-white'}
                badge={readyFresh ? `Version ${ready!.n} ready` : ready ? `Changed since version ${ready.n}` : failing.length + unticked.length ? `${failing.length + unticked.length} to do` : 'All checks pass'}
              >
                <p className="mt-1 text-sm">
                  {readyFresh
                    ? `Marked ready on ${when(ready!.at)}. Nothing in the proposal, inputs or facts has changed since.`
                    : ready
                      ? `You marked version ${ready.n} ready on ${when(ready.at)}, but the proposal or its inputs changed afterwards. Check again and mark the new version.`
                      : 'When every check passes and every item is ticked, mark the proposal ready. The portal records the date and version, and tells you if anything changes afterwards.'}
                </p>
                {!readyFresh && (failing.length > 0 || unticked.length > 0) && (
                  <div className="mt-2 text-sm">
                    <p className="font-semibold">Before it can be marked ready:</p>
                    <ul className="mt-1 list-disc space-y-0.5 pl-5">
                      {failing.slice(0, 6).map((i) => <li key={i.id}>Fix: {i.text}{i.note ? `. ${i.note}` : ''}</li>)}
                      {unticked.slice(0, Math.max(0, 8 - Math.min(failing.length, 6))).map((i) => <li key={i.id}>Tick when done: {i.text}</li>)}
                      {failing.length + unticked.length > 8 && <li>and {failing.length + unticked.length - 8} more</li>}
                    </ul>
                  </div>
                )}
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <button type="button" className={primary} disabled={readyFresh || failing.length > 0 || unticked.length > 0} onClick={markReady}>{readyFresh ? 'Marked ready' : ready ? 'Mark this version ready' : 'Run the final checks and mark ready'}</button>
                  <button type="button" className={ghost} disabled={packBusy} onClick={async () => { setPackBusy(true); try { await exportPackage() } catch { setMsg('Could not create the package. Please try again.') } setPackBusy(false) }}>{packBusy ? 'Creating package...' : 'Download submission package (.zip)'}</button>
                  {ready && <button type="button" className="text-sm font-semibold underline" onClick={() => patch((a) => ({ ...a, ready: undefined }))}>Remove the ready mark</button>}
                </div>
              </Fold>
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <h2 className="font-display text-2xl font-semibold">Proposal quality checklist</h2>
                  <p className="mt-1 text-sm text-muted">The portal checks what it can and marks it. Tick the rest yourself as you complete it.</p>
                </div>
                <p className="font-display text-2xl font-semibold tabular-nums">{done} of {items.length}</p>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={done} aria-valuemin={0} aria-valuemax={items.length}><div className="h-full rounded-full bg-accent transition-all" style={{ width: `${Math.round((done / items.length) * 100)}%` }} /></div>
              <div id="quality-flow" className="mt-4 rounded-card border-2 border-accent/40 bg-white p-4">
                <p className="font-display text-xl font-semibold">Review and improve my proposal</p>
                <p className="mt-1 text-sm text-muted">One press does it all automatically: the AI checks the proposal, rewrites each section that needs work to fix its findings, applies the fixes, and checks again, for up to 3 rounds. A copy of your earlier draft is saved in History, so you can restore it. Facts the AI does not have are left as [bracketed placeholders] for you to fill.</p>
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <button type="button" className={primary} disabled={qFlow.phase === 'checking' || qFlow.phase === 'drafting' || auditBusy || !!busy} onClick={() => startFlow()}>{qFlow.phase === 'checking' ? 'Checking...' : qFlow.phase === 'drafting' ? 'Improving...' : qFlow.phase === 'done' ? 'Review and improve again' : 'Review and improve my proposal'}</button>
                  {(qFlow.phase === 'checking' || qFlow.phase === 'drafting') && <button type="button" className={ghost} onClick={() => { stopRef.current = true; setAutoNext(0) }}>Stop</button>}
                  {qFlow.before !== null && <span className="font-display text-lg font-semibold tabular-nums">Score: {qFlow.before}{qFlow.before !== done ? ` to ${done}` : ''} of {items.length}{done > qFlow.before ? <span className="ml-2 text-sm font-semibold text-green-800">+{done - qFlow.before} solved</span> : null}</span>}
                </div>
                {qFlow.before !== null && (
                  <div className="mt-3" aria-label="Proposal score">
                    <div className="h-2.5 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={done} aria-valuemin={0} aria-valuemax={items.length}><div className="h-full rounded-full bg-green-600 transition-all duration-700" style={{ width: `${Math.round((done / Math.max(1, items.length)) * 100)}%` }} /></div>
                    <p className="mt-1 text-xs text-muted">{Math.round((done / Math.max(1, items.length)) * 100)}% of the checklist is met. The score rises as each issue is solved.</p>
                  </div>
                )}
                {qFlow.prog && <p className="mt-2 text-sm text-muted" role="status">{qFlow.prog}</p>}
                {flowLive && (
                  <div className="mt-2 rounded-card border border-accent/50 bg-white p-4" role="status" aria-label="Live writing">
                    <p className="mb-2 flex items-center gap-2 text-xs font-semibold tracking-wide text-accent uppercase"><span aria-hidden className="inline-block h-2 w-2 animate-pulse rounded-full bg-accent" />Writing live · {wc(flowLive)} words</p>
                    <RenderBlocks text={flowLive} /><LiveEnd />
                  </div>
                )}
                {qFlow.note && <p className="mt-2 text-sm text-accent" role="status">{qFlow.note}</p>}
                {(qFlow.phase === 'review' || qFlow.phase === 'done') && qFlow.cards.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {qFlow.cards.filter((c) => c.status === 'pending' && c.newText).length > 1 && (
                      <button type="button" className={primary} onClick={() => askConfirm(`Apply the drafted changes to ${qFlow.cards.filter((c) => c.status === 'pending' && c.newText).length} sections? A copy of your draft is saved first.`, { title: 'Apply all changes?', yes: 'Yes, apply all', danger: false }).then((ok) => ok && applyCards(qFlow.cards))}>Apply all changes</button>
                    )}
                    {qFlow.cards.map((c) => {
                      const d = lineDiff(c.oldText, c.newText)
                      const added = d.lines.filter((l) => l.add).length
                      return (
                        <div key={c.key} className={`rounded-card border p-3 ${c.status === 'applied' ? 'border-green-300 bg-green-50' : c.status === 'skipped' ? 'border-line bg-card opacity-70' : 'border-line bg-paper'}`}>
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="font-semibold">{c.title} <span className="text-xs font-normal text-muted">{c.kind === 'answers' ? 'from your answers' : `${c.notes.length} finding${c.notes.length === 1 ? '' : 's'}`}</span></p>
                            {c.status === 'applied' ? <span className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-semibold text-green-900">Applied</span> : c.status === 'skipped' ? <span className="text-xs font-semibold text-muted">Skipped</span> : (
                              <span className="flex flex-wrap gap-2">
                                <button type="button" className={`${primary} !min-h-9 !px-4 !text-xs`} disabled={!c.newText} onClick={() => applyCards([c])}>Apply</button>
                                <button type="button" className={`${ghost} !min-h-9 !px-4 !text-xs`} onClick={() => skipCard(c.key)}>Skip</button>
                              </span>
                            )}
                          </div>
                          <ul className="mt-1 list-disc space-y-0.5 pl-5 text-xs text-muted">{c.notes.map((n) => <li key={n}>{n}</li>)}</ul>
                          {c.err && <p className="mt-2 text-xs font-semibold text-red-800">{c.err}</p>}
                          {c.newText && (
                            <details className="mt-2">
                              <summary className="cursor-pointer text-xs font-semibold text-accent">View the changes ({added} new or changed line{added === 1 ? '' : 's'}{d.removed.length ? `, ${d.removed.length} removed` : ''})</summary>
                              <div className="mt-2 max-h-80 overflow-auto rounded-lg border border-line bg-white p-2 text-xs"><DiffBlocks oldText={c.oldText} newText={c.newText} /></div>
                            </details>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                {allProg && <button type="button" className={ghost} onClick={() => { cancelAi(); setAllProg('') }}>Stop</button>}
                <span className="text-xs text-muted">
                  {audit ? `AI check on ${when(audit.at)}: ${items.filter((i) => verdictOf(i)?.status === 'pass').length} passed, ${items.filter((i) => ['partial', 'fail'].includes(verdictOf(i)?.status ?? '')).length} need work.${staleCount ? ` ${staleCount} result${staleCount === 1 ? ' is' : 's are'} from earlier text, so check again when you are done.` : ''}` : 'The AI reads your proposal and judges the content items strictly, with the evidence and a fix for each.'}
                </span>
              </div>
              {auditNote && <p className="mt-2 text-sm text-accent" role="status">{auditNote}</p>}
              <details className="mt-3 rounded-card border border-line bg-white p-3" open={gaps.length > 0 || undefined}>
                <summary className="cursor-pointer text-sm font-semibold">Fill the gaps <span className="ml-2 text-xs font-normal text-muted">answer a few questions and the AI writes your answers into the proposal</span></summary>
                <div className="mt-3">
                  <button type="button" className={primary} disabled={gapBusy || !!busy || auditBusy} onClick={findGaps}>{gapBusy && !gaps.length ? 'Finding the gaps...' : gaps.length ? 'Ask again' : 'Find the gaps'}</button>
                  {gapNote && <p className="mt-2 text-sm text-accent" role="status">{gapNote}</p>}
                  {gaps.length > 0 && (
                    <div className="mt-3 space-y-3">
                      {gaps.map((g, n) => (
                        <label key={n} className="block text-sm font-semibold">
                          {g.question}
                          <span className="ml-2 text-xs font-normal text-muted">{g.section || 'general'}</span>
                          <input className={field} value={g.answer} onChange={(e) => setGaps((c) => c.map((x, j) => (j === n ? { ...x, answer: e.target.value } : x)))} placeholder="Your answer" />
                        </label>
                      ))}
                      <button type="button" className={primary} disabled={gapBusy || !!busy || !gaps.some((g) => g.answer.trim() && g.section)} onClick={writeAnswers}>{gapBusy ? 'Writing...' : 'Write my answers into the proposal'}</button>
                    </div>
                  )}
                </div>
              </details>
              <details className="mt-3 rounded-card border border-line bg-white p-3">
                <summary className="cursor-pointer text-sm font-semibold">Only you can do these <span className="ml-2 text-xs font-normal text-muted">{items.filter((i) => i.auto === null && !i.ai && !isDone(i)).length} left</span></summary>
                <ul className="mt-2 divide-y divide-line">
                  {items.filter((i) => i.auto === null && !i.ai).map((i) => {
                    const kind = ({ b4: 'mou', b5: 'letter', k6: 'signoff', j2: 'reader' } as Record<string, string>)[i.id]
                    const h = kind ? helpers[kind] : undefined
                    return (
                      <li key={i.id} className="py-2 text-sm">
                        <label className="flex items-start gap-3">
                          <input type="checkbox" className="mt-1 size-4 shrink-0" checked={!!app?.quality?.[i.id]} onChange={(e) => patch((a) => ({ ...a, quality: { ...(a.quality ?? {}), [i.id]: e.target.checked } }))} />
                          <span className={app?.quality?.[i.id] ? 'text-muted line-through' : ''}>{i.text}{i.note && !app?.quality?.[i.id] ? <span className="block text-xs text-amber-800">{i.note}</span> : null}</span>
                        </label>
                        {kind && (
                          <div className="mt-1 pl-7">
                            <button type="button" className="text-xs font-semibold text-accent underline" disabled={h?.busy} onClick={() => makeHelper(kind)}>{h?.busy ? 'AI is writing...' : h?.text ? 'Write it again' : kind === 'mou' ? 'Draft a partnership agreement outline' : kind === 'letter' ? 'Draft a letter of support' : kind === 'signoff' ? 'Draft the sign-off request' : 'Draft the request to an outside reader'}</button>
                            {h?.err && <span className="ml-2 text-xs font-semibold text-red-800">{h.err}</span>}
                            {h?.text && (
                              <div className="mt-2 rounded-card border border-line bg-card p-3">
                                <p className="max-h-60 overflow-y-auto text-xs whitespace-pre-wrap">{h.text}</p>
                                <p className="mt-2 flex flex-wrap gap-3 text-xs font-semibold">
                                  <button type="button" className="text-accent underline" onClick={async () => { await navigator.clipboard.writeText(h.text!); setAuditNote('Copied.') }}>Copy</button>
                                  <button type="button" className="text-accent underline" onClick={async () => { const blob = await makeWordBlob({ title: i.text, sections: [['', h.text!]] }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${kind}-draft.docx`; a.click() }}>Download Word (.docx)</button>
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </li>
                    )
                  })}
                </ul>
              </details>
              <details className="mt-3 rounded-card border border-line bg-white p-3">
                <summary className="cursor-pointer text-sm font-semibold">Terminology and acronyms <span className="ml-2 text-xs font-normal text-muted">{qa.acr ? `${qa.acr.filter((x) => !x.defined).length} not defined, ${qa.terms?.length ?? 0} inconsistent terms` : 'check that every acronym is defined and every idea has one name'}</span></summary>
                <div className="mt-3">
                  <button type="button" className={primary} disabled={qa.busy === 'terms' || !!busy} onClick={runTerminologyCheck}>{qa.busy === 'terms' ? 'Checking the terms...' : qa.acr ? 'Check again' : 'Check terminology and acronyms'}</button>
                  {qa.note && <p className="mt-2 text-sm text-accent" role="status">{qa.note}</p>}
                  {qa.acr && (
                    <div className="mt-3">
                      <p className="text-sm font-semibold">Acronyms ({qa.acr.length})</p>
                      {qa.acr.length === 0 ? <p className="mt-1 text-sm text-muted">No acronyms found that need a definition.</p> : (
                        <ul className="mt-1 divide-y divide-line rounded-card border border-line text-sm">
                          {qa.acr.map((x) => (
                            <li key={x.acr} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
                              <span><span className="font-semibold">{x.acr}</span> <span className="text-xs text-muted">used {x.count} time{x.count === 1 ? '' : 's'}, first in {x.section}</span></span>
                              <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${x.defined ? (x.redefined ? 'bg-amber-100 text-amber-900' : 'bg-green-100 text-green-900') : 'bg-red-100 text-red-900'}`}>{x.defined ? (x.redefined ? 'Defined more than once' : 'Defined') : 'Not defined at first use'}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                      {qa.acr.some((x) => !x.defined) && <button type="button" className={`${primary} mt-2`} disabled={!!busy} onClick={fixAcronymsAI}>Define them with AI</button>}
                    </div>
                  )}
                  {qa.terms && (
                    <div className="mt-4">
                      <p className="text-sm font-semibold">Ideas with more than one name ({qa.terms.length})</p>
                      {qa.terms.length === 0 ? <p className="mt-1 text-sm text-muted">The terms look consistent.</p> : (
                        <ul className="mt-1 divide-y divide-line rounded-card border border-line text-sm">
                          {qa.terms.map((g) => <li key={g.preferred} className="px-3 py-2"><span className="font-semibold">Use &quot;{g.preferred}&quot;</span> instead of {g.variants.map((v) => `"${v}"`).join(', ')}<span className="block text-xs text-muted">{g.why}</span></li>)}
                        </ul>
                      )}
                      {qa.terms.length > 0 && <button type="button" className={`${primary} mt-2`} disabled={!!busy} onClick={fixTermsAI}>Make the terms consistent with AI</button>}
                    </div>
                  )}
                </div>
              </details>
              <details className="mt-3 rounded-card border border-line bg-white p-3">
                <summary className="cursor-pointer text-sm font-semibold">Language pass <span className="ml-2 text-xs font-normal text-muted">{qa.lang ? `${qa.lang.sections.filter((x) => x.flags.length).length} of ${qa.lang.sections.length} sections to improve` : 'readability, passive voice, filler, jargon and spelling'}</span></summary>
                <div className="mt-3">
                  <button type="button" className={primary} disabled={!!busy} onClick={runLanguageCheck}>{qa.lang ? 'Check again' : 'Check the language'}</button>
                  {qa.lang && (
                    <div className="mt-3">
                      <p className="text-sm">
                        <span className="font-semibold">Spelling:</span> {qa.lang.spelling.dominant === 'none' ? 'no spelling differences found.' : qa.lang.spelling.mixed ? `mixed. Mostly ${qa.lang.spelling.dominant === 'US' ? 'American' : 'British'}, with ${qa.lang.spelling.dominant === 'US' ? 'British' : 'American'} forms in ${qa.lang.spelling.minority.map((m) => `${m.title} (${m.found.join(', ')})`).join('; ')}.` : `consistently ${qa.lang.spelling.dominant === 'US' ? 'American' : 'British'}.`}
                      </p>
                      <div className="mt-2 overflow-x-auto rounded-card border border-line">
                        <table className="w-full min-w-[34rem] border-collapse text-xs">
                          <thead><tr className="bg-card text-left uppercase"><th className="px-2 py-2">Section</th><th className="px-2 py-2 text-right">Words</th><th className="px-2 py-2 text-right">Avg sentence</th><th className="px-2 py-2 text-right">Passive</th><th className="px-2 py-2 text-right">Grade</th><th className="px-2 py-2">To improve</th></tr></thead>
                          <tbody className="divide-y divide-line">
                            {qa.lang.sections.map((x) => (
                              <tr key={x.key} className="align-top">
                                <td className="px-2 py-2 font-semibold">{x.title}</td>
                                <td className="px-2 py-2 text-right tabular-nums">{x.words}</td>
                                <td className="px-2 py-2 text-right tabular-nums">{x.avgLen} words</td>
                                <td className="px-2 py-2 text-right tabular-nums">{x.passivePct}%</td>
                                <td className="px-2 py-2 text-right tabular-nums">{x.grade}</td>
                                <td className="px-2 py-2">{x.flags.length ? x.flags.join('. ') : <span className="font-semibold text-green-800">Clear</span>}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p className="mt-1 text-xs text-muted">Aim for sentences of about 15 to 22 words, mostly active voice, and a reading grade of 12 or below for a technical proposal.</p>
                      {(qa.lang.sections.some((x) => x.flags.length) || qa.lang.spelling.mixed) && <button type="button" className={`${primary} mt-2`} disabled={!!busy} onClick={fixLanguageAI}>Improve the language with AI</button>}
                    </div>
                  )}
                </div>
              </details>
              {groups.map((gname) => {
                const gi = items.filter((i) => i.group === gname)
                const gd = gi.filter(isDone).length
                return (
                  <details key={gname} className="mt-3 rounded-card border border-line bg-white p-3" open={gd < gi.length && (gname.startsWith('A') || gname.startsWith('C'))}>
                    <summary className="cursor-pointer text-sm font-semibold">{gname} <span className={`ml-2 rounded-full px-2 py-0.5 text-xs ${gd === gi.length ? 'bg-green-100 text-green-900' : 'bg-card text-muted'}`}>{gd}/{gi.length}</span></summary>
                    {gname.startsWith('C') && (() => {
                      const rows = secs.map(([k, t]) => ({ k, t, n: fieldIssues(k, t).notes })).filter((x) => x.n.length)
                      return (
                        <div className="mt-2 rounded-card border border-accent/40 bg-card p-3" id="fix-by-field">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <p className="text-sm font-semibold">Fix by field <span className="ml-1 text-xs font-normal text-muted">one click fixes every issue found in that field, from all the checks</span></p>
                            <button type="button" className={`${primary} !min-h-9 !px-4 !text-xs`} disabled={!!fixBusy || !!busy || auditBusy} onClick={fixAllFields}>{fixBusy === 'all' ? (allProg || 'Fixing...') : 'Fix all fields'}</button>
                          </div>
                          {rows.length === 0 ? <p className="mt-2 text-xs text-muted">No open issues in the written fields. Run the AI check, the language check and the terminology check to look again.</p> : (
                            <ul className="mt-2 divide-y divide-line">
                              {rows.map((x) => (
                                <li key={x.k} className="flex flex-wrap items-start justify-between gap-2 py-2 text-sm">
                                  <span className="min-w-0 flex-1"><span className="font-semibold">{x.t}</span> <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-semibold text-amber-900">{x.n.length} issue{x.n.length === 1 ? '' : 's'}</span>
                                    <details className="mt-1"><summary className="cursor-pointer text-xs text-accent">See the issues</summary><ul className="mt-1 list-disc space-y-0.5 pl-5 text-xs text-muted">{x.n.map((n) => <li key={n}>{n}</li>)}</ul></details>
                                  </span>
                                  <button type="button" className={`${ghost} !min-h-9 !px-4 !text-xs`} disabled={!!fixBusy || !!busy || auditBusy} onClick={() => fixOneField(x.k, x.t)}>{fixBusy === x.k ? 'Fixing...' : 'Fix all issues'}</button>
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )
                    })()}
                    <ul className="mt-2 divide-y divide-line">
                      {gi.flatMap((x, n) => (x.sub && x.sub !== gi[n - 1]?.sub ? [{ head: x.sub } as { head: string } | QItem, x] : [x])).map((row) => {
                        if ('head' in row) return <li key={'h-' + row.head} className="pt-3 pb-1 text-xs font-semibold tracking-wide text-accent uppercase">{row.head}</li>
                        const i = row as QItem
                        const fixed = solvedByFix(i)
                        const v = fixed ? undefined : verdictOf(i)
                        const tone = v ? (v.status === 'pass' ? 'bg-green-600' : v.status === 'partial' ? 'bg-amber-500' : 'bg-red-600') : i.auto ? 'bg-green-600' : 'bg-amber-500'
                        const mark = v ? (v.status === 'pass' ? '✓' : v.status === 'partial' ? '~' : '✕') : i.auto ? '✓' : '!'
                        const target = i.sec ? secs.find(([, t]) => i.sec!.test(t)) : undefined
                        return (
                          <li key={i.id} className="flex items-start gap-3 py-2 text-sm">
                            {fixed ? (
                              <span aria-hidden className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-green-600 text-xs font-bold text-white">✓</span>
                            ) : i.auto === null ? (
                              <input type="checkbox" className="mt-1 size-4 shrink-0" checked={isDone(i)} disabled={v?.status === 'pass'} onChange={(e) => patch((a) => ({ ...a, quality: { ...(a.quality ?? {}), [i.id]: e.target.checked } }))} aria-label={i.text} />
                            ) : (
                              <span aria-hidden className={`mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white ${tone}`}>{mark}</span>
                            )}
                            <span className="min-w-0">
                              {i.text}
                              {fixed && <span className="ml-2 rounded-full bg-green-100 px-2 py-0.5 text-[11px] font-semibold text-green-900">Edited or fixed. The AI is checking it again</span>}
                              {v ? <span className={`ml-2 rounded-full px-2 py-0.5 text-[11px] font-semibold ${v.status === 'pass' ? 'bg-green-100 text-green-900' : v.status === 'partial' ? 'bg-amber-100 text-amber-900' : 'bg-red-100 text-red-900'}`}>AI: {v.status === 'pass' ? 'Pass' : v.status === 'partial' ? 'Partly' : 'Not met'}{v.h !== hashNow ? ' (earlier text)' : ''}</span> : i.auto !== null && <span className="ml-2 rounded-full bg-card px-2 py-0.5 text-[11px] font-semibold text-muted">Checked by the portal</span>}
                              {v?.evidence && <span className="block text-xs text-muted">Evidence: {v.evidence}</span>}
                              {v && v.status !== 'pass' && v.fix && <span className="block text-xs text-amber-800">To fix: {v.fix}</span>}
                              {v && v.status !== 'pass' && v.fix && (
                                <span className="mt-1 flex flex-wrap items-center gap-3">
                                  <button type="button" className="text-xs font-semibold text-accent underline" disabled={!!busy || qSug[i.id]?.busy} onClick={() => suggestForItem(i, v)}>{qSug[i.id]?.busy ? 'AI is writing a suggestion...' : 'Suggest an improvement'}</button>
                                  {target && <button type="button" className="text-xs font-semibold text-accent underline" disabled={!!busy} onClick={async () => { const ok = await complete(target[0], target[1], `Fix this problem found by the proposal review: ${v.fix} Keep everything that is correct, and keep the structure and format (tables stay tables).`); if (ok) patch((a) => ({ ...a, fixedAt: { ...(a.fixedAt ?? {}), [i.id]: Date.now() } })) }}>Rewrite "{target[1]}" now</button>}
                                </span>
                              )}
                              {qSug[i.id]?.err && !fixed && v?.status !== 'pass' && <span className="block text-xs font-semibold text-red-800">{qSug[i.id].err}</span>}
                              {qSug[i.id]?.data && !fixed && v?.status !== 'pass' && (
                                <span className="mt-2 block rounded-card border border-accent/40 bg-card p-3 text-xs">
                                  <span className="block font-semibold">AI suggestion: {qSug[i.id].data!.mode === 'replace' ? 'rewrite' : 'add to'} <select aria-label="Section to change" className="rounded border border-line bg-white px-1 py-0.5 font-semibold" value={qSug[i.id].sec ?? ''} onChange={(e) => setQSug((c) => ({ ...c, [i.id]: { ...c[i.id], sec: e.target.value } }))}><option value="">Choose a section</option>{reviewSections().map((x) => <option key={x.key} value={x.title}>{x.title}</option>)}</select></span>
                                  {qSug[i.id].data!.rationale && <span className="mt-1 block text-muted">{qSug[i.id].data!.rationale}</span>}
                                  {qSug[i.id].data!.steps.length > 0 && <span className="mt-1 block">{qSug[i.id].data!.steps.map((st) => <span key={st} className="block">- {st}</span>)}</span>}
                                  {qSug[i.id].data!.text && <span className="mt-2 block max-h-64 overflow-auto rounded-lg bg-white p-2"><RenderBlocks text={tidy(qSug[i.id].data!.text)} /></span>}
                                  <span className="mt-2 flex flex-wrap gap-3">
                                    {qSug[i.id].data!.text && <button type="button" className={`${primary} !min-h-9 !px-4 !text-xs`} disabled={!qSug[i.id].sec} onClick={() => applySuggestion(i.id)}>Apply to the section</button>}
                                    <button type="button" className="font-semibold underline" onClick={() => setQSug((c) => ({ ...c, [i.id]: {} }))}>Discard</button>
                                  </span>
                                </span>
                              )}
                              {!v && !isDone(i) && i.note && <span className="block text-xs text-amber-800">{i.note}</span>}
                              {!v && i.auto === null && i.note && !app?.quality?.[i.id] && <span className="block text-xs text-muted">{i.note}</span>}
                            </span>
                          </li>
                        )
                      })}
                    </ul>
                  </details>
                )
              })}
            </>
          )
        })()}
      </section>
    </div>
  )
  )
}
