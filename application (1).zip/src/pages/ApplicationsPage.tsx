import { type AppStatus, STATUSES } from '../lib/types'
import { SortTh } from '../components/ui'
import { fmtDate, toggleSort } from '../lib/text'
import { askConfirm } from '../lib/confirm'
import { type HomeState } from './use-home'

export function ApplicationsView(h: HomeState) {
  const {
    Badge,
    PageHead,
    aSort,
    aStatus,
    aView,
    apps,
    daysLeft,
    dragId,
    filteredApps,
    moveApp,
    pageOf,
    pager,
    progressOf,
    setASort,
    setAStatus,
    setAView,
    setActiveId,
    setAppOpen,
    deleteApplication,
    setApps,
    setDragId,
    sortedApps,
    statusTone,
  } = h
  return (
    <div>
      <PageHead title="Applications" sub="Every proposal you are writing or have sent, with its status, progress and deadline." />
      {apps.length === 0 ? (
        <div className="rounded-card border border-dashed border-ink/30 p-8">
          <p className="font-semibold">No applications yet</p>
          <p className="mt-1 text-muted">Start one from Find grants or the Grants pipeline with Start application. Then import the funder's guidance inside the application.</p>
        </div>
      ) : (
        <>
          <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-5">
            {STATUSES.map((st) => {
              const n = apps.filter((a) => a.status === st).length
              const on = aStatus === st
              return (
                <button key={st} type="button" aria-pressed={on} onClick={() => setAStatus(on ? null : st)}
                  className={`rounded-card border p-4 text-left transition ${on ? 'border-accent bg-accent text-accent-ink' : 'border-line bg-card hover:border-accent/60'}`}>
                  <p className={`text-xs font-semibold tracking-wide uppercase ${on ? 'text-accent-ink/85' : 'text-muted'}`}>{st}</p>
                  <p className="mt-1 font-display text-3xl font-semibold tabular-nums">{n}</p>
                  <p className={`mt-1 text-xs ${on ? 'text-accent-ink/85' : 'text-muted'}`}>{on ? 'Showing. Click to clear' : n ? 'Click to filter' : 'None yet'}</p>
                </button>
              )
            })}
          </div>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <div role="group" aria-label="View" className="inline-flex overflow-hidden rounded-full border border-accent/60 text-sm font-semibold">
              {(['list', 'board'] as const).map((v) => <button key={v} type="button" aria-pressed={aView === v} onClick={() => setAView(v)} className={`px-4 py-1.5 capitalize ${aView === v ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{v}</button>)}
            </div>
            {aView === 'board' && <p className="text-xs text-muted">Drag a card to another column to change its stage, or use the drop-down on the card.</p>}
          </div>
          {aStatus && aView === 'list' && <p className="mb-3 text-sm text-muted" aria-live="polite">Showing {filteredApps.length} {aStatus} application{filteredApps.length === 1 ? '' : 's'}. <button type="button" className="font-semibold underline" onClick={() => setAStatus(null)}>Show all {apps.length}</button></p>}
          {aView === 'list' && (
          <div className="overflow-x-auto rounded-card border border-line">
            <table className="w-full min-w-[44rem] border-collapse text-sm">
              <thead>
                <tr className="bg-ink text-left text-paper">
                  <SortTh k="grant" label="Grant" sort={aSort} onSort={(k) => setASort((c) => toggleSort(c, k))} className="px-4" />
                  <SortTh k="status" label="Status" sort={aSort} onSort={(k) => setASort((c) => toggleSort(c, k))} className="px-4" />
                  <SortTh k="progress" label="Progress" sort={aSort} onSort={(k) => setASort((c) => toggleSort(c, k))} className="px-4" />
                  <SortTh k="deadline" label="Deadline" sort={aSort} onSort={(k) => setASort((c) => toggleSort(c, k))} className="px-4" />
                  <SortTh k="updated" label="Updated" sort={aSort} onSort={(k) => setASort((c) => toggleSort(c, k))} className="px-4" />
                  <th scope="col" className="px-4 py-3 text-right text-xs font-semibold tracking-wide uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line bg-white">
                {pageOf(sortedApps, 'apps').map((a) => {
                  const pr = progressOf(a)
                  return (
                    <tr key={a.id} className="align-top">
                      <td className="px-4 py-3">
                        <button className="text-left font-semibold underline decoration-line underline-offset-4 hover:decoration-ink" onClick={() => { setActiveId(a.id); setAppOpen(true) }}>
                          {a.grant?.title ?? (a.project.title || 'Untitled draft')}
                        </button>
                        <p className="text-xs text-muted">{a.grant?.funder ?? 'No funder selected'}{a.project.amount ? ` · $${a.project.amount}` : ''}</p>
                      </td>
                      <td className="px-4 py-3">
                        <select aria-label="Status" className={`rounded-full border-0 px-3 py-1.5 text-xs font-semibold ${statusTone[a.status]}`} value={a.status}
                          onChange={(e) => setApps((cur) => cur.map((x) => (x.id === a.id ? { ...x, status: e.target.value as AppStatus, updated: Date.now() } : x)))}>
                          {STATUSES.map((st) => <option key={st}>{st}</option>)}
                        </select>
                      </td>
                      <td className="px-4 py-3">
                        <div className="h-2 w-28 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${pr.pct}%` }} /></div>
                        <p className="mt-1 text-xs text-muted">{pr.done}/{pr.total} sections</p>
                      </td>
                      <td className="px-4 py-3">{a.grant ? <Badge days={daysLeft(a.grant)} /> : <span className="text-muted">None</span>}</td>
                      <td className="px-4 py-3 text-muted">{fmtDate(a.updated)}</td>
                      <td className="px-4 py-3 text-right">
 <div className="flex flex-wrap items-center justify-end gap-x-4 gap-y-1">
                        <button className="font-semibold underline" onClick={() => { setActiveId(a.id); setAppOpen(true) }}>Open</button>
                        <button className="text-muted underline" onClick={() => askConfirm('Delete this application and its draft? It is also deleted from your online copy.', { title: 'Delete application?' }).then((ok) => ok && deleteApplication(a.id))}>Delete</button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          )}
          {aView === 'list' && pager('apps', sortedApps.length)}
          {aView === 'board' && (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-5" aria-label="Applications board">
              {STATUSES.map((st) => {
                const col = apps.filter((x) => x.status === st)
                return (
                  <section key={st} className={`min-w-0 rounded-card border p-3 ${dragId ? 'border-dashed border-accent/60' : 'border-line'} bg-card`}
                    onDragOver={(e) => { if (dragId) e.preventDefault() }}
                    onDrop={(e) => { e.preventDefault(); const id = e.dataTransfer.getData('text/plain') || dragId; if (id) moveApp(id, st); setDragId(null) }}>
                    <h3 className="flex items-center justify-between text-sm font-semibold"><span className={`rounded-full px-2.5 py-0.5 text-xs ${statusTone[st]}`}>{st}</span><span className="tabular-nums text-muted">{col.length}</span></h3>
                    <ul className="mt-3 space-y-2">
                      {col.length === 0 && <li className="rounded-lg border border-dashed border-line px-3 py-6 text-center text-xs text-muted">Drop an application here</li>}
                      {col.map((a) => {
                        const pr = progressOf(a)
                        return (
                          <li key={a.id} draggable onDragStart={(e) => { e.dataTransfer.setData('text/plain', a.id); e.dataTransfer.effectAllowed = 'move'; setDragId(a.id) }} onDragEnd={() => setDragId(null)}
                            className="cursor-grab rounded-lg border border-line bg-white p-3 shadow-sm active:cursor-grabbing">
                            <button type="button" className="text-left text-sm font-semibold underline decoration-line underline-offset-4 hover:decoration-ink" onClick={() => { setActiveId(a.id); setAppOpen(true) }}>{a.grant?.title ?? (a.project.title || 'Untitled draft')}</button>
                            <p className="text-xs text-muted">{a.grant?.funder ?? 'No funder selected'}{a.project.amount ? ` · $${a.project.amount}` : ''}</p>
                            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${pr.pct}%` }} /></div>
                            <div className="mt-2 flex items-center justify-between gap-2">
                              {a.grant ? <Badge days={daysLeft(a.grant)} /> : <span className="text-xs text-muted">No deadline</span>}
                              <select aria-label={`Move ${a.grant?.title ?? 'application'} to another stage`} className="rounded-md border border-line bg-white px-1.5 py-1 text-xs" value={a.status} onChange={(e) => moveApp(a.id, e.target.value as AppStatus)}>
                                {STATUSES.map((x) => <option key={x}>{x}</option>)}
                              </select>
                            </div>
                          </li>
                        )
                      })}
                    </ul>
                  </section>
                )
              })}
            </div>
          )}
        </>
      )}
    </div>
  )
}
