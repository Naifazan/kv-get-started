import { Hint, RenderBlocks, Section, field, ghost, label, primary } from '../components/ui'
import { COUNTRY_OPTIONS, EU_LABEL, FIELD_LABELS, GRANT_TYPES_SOUGHT, POPULATIONS, SCOPES, SECTORS, csv, emptyProfile, missingKeys } from '../lib/options'
import { askConfirm } from '../lib/confirm'
import { type HomeState } from './use-home'
import MenuButton from '../components/MenuButton'

export function ProfileView(h: HomeState) {
  const {
    PageHead,
    analyzeDoc,
    completeMyProfile,
    docBusy,
    docFileRef,
    docNote,
    exportProfile,
    extracted,
    inp,
    lib,
    multi,
    online,
    pct,
    profBusy,
    profNote,
    profile,
    readiness,
    runProfileSearch,
    aiNeed,
    aiPast,
    pastBusy,
    pastLocked,
    setPastLocked,
    pastNote,
    setPastNote,
    genBusy,
    genNote,
    needLocked,
    setNeedLocked,
    setGenNote,
    saveProfile,
    secOpen,
    setDocNote,
    setExtracted,
    setProfile,
    setSecOpen,
    toggleSec,
    updateFromLibrary,
    updateFromWebsite,
  } = h
  return (
    <div className="space-y-4">
      <PageHead title="Organization profile" sub="Every grant match, fit score and AI draft is built from this profile. The more precise it is, the better the grants you are shown.">
        <div className="w-60">
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">{pct}% complete</p>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${pct}%` }} /></div>
        </div>
      </PageHead>

      <div className="rounded-card border border-line p-5">
        <p className="font-semibold">Matching readiness</p>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {readiness.map(([t, ok]) => (
            <li key={t} className={`flex items-center gap-2 text-sm ${ok ? 'text-ink' : 'text-muted'}`}>
              <span aria-hidden className={`inline-flex size-5 items-center justify-center rounded-full text-xs font-bold ${ok ? 'bg-green-600 text-white' : 'border border-ink/30'}`}>{ok ? '✓' : ''}</span>{t}
            </li>
          ))}
        </ul>
        <div className="mt-4 flex flex-wrap gap-3">
          <button className={primary} onClick={runProfileSearch} disabled={!csv(profile.focus).length}>Find grants that match this profile</button>
          {!csv(profile.focus).length && <p className="self-center text-sm text-muted">Pick at least one sector first.</p>}
        </div>
      </div>

      <input ref={docFileRef} type="file" className="hidden" disabled={docBusy} onChange={(e) => { const f = e.target.files?.[0]; if (f) analyzeDoc(f); e.target.value = '' }} />
      {(docNote || extracted || docBusy) && <div id="doc-import" className="rounded-card border border-dashed border-ink/30 p-4">
            <p className="font-semibold">{docBusy ? 'AI is working...' : 'AI suggestions for your profile'}</p>
            {docNote && <p className="mt-3 text-sm text-accent">{docNote}</p>}
            {extracted && (
              <div className="mt-4">
                <p className="text-sm font-semibold">Suggested profile updates:</p>
                <ul className="mt-2 divide-y divide-line rounded-card border border-line bg-white text-sm">
                  {Object.entries(extracted).map(([k, v]) => {
                    const cur = ((profile as any)[k] ?? '').toString()
                    return (
                      <li key={k} className="grid gap-1 p-3 md:grid-cols-[10rem_1fr]">
                        <span className="font-semibold">{FIELD_LABELS[k] ?? k}</span>
                        <span>
                          {v}
                          {cur && cur !== v && <span className="block text-xs text-muted">Currently: {cur}</span>}
                        </span>
                      </li>
                    )
                  })}
                </ul>
                <div className="mt-3 flex flex-wrap gap-3">
                  <button type="button" className={primary} onClick={() => { setProfile({ ...profile, ...extracted }); setSecOpen([1, 2, 3, 4, 5, 6]); setExtracted(null); setDocNote('Profile updated. Check the fields above and edit anything that is off.') }}>Apply all to my profile</button>
                  <button type="button" className={ghost} onClick={() => { const fill: Record<string, string> = {}; for (const [k, v] of Object.entries(extracted)) if (!((profile as any)[k] ?? '').toString().trim()) fill[k] = v; setProfile({ ...profile, ...fill }); setExtracted(null); setDocNote('Filled only the empty fields.') }}>Fill empty fields only</button>
                  <button type="button" className={ghost} onClick={() => setExtracted(null)}>Discard</button>
                </div>
              </div>
            )}
          </div>}

      <Section n={1} open={secOpen.includes(1)} onToggle={() => toggleSec(1)} title="Identity and legal status" hint="Funders screen on legal form, registration and age before they read anything else.">
        <label className={label}>Organization name<Hint>Use the exact legal name on your registration documents.</Hint><input className={field} value={profile.org} onChange={inp('org')} /></label>
        <div className={label}><p>Organization type<Hint>Pick every legal or operating form that fits.</Hint></p>{multi('orgType', ['NGO / nonprofit', 'Community-based organization', 'Social enterprise', 'Faith-based organization', 'Research or university group', 'Informal group'], 'Organization type')}</div>
        <label className={label}>Legally registered?<Hint>Most funders only fund registered organizations. &quot;In progress&quot; flags a fiscal sponsor as an option.</Hint>
          <select className={field} value={profile.registered} onChange={inp('registered')}>
            <option value="">Select</option><option value="yes">Yes</option><option value="pending">In progress</option><option value="no">No</option>
          </select></label>
        <div className={label}><p>Tax status<Hint>Pick every status that applies. Leave empty if none.</Hint></p>{multi('taxStatus', ['501(c)(3)', 'Registered charity', 'Tax exempt', 'Public benefit organization', 'Non-profit company', 'Cooperative', 'Not tax exempt'], 'Tax status')}</div>
        <label className={label}>Year founded<Hint>Four digits. Many funders look for two to three years of track record.</Hint><input className={field} inputMode="numeric" value={profile.founded} onChange={inp('founded')} /></label>
        <div className={label}><label htmlFor="org-website">Website or social link</label><Hint>A public page funders can check to verify you. AI can read it to update your profile.</Hint>
          <div className="mt-2 flex items-stretch gap-2">
            <input id="org-website" className={`${field} mt-0 min-w-0 flex-1`} placeholder="https://yourorganization.org" value={profile.website} onChange={inp('website')} />
          </div></div>
      </Section>

      <Section n={2} open={secOpen.includes(2)} onToggle={() => toggleSec(2)} title="Where you are and where you work" hint="All your geography in one place: headquarters, registration and every country you operate in. Geography is the fastest way a call excludes you.">
        <label className={`${label} md:col-span-1`}>Headquarters country<Hint>Where your main office is. Funders check this first.</Hint><select className={field} value={profile.country} onChange={inp('country')}><option value="">Select</option>{COUNTRY_OPTIONS.filter((c) => c !== EU_LABEL).map((c) => <option key={c}>{c}</option>)}</select></label>
        <div className="md:col-span-1"><p className={label}>Countries of legal registration<Hint>Every country that issued a registration for you. It can differ from where you work.</Hint></p>{multi('regCountry', COUNTRY_OPTIONS.filter((c) => c !== EU_LABEL), 'Countries of legal registration', 'Select one or more countries', true)}</div>
        <div className="md:col-span-2"><p className={label}>Countries and regions of operation<Hint>Add every country where you run programs, not only your base.</Hint></p>{multi('opCountries', COUNTRY_OPTIONS, 'Countries and regions of operation', 'Select countries and regions', true)}</div>
        <div className="md:col-span-2"><p className={label}>Scope of work<Hint>Every level you operate at today.</Hint></p>{multi('scope', SCOPES, 'Scope of work')}</div>
      </Section>

      <Section n={3} open={secOpen.includes(3)} onToggle={() => toggleSec(3)} title="What you do and who you serve" hint="Sectors and populations drive the sector filter, the profile match score and the profile-based search.">
        <label className={`${label} md:col-span-2`}>Mission<Hint>One or two sentences: who you help, how, and why.</Hint><textarea rows={2} className={field} value={profile.mission} onChange={inp('mission')} /></label>
        <div className="md:col-span-2"><p className={label}>Sectors (pick all that apply)<Hint>Pick only areas you actually deliver in. These drive your grant matches.</Hint></p>{multi('focus', SECTORS, 'Sectors')}</div>
        <div className="md:col-span-2"><p className={label}>Populations you serve<Hint>Funders often target specific groups, so tick every group you reach.</Hint></p>{multi('populations', POPULATIONS, 'Populations you serve')}</div>
      </Section>

      <Section n={4} open={secOpen.includes(4)} onToggle={() => toggleSec(4)} title="The funding you are looking for" hint="Describe what you need, and set the size and kind of grants. It filters out grants that are too big, too small or the wrong kind.">
        <div className="md:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <label htmlFor="funding-need" className="text-sm font-semibold">Describe the funding you need</label>
            <MenuButton
              className={ghost}
              label="Write with AI"
              busy={genBusy}
              busyLabel="Writing..."
              groups={[{ items: [
                { id: 'generate', label: 'Generate from my profile', hint: (profile.fundingNeed ?? '').trim() ? 'Replaces the text below' : undefined, disabled: !profile.org && !csv(profile.focus).length && !profile.mission },
                { id: 'improve', label: 'Improve with AI', disabled: !(profile.fundingNeed ?? '').trim() },
              ] }]}
              onPick={(id) => { if (id === 'generate') aiNeed('generate'); else aiNeed('improve') }}
            />
          </div>
          <Hint>Say what you do, where, for whom and roughly how much you need. Write it yourself or let AI write or improve it. The profile-based search in Find grants uses it to find better matches.</Hint>
          {(profile.fundingNeed ?? '').trim() && needLocked ? (
            <>
              <div id="funding-need" className="mt-1 rounded-card border border-line bg-white p-4"><RenderBlocks text={profile.fundingNeed ?? ''} /></div>
              <div className="mt-2">
                <MenuButton
                  className={ghost}
                  label="Edit"
                  groups={[{ items: [{ id: 'edit', label: 'Edit' }, { id: 'clear', label: 'Clear' }] }]}
                  onPick={(id) => {
                    if (id === 'edit') setNeedLocked(false)
                    else askConfirm('Clear the funding need text? You can write it again with AI.', { title: 'Clear this text?' }).then((ok) => { if (ok) { setProfile({ ...profile, fundingNeed: '' }); setNeedLocked(false); setGenNote('') } })
                  }}
                />
              </div>
            </>
          ) : (
            <textarea
              id="funding-need"
              rows={3}
              className={field}
              value={profile.fundingNeed ?? ''}
              onChange={(e) => setProfile({ ...profile, fundingNeed: e.target.value })}
              autoFocus={!!(profile.fundingNeed ?? '').trim()}
              onBlur={() => { if ((profile.fundingNeed ?? '').trim()) setNeedLocked(true) }}
              placeholder="e.g. We run a girls' coding program in rural Kenya and need around $50,000 for equipment and teacher training"
            />
          )}
          {genNote && <p className="mt-2 text-sm text-accent">{genNote}</p>}
        </div>
        <label className={label}>Smallest grant worth applying for (USD)<Hint>Grants below this are hidden from your best matches.</Hint><input className={field} inputMode="numeric" value={profile.amountMin ?? ''} onChange={inp('amountMin')} /></label>
        <label className={label}>Largest grant you could absorb (USD)<Hint>Be realistic about what your team can manage and report on.</Hint><input className={field} inputMode="numeric" value={profile.amountMax ?? ''} onChange={inp('amountMax')} /></label>
        <div className="md:col-span-2"><p className={label}>Types of funding you want<Hint>Tells matching which kinds of calls to show you.</Hint></p>{multi('grantTypes', GRANT_TYPES_SOUGHT, 'Types of funding')}</div>
        <label className={label}>Open to working in a consortium?<Hint>Many large calls require partners. Say how you prefer to join.</Hint><select className={field} value={profile.partner ?? ''} onChange={inp('partner')}><option value="">Select</option><option value="yes">Yes, as partner or lead</option><option value="partner">As a partner only</option><option value="no">No, we apply alone</option></select></label>
      </Section>

      <Section n={5} open={secOpen.includes(5)} onToggle={() => toggleSec(5)} title="Capacity and compliance" hint="Your budget, team size and the largest grant you have managed. Funders compare award size to these.">
        <label className={label}>Annual budget<Hint>Your total yearly spending. Funders compare award size to this.</Hint>
          <select className={field} value={profile.budget} onChange={inp('budget')}>
            <option value="">Select</option><option>Under $25k</option><option>$25k to $100k</option><option>$100k to $500k</option><option>$500k to $2M</option><option>Over $2M</option>
          </select></label>
        <label className={label}>Team size<Hint>Paid staff and volunteers, for example &quot;6 staff, 20 volunteers&quot;.</Hint><input className={field} placeholder="e.g. 6 staff, 20 volunteers" value={profile.size} onChange={inp('size')} /></label>
        <label className={`${label} md:col-span-2`}>Largest grant you have managed (USD)<Hint>Shows you can handle money at the scale you are asking for.</Hint><input className={field} inputMode="numeric" value={profile.largestGrant ?? ''} onChange={inp('largestGrant')} /></label>
      </Section>

      <Section n={6} open={secOpen.includes(6)} onToggle={() => toggleSec(6)} title="Track record" hint="Funders fund organizations that have delivered. Concrete numbers and past funders carry weight.">
        <div className="md:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <label htmlFor="past-funding" className="text-sm font-semibold">Past funding and key results</label>
            <MenuButton
              className={ghost}
              label="Write with AI"
              busy={pastBusy}
              busyLabel="Writing..."
              groups={[{ items: [
                { id: 'generate', label: 'Generate from my profile and Library', hint: (profile.pastFunding ?? '').trim() ? 'Replaces the text below' : undefined, disabled: !profile.org && !profile.mission && !lib.docs.length },
                { id: 'improve', label: 'Improve with AI', disabled: !(profile.pastFunding ?? '').trim() },
              ] }]}
              onPick={(id) => { if (id === 'generate') aiPast('generate'); else aiPast('improve') }}
            />
          </div>
          <Hint>List funders, amounts, years and what you delivered. Concrete numbers carry weight. AI uses only facts from your profile and Library documents and leaves [placeholders] where a fact is missing, so check every line.</Hint>
          {(profile.pastFunding ?? '').trim() && pastLocked ? (
            <>
              <div id="past-funding" className="mt-1 rounded-card border border-line bg-white p-4"><RenderBlocks text={profile.pastFunding ?? ''} /></div>
              <div className="mt-2">
                <MenuButton
                  className={ghost}
                  label="Edit"
                  groups={[{ items: [{ id: 'edit', label: 'Edit' }, { id: 'clear', label: 'Clear' }] }]}
                  onPick={(id) => {
                    if (id === 'edit') setPastLocked(false)
                    else askConfirm('Clear the past funding text? You can write it again with AI.', { title: 'Clear this text?' }).then((ok) => { if (ok) { setProfile({ ...profile, pastFunding: '' }); setPastLocked(false); setPastNote('') } })
                  }}
                />
              </div>
            </>
          ) : (
            <textarea
              id="past-funding"
              rows={4}
              className={field}
              placeholder="Funders, amounts, years, and what you delivered"
              value={profile.pastFunding ?? ''}
              onChange={(e) => setProfile({ ...profile, pastFunding: e.target.value })}
              autoFocus={!!(profile.pastFunding ?? '').trim()}
              onBlur={() => { if ((profile.pastFunding ?? '').trim()) setPastLocked(true) }}
            />
          )}
          {pastNote && <p className="mt-2 text-sm text-accent">{pastNote}</p>}
        </div>
      </Section>

      <div className="rounded-card border border-line p-5">
          <div className="mt-5 flex flex-wrap gap-3">
            <MenuButton
              className={ghost}
              label="Export profile"
              groups={[{ items: [{ id: 'docx', label: 'Microsoft Word (.docx)' }, { id: 'pdf', label: 'PDF (.pdf)' }] }]}
              onPick={(id) => exportProfile(id as 'docx' | 'pdf')}
            />
            <button type="button" className={ghost} disabled={profBusy} onClick={saveProfile} title="Save this profile to your Whop account so it follows you across devices">
              {profBusy ? 'Working...' : online?.signedIn ? 'Save profile online' : 'Sign in to save profile'}
            </button>
            <select
              aria-label="Update my profile with AI"
              className={`${primary} cursor-pointer appearance-auto pr-2`}
              value=""
              disabled={docBusy}
              onChange={(e) => {
                const v = e.target.value
                e.target.value = ''
                if (v === 'website') updateFromWebsite()
                else if (v === 'library') updateFromLibrary()
                else if (v === 'document') docFileRef.current?.click()
                else if (v === 'gaps') completeMyProfile()
              }}
            >
              <option value="" disabled>{docBusy ? 'AI is working...' : 'Update my profile with AI'}</option>
              <option value="website" className="text-ink">From my website</option>
              <option value="library" className="text-ink" disabled={lib.docs.length === 0 && lib.snippets.length === 0}>From my library documents</option>
              <option value="document" className="text-ink">From a document on my device</option>
              {pct < 100 && <option value="gaps" className="text-ink">Fill the gaps ({missingKeys(profile).length} missing)</option>}
            </select>
            <button type="button" className={ghost} onClick={() => askConfirm('Clear your profile?', { title: 'Clear profile?' }).then((ok) => ok && setProfile(emptyProfile))}>Clear</button>
          </div>
        {profNote && <p className="mt-3 text-sm text-accent">{profNote}</p>}
        <p className="mt-3 text-sm text-muted">Stored in this browser. Save it online to use it on any device, or export it as a file.</p>
      </div>
    </div>
  )
}
