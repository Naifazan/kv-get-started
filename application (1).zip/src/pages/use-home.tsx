import type { QItem, TRow } from '../lib/types'
import { acronymReport, languageReport } from '../lib/language'
import type { AcronymItem, LangReport } from '../lib/language'
import { terminologyCheck } from '../server/grants'
import type { TermGroup } from '../server/grants'
import { useEffect, useMemo, useRef, useState } from 'react'
import { type AppStatus, type Application, ELIG_LABEL, ELIG_TONE, FRAME_FIELDS, type Fit, type Inputs, type PipeTab, type Project, STAGE_PROB, STATUSES, type SortState, type Tpl, VIEWS, type View, areaFilled, areaLabel, emptyInputs, emptyProject } from '../lib/types'
import { useStored } from '../lib/use-stored'
import { matchTitle } from '../lib/match-title'
import { type Limit, hardTrim, measure } from '../lib/limits'
import type { AuditVerdict, SourceItem, EligibilityItem, FrameworkOptions, Grant, GrantDetail, Profile } from '../server/grants'
import { libraryCompliance, FIELD_LABELS, GRANT_TYPES_SOUGHT, POPULATIONS, PURPOSES, Q_META, SCOPES, SDGS, SECTIONS, SECTORS, amountLabel, completeness, csv, emptyProfile, isInvite, matchesCountry, missingKeys, normStatus, parseDate, quickMatch, realism } from '../lib/options'
import { useSynced } from '../lib/use-synced'
import type { Library } from '../components/LibraryPage'
import { docState, emptyLibrary } from '../components/LibraryPage'
import { ALL_SOURCES, type Src } from '../lib/sources'
import { writePastFunding, eligibilityChecklist, extractFramework, analyzeGuidance, addGrantFromLink, budgetFromTemplate, fillBudgetWorkbook, aiSearchGrants, autoComplete, completeProfile, condenseNeeds, analyzeExperience, breakdownLine, analyzeProjectInfo, fitToLimit, suggestAnswer, profileFromWebsite, generateFundingNeed, extractProfile, grantDetails, readGrantLink, generateProjectDoc, extractSources, projectTitles, qualityAudit, gapQuestions, helperDraft, parseTemplate, searchGrants, searchWebForGrants } from '../server/grants'
import { analyzeFit, analyzeFitBatch } from '../server/fit'
import { buildImported, detectMapping, fileErrorText, mergeRemoteApps, readAnyFile, readGrantTable, readNeedsFile } from '../lib/files'
import { type Block, budgetCheck, clean, docLines, escHtml, fromB64, ganttFrom, guidanceText, num, parseBlocks, sectionPlain, sortList, tidy, toB64 } from '../lib/text'
import { appendSheet, cellRef, describeXlsx, fillXlsx, keepOnlySheet, pickMainSheet, readXlsx } from '../lib/xlsx-read'
import type { Fill } from '../lib/xlsx-read'
import { libraryDigest, libraryTextForProfile } from '../lib/library-digest'
import { askConfirm } from '../lib/confirm'
import { getBilling } from '../server/billing'
import { streamWrite } from '../lib/stream-client'
import { trackRequests } from '../lib/activity'
import type { Billing } from '../plans'
import { deleteSaved, getFindings, listSaved, loadProfileOnline, saveApplication, saveProfileOnline, whoami } from '../server/saved'
import type { CompareRow } from '../components/CompareModal'
import type { FixSuggestion } from '../server/review'
import { suggestFix } from '../server/review'
import { Hint, MultiSelect, type Opt, field, ghost, primary } from '../components/ui'

// The state and logic behind every page of the portal. The pages in this folder only draw it.
export function useHome() {

  const [view, setViewState] = useState<View>('dashboard')

  useEffect(() => {
    const h = () => {
      const raw = window.location.hash.replace('#', '')
      if (raw === 'saved') {
        setPipeTab('saved')
        setViewState('pipeline')
        return
      }
      const v = raw as View
      if (v === 'tracker') { setPipeMode('table'); setViewState('pipeline'); return }
      if (VIEWS.includes(v)) setViewState(v)
    }
    h()
    window.addEventListener('hashchange', h)
    return () => window.removeEventListener('hashchange', h)
  }, [])

  // The Grants tracker is now the "Full table" view of the Grants pipeline page.
  const [pipeMode, setPipeMode] = useState<'stages' | 'table'>('stages')

  const setView = (v: View) => {
    if (v === 'tracker') { setPipeMode('table'); v = 'pipeline' }
    window.location.hash = v
    setViewState(v)
    window.scrollTo(0, 0)
  }

  const [profile, setProfile] = useStored<Profile>('ngw_profile', emptyProfile)

  const [online, setOnline] = useState<{ signedIn: boolean; name: string; dbReady: boolean } | null>(null)
  // Plan and AI credits for the signed-in person. Refreshed every 20 seconds while the page is open, and right after a purchase.
  const [billing, setBilling] = useState<Billing | null>(null)
  const [onlineLimit, setOnlineLimit] = useState(0)
  const refreshBilling = async (fresh = false) => { try { setBilling(await getBilling({ data: { fresh } })) } catch {} }
  useEffect(() => {
    const url = new URL(window.location.href)
    const bought = url.searchParams.get('upgraded') === '1'
    refreshBilling(bought)
    const timers: ReturnType<typeof setTimeout>[] = []
    if (bought) {
      for (const ms of [4000, 10000, 20000]) timers.push(setTimeout(() => refreshBilling(true), ms))
      url.searchParams.delete('upgraded')
      window.history.replaceState(null, '', url.pathname + (url.search || '') + url.hash)
    }
    const id = setInterval(() => { if (!document.hidden) refreshBilling() }, 20000)
    const onFocus = () => { refreshBilling() }
    window.addEventListener('focus', onFocus)
    return () => { clearInterval(id); timers.forEach(clearTimeout); window.removeEventListener('focus', onFocus) }
  }, [])

  // ---- Library and awards (kept in this browser and, when signed in, online) ----
  const [lib, setLib] = useSynced<Library>('library', emptyLibrary, !!online?.signedIn)

  // How many grants one page shows. The choice is the same on the Find, Pipeline, Applications and Tracker pages.
  const [storageFull, setStorageFull] = useState(false)

  useEffect(() => {
    const h = () => setStorageFull(true)
    window.addEventListener('ngw-storage-error', h)
    return () => window.removeEventListener('ngw-storage-error', h)
  }, [])

  const [pageSize, setPageSize] = useStored<number>('ngw_pagesize', 20)

  const [pages, setPages] = useState<Record<string, number>>({})

  const pageNo = (key: string, total: number) => Math.min(pages[key] ?? 1, Math.max(1, Math.ceil(total / pageSize)))

  const pageOf = <T,>(list: T[], key: string): T[] => { const p = pageNo(key, list.length); return list.slice((p - 1) * pageSize, p * pageSize) }

  const pageStart = (key: string, total: number) => (pageNo(key, total) - 1) * pageSize

  const pager = (key: string, total: number) => {
    if (total <= 0) return null
    const pages_ = Math.max(1, Math.ceil(total / pageSize))
    const p = pageNo(key, total)
    const go = (n: number) => { setPages((c) => ({ ...c, [key]: Math.max(1, Math.min(pages_, n)) })); window.scrollTo({ top: 0, behavior: 'smooth' }) }
    return (
      <div className="my-3 flex flex-wrap items-center justify-between gap-3 text-sm print:hidden">
        <label className="flex items-center gap-2 font-semibold">Show
          <select aria-label="Items per page" className="rounded-full border border-accent/60 bg-white px-3 py-1.5 font-semibold" value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPages({}) }}>
            {[20, 40, 60, 80, 100].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
          per page
        </label>
        <span className="text-muted tabular-nums">{(p - 1) * pageSize + 1} to {Math.min(total, p * pageSize)} of {total}</span>
        {pages_ > 1 && (
          <span className="inline-flex items-center gap-2">
            <button type="button" className="rounded-full border border-accent/60 px-3 py-1.5 font-semibold text-accent hover:bg-accent/10 disabled:opacity-40" disabled={p <= 1} onClick={() => go(p - 1)}>Previous</button>
            <span className="tabular-nums">Page {p} of {pages_}</span>
            <button type="button" className="rounded-full border border-accent/60 px-3 py-1.5 font-semibold text-accent hover:bg-accent/10 disabled:opacity-40" disabled={p >= pages_} onClick={() => go(p + 1)}>Next</button>
          </span>
        )}
      </div>
    )
  }

  const [saved, setSaved] = useStored<Grant[]>('ngw_saved', [])
  // Every grant brought in from an Excel or CSV file stays here, so "Imported-files search" can look through them later.
  const [importedGrants, setImportedGrants] = useStored<Grant[]>('ngw_imported', [])

  const [fitsAll, setFits] = useStored<Record<string, Fit>>('ngw_fits', {})

  // A fit score is tied to the organization profile it was calculated for. It stays the same until the profile changes.
  const profileKey = (() => {
    const o = Object.fromEntries(Object.entries(profile as Record<string, unknown>).filter(([k, v]) => v !== '' && v != null && k !== 'website').sort(([a], [b]) => a.localeCompare(b)))
    const str = JSON.stringify(o)
    let h = 5381
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0
    // The trailing f2 marks the scoring method. Scores made by the older method are recalculated.
    return 'p' + (h >>> 0).toString(36) + 'f2'
  })()

  const fits = useMemo(() => Object.fromEntries(Object.entries(fitsAll).filter(([, f]) => f && f.pk === profileKey)) as Record<string, Fit>, [fitsAll, profileKey])

  // Scores saved before this rule existed are tied to the current profile once.
  useEffect(() => {
    if (Object.values(fitsAll).some((f) => f && f.pk === undefined)) setFits((cur) => Object.fromEntries(Object.entries(cur).map(([id, f]) => [id, f.pk === undefined ? { ...f, pk: profileKey } : f])))
  }, [fitsAll, profileKey])

  async function fitFor(g: Grant, force = false): Promise<Fit> {
    const cached = fitsAll[g.id]
    if (!force && cached && cached.pk === profileKey && cached.mode === 'ai') return cached
    const f = await analyzeFit({ data: { profile, grant: g, library: libraryDigest(lib, 900, `${g.title} ${g.summary ?? ''}`.slice(0, 600)) } })
    return { ...f, pk: profileKey } as Fit
  }

  const [seen, setSeen] = useStored<Grant[]>('ngw_seen', [])

  // Things the person deleted. They are remembered so that a refresh, a search or the online copy cannot bring them back.
  // They are written to the browser straight away, because a page can be refreshed a moment after a delete.
  const readTomb = (k: string): string[] => { try { const v = JSON.parse(localStorage.getItem(k) || '[]'); return Array.isArray(v) ? v.map(String) : [] } catch { return [] } }
  const [removedGrants, setRemovedGrants] = useState<string[]>([])
  useEffect(() => { setRemovedGrants(readTomb('ngw_removed')) }, [])
  const setTomb = (k: 'ngw_removed' | 'ngw_deleted_apps', next: string[]) => {
    try { localStorage.setItem(k, JSON.stringify(next)) } catch {}
    if (k === 'ngw_removed') setRemovedGrants(next)
  }
  const addTomb = (k: 'ngw_removed' | 'ngw_deleted_apps', ids: string[]) => setTomb(k, [...new Set([...ids, ...readTomb(k)])].slice(0, 400))
  const dropTomb = (k: 'ngw_removed' | 'ngw_deleted_apps', ids: string[]) => { const cur = readTomb(k); if (cur.some((x) => ids.includes(x))) setTomb(k, cur.filter((x) => !ids.includes(x))) }

  const [notesBy, setNotesBy] = useStored<Record<string, string>>('ngw_notes', {})

  const [apps, setApps] = useStored<Application[]>('ngw_apps', [])

  const [activeId, setActiveId] = useState<string | null>(null)

  const [appOpen, setAppOpen] = useState(false)


  const app = apps.find((a) => a.id === activeId) ?? null

  const patch = (fn: (a: Application) => Application) =>
    setApps((cur) => cur.map((a) => (a.id === activeId ? { ...fn(a), updated: Date.now() } : a)))

  const doc = app?.doc ?? {}

  const setDoc = (v: Record<string, string> | ((d: Record<string, string>) => Record<string, string>)) =>
    patch((a) => ({ ...a, doc: typeof v === 'function' ? v(a.doc) : v }))

  const project = app?.project ?? emptyProject

  const setProject = (p: Project) => patch((a) => ({ ...a, project: p }))

  const target = app?.grant ?? null

  const setTpl = (t: Tpl | null) => patch((a) => ({ ...a, tpl: t }))

  const inputs = app?.inputs ?? emptyInputs

  const setInputs = (v: Partial<Inputs>) => patch((a) => ({ ...a, inputs: { ...(a.inputs ?? emptyInputs), ...v } }))

  const [needsBusy, setNeedsBusy] = useState(false)

  const [needsNote, setNeedsNote] = useState('')

  const [needsBackup, setNeedsBackup] = useState<string | null>(null)

  async function importNeeds(f: File) {
    setNeedsBusy(true)
    setNeedsNote('')
    try {
      const text = (await readNeedsFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 30) setNeedsNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      else {
        setInputs({ needs: inputs.needs.trim() ? `${inputs.needs.trim()}\n\n--- Imported from ${f.name} ---\n${text}` : text })
        setNeedsNote(`Imported ${text.length.toLocaleString('en-US')} characters from ${f.name}.${text.length > 6000 ? ' It is long, so press Condense with AI to keep the key evidence.' : ''}`)
      }
    } catch {
      setNeedsNote('Could not read that file. Use Word (.docx), PDF, Excel (.xlsx), CSV or text.')
    }
    setNeedsBusy(false)
  }

  // Information about the planned project, imported from Word, PDF or Excel files and analyzed by the AI. The AI uses it for every section.
  const [planBusy, setPlanBusy] = useState(false)

  const [planNote, setPlanNote] = useState('')

  const planText = (docs: NonNullable<Application['planDocs']>) => docs.map((d) => (docs.length > 1 ? `[${d.name}]\n${d.summary}` : d.summary)).join('\n\n')

  async function importPlan(f: File) {
    setPlanBusy(true)
    setPlanNote('')
    try {
      const text = (await readNeedsFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 30) setPlanNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      else {
        let summary = text.slice(0, 4000)
        let ai = false
        try {
          const r = await analyzeProjectInfo({ data: { text, name: f.name } })
          if (r.ok) { summary = r.text; ai = true }
        } catch {}
        const entry = { id: Math.random().toString(36).slice(2, 10), name: f.name, at: Date.now(), summary, chars: text.length, ai }
        patch((a) => { const docs = [...(a.planDocs ?? []), entry]; return { ...a, planDocs: docs, plan: planText(docs) } })
        setPlanNote(ai ? `Analyzed ${f.name}. The AI will follow its project information in every section of the proposal.` : `Added ${f.name}, but the AI analysis is not available, so the first 4,000 characters are used as they are.`)
      }
    } catch {
      setPlanNote('Could not read that file. Use Word (.docx), PDF, Excel (.xlsx), CSV or text.')
    }
    setPlanBusy(false)
  }

  const removePlan = (id: string) => patch((a) => { const docs = (a.planDocs ?? []).filter((x) => x.id !== id); return { ...a, planDocs: docs, plan: planText(docs) } })

  const [expBusy, setExpBusy] = useState(false)

  const [expNote, setExpNote] = useState('')

  async function importExperience(f: File) {
    setExpBusy(true)
    setExpNote('')
    try {
      const text = (await readNeedsFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 30) setExpNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      else {
        let summary = text.slice(0, 4000)
        let ai = false
        try {
          const r = await analyzeExperience({ data: { text, name: f.name } })
          if (r.ok) { summary = r.text; ai = true }
        } catch {}
        const entry = { id: Math.random().toString(36).slice(2, 10), name: f.name, at: Date.now(), summary, chars: text.length, ai }
        patch((a) => ({ ...a, experience: [...(a.experience ?? []), entry] }))
        setExpNote(ai ? `Analyzed ${f.name}. The AI will now use its facts when it writes this proposal.` : `Added ${f.name}, but the AI analysis is not available, so the first 4,000 characters are used as they are.`)
      }
    } catch {
      setExpNote('Could not read that file. Use Word (.docx), PDF, Excel (.xlsx), CSV or text.')
    }
    setExpBusy(false)
  }

  const removeExperience = (id: string) => patch((a) => ({ ...a, experience: (a.experience ?? []).filter((x) => x.id !== id) }))

  async function condenseNeedsText() {
    setNeedsBusy(true)
    setNeedsNote('')
    try {
      const r = await condenseNeeds({ data: { text: inputs.needs } })
      if (r.ok) {
        setNeedsBackup(inputs.needs)
        setInputs({ needs: r.text })
        setNeedsNote('Condensed. Check that no key facts were lost.')
      } else setNeedsNote(r.reason)
    } catch {
      setNeedsNote('Something went wrong. Please try again.')
    }
    setNeedsBusy(false)
  }


  // One-time move of the old single draft into the Applications list.
  useEffect(() => {
    try {
      if (localStorage.getItem('ngw_migrated')) return
      localStorage.setItem('ngw_migrated', '1')
      const d = JSON.parse(localStorage.getItem('ngw_doc') || '{}')
      if (Object.values(d).some((x) => String(x).trim())) {
        const g = JSON.parse(localStorage.getItem('ngw_target') || 'null')
        const pr = JSON.parse(localStorage.getItem('ngw_project') || 'null') ?? emptyProject
        const tpls = JSON.parse(localStorage.getItem('ngw_templates') || '{}')
        const now = Date.now()
        setApps((cur) =>
          cur.length
            ? cur
            : [{ id: 'app' + now.toString(36), grant: g, status: 'Drafting', project: pr, doc: d, tpl: tpls[g?.id ?? 'custom'] ?? null, notes: '', created: now, updated: now }],
        )
      }
    } catch {}
  }, [])


  function openSaved() {
    setPipeTab('saved')
    setView('pipeline')
  }


  function startApplication(g: Grant | null) {
    if (g) { dropTomb('ngw_removed', [g.id]); setSaved((cur) => (cur.some((x) => x.id === g.id) ? cur : [g, ...cur])) }
    const existing = g ? apps.find((a) => a.grant?.id === g.id && a.status === 'Drafting') ?? apps.find((a) => a.grant?.id === g.id) : null
    if (existing) {
      setActiveId(existing.id)
    } else {
      const now = Date.now()
      const na: Application = { id: 'app' + now.toString(36), grant: g, status: 'Drafting', project: { ...emptyProject }, doc: {}, tpl: null, notes: '', created: now, updated: now }
      setApps((cur) => [na, ...cur])
      setActiveId(na.id)
      window.whop?.track?.('application_started')
    }
    setAppOpen(true)
    setView('applications')
  }


  const [q, setQ] = useState('')

  const [source, setSource] = useState<string[]>([])

  const [results, setResults] = useState<Grant[] | null>(null)

  const [notes, setNotes] = useState<string[]>([])

  useEffect(() => {
    if (!results?.length) return
    setSeen((cur) => {
      const gone = new Set(readTomb('ngw_removed'))
      const map = new Map(cur.filter((g) => !gone.has(g.id)).map((g) => [g.id, g]))
      for (const g of results) if (!gone.has(g.id)) map.set(g.id, { ...g, details: undefined })
      return [...map.values()].slice(-600)
    })
  }, [results])

  const [busy, setBusy] = useState('')

  const [open, setOpen] = useState<string | null>(null)

  const [fStatus, setFStatus] = useState<string[]>([])

  const [fDeadline, setFDeadline] = useState<string[]>([])

  const [fText, setFText] = useState('')

  const [sort, setSort] = useState('priority')

  const [fCountry, setFCountry] = useState<string[]>([])

  const [fType, setFType] = useState<string[]>([])

  const [fSector, setFSector] = useState<string[]>([])

  const [fAmin, setFAmin] = useState('')

  const [fAmax, setFAmax] = useState('')

  const [fUnknownAmt, setFUnknownAmt] = useState(true)

  const [onlyDated, setOnlyDated] = useState(false)

  const [modes, setModes] = useState<string[]>(['keyword', 'profile', 'web'])

  const [aSources, setASources] = useState<string[]>(ALL_SOURCES)

  const [aElig, setAElig] = useState<string[]>([])

  const [aCats, setACats] = useState<string[]>([])

  const [aInstr, setAInstr] = useState<string[]>([])

  const [aPosted, setAPosted] = useState('')

  const [aEu, setAEu] = useState<string[]>(['open', 'forthcoming'])

  const [aAll, setAAll] = useState('')

  const [aAny, setAAny] = useState('')

  const [aNot, setANot] = useState('')

  const [aFunder, setAFunder] = useState('')

  const [aiText, setAiText] = useState('')

  const [hideDead, setHideDead] = useState(true)

  const [aiUseProfile, setAiUseProfile] = useState(true)

  const [aiInfo, setAiInfo] = useState<{ queries: string[]; note: string; usedAi: boolean } | null>(null)


  const shown = (() => {
    let list = [...(results ?? [])]
    if (hideDead && !fStatus.includes('closed')) list = list.filter((g) => normStatus(g) !== 'closed' && !g.inviteOnly && !(parseDate(g.deadline) && (parseDate(g.deadline) as Date).getTime() < Date.now() - 864e5))
    if (fStatus.length) list = list.filter((g) => fStatus.includes(normStatus(g)))
    if (fCountry.length) list = list.filter((g) => fCountry.some((c) => matchesCountry(g, c)))
    if (fType.length) list = list.filter((g) => { const parts = (g.gtype ?? '').toLowerCase().split(/ \/ | or /).map((x) => x.trim()); return fType.some((t) => parts.includes(t.toLowerCase())) })
    if (fSector.length) list = list.filter((g) => (g.sectors ?? []).some((x) => fSector.includes(x)))
    if (fAmin.trim() || fAmax.trim()) {
      const lo = Number(fAmin.replace(/[^0-9.]/g, '')) || 0
      const hi = Number(fAmax.replace(/[^0-9.]/g, '')) || Infinity
      list = list.filter((g) => {
        const gh = g.amountMax || 0
        const gl = g.amountMin || 0
        if (!gh && !gl) return fUnknownAmt
        const top = gh || gl
        const bottom = gl || 0
        return top >= lo && bottom <= hi
      })
    }
    if (fText.trim()) {
      const w = fText.toLowerCase()
      list = list.filter((g) => `${g.title} ${g.funder} ${g.summary ?? ''}`.toLowerCase().includes(w))
    }
    if (onlyDated) list = list.filter((g) => parseDate(g.deadline))
    if (fDeadline.length) {
      const now = Date.now()
      list = list.filter((g) => {
        const d = parseDate(g.deadline)
        if (!d) return fDeadline.includes('rolling')
        return fDeadline.some((x) => x !== 'rolling' && d.getTime() >= now && d.getTime() <= now + Number(x) * 864e5)
      })
    }
    if (sort === 'deadline')
      list.sort((a, b) => (parseDate(a.deadline)?.getTime() ?? Infinity) - (parseDate(b.deadline)?.getTime() ?? Infinity))
    if (sort === 'priority') list.sort((a, b) => realism(b, profile, lib.docs).priority - realism(a, profile, lib.docs).priority)
    if (sort === 'match') list.sort((a, b) => quickMatch(b, profile).score - quickMatch(a, profile).score)
    if (sort === 'amount') list.sort((a, b) => (b.amountMax || b.amountMin || 0) - (a.amountMax || a.amountMin || 0))
    if (sort === 'fit') list.sort((a, b) => (fits[b.id]?.score ?? -1) - (fits[a.id]?.score ?? -1))
    return list
  })()

  const sources = Array.from(new Set((results ?? []).map((g) => g.source)))

  const [fSource, setFSource] = useState<string[]>([])

  const shownFinal = fSource.length ? shown.filter((g) => fSource.includes(g.source)) : shown

  const [hSort, setHSort] = useState<SortState>(null)

  const STATUS_RANK = ['open', 'rolling', 'forthcoming', 'closed', 'unknown']
  const sortedFinal = (() => {
    if (!hSort) return shownFinal
    const val = (g: Grant): number | string | null => {
      switch (hSort.k) {
        case 'title': return g.title.toLowerCase()
        case 'type': return (g.gtype ?? '').toLowerCase() || null
        case 'status': return STATUS_RANK.indexOf(normStatus(g))
        case 'deadline': return parseDate(g.deadline)?.getTime() ?? null
        case 'award': return g.amountMax || g.amountMin || null
        case 'match': return fits[g.id]?.score ?? quickMatch(g, profile).score
        default: return null
      }
    }
    return sortList(shownFinal, val, hSort.dir)
  })()


  const tpl = app?.tpl ?? undefined

  const secs: readonly (readonly [string, string])[] = tpl ? tpl.sections.map((x) => [x.key, x.title] as const) : SECTIONS

  const meta = (k: string) => tpl?.sections.find((x) => x.key === k)

  // Yes/no, drop-down, tick-box, number and date fields of the funder's form hold short answers, so the AI never rewrites them as narrative.
  const isChoiceKey = (k: string) => { const t = meta(k)?.type; return !!t && t !== 'text' && t !== 'table' }

  // The length limit of a field, in the funder's own unit: from the application template first, then from the grant guidance.
  const limitOf = (k: string): Limit | null => {
    const q = meta(k)
    if (q?.limit && q.limit > 0) return { n: q.limit, unit: q.limitUnit ?? 'words' }
    if (q?.wordLimit && q.wordLimit > 0) return { n: q.wordLimit, unit: 'words' }
    const title = secs.find(([x]) => x === k)?.[1] ?? ''
    const hit = (app?.guidance?.limits ?? []).find((x) => x.section && matchTitle([title], x.section))
    return hit ? { n: hit.limit, unit: hit.unit } : null
  }

  // Keeps generated text inside the limit: the AI shortens it, and if it is still too long, whole sentences are removed from the end.
  async function fitText(key: string, title: string, text: string): Promise<{ text: string; trimmed: boolean; over: boolean }> {
    const lim = limitOf(key)
    if (!lim || /budget/i.test(title) || measure(text, lim.unit) <= lim.n) return { text, trimmed: false, over: false }
    setSecMsg((c) => ({ ...c, [key]: { ok: true, text: 'Shortening the text to fit the limit...' } }))
    let t = text
    for (let attempt = 0; attempt < 2 && measure(t, lim.unit) > lim.n; attempt++) {
      try {
        // eslint-disable-next-line no-await-in-loop
        const r = await fitToLimit({ data: { text: t, title, limit: lim.n, unit: lim.unit, attempt } })
        if (r.ok && r.text.trim()) t = tidy(r.text).trim()
      } catch {}
    }
    if (measure(t, lim.unit) > lim.n) t = hardTrim(t, lim)
    return { text: t, trimmed: true, over: measure(t, lim.unit) > lim.n }
  }

  const wc = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0)

  const [tplBusy, setTplBusy] = useState(false)

  const [tplNote, setTplNote] = useState('')

  const [tplPaste, setTplPaste] = useState('')


  // When no input cells can be recognised, the budget is prepared from the template's categories and added as a new sheet. The funder's sheets stay untouched.
  async function addPreparedSheet(buf: ArrayBuffer, f: File, key: string, sheetCount: number, single = false) {
    const text = readXlsx(buf).filter((sh) => sh.rows.length).map((sh) => `Sheet: ${sh.name}\n` + sh.rows.map((r) => r.join(' | ')).join('\n')).join('\n\n')
    const tr = await budgetFromTemplate({ data: { profile, text, context: budgetCtx(), amount: project.amount, months: project.months, rules: budgetRules() || undefined } })
    if (!tr.ok) { setBdNote(tr.reason); return }
    const table = parseBlocks(tr.text).find((b) => b.type === 'table')
    if (!table || table.type !== 'table') { setBdNote('The AI could not turn that template into a budget table. Try again.'); return }
    const matrix = table.rows.map((r) => r.map((c) => { const t = clean(c); const n = t && /^[\d,.\s]+$/.test(t) ? num(t) : null; return n === null ? t : n }))
    const out = appendSheet(buf, 'Prepared budget', matrix)
    // With no budget section in the form, only the one prepared budget sheet is kept.
    const final = single ? keepOnlySheet(out.bytes, out.name).bytes : out.bytes
    const count = single ? 1 : sheetCount + 1
    const b64 = toB64(final)
    patch((a) => ({ ...a, budgetFile: b64.length < 1_400_000 ? { name: f.name, b64, sheets: count } : null }))
    setBdFile({ name: f.name, bytes: final, sheets: count })
    setDoc((d) => ({ ...d, [key]: tidy(tr.text) }))
    setEditing((e) => ({ ...e, [key]: false }))
    setBdNote(single ? `The workbook has no empty cells I could recognise as inputs, so the budget was prepared in the template's categories on one sheet called "${out.name}". Export it below and copy the figures into the funder's own sheet if it must be used.` : `The workbook has no empty cells I could recognise as inputs, so the budget was prepared in the template's categories and added as a new sheet called "${out.name}". The funder's ${sheetCount} original sheet${sheetCount === 1 ? '' : 's'} are unchanged, with their formatting. Copy the figures across if the funder wants them in its own cells.`)
    window.whop?.track?.('budget_workbook_sheet_added')
  }

  // An Excel template is filled in place: every sheet, merged cell, format and formula stays as the funder made it.
  async function fillBudgetWorkbookFrom(f: File, key: string, mainOverride?: string) {
    const buf = await f.arrayBuffer()
    let sheets
    try {
      sheets = describeXlsx(buf)
    } catch {
      throw new Error('parse')
    }
    // With no budget section in the application form, the result is one main budget sheet. Otherwise every sheet is kept.
    // Every sheet of the funder's workbook is filled and exported, also when the form has no budget section.
    const single = false as boolean
    const main = single ? (mainOverride && sheets.some((x) => x.name === mainOverride) ? mainOverride : pickMainSheet(sheets)) : ''
    if (single) setBdSrc({ file: f, sheets: sheets.map((x) => x.name), main })
    // Each sheet gets its own share of the space. Sheets that hold blank cells or formulas (the likely budget tables) come first and get more.
    const blocks: { text: string; weight: number; main?: boolean }[] = []
    for (const sh of sheets) {
      const textCount = new Map<number, number>()
      for (const c of sh.cells) if (c.text && !c.formula) { const rr = Number((c.ref.match(/\d+/) ?? ['0'])[0]); if (rr <= 30) textCount.set(rr, (textCount.get(rr) ?? 0) + 1) }
      const headerRow = [...textCount.entries()].sort((a, b) => b[1] - a[1] || a[0] - b[0])[0]?.[0]
      const inputLike = sh.cells.filter((c) => c.blank || c.formula).length
      const out: string[] = [`SHEET "${sh.name}"${single && sh.name === main ? ' (MAIN BUDGET SHEET)' : ''}${headerRow ? ` (probable header row ${headerRow})` : ''}${sh.merges.length ? ` (merged: ${sh.merges.slice(0, 20).join(', ')})` : ''}${inputLike ? '' : ' (text only, probably instructions)'}`]
      const rows = new Map<number, string[]>()
      for (const c of sh.cells) {
        const row = Number((c.ref.match(/\d+/) ?? ['0'])[0])
        const item = c.formula ? (single && sh.name === main && c.formula.includes('!') ? `${c.ref}=<LINKED TO ANOTHER SHEET (${c.formula.slice(0, 60)}): FILL WITH A FIXED NUMBER>` : `${c.ref}=<formula ${c.formula.slice(0, 80)}>`) : c.blank ? `${c.ref}=[blank]` : `${c.ref}="${c.text.slice(0, inputLike ? 160 : 90)}"`
        if (!c.formula && !c.blank && !c.text) continue
        rows.set(row, [...(rows.get(row) ?? []), item])
      }
      for (const [, items] of [...rows.entries()].sort((a, b) => a[0] - b[0]).slice(0, inputLike ? 240 : 14)) out.push(items.slice(0, 24).join(' | '))
      blocks.push({ text: out.join('\n'), weight: single ? (sh.name === main ? 10 : 1) : inputLike ? 4 : 1, main: single && sh.name === main })
    }
    const totalWeight = blocks.reduce((t, x) => t + x.weight, 0) || 1
    const ordered = single ? [...blocks.filter((x) => x.main), ...blocks.filter((x) => !x.main).slice(0, 14)] : blocks
    const lines = ordered.map((x) => {
      const cap = single ? (x.main ? 6500 : 380) : Math.max(1200, Math.floor((15000 * x.weight) / totalWeight))
      return x.text.length > cap ? x.text.slice(0, cap) + '\n...' : x.text
    })
    if (single && blocks.length > ordered.length) lines.push(`OTHER SHEETS NOT SHOWN: ${sheets.filter((x) => !ordered.some((o) => o.text.startsWith(`SHEET "${x.name}"`))).map((x) => x.name).join(', ').slice(0, 400)}`)
    const description = lines.join('\n')
    if (description.length < 60) throw new Error('parse')
    const asked = Number((project.amount ?? '').replace(/[^0-9.]/g, '')) || 0
    const r = await fillBudgetWorkbook({ data: { profile, description, context: budgetCtx(), amount: project.amount, months: project.months, rules: budgetRules() || undefined, sheetNames: sheets.map((x) => x.name), mainSheet: single ? main : undefined } })
    if (!r.ok) {
      if (!('noInputs' in r && r.noInputs)) { setBdNote(r.reason); return }
      await addPreparedSheet(buf, f, key, sheets.length, single)
      return
    }
    const fills = r.fills.map((x) => ({ ...x }))
    // A second pass fills each sheet that has blank input cells but received nothing, one sheet at a time, with the figures already chosen as context.
    const blankSheets = sheets.filter((sh) => sh.cells.some((c) => c.blank) && !fills.some((x) => x.sheet === sh.name))
    if (blankSheets.length) {
      const done = fills.filter((x) => x.kind === 'line' && typeof x.value === 'number').slice(0, 40).map((x) => `${x.sheet}: ${x.label || x.cell} = ${x.value}`).join('; ')
      for (const sh of blankSheets.slice(0, 8)) {
        const blk = blocks[sheets.indexOf(sh)]
        if (!blk) continue
        try {
          const r2 = await fillBudgetWorkbook({ data: { profile, description: blk.text.slice(0, 12000), context: `Figures already chosen on the other sheets of this workbook (stay consistent with them): ${done.slice(0, 1400)}\n\n` + budgetCtx(), amount: project.amount, months: project.months, rules: budgetRules() || undefined, sheetNames: [sh.name] } })
          if (r2.ok) fills.push(...r2.fills.map((x) => ({ ...x })))
        } catch {}
      }
    }
    // Scale the money lines so the total matches the amount requested.
    const allLines = fills.filter((x) => x.kind === 'line' && typeof x.value === 'number' && x.value > 0)
    // Sheets can repeat the same budget (a summary and a detail sheet), so the biggest sheet sets the scale and only sheets of a similar size follow it.
    const sheetSum = new Map<string, number>()
    for (const x of allLines) sheetSum.set(x.sheet, (sheetSum.get(x.sheet) ?? 0) + (x.value as number))
    const refSheet = [...sheetSum.entries()].sort((a, b) => b[1] - a[1])[0]
    const lineFills = refSheet ? allLines.filter((x) => x.sheet === refSheet[0] || Math.abs((sheetSum.get(x.sheet) ?? 0) - refSheet[1]) < refSheet[1] * 0.08) : []
    if (asked && lineFills.length) {
      const target = r.indirectInFormulas ? asked / (1 + r.indirectRate) : asked
      const sum = refSheet ? refSheet[1] : 0
      if (sum > 0) {
        const k = target / sum
        lineFills.forEach((x) => { const c = (x.value as number) * k; x.value = c >= 20 ? Math.round(c) : Math.round(c * 100) / 100 })
        const last = lineFills.filter((x) => x.sheet === refSheet![0])
        const diff = Math.round((target - last.reduce((t, x) => t + (x.value as number), 0)) * 100) / 100
        if (Math.abs(diff) < target * 0.02) last[last.length - 1].value = Math.round(((last[last.length - 1].value as number) + diff) * 100) / 100
      }
    }
    // Totals the template left blank are added up from the final values.
    const known = new Map<string, number>()
    for (const sh of sheets) for (const c of sh.cells) { const n = Number(c.text.replace(/,/g, '')); if (c.text && Number.isFinite(n)) known.set(`${sh.name}!${c.ref}`, n) }
    for (const x of fills) if (typeof x.value === 'number' && x.kind !== 'total') known.set(`${x.sheet}!${x.cell}`, x.value)
    for (const x of fills.filter((y) => y.kind === 'total' && y.sumRange)) {
      const [a, b] = (x.sumRange as string).split(':')
      const pa = a.match(/^([A-Z]+)(\d+)$/), pb = (b ?? a).match(/^([A-Z]+)(\d+)$/)
      if (!pa || !pb) continue
      const col = (L: string) => L.split('').reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0) - 1
      let t = 0
      for (let ci = col(pa[1]); ci <= col(pb[1]); ci++) for (let ri = Number(pa[2]); ri <= Number(pb[2]); ri++) t += known.get(`${x.sheet}!${cellRef(ci, ri)}`) ?? 0
      x.value = Math.round(t * 100) / 100
      known.set(`${x.sheet}!${x.cell}`, x.value)
    }
    const out = fillXlsx(buf, fills as Fill[], single ? (sh, fm) => sh === main && fm.includes('!') : undefined)
    if (!out.written) { setBdNote('The AI could not place any values in that workbook. Check that it is the funder\'s budget template.'); return }
    let outBytes = out.bytes
    let sheetCount = sheets.length
    let converted = 0
    if (single && sheets.length > 1) {
      const k = keepOnlySheet(out.bytes, main)
      outBytes = k.bytes
      converted = k.converted
      sheetCount = 1
    }
    const b64 = toB64(outBytes)
    patch((a) => ({ ...a, budgetFile: b64.length < 1_400_000 ? { name: f.name, b64, sheets: sheetCount } : null }))
    setBdFile({ name: f.name, bytes: outBytes, sheets: sheetCount })
    // The proposal section gets a plain summary of the same figures.
    const money = (n: number) => n.toLocaleString('en-US', { maximumFractionDigits: 2 })
    const cost = fills.filter((x) => x.kind === 'line' && typeof x.value === 'number')
    const total = Math.round(cost.reduce((t, x) => t + (x.value as number), 0) * 100) / 100
    const cell = (t: string) => t.replace(/\|/g, '/')
    const table = ['| Sheet | Cost line | Amount (USD) |', '|---|---|---|', ...cost.map((x) => `| ${cell(x.sheet)} | ${cell(x.label || x.cell)} | ${money(x.value as number)} |`), `| **Total** | | **${money(total)}** |`].join('\n')
    const text = `${single ? `Budget prepared on the funder's main budget sheet, "${main}"` : `Budget prepared in the funder's budget template (${sheets.length} sheet${sheets.length === 1 ? '' : 's'}, filled in place)`}. Amounts in USD.\n\n${table}\n\n${r.notes ? 'Assumptions: ' + r.notes + ' ' : ''}Unit costs are estimates: replace them with your own quotes and local rates before submitting.`
    setDoc((d) => ({ ...d, [key]: tidy(text) }))
    setEditing((e) => ({ ...e, [key]: false }))
    setBdNote(single && sheets.length > 1 ? `AI filled in the main budget sheet, "${main}" (${out.written} cells), and kept its formatting and formulas. The other ${sheets.length - 1} sheet${sheets.length === 2 ? '' : 's'} of the funder's workbook are not included.${converted ? ` ${converted} cell${converted === 1 ? '' : 's'} that pulled figures from those sheets now hold fixed values, so check them.` : ''} Export it below and check the figures.` : `AI filled in the funder's workbook: ${out.written} cells across ${sheets.length} sheet${sheets.length === 1 ? '' : 's'}, with every sheet, format and formula kept. Download it below and check the figures.`)
    window.whop?.track?.('budget_workbook_filled')
  }

  const [bdFile, setBdFile] = useState<{ name: string; bytes: Uint8Array; sheets: number } | null>(null)

  const [bdSrc, setBdSrc] = useState<{ file: File; sheets: string[]; main: string } | null>(null)

  const [bdPick, setBdPick] = useState('')

  function downloadFilledWorkbook() {
    const bytes = bdFile?.bytes ?? (app?.budgetFile ? fromB64(app.budgetFile.b64) : null)
    if (!bytes) return
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([bytes as BlobPart], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }))
    a.download = exportName('budget', 'xlsx')
    a.click()
  }

  const [bdBusy, setBdBusy] = useState('')

  const [bdNote, setBdNote] = useState('')

  // Reads the funder's budget template (Excel, Word or PDF) with AI and prepares the budget in the template's own structure.
  async function importBudgetTemplate(f: File, key: string) {
    setBdBusy(key)
    setBdNote('')
    if (/\.xlsx$/i.test(f.name)) {
      try {
        await fillBudgetWorkbookFrom(f, key)
      } catch (e) {
        setBdNote(fileErrorText(e))
      }
      setBdBusy('')
      return
    }
    try {
      const text = (await readAnyFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 30) setBdNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      else {
        const r = await budgetFromTemplate({ data: { profile, text, context: budgetCtx(), amount: project.amount, months: project.months, rules: budgetRules() || undefined } })
        if (r.ok) {
          setDoc((d) => ({ ...d, [key]: tidy(r.text) }))
          setEditing((e) => ({ ...e, [key]: false }))
          setBdNote('AI prepared the budget in the funder\'s template structure. Check the unit costs against your own quotes before you submit.')
          window.whop?.track?.('budget_template_imported')
        } else setBdNote(r.reason)
      }
    } catch (e) {
      setBdNote(fileErrorText(e))
    }
    setBdBusy('')
  }

  // ---- Pop-ups opened from the imported grant guidance ----
  const [reviewOpen, setReviewOpen] = useState(false)

  const [shareOpen, setShareOpen] = useState(false)

  const [privacyOpen, setPrivacyOpen] = useState(false)

  const [theme, setTheme] = useStored<'auto' | 'light' | 'dark'>('ngw_theme', 'auto')

  useEffect(() => {
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const apply = () => { document.documentElement.dataset.theme = theme === 'auto' ? (mq.matches ? 'dark' : 'light') : theme }
    apply()
    mq.addEventListener('change', apply)
    return () => mq.removeEventListener('change', apply)
  }, [theme])

  const [historyOpen, setHistoryOpen] = useState(false)

  const [modal, setModal] = useState<'elig' | 'frame' | null>(null)

  const [fiTab, setFiTab] = useState<'form' | 'guidance' | 'link'>('form')

  const [eligDraft, setEligDraft] = useState<(EligibilityItem & { note?: string })[]>([])

  const [frameDraft, setFrameDraft] = useState<{ options: FrameworkOptions; selected: Partial<Record<keyof FrameworkOptions, string[]>> } | null>(null)

  const [modalBusy, setModalBusy] = useState(false)

  const [modalNote, setModalNote] = useState('')

  const guidanceSource = () => app?.guidanceText || (app?.guidance ? guidanceText(app.guidance) : '')

  // Which source the AI reads for the eligibility checklist and the priorities list: the imported guidance, the funder's website link, or both.
  type SrcMode = 'auto' | 'guidance' | 'link' | 'both'
  const [srcMode, setSrcMode] = useState<SrcMode>('auto')
  const [srcUsed, setSrcUsed] = useState('')
  const [linkInput, setLinkInput] = useState('')
  const sourceLink = () => (app?.grantLink ?? app?.grant?.url ?? '').trim()

  async function gatherSource(mode: SrcMode = srcMode): Promise<{ text: string; note: string; used: string }> {
    const guidance = guidanceSource().trim()
    const link = sourceLink()
    const want = mode === 'auto' ? (guidance && link ? 'both' : guidance ? 'guidance' : 'link') : mode
    if ((want === 'guidance' || want === 'both') && !guidance && want === 'guidance') return { text: '', note: 'No guidance is imported yet. Import it in Funder information, under Guidance, or choose the website link.', used: '' }
    if (want === 'link' && !link) return { text: '', note: 'Add the funder\'s website link below first, or choose the guidance.', used: '' }
    let note = ''
    let linkText = ''
    if (want === 'link' || want === 'both') {
      linkText = app?.linkFetched === link ? app?.linkText ?? '' : ''
      if (!linkText && link) {
        try {
          const r = await readGrantLink({ data: { url: link } })
          if (r.ok) { linkText = r.text; patch((a) => ({ ...a, linkText: r.text, linkFetched: link })) }
          else note = r.reason
        } catch { note = 'I could not read the funder\'s website link. Check it and try again.' }
      }
    }
    if (want === 'link') return linkText ? { text: `FUNDER WEBSITE (${link}):\n` + linkText, note: '', used: 'the funder\'s website link' } : { text: '', note: note || 'I could not read the funder\'s website link.', used: '' }
    if (want === 'guidance') return { text: guidance, note: '', used: 'the imported guidance' }
    // Both: the guidance leads and the website adds to it. Each is trimmed so that both fit what the AI can read at once.
    if (guidance && linkText) return { text: `IMPORTED GUIDANCE:\n${guidance.slice(0, 5500)}\n\nFUNDER WEBSITE (${link}):\n${linkText.slice(0, 4000)}`, note: '', used: 'the imported guidance and the funder\'s website link' }
    if (guidance) return { text: guidance, note: (note || 'No website link was given.') + ' This result uses the imported guidance only.', used: 'the imported guidance' }
    if (linkText) return { text: `FUNDER WEBSITE (${link}):\n` + linkText, note: 'No guidance is imported, so this result uses the website link only.', used: 'the funder\'s website link' }
    return { text: '', note: note || 'Import the grant guidance or add the funder\'s website link first.', used: '' }
  }

  async function runEligibility(mode: SrcMode = srcMode) {
    setModalBusy(true)
    setModalNote('')
    try {
      const src = await gatherSource(mode)
      if (!src.text.trim()) { setModalNote(src.note || 'Add a grant website link or import the grant guidance first.'); setModalBusy(false); return }
      setSrcUsed(src.used)
      const r = await eligibilityChecklist({ data: { text: src.text, profile, library: libraryDigest(lib, 1800, src.text.slice(0, 1500)) } })
      if (r.ok) { setEligDraft(r.items.map((x) => ({ ...x }))); if (src.note) setModalNote(src.note) }
      else setModalNote(r.reason)
    } catch {
      setModalNote('Something went wrong. Please try again.')
    }
    setModalBusy(false)
  }

  function openEligibility() {
    setModal('elig')
    setModalNote('')
    setSrcMode('auto')
    setSrcUsed('')
    setLinkInput('')
    const link = (app?.grantLink ?? app?.grant?.url ?? '').trim()
    const stale = !!link && !!app?.linkFetched && app.linkFetched !== link
    const saved = stale ? null : app?.eligibility
    if (saved?.length) setEligDraft(saved.map((x) => ({ ...x })))
    else setEligDraft([])
  }

  async function runFramework(mode: SrcMode = srcMode) {
    setModalBusy(true)
    setModalNote('')
    try {
      const src = await gatherSource(mode)
      if (!src.text.trim()) { setModalNote(src.note || 'Add a grant website link or import the grant guidance first.'); setModalBusy(false); return }
      setSrcUsed(src.used)
      const r = await extractFramework({ data: { text: src.text } })
      if (r.ok) { setFrameDraft((cur) => ({ options: r.options, selected: cur?.selected ?? {} })); if (src.note) setModalNote(src.note) }
      else setModalNote(r.reason)
    } catch {
      setModalNote('Something went wrong. Please try again.')
    }
    setModalBusy(false)
  }

  function openFramework() {
    setModal('frame')
    setModalNote('')
    setSrcMode('auto')
    setSrcUsed('')
    setLinkInput('')
    const link = (app?.grantLink ?? app?.grant?.url ?? '').trim()
    if (app?.framework && !(link && app.linkFetched && app.linkFetched !== link)) setFrameDraft({ options: app.framework.options, selected: { ...app.framework.selected } })
    else setFrameDraft(null)
  }

  function saveModal() {
    if (modal === 'elig') patch((a) => ({ ...a, eligibility: eligDraft }))
    if (modal === 'frame' && frameDraft) patch((a) => ({ ...a, framework: frameDraft }))
    window.whop?.track?.(modal === 'elig' ? 'eligibility_saved' : 'framework_saved')
    setModal(null)
  }

  useEffect(() => {
    if (modal && (view !== 'applications' || !appOpen)) setModal(null)
    if ((reviewOpen || historyOpen || shareOpen) && (view !== 'applications' || !appOpen)) { setReviewOpen(false); setHistoryOpen(false); setShareOpen(false) }
  }, [view, appOpen, modal, reviewOpen, historyOpen, shareOpen])

  useEffect(() => {
    if (!modal) return
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setModal(null) }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [modal])

  // Checks which selected framework items appear in the written sections (by their key words).
  const frameworkCoverage = (() => {
    const sel = app?.framework?.selected
    if (!sel) return null
    const all = secs.map(([k]) => doc[k] ?? '').join(' ').toLowerCase()
    if (all.trim().length < 80) return null
    const words = (t: string) => [...new Set(t.toLowerCase().replace(/[^a-z0-9% ]+/g, ' ').split(/\s+/).filter((w) => w.length > 3))]
    const items = FRAME_FIELDS.flatMap(([k, group]) => ((sel[k] ?? []) as string[]).map((text) => ({ group, text })))
    if (!items.length) return null
    const missing = items.filter(({ text }) => {
      const w = words(text)
      if (!w.length) return false
      return w.filter((x) => all.includes(x)).length / w.length < 0.6
    })
    return { total: items.length, covered: items.length - missing.length, missing }
  })()

  const [gdBusy, setGdBusy] = useState(false)

  const [gdNote, setGdNote] = useState('')

  async function importGuidance(f: File) {
    setGdBusy(true)
    setGdNote('')
    try {
      const text = (await readAnyFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 40) setGdNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      else {
        const r = await analyzeGuidance({ data: { text, profile } })
        if (r.ok) {
          patch((a) => ({ ...a, guidance: r.guidance, guidanceText: text.slice(0, 14000), eligibility: null, framework: null }))
          setGdNote('AI analyzed the grant guidance. It will keep these points in mind when it writes your sections.')
          window.whop?.track?.('guidance_imported')
        } else setGdNote(r.reason)
      }
    } catch (e) {
      setGdNote(fileErrorText(e))
    }
    setGdBusy(false)
  }


  async function importTemplate(text: string, fileName: string) {
    setTplBusy(true)
    setTplNote('')
    try {
      const t = text.replace(/\s+\n/g, '\n').trim()
      if (t.length < 40) {
        setTplNote('I could not read any text from that file.')
      } else {
        const r = await parseTemplate({ data: { text: t } })
        if (r.ok) {
          const stamp = Date.now().toString(36)
          setTpl({
            name: r.funder || target?.funder || fileName,
            sections: r.sections.map((x: any, i: number) => ({ key: `t${stamp}_${i}`, title: x.title, guidance: x.guidance, wordLimit: x.wordLimit, limit: x.limit || undefined, limitUnit: x.limitUnit, group: x.group || undefined, type: x.type, options: x.options?.length ? x.options : undefined, explain: x.explain || undefined, required: x.required || undefined, unit: x.unit || undefined })),
          })
          const nChoice = r.sections.filter((x: any) => x.type && x.type !== 'text' && x.type !== 'table').length
          setTplNote(`Imported ${r.sections.length} fields from the template${nChoice ? `, ${nChoice} of them as yes/no, drop-down, tick-box, number or date fields` : ''}. Review them below.`)
          setTplPaste('')
        } else setTplNote(r.reason)
      }
    } catch {
      setTplNote('Could not read that file. Use a Word (.docx), PDF, Excel (.xlsx), CSV or text file.')
    }
    setTplBusy(false)
  }


  const [impOpen, setImpOpen] = useState(false)

  const [impName, setImpName] = useState('')

  const [impRows, setImpRows] = useState<string[][]>([])

  const [impHeaders, setImpHeaders] = useState<string[]>([])

  const [impMap, setImpMap] = useState<Record<string, number>>({})

  const [impNote, setImpNote] = useState('')

  const [impSaveAll, setImpSaveAll] = useState(false)

  const [impBusy, setImpBusy] = useState(false)

  const [impDone, setImpDone] = useState<Grant[]>([])


  async function loadImportFile(f: File) {
    setImpBusy(true)
    setImpNote('')
    try {
      const table = (await readGrantTable(f)).slice(0, 1001)
      if (table.length < 2) {
        setImpNote('I found no data rows. The first row must be the column headings.')
        setImpRows([])
      } else {
        setImpHeaders(table[0].map((h) => h.trim()))
        setImpRows(table.slice(1))
        setImpMap(detectMapping(table[0]))
        setImpName(f.name)
      }
    } catch (e: any) {
      setImpNote(e?.message === 'xls' ? 'Old .xls files are not supported. Save it as .xlsx or .csv and try again.' : 'Could not read that file. Use .xlsx or .csv.')
      setImpRows([])
    }
    setImpBusy(false)
  }


  function runImport() {
    const { grants, skipped } = buildImported(impRows, impMap)
    if (!grants.length) {
      setImpNote('No grants could be imported. Check that the Grant name column is mapped.')
      return
    }
    setResults(grants)
    setImpDone(grants)
    setImportedGrants((cur) => [...grants, ...cur.filter((x) => !grants.some((g) => g.id === x.id))].slice(0, 3000))
    setNotes([])
    setAiInfo(null)
    dropTomb('ngw_removed', grants.map((g) => g.id))
    if (impSaveAll) setSaved((cur) => [...grants, ...cur.filter((x) => !grants.some((g) => g.id === x.id))])
    setImpNote(`Imported ${grants.length} grant${grants.length === 1 ? '' : 's'}${skipped ? `, skipped ${skipped} (no name or duplicate)` : ''}. They are listed below and in your Grants pipeline.`)
    setImpRows([])
    setImpName('')
    window.whop?.track?.('grants_imported_file')
  }


  const [linkUrl, setLinkUrl] = useState('')

  const [linkText, setLinkText] = useState('')

  const [linkNote, setLinkNote] = useState('')

  const [linkBusy, setLinkBusy] = useState(false)

  const [linkGrant, setLinkGrant] = useState<Grant | null>(null)

  const [needPaste, setNeedPaste] = useState(false)


  async function addByLink(e?: React.FormEvent) {
    e?.preventDefault()
    setLinkBusy(true)
    setLinkNote('')
    setLinkGrant(null)
    try {
      const r = await addGrantFromLink({ data: { url: linkUrl, text: linkText } })
      if (r.ok) {
        const g = r.grant
        dropTomb('ngw_removed', [g.id])
        setSaved((cur) => [g, ...cur.filter((x) => x.id !== g.id)])
        setLinkGrant(g)
        setNeedPaste(false)
        setLinkUrl('')
        setLinkText('')
        setLinkNote('Added to your saved grants. Analyzing fit...')
        try {
          const f = await fitFor(g)
          setFits((cur) => ({ ...cur, [g.id]: f }))
          setLinkNote('Added to your saved grants and analyzed. Press Show fit to see the analysis.')
        } catch {
          setLinkNote('Added to your saved grants. Fit analysis failed, press Fit analysis to retry.')
        }
        window.whop?.track?.('grant_added_by_link')
      } else {
        setLinkNote(r.reason)
        setNeedPaste(/paste|script/i.test(r.reason))
      }
    } catch {
      setLinkNote('Something went wrong. Please try again.')
    }
    setLinkBusy(false)
  }


  const isSaved = (id: string) => saved.some((g) => g.id === id)

  const toggleSave = (g: Grant) => {
    if (!isSaved(g.id)) { dropTomb('ngw_removed', [g.id]); setSaved([{ ...g, checkedAt: g.checkedAt ?? Date.now() }, ...saved]); return }
    removeGrant(g)
  }

  // Removes a grant from the pipeline for good: it leaves your saved grants and every stage, and a refresh or a new search does not bring it back.
  // Saving it again yourself, or starting an application for it, undoes this.
  const removeGrant = (g: Grant) => {
    askConfirm(`Remove "${g.title}" from your pipeline? It will not come back after a refresh.`, { title: 'Remove grant?' }).then((ok) => {
      if (!ok) return
      addTomb('ngw_removed', [g.id])
      setSaved((cur) => cur.filter((x) => x.id !== g.id))
      setSeen((cur) => cur.filter((x) => x.id !== g.id))
      setResults((cur) => (cur ? cur.filter((x) => x.id !== g.id) : cur))
      setImportedGrants((cur) => cur.filter((x) => x.id !== g.id))
    })
  }

  // Deletes an application here and in your online copy. It is remembered, so the online copy cannot bring it back on a refresh.
  const deleteApplication = (id: string) => {
    addTomb('ngw_deleted_apps', [id])
    setApps((cur) => cur.filter((x) => x.id !== id))
    if (activeId === id) { setAppOpen(false); setActiveId(null) }
    if (online?.signedIn) deleteSaved({ data: { id } }).catch(() => {})
  }

  // Online applications minus the ones you deleted. A deleted one that is still online is deleted there again.
  const liveRemote = <T extends { id: string }>(items: T[]): T[] => {
    const gone = new Set(readTomb('ngw_deleted_apps'))
    for (const it of items) if (gone.has(it.id)) deleteSaved({ data: { id: it.id } }).catch(() => {})
    return items.filter((it) => !gone.has(it.id))
  }


  async function runSearch(e?: React.FormEvent, kw?: string) {
    e?.preventDefault()
    setBusy('search')
    setNotes([])
    try {
      const keyword = (kw ?? q).trim() || profile.focus.trim() || 'community development'
      const r = await searchGrants({ data: { keyword, sources: (source.length ? source : ALL_SOURCES) as Src[] } })
      setResults(r.grants)
      setNotes(r.errors)
      window.whop?.track?.('grant_search')
    } catch {
      setNotes(['Search failed. Please try again.'])
    }
    setBusy('')
  }


  const [webNote, setWebNote] = useState('')

  async function runCombined(e?: React.FormEvent) {
    e?.preventDefault()
    if (!modes.length) {
      setNotes(['Pick at least one search method.'])
      return
    }
    setBusy('search')
    setNotes([])
    setWebNote('')
    setAiInfo(null)
    const errs: string[] = []
    const lists: Grant[][] = []
    const jobs: Promise<void>[] = []
    const ALL = ALL_SOURCES
    if (modes.includes('keyword')) {
      jobs.push((async () => {
        const keyword = q.trim() || profile.focus.trim() || 'community development'
        const r = await searchGrants({ data: { keyword, sources: (source.length ? source : ALL) as Src[] } })
        lists[0] = r.grants
        errs.push(...r.errors)
      })().catch(() => void errs.push('Keyword search failed.')))
    }
    if (modes.includes('filters')) {
      jobs.push((async () => {
        const sources = ALL.filter((x) => aSources.includes(x))
        if (!sources.length) { errs.push('Advanced filters: pick at least one source.'); return }
        const kw = [aAll, aAny].join(' ').trim() || q.trim() || profile.focus.trim()
        const r = await searchGrants({
          data: {
            keyword: kw,
            sources,
            us: { eligibilities: aElig, categories: aCats, instruments: aInstr, postedWithin: aPosted ? Number(aPosted) : undefined },
            euStatus: aEu.length === 1 ? (aEu[0] as 'open' | 'forthcoming') : 'both',
          },
        })
        const need = aAll.toLowerCase().split(/\s+/).filter(Boolean)
        const any = aAny.toLowerCase().split(/[\s,]+/).filter(Boolean)
        const not = aNot.toLowerCase().split(/[\s,]+/).filter(Boolean)
        const fun = aFunder.toLowerCase().trim()
        lists[1] = r.grants.filter((g) => {
          const hay = `${g.title} ${g.summary ?? ''} ${g.funder}`.toLowerCase()
          if (need.length && !need.every((w) => hay.includes(w))) return false
          if (any.length && !any.some((w) => hay.includes(w))) return false
          if (not.length && not.some((w) => hay.includes(w))) return false
          if (fun && !g.funder.toLowerCase().includes(fun)) return false
          return true
        })
        errs.push(...r.errors)
      })().catch(() => void errs.push('Advanced filter search failed.')))
    }
    if (modes.includes('ai')) {
      jobs.push((async () => {
        const request = aiText.trim() || (profile.fundingNeed ?? '').trim()
        if (!request && !(aiUseProfile && profile.focus.trim())) { errs.push('AI search: describe what you are looking for, or add sectors or a funding description to your profile.'); return }
        const r = await aiSearchGrants({ data: { request, profile, useProfile: aiUseProfile, libraryNote: libraryDigest(lib, 1500, `${request} ${profile.focus}`) } })
        lists[2] = r.grants
        errs.push(...r.errors)
        setAiInfo({ queries: r.queries, note: r.note, usedAi: r.usedAi })
      })().catch(() => void errs.push('AI search failed.')))
    }
    if (modes.includes('imported')) {
      jobs.push((async () => {
        const words = q.toLowerCase().split(/[\s,;]+/).filter((w) => w.length > 1)
        if (!importedGrants.length) { errs.push('Imported-files search: no files imported yet. Use Import from Excel or CSV first.'); return }
        const scored = importedGrants.map((g) => {
          const hay = `${g.title} ${g.funder} ${g.summary ?? ''} ${(g.sectors ?? []).join(' ')} ${(g.countries ?? []).join(' ')} ${g.gtype ?? ''}`.toLowerCase()
          return { g, n: words.filter((w) => hay.includes(w)).length }
        })
        const need = words.length ? Math.max(1, Math.ceil(words.length / 2)) : 0
        lists[5] = scored.filter((x) => x.n >= need).sort((a, b) => b.n - a.n).map((x) => x.g).slice(0, 200)
      })().catch(() => void errs.push('Imported-files search failed.')))
    }
    if (modes.includes('web')) {
      jobs.push((async () => {
        const r = await searchWebForGrants({ data: { keyword: q.trim() || (profile.fundingNeed ?? '').trim().slice(0, 80), profile } })
        if (r.ok) {
          lists[3] = r.grants
          setWebNote('')
        } else setWebNote(r.reason)
      })().catch(() => setWebNote('Internet search failed. Please try again.')))
    }
    if (modes.includes('profile')) {
      jobs.push((async () => {
        if (!csv(profile.focus).length && !(profile.fundingNeed ?? '').trim()) { errs.push('Profile-based search: pick your sectors or describe the funding you need in the organization profile first.'); return }
        const r = await aiSearchGrants({ data: { request: profile.fundingNeed ?? '', profile, useProfile: true, libraryNote: libraryDigest(lib, 1500, `${profile.fundingNeed ?? ''} ${profile.focus}`) } })
        lists[4] = r.grants
        errs.push(...r.errors)
        setAiInfo({ queries: r.queries, note: r.note, usedAi: r.usedAi })
      })().catch(() => void errs.push('Profile-based search failed.')))
    }
    await Promise.all(jobs)
    const seenIds = new Set<string>()
    const merged: Grant[] = []
    for (const l of lists) for (const g of l ?? []) if (!seenIds.has(g.id)) { seenIds.add(g.id); merged.push(g) }
    setResults(merged)
    setNotes([...new Set(errs)])
    setFStatus([]); setFDeadline([]); setFSource([]); setFText(''); setSort('priority'); setOnlyDated(false); setFCountry([]); setFType([]); setFSector([]); setFAmin(''); setFAmax('')
    window.whop?.track?.('grant_search_combined', { methods: modes.join(',') })
    setBusy('')
  }


  const [genBusy, setGenBusy] = useState(false)
  // Generated funding-need text is shown as read-only until the person chooses Edit.
  const [needLocked, setNeedLocked] = useState(false)

  const [genNote, setGenNote] = useState('')

  // Writes or improves the "funding you need" description in the organization profile.
  async function aiNeed(kind: 'generate' | 'improve') {
    setGenBusy(true)
    setGenNote('')
    const current = (profile.fundingNeed ?? '').trim()
    const local = () => {
      const bits = [
        `We are ${profile.orgType ? 'a ' + profile.orgType.toLowerCase() : 'an organization'}${profile.country ? ' based in ' + profile.country : ''}.`,
        csv(profile.focus).length ? `We work in ${csv(profile.focus).join(', ').toLowerCase()}${csv(profile.populations).length ? ' with ' + csv(profile.populations).join(', ').toLowerCase() : ''}.` : '',
        profile.mission ? profile.mission : '',
        profile.amountMin || profile.amountMax ? `We are looking for ${csv(profile.grantTypes).join(', ').toLowerCase() || 'grant funding'} of ${profile.amountMin ? '$' + profile.amountMin : ''}${profile.amountMin && profile.amountMax ? ' to ' : ''}${profile.amountMax ? '$' + profile.amountMax : ''}.` : '',
      ]
      return bits.filter(Boolean).join(' ')
    }
    try {
      const r = await generateFundingNeed({ data: { profile, current: kind === 'improve' ? current : undefined } })
      if (r.ok) {
        setProfile((p) => ({ ...p, fundingNeed: r.text }))
        setNeedLocked(true)
        setGenNote(kind === 'improve' ? 'Improved. Read it through and choose Edit to change anything.' : 'Written from your profile. Choose Edit to change anything.')
      } else if (kind === 'generate') {
        setProfile((p) => ({ ...p, fundingNeed: local() }))
        setNeedLocked(true)
        setGenNote('AI was not available, so I assembled this from your profile fields. Choose Edit to change it.')
      } else setGenNote(r.reason)
    } catch {
      if (kind === 'generate') {
        setProfile((p) => ({ ...p, fundingNeed: local() }))
        setNeedLocked(true)
        setGenNote('AI was not available, so I assembled this from your profile fields. Choose Edit to change it.')
      } else setGenNote('Something went wrong. Please try again.')
    }
    setGenBusy(false)
  }

  const [pastBusy, setPastBusy] = useState(false)
  const [pastLocked, setPastLocked] = useState(false)
  const [pastNote, setPastNote] = useState('')

  // Writes or improves "Past funding and key results" in the organization profile, from the profile and the Library documents only.
  async function aiPast(kind: 'generate' | 'improve') {
    setPastBusy(true)
    setPastNote('')
    try {
      const r = await writePastFunding({ data: { profile, current: kind === 'improve' ? (profile.pastFunding ?? '') : undefined, library: libraryDigest(lib, 2200, 'funding grant donor results past projects') } })
      if (r.ok) {
        setProfile((p) => ({ ...p, pastFunding: r.text }))
        setPastLocked(true)
        setPastNote(kind === 'improve' ? 'Improved. Check every line and fill any [placeholder].' : 'Written from your profile and Library. Fill every [placeholder] and check each line before you rely on it.')
      } else setPastNote(r.reason)
    } catch {
      setPastNote('Something went wrong. Please try again.')
    }
    setPastBusy(false)
  }

  // "What are you looking for?" in AI search: written or improved by AI, shown as a read-only card until Edit is chosen.
  const [askBusy, setAskBusy] = useState(false)
  const [askLocked, setAskLocked] = useState(false)
  const [askNote, setAskNote] = useState('')

  async function aiAsk(kind: 'generate' | 'improve') {
    setAskBusy(true)
    setAskNote('')
    const current = aiText.trim()
    const local = () => [
      `We are ${profile.orgType ? 'a ' + profile.orgType.toLowerCase() : 'an organization'}${profile.country ? ' based in ' + profile.country : ''}.`,
      csv(profile.focus).length ? `We work in ${csv(profile.focus).join(', ').toLowerCase()}${csv(profile.populations).length ? ' with ' + csv(profile.populations).join(', ').toLowerCase() : ''}.` : '',
      (profile.fundingNeed ?? '').trim() || profile.mission || '',
    ].filter(Boolean).join(' ')
    try {
      const r = await generateFundingNeed({ data: { profile, current: kind === 'improve' ? current : undefined } })
      if (r.ok) { setAiText(r.text); setAskLocked(true); setAskNote(kind === 'improve' ? 'Improved. Choose Edit to change anything.' : 'Written from your profile. Choose Edit to change anything.') }
      else if (kind === 'generate') { setAiText(local()); setAskLocked(true); setAskNote('AI was not available, so I assembled this from your profile. Choose Edit to change it.') }
      else setAskNote(r.reason)
    } catch {
      if (kind === 'generate') { setAiText(local()); setAskLocked(true); setAskNote('AI was not available, so I assembled this from your profile. Choose Edit to change it.') }
      else setAskNote('Something went wrong. Please try again.')
    }
    setAskBusy(false)
  }

  // Search for funding like one call: the AI reads that call and looks for similar ones.
  async function findSimilar(g: Grant) {
    setBusy('search')
    setNotes([])
    setWebNote('')
    try {
      const r = await aiSearchGrants({ data: { request: `Funding similar to "${g.title}" from ${g.funder}: ${(g.summary ?? '').slice(0, 300)}`, profile, useProfile: false, libraryNote: '' } })
      setResults(r.grants.filter((x) => x.id !== g.id))
      setNotes(r.errors)
      setAiInfo({ queries: r.queries, note: r.note, usedAi: r.usedAi })
      setFStatus([]); setFDeadline([]); setFSource([]); setFText(''); setSort('priority'); setOnlyDated(false); setFCountry([]); setFType([]); setFSector([]); setFAmin(''); setFAmax('')
    } catch {
      setNotes(['Search failed. Please try again.'])
    }
    setBusy('')
  }


  async function runProfileSearch() {
    setView('find')
    setModes((m) => (m.includes('profile') ? m : [...m, 'profile']))
    setBusy('search')
    setNotes([])
    try {
      const r = await aiSearchGrants({ data: { request: profile.fundingNeed ?? '', profile, useProfile: true, libraryNote: libraryDigest(lib, 1500, `${profile.fundingNeed ?? ''} ${profile.focus}`) } })
      setResults(r.grants)
      setNotes(r.errors)
      setAiInfo({ queries: r.queries, note: r.note, usedAi: r.usedAi })
      setFStatus([]); setFDeadline([]); setFSource([]); setFText(''); setOnlyDated(false); setFCountry([]); setFType([]); setFSector([]); setFAmin(''); setFAmax('')
      setSort('priority')
      window.whop?.track?.('grant_search_profile')
    } catch {
      setNotes(['Search failed. Please try again.'])
    }
    setBusy('')
  }


  const [fitProgress, setFitProgress] = useState('')

  const fitStopRef = useRef(false)

  const [fitBulkBusy, setFitBulkBusy] = useState(false)

  // One click scores every grant in the list that does not have a score for the current profile.
  // Grants go to the AI five at a time, so a long list needs only a few requests. A score stays the same until the profile changes.
  async function runFitBulk(list: Grant[]) {
    const uniq = [...new Map(list.map((g) => [g.id, g])).values()]
    const todo = uniq.filter((g) => !(fits[g.id] && fits[g.id].mode === 'ai'))
    if (!uniq.length) { setWebNote('There are no grants to analyze yet.'); return }
    if (!todo.length) { setWebNote(`All ${uniq.length} grants already have a fit score for your current profile. Open a grant's fit to read why.`); return }
    setFitBulkBusy(true)
    fitStopRef.current = false
    setWebNote('')
    const library = libraryDigest(lib, 900, '')
    let scored = 0
    let unscored = 0
    let stopped = ''
    for (let i = 0; i < todo.length; i += 5) {
      if (fitStopRef.current) { stopped = 'Stopped.'; break }
      const chunk = todo.slice(i, i + 5)
      setFitProgress(`Analyzing grants ${i + 1} to ${i + chunk.length} of ${todo.length}...`)
      let r: Awaited<ReturnType<typeof analyzeFitBatch>> | null = null
      for (let attempt = 0; attempt < 2 && !r; attempt++) {
        try { r = await analyzeFitBatch({ data: { profile, grants: chunk, library } }) } catch { r = null; await sleepMs(2500) }
      }
      if (!r) { unscored += chunk.length; continue }
      if (!r.ok) { stopped = r.reason; break }
      const got = Object.entries(r.results)
      setFits((cur) => ({ ...cur, ...Object.fromEntries(got.filter(([, f]) => f.mode === 'ai').map(([id, f]) => [id, { ...f, pk: profileKey } as Fit])) }))
      scored += got.filter(([, f]) => f.mode === 'ai').length
      unscored += got.filter(([, f]) => f.mode !== 'ai').length
      await sleepMs(400)
    }
    setFitProgress('')
    setFitBulkBusy(false)
    setWebNote(`Fit analysis done for ${scored} of ${todo.length} grant${todo.length === 1 ? '' : 's'}.${unscored ? ` ${unscored} could not be scored this time. Press the button again to retry them.` : ''}${stopped ? ' ' + stopped : ''}`)
    window.whop?.track?.('fit_all', { grants: scored })
  }

  function runFitAll() {
    const picked = shownFinal.filter((g) => cmpIds.includes(g.id))
    return runFitBulk(picked.length ? picked : shownFinal)
  }


  async function runFit(g: Grant) {
    setBusy('fit-' + g.id)
    setOpen(g.id)
    try {
      const prev = fitsAll[g.id]
      const keep = prev && prev.pk === profileKey && prev.mode === 'ai' ? prev : null
      const f = await fitFor(g, true)
      // With an unchanged profile the score never moves: a re-run refreshes the notes, and keeps the earlier score.
      if (keep && f.mode !== 'ai') { setFits((cur) => ({ ...cur, [g.id]: keep })); setBusy(''); return }
      setFits((cur) => ({ ...cur, [g.id]: keep ? { ...f, score: keep.score } : f }))
    } catch {}
    setBusy('')
  }


  const inputsCtx = (n = 1500, planN = 3500, primN = 1200) => {
    const areas = inputs.areas.filter(areaFilled).map((a) => `- ${areaLabel(a)}`).join('\n')
    return (
      ((app?.plan ?? '').trim() ? `PLANNED PROJECT INFORMATION (provided by the applicant; the proposal must follow it and never contradict it):\n${(app?.plan ?? '').trim().slice(0, planN)}\n\n` : '') +
      (inputs.needs.trim() ? `NEEDS ASSESSMENT (evidence to use):\n${inputs.needs.trim().slice(0, n)}\n\n` : '') +
      (areas ? `PLANNED TARGET AREAS:\n${areas}\n\n` : '') +
      (inputs.primary.trim() ? `PRIMARY INFORMATION ABOUT THE TARGET AREAS (written by the applicant):\n${inputs.primary.trim().slice(0, primN)}\n\n` : '')
    )
  }

  // The context sent with each AI write is kept compact and ordered by importance, so the AI answers faster and nothing important is cut off.
  const ctx = (skipKey?: string) =>
    (app?.guidance ? `GRANT GUIDANCE (follow it):\n${guidanceText(app.guidance).slice(0, 750)}\n\n` : '') + (app?.framework ? `FRAMEWORK THE PROJECT RESPONDS TO (reflect it): ${FRAME_FIELDS.map(([k, t]) => ((app.framework?.selected[k] ?? []).length ? `${t}: ${(app.framework?.selected[k] ?? []).join('; ')}` : '')).filter(Boolean).join(' | ').slice(0, 380)}\n\n` : '') + `Project title: ${project.title}\nAmount requested: ${project.amount} USD\nDuration: ${project.months} months\n\n` + factsCtx() + inputsCtx(450, 480, 320) + ((app?.experience ?? []).length ? `PREVIOUS EXPERIENCE OF THE APPLICANT ORGANIZATION (from its own documents; reflect relevant past projects, results and lessons, and never contradict them):\n${(app?.experience ?? []).map((x) => `[${x.name}]\n${x.summary.slice(0, 600)}`).join('\n\n').slice(0, 800)}\n\n` : '') +
    secs.filter(([k]) => doc[k] && k !== skipKey).slice(0, 7).map(([k, t]) => `## ${t}\n${doc[k].slice(0, 220)}`).join('\n\n') +
    ((): string => { const q = secs.find(([k]) => k === skipKey)?.[1] ?? ''; const dg = libraryDigest(lib, 600, `${q} ${project.title}`); return dg ? `\n\nFACTS FROM THE ORGANIZATION'S OWN DOCUMENTS (use them for real names, dates, figures and past results, and never contradict them):\n${dg}` : '' })()


  const [msg, setMsg] = useState('')

  // The budget is built from what the written sections say: activities, timeline, results, people and scale.
  // The budget is built from what the written sections say: activities, timeline, results, people and scale.
  const budgetCtx = () => {
    const parts: string[] = [`Project title: ${project.title || 'not set'}\nDuration: ${project.months} months\nAmount requested: ${project.amount || 'not set'} USD`, ...(factsCtx() ? [factsCtx().trim()] : [])]
    const take = (re: RegExp, n: number, label: string) => {
      const sec = secs.find(([, t]) => re.test(t) && !/budget/i.test(t))
      const text = sec ? (doc[sec[0]] ?? '').trim() : ''
      if (text) parts.push(`## ${label} (section "${sec![1]}")\n${text.slice(0, n)}`)
    }
    take(/activit|method|approach|implement|intervention/i, 1700, 'ACTIVITIES (every budget line must serve one of these)')
    take(/timeline|work ?plan|schedule/i, 1100, 'TIMELINE (keep the activity numbering)')
    take(/outcome|evaluation|result|monitor|indicator|logframe/i, 700, 'OUTPUTS, OUTCOMES AND INDICATORS')
    take(/beneficiar|target|participant|population/i, 450, 'BENEFICIARIES AND SCALE')
    take(/management|team|staff|personnel|capacity|governance|organi[sz]ation/i, 450, 'TEAM AND MANAGEMENT')
    take(/summary|abstract|overview/i, 400, 'SUMMARY')
    const fw = selectedFramework()
    if (fw) parts.push(`Selected funder framework: ${JSON.stringify(fw).slice(0, 700)}`)
    parts.push(inputsCtx(450))
    return parts.join('\n\n').slice(0, 5600)
  }

  // Activities written in the proposal that no budget line seems to pay for.
  const budgetLinkWarnings = (budgetText: string): string[] => {
    const ac = secs.find(([, t]) => /activit|method|approach|implement|intervention/i.test(t) && !/budget/i.test(t))
    const acText = ac ? doc[ac[0]] ?? '' : ''
    if (!acText.trim() || !budgetText.trim()) return []
    const lines = tidy(acText).split('\n').map((l) => l.trim().replace(/^[-•*\d.)\s]+/, '')).filter((l) => l.length > 12 && l.length < 140 && !l.includes('|') && !/[.!?]$/.test(l) || /^\s*(activity|a)\s*\d/i.test(l))
    const hay = budgetText.toLowerCase()
    const miss = lines.filter((l) => {
      const w = [...new Set(l.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((x) => x.length > 3))]
      return w.length >= 2 && w.filter((x) => hay.includes(x.slice(0, 6))).length / w.length < 0.34
    })
    return miss.slice(0, 6).map((l) => `No clear cost line for the activity: ${l}`)
  }

  const [editing, setEditing] = useState<Record<string, boolean>>({})

  // Sections the AI just wrote or improved are shown as formatted text, with an Edit button at the end.
  const [viewing, setViewing] = useState<Record<string, boolean>>({})

  const [extracted, setExtracted] = useState<Record<string, string> | null>(null)

  const [secOpen, setSecOpen] = useState<number[]>([])

  const docFileRef = useRef<HTMLInputElement>(null)

  const toggleSec = (n: number) => setSecOpen((c) => (c.includes(n) ? c.filter((x) => x !== n) : [...c, n]))

  // After the profile is updated from a website or a document, every section opens so the changes are visible.
  useEffect(() => { if (extracted) setSecOpen([1, 2, 3, 4, 5, 6]) }, [extracted])

  const [docBusy, setDocBusy] = useState(false)

  const [docNote, setDocNote] = useState('')

  const [accent, setAccent] = useStored<string>('ngw_accent_v2', '')

  const accentOk = /^#[0-9a-f]{6}$/i.test(accent)

  // The chosen brand accent colour recolours the whole portal, not only the exported files.
  useEffect(() => {
    const root = document.documentElement
    if (!accentOk) {
      root.style.removeProperty('--color-accent')
      root.style.removeProperty('--color-accent-ink')
      return
    }
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(accent.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    root.style.setProperty('--color-accent', accent)
    root.style.setProperty('--color-accent-ink', lum > 0.45 ? '#12201f' : '#ffffff')
  }, [accent, accentOk])

  const accentHex = /^#[0-9a-f]{6}$/i.test(accent) ? accent.slice(1).toUpperCase() : '12302F'


  async function analyzeDoc(f: File) {
    setDocBusy(true)
    setDocNote('')
    setExtracted(null)
    try {
      const text = (await readAnyFile(f)).replace(/\s+\n/g, '\n').trim()
      if (text.length < 40) {
        setDocNote('I could not read any text from that file. Scanned PDFs need to be converted to text first.')
      } else {
        const r = await extractProfile({ data: { text } })
        if (r.ok && Object.keys(r.fields).length) {
          setExtracted(r.fields)
          setDocNote('AI found updates for your profile. Review them below before applying.')
        } else if (r.ok) setDocNote('The document did not contain clear organization details.')
        else setDocNote(r.reason)
      }
    } catch (e: any) {
      setDocNote(fileErrorText(e))
    }
    setDocBusy(false)
  }

  async function updateFromLibrary() {
    const text = libraryTextForProfile(lib)
    if (text.trim().length < 80) { setDocNote('Your library has no readable documents yet. Import your registration papers, annual reports or past proposals in the Library page first.'); return }
    setDocBusy(true)
    setExtracted(null)
    setDocNote('')
    try {
      const r = await extractProfile({ data: { text } })
      if (r.ok && Object.keys(r.fields).length) {
        setExtracted(r.fields)
        setDocNote(`AI read your library (${lib.docs.filter((d) => d.text).length} document${lib.docs.filter((d) => d.text).length === 1 ? '' : 's'}${lib.snippets.length ? ` and ${lib.snippets.length} saved text${lib.snippets.length === 1 ? '' : 's'}` : ''}) and found profile updates. Review them below before applying.`)
      } else if (r.ok) setDocNote('The library documents did not contain clear organization details.')
      else setDocNote(r.reason)
    } catch {
      setDocNote('Something went wrong reading your library. Please try again.')
    }
    setDocBusy(false)
    setTimeout(() => document.getElementById('doc-import')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50)
    window.whop?.track?.('profile_update_from_library')
  }

  async function updateFromWebsite() {
    if (!(profile.website ?? '').trim()) { setDocNote('Add your website address first, then press Update from website.'); return }
    setDocBusy(true)
    setExtracted(null)
    setDocNote('')
    try {
      const r = await profileFromWebsite({ data: { url: profile.website ?? '' } })
      if (!r.ok) setDocNote(r.reason)
      else if (Object.keys(r.fields).length) {
        setExtracted(r.fields)
        setDocNote(`AI read ${r.pages} page${r.pages === 1 ? '' : 's'} of your website and found updates. Review them below before applying.`)
      } else setDocNote('I could not find clear organization details on that website.')
    } catch {
      setDocNote('Something went wrong reading the website. Please try again.')
    }
    setDocBusy(false)
    setTimeout(() => document.getElementById('doc-import')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50)
    window.whop?.track?.('profile_update_from_website')
  }

  async function completeMyProfile() {
    const missing = missingKeys(profile)
    if (!missing.length) { setDocNote('Your profile is already complete.'); return }
    setDocBusy(true)
    setExtracted(null)
    setDocNote('')
    try {
      const r = await completeProfile({ data: { profile, missing: missing as string[], options: { focus: SECTORS, populations: POPULATIONS, sdgs: SDGS, scope: SCOPES, grantTypes: GRANT_TYPES_SOUGHT, purposes: PURPOSES, orgType: ['NGO / nonprofit', 'Community-based organization', 'Social enterprise', 'Faith-based organization', 'Research or university group', 'Informal group'] } } })
      if (!r.ok) setDocNote(r.reason)
      else {
        const left = missing.filter((k) => !r.fields[k]).map((k) => FIELD_LABELS[k] ?? k)
        if (Object.keys(r.fields).length) setExtracted(r.fields)
        setDocNote(`${Object.keys(r.fields).length ? `AI suggests ${Object.keys(r.fields).length} field${Object.keys(r.fields).length === 1 ? '' : 's'} from what you already entered. Review them below. ` : ''}${left.length ? `Still needs your input: ${left.join(', ')}.` : ''}`.trim())
      }
    } catch {
      setDocNote('Something went wrong. Please try again.')
    }
    setDocBusy(false)
    setTimeout(() => document.getElementById('doc-import')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50)
    window.whop?.track?.('profile_complete_with_ai')
  }

  // What the applicant ticked in the framework pop-up, ready to send to the AI.
  const selectedFramework = () => {
    const sel = app?.framework?.selected
    if (!sel) return undefined
    const out: Record<string, string[]> = {}
    for (const [k] of FRAME_FIELDS) if ((sel[k] ?? []).length) out[k] = sel[k] as string[]
    return Object.keys(out).length ? out : undefined
  }

  // Budget rules the AI must respect: the guidance's budget rules plus the ceilings the applicant selected.
  const budgetRules = () => [...(app?.guidance?.budget ?? []), ...((app?.framework?.selected.budgetCeilings ?? []) as string[])].filter(Boolean).join('; ').slice(0, 1500)

  // The budget categories and amounts of an application, read from its budget table.
  const budgetLinesFor = (appId: string): { category: string; amount: number }[] => {
    const a = apps.find((x) => x.id === appId)
    if (!a) return []
    const secsOf = a.tpl ? a.tpl.sections.map((x) => [x.key, x.title] as const) : SECTIONS
    const bs = secsOf.find(([, t]) => /budget/i.test(t))
    const tb = parseBlocks(bs ? a.doc[bs[0]] ?? '' : a.doc['x_budget'] ?? '').find((b) => b.type === 'table')
    if (!tb || tb.type !== 'table') return []
    const head = tb.rows[0].map((c) => c.toLowerCase())
    const tot = head.findIndex((c) => /total|amount/.test(c))
    if (tot < 0) return []
    const out: { category: string; amount: number }[] = []
    let current = ''
    for (const r of tb.rows.slice(1)) {
      const joined = r.join(' ').toLowerCase()
      const amt = num(r[tot] ?? '')
      if (/subtotal/.test(joined)) { if (current && amt !== null) out.push({ category: clean(current), amount: amt }); current = ''; continue }
      if (/direct costs|^\W*total\W*$|\btotal\b/.test(joined) && !/subtotal/.test(joined) && !/indirect/.test(joined)) continue
      if (/indirect/.test(joined)) { if (amt !== null) out.push({ category: 'Indirect and administrative', amount: amt }); continue }
      const name = (r[1] ?? '').trim() || (r[0] ?? '').trim()
      if (head.length <= 4) { if (amt !== null && name) out.push({ category: clean(name), amount: amt }); continue }
      if ((r[1] ?? '').trim()) current = (r[1] ?? '').trim()
    }
    return out.filter((x) => x.amount > 0)
  }

  // ---- Budget lines breakdown: one Excel sheet per budget line, plus a main sheet by budget category ----
  const [abBusy, setAbBusy] = useState(false)

  type BLine = { cat: string; item: string; unit: string; qty: number; unitCost: number; total: number }
  function readBudgetLines(text: string): { lines: BLine[]; indirect: number; stated: number } {
    const tb = parseBlocks(text).find((b) => b.type === 'table' && b.rows[0].some((c) => /total|amount/i.test(c)) && b.rows[0].length >= 3) as Extract<Block, { type: 'table' }> | undefined
    if (!tb) return { lines: [], indirect: 0, stated: 0 }
    const h = tb.rows[0].map((c) => c.toLowerCase())
    const find = (re: RegExp, skip: number[] = []) => h.findIndex((c, i) => re.test(c) && !skip.includes(i))
    let total = -1
    h.forEach((c, i) => { if (/total|amount/.test(c) && !/unit/.test(c)) total = i })
    const item = find(/cost item|cost line|^item|line|description|expense|particular/, [total])
    const cat = find(/activity|category|sheet|heading|group|budget line/, [total, item])
    const unit = find(/^unit$|^uom/)
    const qty = find(/^qty|quantity|^no\.?$|number/, [total])
    const uc = find(/unit cost|unit price|rate/)
    if (total < 0) return { lines: [], indirect: 0, stated: 0 }
    const itemCol = item >= 0 ? item : cat >= 0 ? (cat === 0 ? 1 : 0) : 1
    const lines: BLine[] = []
    let indirect = 0
    let stated = 0
    let cur = ''
    for (const r of tb.rows.slice(1)) {
      const joined = r.join(' ').toLowerCase()
      const amt = num(r[total] ?? '')
      if (cat >= 0 && (r[cat] ?? '').trim() && !/subtotal|total|indirect/i.test(r[cat] ?? '')) cur = clean(r[cat]).replace(/^\d+[.)]?\s*/, '')
      if (/indirect|administrative/.test(joined)) { if (amt) indirect += amt; continue }
      if (/\btotal\b/.test(joined) && !/subtotal|direct/.test(joined) && amt && /^\W*total\W*(budget|costs?)?\W*$/.test(clean(r[itemCol] ?? r[0] ?? '').toLowerCase() || clean(r[0] ?? '').toLowerCase())) { stated = amt; continue }
      if (/subtotal|direct costs|grand total|^\W*total\W*$|\btotal\b/.test(joined) && !(r[itemCol] ?? '').trim()) continue
      if (/subtotal|direct costs|\btotal budget|^\W*total/.test((r[itemCol] ?? '').toLowerCase()) || /subtotal/.test(joined)) continue
      const name = clean(r[itemCol] ?? '').trim()
      if (!name || amt === null || amt <= 0) continue
      const q = qty >= 0 ? num(r[qty] ?? '') ?? 0 : 0
      const u = uc >= 0 ? num(r[uc] ?? '') ?? 0 : 0
      lines.push({ cat: cur || 'Budget lines', item: name, unit: unit >= 0 ? clean(r[unit] ?? '') : '', qty: q > 0 ? q : 1, unitCost: u > 0 ? u : amt / (q > 0 ? q : 1), total: amt })
    }
    return { lines, indirect, stated }
  }

  async function generateBudgetLinesBreakdown() {
    if (abBusy) return
    const bsec = secs.find(([, t]) => /budget/i.test(t))
    const budgetText = ((bsec ? doc[bsec[0]] : doc['x_budget']) ?? '').trim()
    const { lines: all, indirect, stated } = readBudgetLines(budgetText)
    if (!all.length) { setBdNote('There is no budget table to break down yet. Write the budget first (AI write, or import the funder\'s budget template), then press Budget lines breakdown.'); return }
    setAbBusy(true)
    try {
      // At most this many lines get their own sheet, the largest first, so the workbook stays complete and workable.
      const MAX = 30
      const sheetSet = new Set(all.length > MAX ? [...all].sort((a, b) => b.total - a.total).slice(0, MAX) : all)
      const lines = all
      const months = Math.max(1, Number(project.months) || 12)
      const periods = Math.min(12, Math.max(1, Math.ceil(months / 3)))
      const proposal = ((app?.plan ?? '').trim() ? `PLANNED PROJECT INFORMATION:\n${(app?.plan ?? '').trim().slice(0, 2000)}\n\n` : '') + factsCtx() + full
      const others = all.map((l) => `${l.cat}: ${l.item} (${Math.round(l.total)})`).join('; ')
      const res: (any | null)[] = lines.map(() => null)
      let done = 0
      const queue = lines.map((_, i) => i).filter((i) => sheetSet.has(lines[i]))
      const nSheets = queue.length
      setBdNote(`Breaking down ${nSheets} budget line${nSheets === 1 ? '' : 's'}...`)
      const worker = async () => {
        while (queue.length) {
          const i = queue.shift()!
          const l = lines[i]
          let r: any = null
          for (let attempt = 0; attempt < 2 && !(r && r.ok); attempt++) {
            // eslint-disable-next-line no-await-in-loop
            try { r = await breakdownLine({ data: { profile, category: l.cat, item: l.item, unit: l.unit, qty: l.qty, unitCost: l.unitCost, total: l.total, others, proposal, months: project.months, periods, rules: budgetRules() || undefined, instruction: (app?.lineNotes ?? '').trim() || undefined } }) } catch { r = null }
          }
          res[i] = r && r.ok ? r.breakdown : null
          done++
          setBdNote(`Breaking down the budget lines: ${done} of ${nSheets} done...`)
        }
      }
      await Promise.all([worker(), worker(), worker()])
      const ExcelJS: any = (await import('exceljs')).default ?? (await import('exceljs'))
      const wb = new ExcelJS.Workbook()
      const NAVY = 'FF12302F'
      const head = { font: { bold: true, color: { argb: 'FFFFFFFF' } }, fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: NAVY } }, alignment: { vertical: 'middle', horizontal: 'center', wrapText: true } } as const
      const soft = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFEADC' } } as const
      const band = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDCE8E6' } } as const
      const thin = { style: 'thin', color: { argb: 'FFBBBBBB' } } as const
      const box = { top: thin, left: thin, bottom: thin, right: thin }
      const MONEY = '#,##0.00'
      const org = `${profile.org || ''}${profile.country ? ', ' + profile.country : ''}${target ? ' | ' + target.funder : ''}`
      const q = (n: string) => `'${n.replace(/'/g, "''")}'`
      const used = new Set<string>(['main budget'])
      const cats: string[] = []
      lines.forEach((l) => { if (!cats.includes(l.cat)) cats.push(l.cat) })
      const main = wb.addWorksheet('Main Budget', { properties: { tabColor: { argb: NAVY } } })
      type Meta = { name: string; ref: string; total: number; line: BLine; no: string; ok: boolean }
      const metas: Meta[] = []
      lines.forEach((l, i) => {
        const bd = res[i] as any
        const ci = cats.indexOf(l.cat) + 1
        const li = lines.slice(0, i).filter((x) => x.cat === l.cat).length + 1
        const no = `${ci}.${li}`
        // Smaller lines beyond the limit keep their amount on the main sheet without a sheet of their own, so the total never changes.
        if (!sheetSet.has(l)) { metas.push({ name: '', ref: '', total: l.total, line: l, no, ok: true }); return }
        let nm = `${no} ${l.item}`.replace(/[\\/?*:\[\]]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 28)
        let n = nm, k = 2
        while (used.has(n.toLowerCase())) n = `${nm.slice(0, 26)} ${k++}`
        used.add(n.toLowerCase())
        const ws = wb.addWorksheet(n)
        ws.columns = [{ width: 6 }, { width: 30 }, { width: 54 }, { width: 11 }, { width: 9 }, { width: 14 }, { width: 16 }]
        ws.mergeCells('A1:G1'); ws.getCell('A1').value = `Budget line ${no}: ${l.item}`; ws.getCell('A1').font = { bold: true, size: 14, color: { argb: NAVY } }
        ws.mergeCells('A2:G2'); ws.getCell('A2').value = `${project.title || 'Project'} | ${org} | USD`; ws.getCell('A2').font = { italic: true, color: { argb: 'FF555555' } }
        const info: [string, string][] = [['Main budget category', l.cat], ['Amount in the budget', `${l.total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD (${l.qty.toLocaleString('en-US')} ${l.unit || 'units'} x ${l.unitCost.toLocaleString('en-US', { maximumFractionDigits: 2 })} USD)`], ['What it pays for', bd?.description || ''], ['Justification', bd?.justification || ''], ['Basis of the estimate', bd?.basis || ''], ['Assumptions', bd?.assumptions || ''], ['Supporting documents', bd?.verification || '']]
        let r = 4
        for (const [kx, v] of info) {
          ws.mergeCells(`A${r}:B${r}`); ws.getCell(`A${r}`).value = kx; ws.getCell(`A${r}`).font = { bold: true }; ws.getCell(`A${r}`).fill = band
          ws.mergeCells(`C${r}:G${r}`); ws.getCell(`C${r}`).value = v || (bd ? '[to be completed]' : '[the AI could not break this line down: press the button again]'); ws.getCell(`C${r}`).alignment = { wrapText: true, vertical: 'top' }
          for (const c of ['A', 'B', 'C', 'D', 'E', 'F', 'G']) ws.getCell(`${c}${r}`).border = box
          ws.getRow(r).height = v && v.length > 140 ? 64 : v && v.length > 70 ? 36 : 20
          r++
        }
        r++
        const hdr = ws.getRow(r)
        hdr.values = ['#', 'Component', 'Description and basis', 'Unit', 'Qty', 'Unit cost (USD)', 'Total (USD)']
        hdr.eachCell((c: any) => Object.assign(c, head, { border: box })); hdr.height = 30
        r++
        // The components always add up exactly to the line's amount in the budget.
        let comps: { component: string; description: string; unit: string; qty: number; unitCost: number }[] = bd?.components?.length ? bd.components.map((c: any) => ({ ...c })) : [{ component: l.item, description: 'Line as entered in the budget', unit: l.unit, qty: l.qty, unitCost: l.unitCost }]
        const raw = comps.reduce((t, c) => t + c.qty * c.unitCost, 0)
        if (raw > 0) { const kf = l.total / raw; comps = comps.map((c) => ({ ...c, unitCost: Math.round(c.unitCost * kf * 100) / 100 })) }
        // The last component takes the exact balance, so the components add up to the cent to the line's amount in the budget.
        const r2 = (n: number) => Math.round(n * 100) / 100
        if (comps.length) {
          const lastC = comps[comps.length - 1]
          const others2 = comps.slice(0, -1).reduce((t, c) => t + r2(c.qty * c.unitCost), 0)
          const rem = r2(l.total - others2)
          if (rem > 0) {
            const ucx = r2(rem / (lastC.qty || 1))
            if (Math.abs(r2(ucx * lastC.qty) - rem) < 0.005) lastC.unitCost = ucx
            else { lastC.qty = 1; lastC.unit = lastC.unit || 'lump sum'; lastC.unitCost = rem }
          } else comps = [{ component: l.item, description: 'Line as entered in the budget', unit: l.unit, qty: l.qty, unitCost: l.unitCost }]
          if (comps.length === 1) { comps[0].qty = l.qty; comps[0].unitCost = r2(l.total / (l.qty || 1)); if (Math.abs(r2(comps[0].qty * comps[0].unitCost) - l.total) >= 0.005) { comps[0].qty = 1; comps[0].unit = comps[0].unit || 'lump sum'; comps[0].unitCost = l.total } }
        }
        const first = r
        comps.forEach((c, j) => {
          const row = ws.getRow(r)
          row.values = [j + 1, c.component, c.description, c.unit, c.qty, c.unitCost, { formula: `ROUND(E${r}*F${r},2)`, result: Math.round(c.qty * c.unitCost * 100) / 100 }]
          row.eachCell({ includeEmpty: true }, (cc: any) => { cc.border = box; cc.alignment = { vertical: 'top', wrapText: true } })
          row.getCell(5).numFmt = '#,##0.##'; row.getCell(6).numFmt = MONEY; row.getCell(7).numFmt = MONEY
          r++
        })
        const tr = ws.getRow(r)
        ws.mergeCells(`A${r}:F${r}`); tr.getCell(1).value = `Total for budget line ${no}`
        tr.getCell(7).value = { formula: `SUM(G${first}:G${r - 1})`, result: l.total }; tr.getCell(7).numFmt = MONEY
        tr.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = soft; cc.font = { bold: true }; cc.border = box })
        const totalRef = `G${r}`
        r += 2
        ws.getCell(`A${r}`).value = 'Spending by project period (quarter)'; ws.getCell(`A${r}`).font = { bold: true, color: { argb: NAVY } }
        r++
        const ph = ws.getRow(r)
        ph.values = ['', 'Period', 'Months', 'Share', '', '', 'Amount (USD)']
        ph.eachCell((cc: any) => Object.assign(cc, head, { border: box }))
        r++
        const pfirst = r
        const shares: number[] = bd?.phasing?.length === periods ? bd.phasing : Array.from({ length: periods }, () => 100 / periods)
        const rounded = shares.map((v) => Math.round(v * 10) / 10)
        const diff = Math.round((100 - rounded.reduce((t, v) => t + v, 0)) * 10) / 10
        rounded[rounded.length - 1] = Math.round((rounded[rounded.length - 1] + diff) * 10) / 10
        rounded.forEach((v, pi) => {
          const m1 = pi * 3 + 1, m2 = Math.min(months, pi * 3 + 3)
          const row = ws.getRow(r)
          const absRef = `$${totalRef.replace(/(\d+)/, '$$$1')}`
          row.values = ['', `Q${pi + 1}`, m1 === m2 ? `Month ${m1}` : `Months ${m1}-${m2}`, v / 100, '', '', { formula: pi === rounded.length - 1 && pi > 0 ? `ROUND(${absRef}-SUM(G${pfirst}:G${r - 1}),2)` : `ROUND(${absRef}*D${r},2)`, result: Math.round(l.total * v) / 100 }]
          row.getCell(4).numFmt = '0.0%'; row.getCell(7).numFmt = MONEY
          for (const c of ['A', 'B', 'C', 'D', 'E', 'F', 'G']) row.getCell(c).border = box
          r++
        })
        const pt = ws.getRow(r)
        ws.mergeCells(`A${r}:C${r}`); pt.getCell(1).value = 'Total'
        pt.getCell(4).value = { formula: `SUM(D${pfirst}:D${r - 1})`, result: 1 }; pt.getCell(4).numFmt = '0.0%'
        pt.getCell(7).value = { formula: `SUM(G${pfirst}:G${r - 1})`, result: l.total }; pt.getCell(7).numFmt = MONEY
        pt.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = soft; cc.font = { bold: true }; cc.border = box })
        r += 2
        ws.mergeCells(`A${r}:G${r}`); ws.getCell(`A${r}`).value = '← Back to Main Budget'
        ws.getCell(`A${r}`).value = { text: '← Back to Main Budget', hyperlink: "#'Main Budget'!A1" }; ws.getCell(`A${r}`).font = { color: { argb: 'FF0563C1' }, underline: true }
        ws.views = [{ state: 'frozen', ySplit: 2 }]
        ws.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 }
        metas.push({ name: n, ref: totalRef, total: l.total, line: l, no, ok: !!bd })
      })
      // Main sheet: budget categories, with every line linked to its own sheet
      main.columns = [{ width: 8 }, { width: 44 }, { width: 14 }, { width: 10 }, { width: 14 }, { width: 18 }, { width: 10 }]
      main.mergeCells('A1:G1'); main.getCell('A1').value = `${project.title || 'Project'}: budget by main category and line`; main.getCell('A1').font = { bold: true, size: 15, color: { argb: NAVY } }
      main.mergeCells('A2:G2'); main.getCell('A2').value = `${org} | Duration ${project.months || '12'} months | All amounts in USD. Click a line to open its breakdown sheet.`; main.getCell('A2').font = { italic: true, color: { argb: 'FF555555' } }
      const mh = main.getRow(4)
      mh.values = ['#', 'Budget category / line', 'Unit', 'Qty', 'Unit cost (USD)', 'Total (USD)', 'Share']
      mh.eachCell((c: any) => Object.assign(c, head, { border: box })); mh.height = 30
      let rr = 5
      const catRows: number[] = []
      const grand = Math.round(metas.reduce((t, m) => t + m.total, 0) * 100) / 100
      const grandRowRef = { v: 0 }
      const lineRows: { cat: string; row: number }[] = []
      cats.forEach((c, ci) => {
        const cr = rr
        const crow = main.getRow(cr)
        crow.getCell(1).value = ci + 1; crow.getCell(2).value = c
        crow.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = band; cc.font = { bold: true }; cc.border = box })
        for (let k = 1; k <= 7; k++) crow.getCell(k).border = box
        catRows.push(cr)
        rr++
        const ms = metas.filter((m) => m.line.cat === c)
        const f0 = rr
        ms.forEach((m) => {
          const row = main.getRow(rr)
          row.getCell(1).value = m.no
          if (m.name) { row.getCell(2).value = { text: m.line.item, hyperlink: `#${q(m.name)}!A1` }; row.getCell(2).font = { color: { argb: 'FF0563C1' }, underline: true } } else row.getCell(2).value = m.line.item
          row.getCell(3).value = m.line.unit; row.getCell(4).value = m.line.qty; row.getCell(5).value = Math.round(m.line.unitCost * 100) / 100
          row.getCell(6).value = m.name ? { formula: `${q(m.name)}!${m.ref}`, result: m.total } : m.total
          row.getCell(5).numFmt = MONEY; row.getCell(6).numFmt = MONEY; row.getCell(4).numFmt = '#,##0.##'
          for (let k = 1; k <= 7; k++) { row.getCell(k).border = box; row.getCell(k).alignment = { vertical: 'top', wrapText: true } }
          lineRows.push({ cat: c, row: rr })
          rr++
        })
        const sub = Math.round(ms.reduce((t, m) => t + m.total, 0) * 100) / 100
        const srow = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); srow.getCell(1).value = `Subtotal, ${c}`
        srow.getCell(6).value = { formula: `SUM(F${f0}:F${rr - 1})`, result: sub }; srow.getCell(6).numFmt = MONEY
        srow.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = soft; cc.font = { bold: true }; cc.border = box })
        crow.getCell(6).value = { formula: `F${rr}`, result: sub }; crow.getCell(6).numFmt = MONEY
        rr++
      })
      const subRows = catRows.map((cr, i) => { let n = cr + 1 + metas.filter((m) => m.line.cat === cats[i]).length; return n })
      const drow = main.getRow(rr)
      main.mergeCells(`A${rr}:E${rr}`); drow.getCell(1).value = 'Direct costs'
      drow.getCell(6).value = { formula: subRows.map((x) => `F${x}`).join('+'), result: grand }; drow.getCell(6).numFmt = MONEY
      drow.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = soft; cc.font = { bold: true }; cc.border = box })
      grandRowRef.v = rr
      const directRow = rr
      rr++
      let totalBudget = Math.round((grand + indirect) * 100) / 100
      const adjRows: number[] = []
      if (indirect > 0) {
        const irow = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); irow.getCell(1).value = 'Indirect and administrative costs'
        irow.getCell(6).value = indirect; irow.getCell(6).numFmt = MONEY
        for (let k = 1; k <= 7; k++) irow.getCell(k).border = box
        adjRows.push(rr)
        rr++
      }
      // The workbook total must equal the total of the budget table. Any difference is shown openly instead of being hidden.
      const gapToTable = stated ? Math.round((stated - totalBudget) * 100) / 100 : 0
      if (Math.abs(gapToTable) >= 0.5) {
        const grow = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); grow.getCell(1).value = 'Other costs in the budget table that are not itemised line by line'
        grow.getCell(6).value = gapToTable; grow.getCell(6).numFmt = MONEY
        for (let k = 1; k <= 7; k++) grow.getCell(k).border = box
        adjRows.push(rr)
        rr++
        totalBudget = Math.round((totalBudget + gapToTable) * 100) / 100
      }
      if (adjRows.length) {
        const trow = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); trow.getCell(1).value = 'TOTAL BUDGET'
        trow.getCell(6).value = { formula: `F${directRow}+${adjRows.map((x) => `F${x}`).join('+')}`, result: totalBudget }; trow.getCell(6).numFmt = MONEY
        trow.eachCell({ includeEmpty: true }, (cc: any) => { cc.fill = head.fill; cc.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cc.border = box })
        rr++
      }
      // Shares of the direct costs
      for (const lr of lineRows) { const c = main.getRow(lr.row).getCell(7); c.value = { formula: `F${lr.row}/F$${directRow}`, result: 0 }; c.numFmt = '0.0%' }
      for (const cr of catRows) { const c = main.getRow(cr).getCell(7); c.value = { formula: `F${cr}/F$${directRow}`, result: 0 }; c.numFmt = '0.0%' }
      const asked = Number((project.amount ?? '').replace(/[^0-9.]/g, '')) || 0
      if (asked) {
        const rq = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); rq.getCell(1).value = 'Amount requested'; rq.getCell(6).value = asked; rq.getCell(6).numFmt = MONEY
        for (let k = 1; k <= 7; k++) rq.getCell(k).border = box
        rr++
        const dv = main.getRow(rr)
        main.mergeCells(`A${rr}:E${rr}`); dv.getCell(1).value = 'Difference (total budget minus amount requested)'
        dv.getCell(6).value = { formula: `F${rr - 2}-F${rr - 1}`, result: Math.round((totalBudget - asked) * 100) / 100 }; dv.getCell(6).numFmt = MONEY
        for (let k = 1; k <= 7; k++) dv.getCell(k).border = box
        rr++
      }
      rr++
      const skipped = all.length - sheetSet.size
      main.mergeCells(`A${rr}:G${rr}`)
      main.getCell(`A${rr}`).value = `Notes: each line of the budget has its own sheet with its components, justification, basis of the estimate, supporting documents and spending by quarter. The amounts on this sheet are linked to those sheets. The components of every line add up exactly to the amount in the approved budget. Unit costs are estimates: replace them with your own quotes and local rates before submitting.${skipped ? ` ${skipped} smaller line${skipped === 1 ? ' has' : 's have'} no sheet of their own to keep the workbook workable: ${skipped === 1 ? 'its amount stays' : 'their amounts stay'} on this sheet and in the total.` : ''}`
      main.getCell(`A${rr}`).alignment = { wrapText: true, vertical: 'top' }; main.getRow(rr).height = 64
      main.views = [{ state: 'frozen', ySplit: 4 }]
      main.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 }
      const buf: ArrayBuffer = await wb.xlsx.writeBuffer()
      const a = document.createElement('a')
      a.href = URL.createObjectURL(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }))
      a.download = exportName('budget', 'xlsx').replace('-budget-', '-budget-lines-breakdown-')
      a.click()
      const failed = metas.filter((m) => !m.ok && m.name).length
      const nSh = metas.filter((m) => m.name).length
      setBdNote(`Budget lines breakdown downloaded: a Main Budget sheet by category plus ${nSh} line sheet${nSh === 1 ? '' : 's'}. Total ${totalBudget.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD${stated ? (Math.abs(gapToTable) >= 0.5 ? `, equal to the total of your budget table (${gapToTable > 0 ? 'the' : 'including a'} ${Math.abs(gapToTable).toLocaleString('en-US', { maximumFractionDigits: 2 })} USD difference is shown on its own row because those costs are not itemised in the table)` : ', the same as your budget table') : ''}.${failed ? ` ${failed} line${failed === 1 ? '' : 's'} could not be detailed by the AI and show the line as entered, so press the button again.` : ''}${skipped ? ` The ${MAX} largest lines have their own sheet; the other ${skipped} stay on the Main Budget sheet with their amounts.` : ''} Check the unit costs before submitting.`)
      window.whop?.track?.('budget_lines_breakdown_downloaded')
    } catch {
      setBdNote('Something went wrong while preparing the budget lines breakdown. Please try again.')
    }
    setAbBusy(false)
  }

  // ---- Review, checklist, package, version history, autosave ----
  const hasBudgetSection = secs.some(([, t]) => /budget/i.test(t))

  const reviewSections = () => [...secs.map(([k, t]) => ({ key: k, title: t, text: doc[k] ?? '', wordLimit: meta(k)?.wordLimit ?? 0 })), ...(!hasBudgetSection && (doc['x_budget'] ?? '').trim() ? [{ key: 'x_budget', title: 'Budget (funder template)', text: doc['x_budget'] ?? '', wordLimit: 0 }] : [])]

  async function exportPackage() {
    if (!app) return
    const { zipSync, strToU8 } = await import('fflate')
    const base = (target?.title || project.title || 'grant-application').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 50) || 'grant-application'
    const files: Record<string, Uint8Array> = {}
    files[`${base}-proposal.docx`] = new Uint8Array(await (await makeWordBlob()).arrayBuffer())
    files[`${base}-proposal.txt`] = strToU8(tidy(full))
    const bsec = secs.find(([, t]) => /budget/i.test(t))
    if (bdFile?.bytes) files[`${base}-budget-funder-template.xlsx`] = bdFile.bytes
    else if (app.budgetFile) files[`${base}-budget-funder-template.xlsx`] = fromB64(app.budgetFile.b64)
    const btxt = bsec ? doc[bsec[0]] ?? '' : doc['x_budget'] ?? ''
    if (btxt.includes('|')) {
      const buf = await budgetExcelBuffer(btxt)
      if (buf) files[`${base}-budget.xlsx`] = new Uint8Array(buf)
    }
    const items = qualityItems().map((i) => ({ label: i.text, done: qDone(i) }))
    files[`${base}-submission-checklist.txt`] = strToU8([`Submission checklist: ${target?.title || project.title || 'application'}`, `Prepared ${new Date().toLocaleDateString('en-GB')}`, '', ...items.map((i) => `[${i.done ? 'x' : ' '}] ${i.label}`), ''].join('\n'))
    const out = zipSync(files, { level: 6 })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([out as BlobPart], { type: 'application/zip' }))
    a.download = exportName('proposal', 'zip').replace('-proposal-', '-submission-package-')
    a.click()
    window.whop?.track?.('package_exported')
  }

  // Snapshots of the draft, kept for version history (newest first, at most 10).
  function snapshotDoc(label: string) {
    patch((a) => {
      const cur = a.doc ?? {}
      const last = a.history?.[0]
      if (last && JSON.stringify(last.doc) === JSON.stringify(cur)) return a
      let hist = [{ at: Date.now(), label, doc: { ...cur } }, ...(a.history ?? [])].slice(0, 10)
      while (hist.length > 2 && JSON.stringify(hist).length > 900_000) hist = hist.slice(0, -1)
      return { ...a, history: hist }
    })
  }

  function restoreVersion(i: number) {
    const entry = app?.history?.[i]
    if (!entry) return
    snapshotDoc('Before restoring a version')
    patch((a) => ({ ...a, doc: { ...entry.doc } }))
    setHistoryOpen(false)
  }

  // Autosave: when signed in, changes are also saved online after a short pause.
  const syncedRef = useRef(0)

  const [syncedAt, setSyncedAt] = useState(0)

  const [tick, setTick] = useState(0)

  useEffect(() => { const id = setInterval(() => setTick((n) => n + 1), 30000); return () => clearInterval(id) }, [])

  useEffect(() => { syncedRef.current = app?.updated ?? 0; setSyncedAt(0) }, [activeId])

  useEffect(() => {
    if (!app || !online?.signedIn || !online.dbReady) return
    if ((app.updated ?? 0) <= syncedRef.current) return
    const snap = app
    const t = setTimeout(async () => {
      try {
        const cleanDoc: Record<string, string> = {}
        for (const [k, v] of Object.entries(snap.doc)) cleanDoc[k] = tidy(v)
        const r = await saveApplication({ data: { id: snap.id, title: snap.project.title || snap.grant?.title || 'Untitled application', data: { ...snap, doc: cleanDoc } } })
        if (r.ok) { syncedRef.current = snap.updated; setSyncedAt(Date.now()); setOnlineLimit(0) }
        else if (r.reason === 'project_limit') setOnlineLimit(r.max)
      } catch {}
    }, 20000)
    return () => clearTimeout(t)
  }, [app?.updated, app?.id, online?.signedIn, online?.dbReady])

  const saveStatus = (() => {
    void tick
    if (!app) return ''
    if (!online?.signedIn) return 'Saved in this browser. Sign in to save online too.'
    if (onlineLimit) return `Saved in this browser only. Your plan keeps ${onlineLimit} project${onlineLimit === 1 ? '' : 's'} online. See Plans to upgrade.`
    if ((app.updated ?? 0) > syncedRef.current) return 'Saved in this browser. Saving online shortly...'
    if (syncedAt) { const m = Math.round((Date.now() - syncedAt) / 60000); return m < 1 ? 'Saved online just now' : `Saved online ${m} minute${m === 1 ? '' : 's'} ago` }
    return 'Up to date online'
  })()

  const [secMsg, setSecMsg] = useState<Record<string, { text: string; ok: boolean }>>({})

  const [flashKey, setFlashKey] = useState('')

  const friendlyAiError = (reason: string) =>
    /429|rate limit|usage limit|tokens per minute/i.test(reason) ? 'The AI service has reached its usage limit for the moment. Wait about a minute and press the button again.'
      : /took too long/i.test(reason) ? 'The AI service took too long to answer. Press the button again.'
        : /empty answer/i.test(reason) ? 'The AI returned an empty answer. Press the button again.'
          : /not switched on/i.test(reason) ? 'The AI is not switched on yet. The site owner needs to add a working AI key.'
            : `The AI could not finish this section. ${reason.replace(/^AI provider error \d+:\s*/i, '').slice(0, 140)}`

  const runRef = useRef(0)

  const stopRef = useRef(false)

  const [aiSecs, setAiSecs] = useState(0)
  // Text that is being written right now, by section, and what the AI is doing before the first words arrive.
  const [live, setLive] = useState<Record<string, string>>({})
  const [liveStatus, setLiveStatus] = useState('')
  const [flowLive, setFlowLive] = useState('')
  const abortRef = useRef<AbortController | null>(null)
  useEffect(() => { trackRequests() }, [])

  useEffect(() => {
    if (!busy.startsWith('ai-')) { setAiSecs(0); return }
    const t0 = Date.now()
    const id = setInterval(() => setAiSecs(Math.floor((Date.now() - t0) / 1000)), 1000)
    return () => clearInterval(id)
  }, [busy])

  function cancelAi() {
    stopRef.current = true
    abortRef.current?.abort()
    runRef.current++
    setBusy('')
    setMsg('Stopped. Press AI write or AI improve to try again.')
  }

  // Fields of the funder's form that are not narrative text: the AI suggests the answer from what the applicant has filled in.
  const [choiceBusy, setChoiceBusy] = useState('')

  async function suggestChoice(key: string, title: string): Promise<boolean> {
    const q = meta(key)
    if (!q) return true
    let done = false
    setChoiceBusy(key)
    setSecMsg((c) => { const n = { ...c }; delete n[key]; return n })
    try {
      const r = await suggestAnswer({ data: { question: title, guidance: q.guidance || undefined, type: q.type || 'text', options: q.options ?? [], unit: q.unit, explain: q.explain, context: ctx(key) } })
      if (r.ok) {
        if (!r.value) setSecMsg((c) => ({ ...c, [key]: { text: 'The AI could not choose an answer from the information provided. Choose it yourself.', ok: false } }))
        else {
          const text = q.explain && r.explanation ? `${r.value}\n\n${r.explanation}` : r.value
          setDoc((d) => ({ ...d, [key]: text }))
          done = true
          setSecMsg((c) => ({ ...c, [key]: { text: r.confident ? 'Suggested from your application. Check it before submitting.' : `Not enough information to be sure. ${r.explanation}`, ok: r.confident } }))
        }
      } else setSecMsg((c) => ({ ...c, [key]: { text: friendlyAiError(r.reason), ok: false } }))
    } catch {
      setSecMsg((c) => ({ ...c, [key]: { text: 'Something went wrong. Please try again.', ok: false } }))
    }
    setChoiceBusy('')
    return done
  }

  async function complete(key: string, title: string, instructionOverride?: string) {
    if (isChoiceKey(key)) return true
    // The target areas changed since the proposal was written: update the whole proposal, or at least this section.
    if (areasStale && !instructionOverride && !allProg && !bulkRef.current) {
      const all = await askConfirm('The planned target areas changed after the proposal was written. Update every written section to match them? Choose No to update only this section.', { title: 'Update the whole proposal?', yes: 'Yes, update all', no: 'Only this section', danger: false })
      if (all) { improveAll('inputs'); return true }
      instructionOverride = areasInstruction()
    }
    const myRun = ++runRef.current
    setBusy('ai-' + key)
    setMsg('')
    setSecMsg((c) => { const n = { ...c }; delete n[key]; return n })
    try {
      const payload = {
          profile,
          section: title,
          context: /budget/i.test(title) ? budgetCtx() : ctx(key),
          current: doc[key] || undefined,
          grant: target ?? undefined,
          amount: project.amount,
          months: project.months,
          instruction: doc[key] ? instructionOverride ?? 'Improve and expand the existing text for this section.' : undefined,
          guidance: meta(key)?.guidance || undefined,
          wordLimit: meta(key)?.wordLimit || undefined,
          limit: limitOf(key)?.n,
          limitUnit: limitOf(key)?.unit,
          framework: selectedFramework(),
          rules: budgetRules() || undefined,
      }
      // Sections are written live, so the text appears as the AI types it. The budget is built from a table of costs and cannot be shown piece by piece.
      let r: { ok: true; text: string } | { ok: false; reason: string }
      if (/budget/i.test(title)) {
        r = await autoComplete({ data: payload })
      } else {
        const ctrl = new AbortController()
        abortRef.current = ctrl
        setLive((l) => ({ ...l, [key]: '' }))
        setLiveStatus('Thinking about the section...')
        const sr = await streamWrite(payload, { delta: (d) => { setLiveStatus(''); setLive((l) => ({ ...l, [key]: (l[key] ?? '') + d })) }, reset: () => setLive((l) => ({ ...l, [key]: '' })), status: setLiveStatus }, ctrl.signal)
        setLive((l) => { const n = { ...l }; delete n[key]; return n })
        setLiveStatus('')
        abortRef.current = null
        r = sr.ok ? sr : (sr as any).network ? await autoComplete({ data: payload }) : sr
      }
      if (runRef.current !== myRun) return false
      if (r.ok) {
        const before = (doc[key] ?? '').trim()
        const fit = await fitText(key, title, tidy(r.text).trim())
        if (runRef.current !== myRun) return false
        const after = fit.text
        const lim = limitOf(key)
        if (before.length > 20) snapshotDoc(`Before AI improve: ${title}`)
        setDoc((d) => ({ ...d, [key]: after }))
        setViewing((v) => ({ ...v, [key]: true }))
        setEditing((e) => ({ ...e, [key]: false }))
        setSecMsg((c) => ({ ...c, [key]: before === after ? { ok: true, text: 'The AI found nothing to change in this section.' } : { ok: !fit.over, text: `${before ? 'Improved.' : 'Written. Read it through and edit anything that is off.'}${fit.trimmed && lim ? ` Shortened to fit the limit of ${lim.n.toLocaleString('en-US')} ${lim.unit === 'words' ? 'words' : lim.unit === 'characters' ? 'characters' : 'characters without spaces'}.` : ''}${fit.over ? ' It is still over the limit: shorten it by hand.' : ''}` } }))
        setFlashKey(key)
        setTimeout(() => setFlashKey((k) => (k === key ? '' : k)), 2500)
      } else {
        setMsg(friendlyAiError(r.reason))
        setSecMsg((c) => ({ ...c, [key]: { ok: false, text: friendlyAiError(r.reason) } }))
        setBusy('')
        return false
      }
    } catch {
      if (runRef.current !== myRun) return false
      setMsg('Something went wrong. Please try again.')
      setSecMsg((c) => ({ ...c, [key]: { ok: false, text: 'Something went wrong while contacting the AI. Check your connection and press the button again.' } }))
      setBusy('')
      return false
    }
    setBusy('')
    return true
  }

  const [allProg, setAllProg] = useState('')

  const bulkRef = useRef(false)

  // ---- Key project facts: fixed once, used by every section and document ----
  const emptyFacts = { direct: '', indirect: '', partners: '', targets: '' }

  const facts = app?.facts ?? emptyFacts

  const setFacts = (v: Partial<typeof emptyFacts>) => patch((a) => ({ ...a, facts: { ...(a.facts ?? emptyFacts), ...v } }))

  const factsCtx = (): string => {
    const areaList = (app?.inputs?.areas ?? []).filter(areaFilled)
    const parts = [
      project.months && `Duration: ${project.months} months`,
      project.amount && `Amount requested: ${project.amount} USD`,
      areaList.length && `Planned areas: ${areaList.length}`,
      facts.direct.trim() && `Direct beneficiaries: ${facts.direct.trim()}`,
      facts.indirect.trim() && `Indirect beneficiaries: ${facts.indirect.trim()}`,
      facts.partners.trim() && `Partners: ${facts.partners.trim().replace(/\n+/g, '; ')}`,
      facts.targets.trim() && `Key targets: ${facts.targets.trim().replace(/\n+/g, '; ')}`,
    ].filter(Boolean)
    return parts.length > 2 ? `FIXED PROJECT FACTS (use exactly these figures, names and numbers in every section; never change or contradict them):\n${parts.join('\n')}\n\n` : ''
  }

  // Where each fixed number appears in the written proposal.
  const factCoverage = () => {
    const written = secs.filter(([k]) => (doc[k] ?? '').trim().length > 40)
    const num = (v: string) => Number(v.replace(/[^0-9.]/g, '')) || 0
    const mentions = (text: string, n: number) => [String(n), n.toLocaleString('en-US')].some((x) => new RegExp(`(^|[^0-9.,])${x.replace(/[.,]/g, (c) => '\\' + c)}([^0-9]|$)`).test(text))
    const rows: { label: string; value: string; found: number }[] = []
    const add = (label: string, value: string, fn: (t: string) => boolean) => { if (!value) return; rows.push({ label, value, found: written.filter(([k]) => fn(doc[k] ?? '')).length }) }
    if (num(facts.direct)) add('Direct beneficiaries', facts.direct.trim(), (t) => mentions(t, num(facts.direct)))
    if (num(facts.indirect)) add('Indirect beneficiaries', facts.indirect.trim(), (t) => mentions(t, num(facts.indirect)))
    if (num(project.amount)) add('Amount requested', `$${project.amount}`, (t) => mentions(t, num(project.amount)))
    if (num(project.months)) add('Duration', `${project.months} months`, (t) => new RegExp(`\\b${num(project.months)}[ -]months?\\b`, 'i').test(t))
    return { rows, total: written.length }
  }

  // The planned target areas as they are now. When they differ from the areas the proposal was last updated for, the proposal is out of date.
  const areasKey = JSON.stringify((app?.inputs?.areas ?? []).filter(areaFilled).map((a) => [areaLabel(a), '', '']))

  const hasWritten = !!app && secs.some(([k]) => (doc[k] ?? '').trim().length > 40)

  useEffect(() => {
    // A proposal written before this check existed is treated as up to date with the current areas.
    if (app && hasWritten && app.areasSnap === undefined) patch((a) => ({ ...a, areasSnap: areasKey }))
    // A snapshot saved in the older format (area name and country separately) is carried over when nothing really changed.
    const prevKey = JSON.stringify((app?.inputs?.areas ?? []).filter(areaFilled).map((a) => [areaLabel(a), '', (a.beneficiaries ?? '').replace(/[^0-9]/g, '')]))
    if (app && app.areasSnap !== undefined && app.areasSnap !== areasKey && app.areasSnap === prevKey) patch((a) => ({ ...a, areasSnap: areasKey }))
    const oldKey = JSON.stringify((app?.inputs?.areas ?? []).filter((a) => (a.name ?? '').trim()).map((a) => [a.name.trim(), a.country, a.beneficiaries.replace(/[^0-9]/g, '')]))
    if (app && app.areasSnap !== undefined && app.areasSnap !== areasKey && app.areasSnap === oldKey) patch((a) => ({ ...a, areasSnap: areasKey }))
  }, [app?.id, hasWritten])

  const areasStale = !!app && hasWritten && app.areasSnap !== undefined && app.areasSnap !== areasKey

  // A readable list of what changed in the planned target areas, for the AI.
  const areasChange = (): string => {
    try {
      const was: [string, string, string][] = JSON.parse(app?.areasSnap ?? '[]')
      const now: [string, string, string][] = JSON.parse(areasKey)
      const nm = (x: [string, string, string]) => x[0].toLowerCase()
      const out: string[] = []
      for (const o of was) { const n = now.find((x) => nm(x) === nm(o)); if (!n) out.push(`removed: ${o[0]}${o[1] ? ', ' + o[1] : ''}`); else if (n[1] !== o[1] || n[2] !== o[2]) out.push(`changed: ${o[0]} (${[o[1], o[2] && o[2] + ' people'].filter(Boolean).join(', ')}) is now ${n[0]} (${[n[1], n[2] && n[2] + ' people'].filter(Boolean).join(', ')})`) }
      for (const n of now) if (!was.some((o) => nm(o) === nm(n))) out.push(`added: ${n[0]}${n[1] ? ', ' + n[1] : ''}${n[2] ? ' (' + n[2] + ' people)' : ''}`)
      return out.join('; ')
    } catch { return '' }
  }

  const areasInstruction = () => `The PLANNED TARGET AREAS have changed${areasChange() ? ' (' + areasChange() + ')' : ''}. Update this section so that every place, site, community, beneficiary number, activity location, timeline step, budget quantity and indicator target matches the CURRENT planned target areas listed in the project inputs, at country level and at every smaller level (region, district, ward, village). Remove places that are no longer planned, add the new ones, and recalculate any totals from the new beneficiary numbers. Keep everything else that is still correct, keep the structure and format (tables stay tables), and stay consistent with the other sections.`

  // Rewrites every written section so it matches the latest inputs: needs assessment, target areas, primary information, framework and budget.
  async function improveAll(reason?: 'areas' | 'inputs', ask = false) {
    const keys: [string, string][] = secs.filter(([k]) => (doc[k] ?? '').trim() && !isChoiceKey(k)).map(([k, t]) => [k, t])
    if (!hasBudgetSection && (doc['x_budget'] ?? '').trim()) keys.push(['x_budget', 'Budget summary and justification'])
    if (!keys.length) { setMsg('There are no written sections to improve yet. Use AI complete all empty sections first.'); return }
    const ok = reason && !ask ? true : await askConfirm(`The AI will update ${keys.length} written section${keys.length === 1 ? '' : 's'} to match your current needs assessment, target areas, primary information, framework and budget. Your text is replaced by the improved version. Continue?`, { title: 'Improve all sections?', yes: 'Yes, improve all', danger: false })
    if (!ok) return
    stopRef.current = false
    const instruction = reason === 'areas' ? areasInstruction() : reason === 'inputs' ? `${areasStale ? areasInstruction() + ' ' : ''}The applicant just added or changed information in the project inputs (needs assessment, planned target areas, primary information about the target areas, fixed project facts). Update this section so that it reflects that information: use the new facts, figures, places and findings where they belong, correct anything they contradict, and keep everything else that is still correct. Keep the structure and format (tables stay tables) and stay consistent with the other sections.` : 'Update this section so it matches the CURRENT project inputs (needs assessment, planned target areas, primary information about the target areas), the funder framework, the budget and the other written sections. Keep everything that is still correct and specific. Change the figures, places, beneficiaries, activities and indicators that no longer match, and make the section consistent with the rest of the proposal. Keep its structure and format: tables stay tables.'
    let done = 0
    for (const [k, t] of keys) {
      if (stopRef.current) break
      setAllProg(`Improving ${done + 1} of ${keys.length}: ${t}`)
      // eslint-disable-next-line no-await-in-loop
      const good = await untilDone(() => complete(k, t, instruction))
      if (stopRef.current) break
      if (!good) { setAllProg(''); setMsg(`Stopped at "${t}" because the AI could not finish it. ${done} of ${keys.length} sections were improved, and the sections after it were not started. Press the button again to continue.`); return }
      done++
      // eslint-disable-next-line no-await-in-loop
      await new Promise((r) => setTimeout(r, 300))
    }
    setAllProg('')
    if (!stopRef.current) {
      patch((a) => ({ ...a, areasSnap: areasKey }))
      setMsg(`Improved ${done} section${done === 1 ? '' : 's'} to match your latest inputs. Read them through before you submit.`)
    }
  }

  // ---- Project title: suggestions and AI improve ----
  const [titleBusy, setTitleBusy] = useState<'' | 'suggest' | 'improve'>('')

  const [titleOpts, setTitleOpts] = useState<string[]>([])

  const [titleNote, setTitleNote] = useState('')

  const [prevTitle, setPrevTitle] = useState<string | null>(null)

  const titleCtx = (): string => {
    const g = app?.grant
    const bodyOf = (re: RegExp, n: number) => { const x = secs.find(([, t]) => re.test(t)); return x ? (doc[x[0]] ?? '').trim().slice(0, n) : '' }
    const areas = (app?.inputs?.areas ?? []).filter(areaFilled).map(areaLabel).join('; ')
    return [
      g && `Grant: ${g.title}. Funder: ${g.funder}. ${(g.summary ?? '').slice(0, 400)}`,
      app?.guidance?.priorities?.length ? `Funder priorities: ${app.guidance.priorities.slice(0, 8).join('; ')}` : app?.guidanceText ? `Funder guidance: ${app.guidanceText.slice(0, 600)}` : '',
      app?.linkText ? `Funder web page: ${app.linkText.slice(0, 600)}` : '',
      profile.org && `Organization: ${profile.org}${profile.country ? ', ' + profile.country : ''}. Focus: ${profile.focus ?? ''}. Mission: ${(profile.mission ?? '').slice(0, 200)}`,
      inputs.needs.trim() && `Needs assessment: ${inputs.needs.trim().slice(0, 600)}`,
      areas && `Planned target areas: ${areas}`,
      facts.direct.trim() && `Direct beneficiaries: ${facts.direct.trim()}`,
      facts.targets.trim() && `Key targets: ${facts.targets.trim().replace(/\n+/g, '; ')}`,
      bodyOf(/executive|summary/i, 700) && `Written executive summary: ${bodyOf(/executive|summary/i, 700)}`,
      bodyOf(/goal|objective/i, 600) && `Written objectives: ${bodyOf(/goal|objective/i, 600)}`,
    ].filter(Boolean).join('\n')
  }

  async function runTitles(mode: 'suggest' | 'improve') {
    const context = titleCtx()
    if (context.trim().length < 40 && !project.title.trim()) { setTitleNote('Add the grant, the needs assessment or some target areas first, so the AI has something to base the title on.'); return }
    setTitleBusy(mode)
    setTitleNote('')
    setTitleOpts([])
    try {
      const r = await projectTitles({ data: { mode, current: project.title, context } })
      if (!r.ok) setTitleNote(friendlyAiError(r.reason))
      else if (mode === 'suggest') { setTitleOpts(r.titles); setTitleNote('Pick a title, or keep writing your own.') }
      else if (r.titles[0].trim() === project.title.trim()) setTitleNote('The title already fits your proposal, so the AI left it as it is.')
      else { setPrevTitle(project.title); setProject({ ...project, title: r.titles[0] }); setTitleNote('Title improved from the progress of your proposal.') }
    } catch {
      setTitleNote('Something went wrong. Please try again.')
    }
    setTitleBusy('')
  }

  // ---- Sources and references ----
  const [srcBusy, setSrcBusy] = useState(false)

  const [srcNote, setSrcNote] = useState('')

  async function scanSources() {
    const parts = [
      ...(inputs.needs.trim() ? [{ title: 'Needs assessment (project inputs)', text: inputs.needs }] : []),
      ...secs.filter(([k]) => (doc[k] ?? '').trim().length > 40).map(([k, t]) => ({ title: t, text: doc[k] })),
    ]
    setSrcBusy(true)
    setSrcNote('')
    try {
      const r = await extractSources({ data: { parts } })
      if (r.ok) {
        const old = new Map((app?.sources ?? []).map((x) => [x.claim.toLowerCase(), x]))
        // What you already filled in stays.
        const items = r.items.map((x) => { const o = old.get(x.claim.toLowerCase()); return o && o.source ? { ...x, source: o.source, year: o.year, sourced: true } : x })
        patch((a) => ({ ...a, sources: items, sourcesAt: Date.now() }))
        const missing = items.filter((x) => !x.sourced).length
        setSrcNote(items.length ? `Found ${items.length} statistic${items.length === 1 ? '' : 's'} and facts. ${missing ? `${missing} ha${missing === 1 ? 's' : 've'} no source. Fill them in, or remove the claim.` : 'Every one names a source.'}` : 'I found no outside statistics in the written text.')
      } else setSrcNote(friendlyAiError(r.reason))
    } catch {
      setSrcNote('Something went wrong. Please try again.')
    }
    setSrcBusy(false)
  }

  const setSrcRow = (i: number, v: Partial<SourceItem>) => patch((a) => ({ ...a, sources: (a.sources ?? []).map((x, j) => (j === i ? { ...x, ...v, sourced: ((v.source ?? x.source) || '').trim().length > 1 } : x)) }))

  function buildReferences() {
    const items = app?.sources ?? []
    if (!items.length) { setSrcNote('Scan the proposal first.'); return }
    const withSrc = items.filter((x) => x.sourced)
    const lines = [...new Map(withSrc.map((x) => [`${x.source}|${x.year}`, x])).values()].sort((a, b) => a.source.localeCompare(b.source)).map((x) => `- ${x.source}${x.year ? ` (${x.year})` : ''}. ${x.claim}.`)
    const missing = items.filter((x) => !x.sourced).map((x) => `- [source needed]. ${x.claim}.`)
    const text = `${lines.join('\n') || '- [no sourced statistics yet]'}${missing.length ? `\n\nStatistics that still need a source\n\n${missing.join('\n')}` : ''}`
    patch((a) => ({ ...a, extras: { ...(a.extras ?? {}), references: { title: 'References', text, at: Date.now() } } }))
    setSrcNote(`The references list is ready under Project documents (${lines.length} source${lines.length === 1 ? '' : 's'}${missing.length ? `, ${missing.length} still without one` : ''}). You can download or edit it there.`)
  }

  // Save and reflect: every field of the application form that is still empty is written by the AI (narrative fields are written, yes/no, drop-down,
  // tick-box, number and date fields get a suggested answer), then the fields that were already written are updated to match the inputs.
  async function reflectInputs() {
    const hadWritten = hasWritten
    await completeAll()
    if (stopRef.current) { setAllProg(''); return }
    if (hadWritten) await improveAll('inputs')
    else setMsg('Saved. Every empty field of the application was written. Read each one through before you submit.')
  }
  // A field is finished before the next one starts: a field the AI could not finish is retried, never skipped.
  async function untilDone(run: () => Promise<boolean>): Promise<boolean> {
    for (let i = 0; i < 4; i++) {
      if (stopRef.current) return false
      // eslint-disable-next-line no-await-in-loop
      const ok = await run()
      if (ok) return true
      if (stopRef.current) return false
      if (i < 3) {
        setMsg(`The AI did not finish this field. Retrying (${i + 1} of 3)...`)
        // eslint-disable-next-line no-await-in-loop
        await new Promise((r) => setTimeout(r, (i + 1) * 8000))
      }
    }
    return false
  }

  async function completeAll() {
    stopRef.current = false
    bulkRef.current = true
    try { await completeAllInner() } finally { bulkRef.current = false }
  }

  async function completeAllInner() {
    const empty = secs.filter(([k]) => !doc[k]?.trim())
    let n = 0
    for (const [k, t] of secs) {
      if (stopRef.current) return
      if (!doc[k]?.trim()) {
        n++
        setAllProg(`Writing ${n} of ${empty.length}: ${t}`)
        // eslint-disable-next-line no-await-in-loop
        const ok = await untilDone(() => (isChoiceKey(k) ? suggestChoice(k, t) : complete(k, t)))
        if (!ok) {
          setAllProg('')
          if (!stopRef.current) setMsg(`Stopped at "${t}" because the AI could not finish it. The fields after it were not started, so press Save and reflect again to continue from this field.`)
          return
        }
        // eslint-disable-next-line no-await-in-loop
        await new Promise((r) => setTimeout(r, 300))
      }
    }
    setAllProg('')
  }


  const full =
    `${project.title || 'Grant proposal'}\n${profile.org}${profile.country ? ', ' + profile.country : ''}${target ? `\nPrepared for: ${target.funder}, ${target.title}` : ''}\n\n` +
    secs.map(([k, t], i) => `${i + 1}. ${t.toUpperCase()}\n${sectionPlain(doc[k] || '') || '[to complete]'}`).join('\n\n')


  const [saving, setSaving] = useState(false)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const w = await whoami()
        if (cancelled) return
        setOnline(w)
        if (!w.signedIn || !w.dbReady) return
        const [pr, r] = await Promise.all([loadProfileOnline().catch(() => null), listSaved().catch(() => null)])
        if (cancelled) return
        if (pr && pr.ok && pr.profile) {
          setProfile((cur) => (completeness(cur) === 0 ? ({ ...emptyProfile, ...pr.profile } as Profile) : cur))
        }
        if (!r || !r.ok) return
        setApps((cur) => mergeRemoteApps(cur, liveRemote(r.items)))
      } catch {}
    })()
    return () => { cancelled = true }
  }, [])


  const [exportOpen, setExportOpen] = useState(false)

  const profileSections = (): [string, [string, string][]][] => {
    const pr = profile as unknown as Record<string, string | undefined>
    const v = (k: string) => (pr[k] ?? '').toString().trim()
    const yn: Record<string, string> = { yes: 'Yes', pending: 'In progress', no: 'No' }
    const partner: Record<string, string> = { yes: 'Yes, as partner or lead', partner: 'As a partner only', no: 'No, we apply alone' }
    const usd = (k: string) => (v(k) ? `$${v(k).replace(/[^0-9.]/g, '') ? Number(v(k).replace(/[^0-9.]/g, '')).toLocaleString('en-US') : v(k)}` : '')
    return [
      ['Identity and legal status', [['Organization name', v('org')], ['Headquarters country', v('country')], ['Countries of legal registration', v('regCountry')], ['Organization type', v('orgType')], ['Legally registered', yn[v('registered')] ?? v('registered')], ['Tax status', v('taxStatus')], ['Year founded', v('founded')], ['Website or social link', v('website')]]],
      ['Where we work', [['Countries and regions of operation', v('opCountries')], ['Scope of work', v('scope')]]],
      ['What we do and who we serve', [['Sectors', v('focus')], ['Populations served', v('populations')], ['Mission', v('mission')]]],
      ['The funding we are looking for', [['Smallest grant worth applying for', usd('amountMin')], ['Largest grant we could absorb', usd('amountMax')], ['Types of funding wanted', v('grantTypes')], ['Open to working in a consortium', partner[v('partner')] ?? v('partner')]]],
      ['Capacity and compliance', [['Annual budget', v('budget')], ['Team size', v('size')], ['Largest grant managed', usd('largestGrant')]]],
      ['Track record', [['Past funding and key results', v('pastFunding')]]],
    ]
  }

  async function exportProfile(kind: 'docx' | 'pdf') {
    setExportOpen(false)
    const secs0 = profileSections()
    const name = (profile.org || 'organization').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase() || 'organization'
    const today = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })
    if (kind === 'pdf') {
      try {
        const { jsPDF } = await import('jspdf')
        const autoTable = (await import('jspdf-autotable')).default
        const pdf = new jsPDF({ unit: 'pt', format: 'a4' })
        const rgb = [parseInt(accentHex.slice(0, 2), 16), parseInt(accentHex.slice(2, 4), 16), parseInt(accentHex.slice(4, 6), 16)] as [number, number, number]
        const pageW = pdf.internal.pageSize.getWidth()
        const margin = 48
        pdf.setFont('times', 'bold').setFontSize(22).setTextColor(...rgb)
        const titleLines = pdf.splitTextToSize(profile.org || 'Organization profile', pageW - margin * 2) as string[]
        pdf.text(titleLines, margin, 62)
        let y = 62 + titleLines.length * 26 - 6
        pdf.setFont('times', 'italic').setFontSize(11).setTextColor(90, 90, 90)
        pdf.text(`Organization profile. Prepared ${today}.`, margin, y)
        y += 18
        for (const [t, rows] of secs0) {
          autoTable(pdf, {
            startY: y,
            margin: { left: margin, right: margin, bottom: 48 },
            head: [[{ content: t, colSpan: 2, styles: { halign: 'left', fillColor: rgb, textColor: 255, fontSize: 12, fontStyle: 'bold' } }]],
            body: rows.map(([l, val]) => [l, val || 'Not provided']),
            theme: 'grid',
            styles: { font: 'times', fontSize: 10.5, cellPadding: 6, lineColor: [207, 201, 184], lineWidth: 0.5, textColor: [26, 26, 26], overflow: 'linebreak' },
            columnStyles: { 0: { cellWidth: 170, fontStyle: 'bold', fillColor: [244, 241, 232] }, 1: { cellWidth: 'auto' } },
            didParseCell: (d: any) => { if (d.section === 'body' && d.column.index === 1 && d.cell.raw === 'Not provided') { d.cell.styles.textColor = [150, 150, 150]; d.cell.styles.fontStyle = 'italic' } },
          })
          y = ((pdf as any).lastAutoTable?.finalY ?? y) + 18
        }
        const pages = pdf.getNumberOfPages()
        for (let i = 1; i <= pages; i++) {
          pdf.setPage(i)
          pdf.setFont('times', 'normal').setFontSize(9).setTextColor(130, 130, 130)
          pdf.text(`${profile.org || 'Organization profile'}  |  Page ${i} of ${pages}`, margin, pdf.internal.pageSize.getHeight() - 24)
        }
        pdf.save(`${name}-organization-profile.pdf`)
        window.whop?.track?.('profile_exported_pdf')
      } catch {
        setProfNote('Could not create the PDF. Please try again.')
      }
      return
    }
    const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle } = await import('docx')
    const border = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' }
    const borders = { top: border, bottom: border, left: border, right: border }
    const kids: any[] = [
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: profile.org || 'Organization profile', color: accentHex })] }),
      new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: `Organization profile. Prepared ${today}.`, italics: true })] }),
    ]
    for (const [t, rows] of secs0) {
      kids.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 320, after: 120 }, children: [new TextRun({ text: t, color: accentHex })] }))
      kids.push(new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        columnWidths: [3100, 5900],
        rows: rows.map(([l, val]) => new TableRow({
          cantSplit: true,
          children: [
            new TableCell({ borders, width: { size: 34, type: WidthType.PERCENTAGE }, margins: { top: 60, bottom: 60, left: 100, right: 100 }, shading: { type: ShadingType.CLEAR, fill: 'F4F1E8', color: 'auto' }, children: [new Paragraph({ children: [new TextRun({ text: l, bold: true, size: 20 })] })] }),
            new TableCell({ borders, width: { size: 66, type: WidthType.PERCENTAGE }, margins: { top: 60, bottom: 60, left: 100, right: 100 }, children: (val || 'Not provided').split('\n').map((line) => new Paragraph({ children: [new TextRun({ text: line, size: 20, italics: !val, color: val ? undefined : '999999' })] })) }),
          ],
        })),
      }))
    }
    const blob = await Packer.toBlob(new Document({ sections: [{ children: kids }] }))
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `${name}-organization-profile.docx`
    a.click()
  }

  const [profBusy, setProfBusy] = useState(false)

  const [profNote, setProfNote] = useState('')

  async function saveProfile() {
    if (!online?.signedIn) {
      window.location.href = '/api/oauth/login?redirect_to=' + encodeURIComponent('/#profile')
      return
    }
    setProfBusy(true)
    setProfNote('')
    try {
      const r = await saveProfileOnline({ data: { profile: profile as Record<string, any> } })
      setProfNote(r.ok ? 'Profile saved online. It will load automatically when you sign in on another device.' : r.reason === 'signed_out' ? 'Your sign-in expired. Press the button again to sign in.' : 'Online saving is not available right now. Try again in a moment.')
      if (r.ok) window.whop?.track?.('profile_saved_online')
    } catch {
      setProfNote('Could not save online. Please try again.')
    }
    setProfBusy(false)
  }


  async function saveOnline() {
    if (!app) return
    if (!online?.signedIn) {
      window.location.href = '/api/oauth/login?redirect_to=' + encodeURIComponent('/#applications')
      return
    }
    setSaving(true)
    setMsg('')
    try {
      const cleanDoc: Record<string, string> = {}
      for (const [k, v] of Object.entries(app.doc)) cleanDoc[k] = tidy(v)
      const r = await saveApplication({ data: { id: app.id, title: project.title || target?.title || 'Untitled application', data: { ...app, doc: cleanDoc, updated: Date.now() } } })
      if (r.ok) { setMsg('Saved online. Sign in on any device to open this application again.'); syncedRef.current = app.updated; setSyncedAt(Date.now()); window.whop?.track?.('application_saved_online') }
      else if (r.reason === 'signed_out') { setOnline({ signedIn: false, name: '', dbReady: online.dbReady }); setMsg('Your sign-in expired. Press Save draft again to sign in.') }
      else if (r.reason === 'too_big') setMsg('This draft is too large to save online.')
      else if (r.reason === 'project_limit') { setOnlineLimit(r.max); setMsg(`Your plan keeps ${r.max} project${r.max === 1 ? '' : 's'} online. This draft is still saved in this browser. Open Plans to upgrade.`) }
      else setMsg('Online saving is not available right now. Try again in a moment.')
    } catch {
      setMsg('Could not save online. Please try again.')
    }
    setSaving(false)
  }


  // File name made of the grant name, the kind of file and a version number that goes up with each download, e.g. gates-foundation-proposal-V01.docx
  function exportName(kind: 'proposal' | 'budget', ext: string, bump = true) {
    const base = (target?.title || project.title || 'grant-proposal').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 60) || 'grant-proposal'
    const n = (app?.versions?.[kind] ?? 0) + (bump ? 1 : 0) || 1
    if (bump && app) patch((a) => ({ ...a, versions: { ...(a.versions ?? {}), [kind]: n } }))
    return `${base}-${kind}-V${String(n).padStart(2, '0')}${ext ? '.' + ext : ''}`
  }


  function downloadPdf() {
    const w = window.open('', '_blank')
    if (!w) { setMsg('Allow pop-ups to export the PDF.'); return }
    const c = '#' + accentHex
    const body = secs.map(([k, t], i) => {
      const parts = parseBlocks(tidy(doc[k] || '[to complete]')).map((b) => {
        if (b.type === 'table') return `<table>${b.rows.map((r, ri) => `<tr>${r.map((x) => (ri === 0 ? `<th>${escHtml(x)}</th>` : `<td>${escHtml(x)}</td>`)).join('')}</tr>`).join('')}</table>`
        return docLines(b.text).map((l) => (l.sub ? `<h3>${escHtml(l.text)}</h3>` : `<p>${escHtml(l.text)}</p>`)).join('')
      }).join('')
      return `<h2>${i + 1}. ${escHtml(t)}</h2>${parts}`
    }).join('')
    const meta = [project.amount && `Amount requested: ${project.amount} USD`, project.months && `Duration: ${project.months} months`].filter(Boolean).join(' | ')
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escHtml(exportName('proposal', ''))}</title><style>
      body{font-family:Georgia,serif;color:#1a1a1a;line-height:1.5;max-width:760px;margin:40px auto;padding:0 24px}
      h1{color:${c};font-size:28px;margin:0 0 4px} h2{color:${c};font-size:20px;margin:28px 0 8px;border-bottom:2px solid ${c};padding-bottom:4px}
      h3{color:#000;font-size:15px;margin:16px 0 4px} p{margin:6px 0;white-space:pre-wrap} .sub{color:#555;font-style:italic;margin:2px 0}
      table{border-collapse:collapse;width:100%;margin:10px 0;font-size:12px} th{background:${c};color:#fff;text-align:left} th,td{border:1px solid #bbb;padding:5px 8px}
      @media print{body{margin:0}h2{break-after:avoid}table{break-inside:avoid}} *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    </style></head><body><h1>${escHtml(project.title || 'Grant proposal')}</h1>
    <p class="sub">${escHtml([profile.org, profile.country].filter(Boolean).join(', '))}</p>
    ${target ? `<p class="sub">Prepared for: ${escHtml(target.funder)}, ${escHtml(target.title)}</p>` : ''}
    ${meta ? `<p>${escHtml(meta)}</p>` : ''}${body}</body></html>`)
    w.document.close()
    w.focus()
    setTimeout(() => w.print(), 400)
  }


  async function budgetExcelBuffer(text: string, singleSheet = false): Promise<ArrayBuffer | null> {
    const table = parseBlocks(text).find((b) => b.type === 'table' && b.rows[0].some((c) => /unit cost/i.test(c))) as Extract<Block, { type: 'table' }> | undefined
    const any = table ?? (parseBlocks(text).find((b) => b.type === 'table') as Extract<Block, { type: 'table' }> | undefined)
    if (!any) return null
    const ExcelJS: any = (await import('exceljs')).default ?? (await import('exceljs'))
    const wb = new ExcelJS.Workbook()
    const ws = wb.addWorksheet('Budget')
    const head = { font: { bold: true, color: { argb: 'FFFFFFFF' } }, fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF12302F' } }, alignment: { vertical: 'middle', wrapText: true } }
    const soft = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFEADC' } }
    const thin = { style: 'thin', color: { argb: 'FFBBBBBB' } }
    const box = { top: thin, left: thin, bottom: thin, right: thin }
    const money = '#,##0.00'
    ws.addRow([project.title || 'Project budget'])
    ws.getRow(1).font = { bold: true, size: 14 }
    ws.addRow([`${profile.org}${profile.country ? ', ' + profile.country : ''}${target ? ' | ' + target.funder : ''} | USD`])
    ws.addRow([])
    const styleRow = (row: any, fill?: any, bold = false) => row.eachCell({ includeEmpty: true }, (c: any) => { c.border = box; if (fill) c.fill = fill; if (bold) c.font = { bold: true }; c.alignment = { vertical: 'top', wrapText: true } })

    if (!table) {
      const hdr = ws.addRow(any.rows[0].map((c) => clean(c)))
      hdr.eachCell((c: any) => Object.assign(c, head, { border: box }))
      for (const r of any.rows.slice(1)) {
        const row = ws.addRow(r.map((c) => (num(c) !== null ? num(c) : clean(c))))
        styleRow(row, /total/i.test(r.join(' ')) ? soft : undefined, /total/i.test(r.join(' ')))
      }
      ws.columns.forEach((c: any) => { c.width = 22 })
    } else {
      const h = table.rows[0].map((c) => c.toLowerCase())
      const col = (re: RegExp) => h.findIndex((c) => re.test(c))
      const ci = { n: col(/^#/), act: col(/activity/), item: col(/cost item|item/), unit: col(/^unit$/), qty: col(/^qty|quantity/), uc: col(/unit cost/), tot: col(/total/) }
      const hdr = ws.addRow(['#', 'Activity', 'Cost item', 'Unit', 'Qty', 'Unit cost (USD)', 'Total (USD)'])
      hdr.height = 28
      hdr.eachCell((c: any) => Object.assign(c, head, { border: box }))
      const g = (r: string[], i: number) => (i >= 0 ? clean(r[i] ?? '') : '')
      let actN = '', actName = ''
      let first = 0, last = 0
      const subRows: { n: string; name: string; row: number }[] = []
      let directRow = 0, indirectRow = 0, rate = 0.1
      let direct = 0
      for (const r of table.rows.slice(1)) {
        const joined = r.join(' ')
        const isSub = /subtotal/i.test(joined)
        const isDirect = /direct costs/i.test(joined)
        const isInd = /indirect/i.test(joined)
        const isTotal = /\btotal\b/i.test(joined) && !isSub && !isDirect && !isInd
        if (isSub) {
          const row = ws.addRow(['', `Subtotal, activity ${actN}`, '', '', '', '', { formula: `SUM(G${first}:G${last})` }])
          styleRow(row, soft, true)
          subRows.push({ n: actN, name: actName, row: row.number })
          first = 0
        } else if (isDirect) {
          const refs = subRows.map((x) => `G${x.row}`).join(',')
          const row = ws.addRow(['', 'Direct costs', '', '', '', '', { formula: refs ? `SUM(${refs})` : '0' }])
          styleRow(row, soft, true)
          directRow = row.number
        } else if (isInd) {
          const v = num(r[ci.tot] ?? '') ?? 0
          const dRow = table.rows.find((x) => /direct costs/i.test(x.join(' ')))
          direct = dRow ? (num(dRow[ci.tot] ?? '') ?? 0) : 0
          rate = direct ? Math.round((v / direct) * 1000) / 1000 : 0.1
          const row = ws.addRow(['', 'Indirect and administrative costs (rate in column F)', '', '', '', rate, { formula: `ROUND(G${directRow}*F${ws.rowCount + 1},2)` }])
          row.getCell(6).numFmt = '0.0%'
          row.getCell(6).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF3CD' } }
          styleRow(row)
          indirectRow = row.number
        } else if (isTotal) {
          const row = ws.addRow(['', 'TOTAL', '', '', '', '', { formula: `G${directRow}+G${indirectRow}` }])
          styleRow(row, soft, true)
        } else {
          const n = g(r, ci.n)
          if (n) { actN = n; actName = g(r, ci.act) }
          const rowNo = ws.rowCount + 1
          const row = ws.addRow([n, g(r, ci.act), g(r, ci.item), g(r, ci.unit), num(r[ci.qty] ?? '') ?? 0, num(r[ci.uc] ?? '') ?? 0, { formula: `E${rowNo}*F${rowNo}` }])
          if (!first) first = rowNo
          last = rowNo
          styleRow(row)
        }
      }
      ws.columns = [{ width: 5 }, { width: 34 }, { width: 34 }, { width: 11 }, { width: 9 }, { width: 16 }, { width: 16 }]
      ws.eachRow((row: any, i: number) => { if (i > 3) { row.getCell(5).numFmt = '#,##0.##'; if (row.getCell(6).numFmt !== '0.0%') row.getCell(6).numFmt = money; row.getCell(7).numFmt = money } })
      ws.views = [{ state: 'frozen', ySplit: 4 }]

      const sm = wb.addWorksheet('Summary by activity')
      const sh = sm.addRow(['Activity', 'Subtotal (USD)', 'Share of total'])
      sh.eachCell((c: any) => Object.assign(c, head, { border: box }))
      const lastSum = subRows.length + 1
      subRows.forEach((x, i) => {
        const row = sm.addRow([`${x.n}. ${x.name}`, { formula: `Budget!G${x.row}` }, { formula: `B${i + 2}/B${lastSum + 2}` }])
        styleRow(row)
      })
      const ind = sm.addRow(['Indirect and administrative', { formula: `Budget!G${indirectRow}` }, { formula: `B${lastSum + 1}/B${lastSum + 2}` }])
      styleRow(ind)
      const tt = sm.addRow(['TOTAL', { formula: `SUM(B2:B${lastSum + 1})` }, { formula: `SUM(C2:C${lastSum + 1})` }])
      styleRow(tt, soft, true)
      sm.columns = [{ width: 48 }, { width: 18 }, { width: 14 }]
      sm.eachRow((row: any, i: number) => { if (i > 1) { row.getCell(2).numFmt = money; row.getCell(3).numFmt = '0.0%' } })
    }
    if (singleSheet) { const extra = wb.getWorksheet('Summary by activity'); if (extra) wb.removeWorksheet(extra.id) }
    return (await wb.xlsx.writeBuffer()) as ArrayBuffer
  }

  async function downloadExcel(text: string, singleSheet = false) {
    const buf = await budgetExcelBuffer(text, singleSheet)
    if (!buf) { setMsg('There is no budget table to export yet.'); return }
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }))
    a.download = exportName('budget', 'xlsx')
    a.click()
  }


  async function makeWordBlob(custom?: { title: string; sections: [string, string][] }): Promise<Blob> {
    const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle } = await import('docx')
    const kids: any[] = [
      new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: custom?.title ?? (project.title || 'Grant proposal'), color: accentHex })] }),
      new Paragraph({ children: [new TextRun({ text: [profile.org, profile.country].filter(Boolean).join(', '), italics: true })] }),
    ]
    if (target && !custom) kids.push(new Paragraph({ children: [new TextRun({ text: `Prepared for: ${target.funder}, ${target.title}`, italics: true })] }))
    const meta = [project.amount && `Amount requested: $${project.amount} USD`, project.months && `Duration: ${project.months} months`].filter(Boolean)
    if (meta.length && !custom) kids.push(new Paragraph({ spacing: { before: 120, after: 240 }, children: [new TextRun(meta.join('   |   '))] }))
    ;(custom ? custom.sections.map(([t, text], i) => [`c${i}`, t, text] as const) : secs.map(([k, t]) => [k, t, doc[k] || ''] as const)).forEach(([k, t, body], i) => {
      if (t) kids.push(new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 120 }, children: [new TextRun({ text: custom ? t : `${i + 1}. ${t}`, color: accentHex })] }))
      for (const blk of parseBlocks(tidy(body || '[to complete]'))) {
        if (blk.type === 'text') {
          docLines(blk.text).forEach((l) => {
            if (l.sub) {
              kids.push(new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 200, after: 80 }, children: [new TextRun({ text: l.text, bold: true, color: '000000' })] }))
              return
            }
            const bullet = /^\s*[-•]\s+/.test(l.text)
            kids.push(new Paragraph({ bullet: bullet ? { level: 0 } : undefined, spacing: { after: 120 }, children: [new TextRun(l.text.replace(/^\s*[-•]\s+/, ''))] }))
          })
        } else {
          const cols = blk.rows[0].length
          const border = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' }
          const borders = { top: border, bottom: border, left: border, right: border }
          const widths = blk.rows[0].map((_h, ci) => {
            const longest = Math.max(...blk.rows.map((r) => (r[ci] ?? '').length), 4)
            return Math.min(Math.max(longest, 8), 40)
          })
          const sum = widths.reduce((x, y) => x + y, 0)
          const pct = widths.map((w) => Math.round((w / sum) * 100))
          kids.push(
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              columnWidths: pct.map((p) => Math.round((p / 100) * 9000)),
              rows: blk.rows.map((r, ri) => {
                const isTotal = ri > 0 && /total/i.test(r.join(' '))
                return new TableRow({
                  tableHeader: ri === 0,
                  cantSplit: true,
                  children: r.slice(0, cols).map((c, ci) =>
                    new TableCell({
                      borders,
                      width: { size: pct[ci], type: WidthType.PERCENTAGE },
                      margins: { top: 60, bottom: 60, left: 100, right: 100 },
                      shading: ri === 0 ? { type: ShadingType.CLEAR, fill: accentHex, color: 'auto' } : isTotal ? { type: ShadingType.CLEAR, fill: 'EFEADC', color: 'auto' } : undefined,
                      children: [
                        new Paragraph({
                          alignment: ri > 0 && num(c) !== null ? AlignmentType.RIGHT : AlignmentType.LEFT,
                          children: [new TextRun({ text: clean(c), bold: ri === 0 || isTotal, color: ri === 0 ? 'FFFFFF' : undefined, size: 20 })],
                        }),
                      ],
                    }),
                  ),
                })
              }),
            }),
          )
          kids.push(new Paragraph({ spacing: { after: 160 }, children: [] }))
        }
      }
      if (!custom && /timeline|work ?plan|schedule/i.test(t)) {
        const g = ganttFrom(doc[k] || '', Number(project.months) || 12)
        if (g) {
          const bd = { style: BorderStyle.SINGLE, size: 4, color: 'BBBBBB' }
          const bds = { top: bd, bottom: bd, left: bd, right: bd }
          const nameW = 3000
          const cellW = Math.max(Math.floor(6000 / g.max), 220)
          const hdr = { type: ShadingType.CLEAR, fill: accentHex, color: 'auto' } as const
          kids.push(new Paragraph({ spacing: { before: 120, after: 80 }, children: [new TextRun({ text: 'Gantt view (columns are months)', bold: true, color: '000000' })] }))
          kids.push(
            new Table({
              columnWidths: [nameW, ...Array(g.max).fill(cellW)],
              rows: [
                new TableRow({
                  tableHeader: true,
                  children: [
                    new TableCell({ borders: bds, width: { size: nameW, type: WidthType.DXA }, shading: hdr, children: [new Paragraph({ children: [new TextRun({ text: 'Activity', bold: true, color: 'FFFFFF', size: 16 })] })] }),
                    ...Array.from({ length: g.max }, (_, i) => new TableCell({ borders: bds, width: { size: cellW, type: WidthType.DXA }, shading: hdr, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: String(i + 1), color: 'FFFFFF', size: 14 })] })] })),
                  ],
                }),
                ...g.rows.map((r) => new TableRow({
                  cantSplit: true,
                  children: [
                    new TableCell({ borders: bds, width: { size: nameW, type: WidthType.DXA }, children: [new Paragraph({ children: [new TextRun({ text: r.name, size: 16 })] })] }),
                    ...Array.from({ length: g.max }, (_, i) => new TableCell({ borders: bds, width: { size: cellW, type: WidthType.DXA }, shading: i + 1 >= r.s && i + 1 <= r.e ? { type: ShadingType.CLEAR, fill: 'C2570C', color: 'auto' } : undefined, children: [new Paragraph({ children: [] })] })),
                  ],
                })),
              ],
            }),
          )
        }
      }
    })
    return await Packer.toBlob(new Document({ sections: [{ children: kids }] }))
  }

  async function downloadWord() {
    const blob = await makeWordBlob()
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = exportName('proposal', 'docx')
    a.click()
  }


  // Reflects any improvement that is still waiting, then downloads the updated proposal as Word. The download runs after the draft has updated.
  const [wantWord, setWantWord] = useState(false)

  useEffect(() => {
    if (wantWord) { setWantWord(false); downloadWord() }
  }, [wantWord])

  function reflectAndDownload() {
    const pending = qFlow.cards.filter((c) => c.status === 'pending' && c.newText)
    if (pending.length) applyCards(pending)
    setWantWord(true)
  }

  // ---- Project documents prepared from the written proposal: MEAL plan, tools, logframe, implementation plan, reporting templates ----
  const [pdBusy, setPdBusy] = useState('')

  const [exEditing, setExEditing] = useState<Record<string, boolean>>({})

  const [pdNote, setPdNote] = useState('')

  async function genProjectDoc(key: string, kind: 'meal' | 'tool' | 'logframe' | 'implementation' | 'matrix' | 'report', variant: string, title: string) {
    const written = secs.filter(([k]) => (doc[k] ?? '').trim().length > 40).length
    if (written < 2) { setPdNote('Write at least two proposal sections first. These documents are built from the written proposal.'); return }
    setPdBusy(key)
    setPdNote('')
    try {
      const bsec = secs.find(([, t]) => /budget/i.test(t))
      const budgetTxt = ((bsec ? doc[bsec[0]] : doc['x_budget']) ?? '').trim()
      const proposal = (kind === 'matrix' && budgetTxt ? `BUDGET TABLE (the source of every cost in the matrix):\n${budgetTxt.slice(0, 5000)}\n\n` : '') + factsCtx() + full + ((doc['x_budget'] ?? '').trim() ? `\n\nBUDGET\n${doc['x_budget']}` : '')
      const r = await generateProjectDoc({ data: { kind, variant, profile, proposal, instruction: (app?.docNotes ?? '').trim() || undefined, title: project.title, amount: project.amount, months: project.months, funder: target?.funder, framework: app?.framework ? FRAME_FIELDS.map(([k, t]) => ((app.framework!.selected as any)[k] ?? []).length ? `${t}: ${((app.framework!.selected as any)[k] as string[]).join('; ')}` : '').filter(Boolean).join(' | ') : undefined } })
      if (r.ok) {
        patch((a) => ({ ...a, extras: { ...(a.extras ?? {}), [key]: { title, text: r.text, at: Date.now(), ...('data' in r && r.data ? { data: r.data } : {}) } } }))
        setPdNote(`${title} is ready below.`)
        window.whop?.track?.('project_doc_generated', { kind })
      } else setPdNote(friendlyAiError(r.reason))
    } catch {
      setPdNote('Something went wrong. Please try again.')
    }
    setPdBusy('')
  }

  async function downloadExtraExcel(key: string) {
    const x = app?.extras?.[key]
    if (!x) return
    const mod: any = await import('exceljs')
    const ExcelJS = mod.default ?? mod
    const wb = new ExcelJS.Workbook()
    const accentArgb = 'FF' + accentHex.toUpperCase()
    const thin = { style: 'thin', color: { argb: 'FFBBBBBB' } }
    const border = { top: thin, bottom: thin, left: thin, right: thin }
    const colL = (n: number) => { let s = ''; for (let i = n; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + ((i - 1) % 26)) + s; return s }
    let parsed: any = null
    try { parsed = x.data ? JSON.parse(x.data) : null } catch {}
    // An edited IPTT table is read back, so the workbook matches what is on screen.
    if (parsed?.indicators?.length) {
      const tb = parseBlocks(tidy(x.text)).find((b): b is Extract<typeof b, { type: 'table' }> => b.type === 'table')
      const hd = tb?.rows[0]?.map((h) => h.toLowerCase()) ?? []
      const ix = (re: RegExp) => hd.findIndex((h) => re.test(h))
      const iInd = ix(/^indicator$/), iTgt = ix(/target \(project\)/)
      if (tb && iInd >= 0 && iTgt >= 0) {
        const P2 = parsed.periods as number
        const qIdx = Array.from({ length: P2 }, (_, q) => ix(new RegExp(`^q${q + 1} target$`)))
        const nn = (v: string) => { const n = Number(String(v ?? '').replace(/[^0-9.\-]/g, '')); return Number.isFinite(n) ? n : 0 }
        const cell = (r: string[], i: number) => (i >= 0 ? clean(r[i] ?? '') : '')
        const rows = tb.rows.slice(1).filter((r) => cell(r, iInd))
        if (rows.length) {
          parsed = { periods: P2, indicators: rows.map((r, ri) => {
            const old = parsed.indicators[ri] ?? {}
            return {
              level: cell(r, ix(/^level$/)) || old.level || 'Outcome',
              indicator: cell(r, iInd),
              definition: cell(r, ix(/^definition/)),
              unit: '',
              disaggregation: old.disaggregation ?? '',
              baseline: cell(r, ix(/^baseline$/)),
              target: nn(cell(r, iTgt)),
              periodTargets: qIdx.map((qi) => (qi >= 0 ? nn(cell(r, qi)) : 0)),
              source: cell(r, ix(/^data source$/)),
              method: cell(r, ix(/^method$/)),
              frequency: cell(r, ix(/^frequency$/)),
              responsible: cell(r, ix(/^responsible$/)),
            }
          }) }
        }
      }
    }
    if (parsed?.indicators?.length) {
      const P: number = parsed.periods
      const ws = wb.addWorksheet('IPTT', { views: [{ state: 'frozen', xSplit: 3, ySplit: 5 }] })
      const heads = ['#', 'Level', 'Indicator', 'Definition', 'Unit', 'Disaggregation', 'Baseline', 'Target (project)']
      for (let i = 1; i <= P; i++) heads.push(`Q${i} target`, `Q${i} actual`)
      heads.push('Total achieved', '% of target', 'Data source', 'Method', 'Frequency', 'Responsible', 'Remarks')
      ws.mergeCells(1, 1, 1, 8)
      ws.getCell('A1').value = `Indicator Performance Tracking Table (IPTT): ${project.title || 'Project'}`
      ws.getCell('A1').font = { bold: true, size: 14, color: { argb: accentArgb } }
      ws.getCell('A2').value = [profile.org, target?.funder && `Funder: ${target.funder}`, project.months && `Duration: ${project.months} months`].filter(Boolean).join('   |   ')
      ws.getCell('A3').value = 'Enter the actual result for each quarter in the yellow cells. Total achieved and % of target are calculated automatically.'
      ws.getCell('A3').font = { italic: true, color: { argb: 'FF666666' } }
      const hr = ws.getRow(5)
      heads.forEach((h, i) => { const c = hr.getCell(i + 1); c.value = h; c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: accentArgb } }; c.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' }; c.border = border })
      hr.height = 32
      const firstQ = 9
      const totalCol = firstQ + P * 2
      const pctCol = totalCol + 1
      parsed.indicators.forEach((x2: any, i: number) => {
        const r = 6 + i
        const row = ws.getRow(r)
        const vals: any[] = [i + 1, x2.level, x2.indicator, x2.definition, x2.unit, x2.disaggregation, x2.baseline, x2.target || null]
        for (let q = 0; q < P; q++) vals.push(x2.periodTargets[q] || null, null)
        const actualRefs = Array.from({ length: P }, (_, q) => `${colL(firstQ + q * 2 + 1)}${r}`)
        vals.push({ formula: `IF(COUNT(${actualRefs.join(',')})=0,"",SUM(${actualRefs.join(',')}))` })
        vals.push({ formula: `IF(OR(H${r}="",H${r}=0,${colL(totalCol)}${r}=""),"",${colL(totalCol)}${r}/H${r})` })
        vals.push(x2.source, x2.method, x2.frequency, x2.responsible, '')
        vals.forEach((v, ci) => {
          const c = row.getCell(ci + 1)
          c.value = v
          c.border = border
          c.alignment = { wrapText: true, vertical: 'top' }
        })
        for (let q = 0; q < P; q++) row.getCell(firstQ + q * 2 + 1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF6C8' } }
        row.getCell(pctCol).numFmt = '0%'
        if (x2.level === 'Goal' || x2.level === 'Outcome') row.getCell(2).font = { bold: true }
      })
      const widths = [5, 10, 46, 38, 10, 22, 14, 14, ...Array.from({ length: P * 2 }, () => 11), 14, 12, 28, 26, 16, 20, 24]
      widths.forEach((w, i) => { ws.getColumn(i + 1).width = w })
      const lastRow = 5 + parsed.indicators.length
      ws.addConditionalFormatting({ ref: `${colL(pctCol)}6:${colL(pctCol)}${lastRow}`, rules: [
        { type: 'cellIs', operator: 'greaterThanOrEqual', formulae: [0.9], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFC6EFCE' } } } },
        { type: 'cellIs', operator: 'lessThan', formulae: [0.5], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFFFC7CE' } } } },
      ] })
      ws.autoFilter = { from: { row: 5, column: 1 }, to: { row: lastRow, column: heads.length } }
    } else {
      const tables = parseBlocks(tidy(x.text)).filter((b): b is Extract<typeof b, { type: 'table' }> => b.type === 'table')
      if (!tables.length) { setPdNote('This document has no table to export. Use Download Word instead.'); return }
      tables.slice(0, 12).forEach((t, ti) => {
        const ws = wb.addWorksheet(`Table ${ti + 1}`.slice(0, 31), { views: [{ state: 'frozen', ySplit: 1 }] })
        t.rows.forEach((r, ri) => {
          const row = ws.addRow(r.map((c) => clean(c)))
          row.eachCell((c: any) => { c.border = border; c.alignment = { wrapText: true, vertical: 'top' }; if (ri === 0) { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: accentArgb } } } })
        })
        t.rows[0].forEach((_h, ci) => { ws.getColumn(ci + 1).width = Math.min(48, Math.max(12, ...t.rows.map((r) => (r[ci] ?? '').length / 1.6))) })
      })
    }
    const buf = await wb.xlsx.writeBuffer()
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }))
    const base = (project.title || 'project').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 40) || 'project'
    a.download = `${base}-${x.title.replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase()}.xlsx`
    a.click()
  }

  async function downloadExtraWord(key: string) {
    const x = app?.extras?.[key]
    if (!x) return
    const blob = await makeWordBlob({ title: `${x.title}: ${project.title || 'Project'}`, sections: [['', x.text]] })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    const base = (project.title || 'project').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 40) || 'project'
    a.download = `${base}-${x.title.replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase()}.docx`
    a.click()
  }


  const [findsTried, setFindsTried] = useState(false)

  // ---- Compare grants, last verified date and saved searches ----
  const [cmpIds, setCmpIds] = useState<string[]>([])

  const [cmpOpen, setCmpOpen] = useState(false)

  const [resultsAt, setResultsAt] = useState(0)

  useEffect(() => {
    if (!results?.length) return
    const now = Date.now()
    setResultsAt(now)
    // A saved grant that comes back with a new deadline is updated and flagged.
    const fresh = new Map(results.map((g) => [g.id, g]))
    setSaved((cur) => cur.map((g) => {
      const f = fresh.get(g.id)
      if (!f) return g
      if (f.deadline && f.deadline !== 'Not stated' && f.deadline !== g.deadline) return { ...g, prevDeadline: g.deadline, deadline: f.deadline, checkedAt: now }
      return { ...g, checkedAt: now }
    }))
  }, [results])

  const toggleCmp = (id: string) => setCmpIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : cur.length >= 4 ? cur : [...cur, id]))

  type SavedSearch = { id: string; name: string; keyword: string; sources: string[]; lastRun: number; lastIds: string[]; newCount: number }

  const [searches, setSearches] = useStored<SavedSearch[]>('ngw_searches', [])

  const [ssBusy, setSsBusy] = useState(false)

  async function checkSearches(only?: string) {
    setSsBusy(true)
    const out: SavedSearch[] = []
    for (const ss of searches) {
      if (only && ss.id !== only) { out.push(ss); continue }
      try {
        // eslint-disable-next-line no-await-in-loop
        const r = await searchGrants({ data: { keyword: ss.keyword, sources: ss.sources as Src[] } })
        const ids = r.grants.map((g) => g.id)
        const fresh = ss.lastIds.length ? ids.filter((id) => !ss.lastIds.includes(id)).length : 0
        out.push({ ...ss, lastRun: Date.now(), lastIds: ids, newCount: ss.newCount + fresh })
      } catch { out.push(ss) }
    }
    setSearches(out)
    setSsBusy(false)
  }

  useEffect(() => {
    if (view !== 'find' || !searches.length) return
    if (searches.some((x) => Date.now() - x.lastRun > 12 * 3600 * 1000)) checkSearches()
  }, [view, searches.length])

  const cmpRows = (): CompareRow[] => cmpIds.map((id) => (results ?? []).find((g) => g.id === id) ?? saved.find((g) => g.id === id)).filter((g): g is Grant => !!g).map((g) => {
    const dd = parseDate(g.deadline)
    return { g, match: quickMatch(g, profile), status: normStatus(g), days: dd ? Math.ceil((dd.getTime() - Date.now()) / 864e5) : null, award: amountLabel(g), saved: isSaved(g.id), hasApp: apps.some((a) => a.grant?.id === g.id) }
  })

  // Loads the grants matched to your saved profile into the results list. `force` searches again right now.
  async function refreshMatches(force: boolean) {
    if (!online?.signedIn) {
      if (force) await runProfileSearch()
      return
    }
    setBusy('refresh')
    setNotes([])
    try {
      const r = await getFindings({ data: { profile, force } })
      if (r.ok) {
        const list = (r.items as unknown as { g: Grant }[]).map((x) => x.g)
        if (list.length || force) {
          setResults(list)
          setFStatus([]); setFDeadline([]); setFSource([]); setFText(''); setOnlyDated(false); setFCountry([]); setFType([]); setFSector([]); setFAmin(''); setFAmax('')
          setSort('priority')
        }
        setNotes(r.note ? [r.note] : force && !list.length ? ['No strong matches yet. Add sectors and countries to your profile, then try again.'] : [])
      } else if (force) setNotes([r.reason === 'signed_out' ? 'Sign in to refresh your matches.' : 'Matches are not available right now. Try again in a moment.'])
    } catch {
      if (force) setNotes(['Could not refresh matches. Please try again.'])
    }
    setBusy('')
  }

  useEffect(() => {
    if (view === 'find' && online?.signedIn && online.dbReady && !findsTried) {
      setFindsTried(true)
      refreshMatches(false)
    }
  }, [view, online, findsTried])


  const daysLeft = (g: Grant | null) => {
    const d = g ? parseDate(g.deadline) : null
    return d ? Math.ceil((d.getTime() - Date.now()) / 864e5) : null
  }

  const progressOf = (a: Application) => {
    const keys = a.tpl ? a.tpl.sections.map((x) => x.key) : SECTIONS.map(([k]) => k)
    const done = keys.filter((k) => (a.doc[k] ?? '').trim().length > 20).length
    return { done, total: keys.length, pct: keys.length ? Math.round((done / keys.length) * 100) : 0 }
  }

  const statusTone: Record<AppStatus, string> = {
    Drafting: 'bg-card text-ink',
    'In review': 'bg-amber-100 text-amber-900',
    Submitted: 'bg-sky-100 text-sky-900',
    Awarded: 'bg-green-100 text-green-900',
    Declined: 'bg-red-100 text-red-900',
  }

  const Badge = ({ days }: { days: number | null }) =>
    days === null ? (
      <span className="rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-muted">No date</span>
    ) : days < 0 ? (
      <span className="rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-muted">Closed</span>
    ) : (
      <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${days <= 14 ? 'bg-red-100 text-red-900' : days <= 45 ? 'bg-amber-100 text-amber-900' : 'bg-green-100 text-green-900'}`}>
        {days === 0 ? 'Due today' : `${days} day${days === 1 ? '' : 's'} left`}
      </span>
    )

  const PageHead = ({ title, sub, children }: { title: string; sub: string; children?: React.ReactNode }) => (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-4 border-b border-line pb-4">
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight md:text-3xl">{title}</h1>
        <p className="mt-2 max-w-2xl text-muted">{sub}</p>
      </div>
      {children}
    </div>
  )

  const Stat = ({ label: l, value, hint, onClick }: { label: string; value: React.ReactNode; hint?: string; onClick?: () => void }) => (
    <button onClick={onClick} className="rounded-card border border-line bg-card p-5 text-left transition hover:border-accent/60">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{l}</p>
      <p className="mt-2 font-display text-3xl font-semibold tabular-nums">{value}</p>
      {hint && <p className="mt-1 text-sm text-muted">{hint}</p>}
    </button>
  )


  const pct = completeness(profile)

  const activeApps = apps.filter((a) => a.status === 'Drafting' || a.status === 'In review')

  const fitScores = saved.map((g) => fits[g.id]?.score).filter((x): x is number => typeof x === 'number')

  const avgFit = fitScores.length ? Math.round(fitScores.reduce((x, y) => x + y, 0) / fitScores.length) : null

  const deadlineItems = (() => {
    const map = new Map<string, { g: Grant; days: number }>()
    for (const g of [...saved, ...apps.map((a) => a.grant).filter((x): x is Grant => !!x)]) {
      const d = daysLeft(g)
      if (d !== null && d >= 0) map.set(g.id, { g, days: d })
    }
    return [...map.values()].sort((a, b) => a.days - b.days)
  })()

  const nextDeadline = deadlineItems[0]

  const focusTags = profile.focus.split(',').map((x) => x.trim()).filter(Boolean)

  const nextAction = (() => {
    if (pct < 60) return { title: 'Complete your organization profile', body: `It is ${pct}% complete. A fuller profile gives sharper fit scores and better drafts.`, cta: 'Open profile', go: () => setView('profile') }
    if (saved.length === 0) return { title: 'Find your first grants', body: 'Search open calls and save the ones worth a closer look.', cta: 'Search grants', go: () => setView('find') }
    if (apps.length === 0) {
      const best = [...saved].sort((a, b) => (fits[b.id]?.score ?? -1) - (fits[a.id]?.score ?? -1))[0]
      return { title: `Start an application for ${best.title}`, body: 'Turn a saved grant into a draft proposal with funder-specific sections.', cta: 'Start application', go: () => startApplication(best) }
    }
    const cont = [...activeApps].sort((a, b) => b.updated - a.updated)[0]
    if (cont) return { title: `Continue ${cont.grant?.title ?? (cont.project.title || 'your draft')}`, body: `${progressOf(cont).done} of ${progressOf(cont).total} sections written.`, cta: 'Open application', go: () => { setActiveId(cont.id); setAppOpen(true); setView('applications') } }
    return { title: 'Look for more opportunities', body: 'All your applications are submitted or decided. Keep the pipeline full.', cta: 'Search grants', go: () => setView('find') }
  })()

  const goSearch = (kw: string) => {
    setQ(kw)
    setView('find')
    runSearch(undefined, kw)
  }


  const [detailsCache, setDetailsCache] = useStored<Record<string, GrantDetail>>('ngw_details', {})

  const [detailGrant, setDetailGrant] = useState<Grant | null>(null)

  const [detailBusy, setDetailBusy] = useState(false)

  const [detailErr, setDetailErr] = useState('')

  async function loadDetails(g: Grant) {
    setDetailBusy(true)
    setDetailErr('')
    try {
      const r = await grantDetails({ data: { grant: { ...g, details: g.details?.slice(0, 3000) }, profile } })
      if (r.ok) setDetailsCache((c) => ({ ...c, [g.id]: r.detail }))
      else setDetailErr(r.reason)
    } catch {
      setDetailErr('Could not build the brief. Please try again.')
    }
    setDetailBusy(false)
  }

  function openDetails(g: Grant) {
    setDetailGrant(g)
    setDetailErr('')
    if (!detailsCache[g.id]) loadDetails(g)
  }

  const [pipeTab, setPipeTab] = useState<PipeTab>('open')

  const [pipeOpen, setPipeOpen] = useState<string | null>(null)

  type Row = { id: string; name: string; sub: string; amount: string; amt: number; dlt: number; status: string; tone: string; deadline: string; grant: Grant | null; appId?: string }

  const pool = (() => {
    const m = new Map<string, Grant>()
    const gone = new Set(removedGrants)
    for (const g of [...seen, ...(results ?? [])]) if (!gone.has(g.id)) m.set(g.id, g)
    for (const g of [...saved, ...apps.map((a) => a.grant).filter((x): x is Grant => !!x)]) m.set(g.id, g)
    return [...m.values()]
  })()

  const dl = (g: Grant) => parseDate(g.deadline)?.getTime() ?? Infinity

  const toneFor = (label: string) =>
    /open|rolling/i.test(label) ? 'bg-green-100 text-green-900'
      : /upcoming/i.test(label) ? 'bg-sky-100 text-sky-900'
      : /invite/i.test(label) ? 'bg-violet-100 text-violet-900'
      : /draft|review/i.test(label) ? 'bg-amber-100 text-amber-900'
      : /saved/i.test(label) ? 'bg-card text-ink' : 'bg-card text-muted'

  const gRow = (g: Grant, label: string): Row => ({ id: g.id, name: g.title, sub: g.funder, amount: amountLabel(g) || 'Not stated', amt: g.amountMax || g.amountMin || 0, dlt: dl(g), status: label, tone: toneFor(label), deadline: g.deadline, grant: g })

  const grantLabel = (g: Grant) => {
    const st = normStatus(g)
    if (isInvite(g) && st !== 'closed') return 'Invite only'
    if (st === 'open') return 'Open'
    if (st === 'rolling') return 'Open (rolling)'
    if (st === 'forthcoming') return 'Upcoming cycle'
    if (st === 'closed') return 'Closed'
    return 'Status unknown'
  }

  const pipeRows: Record<PipeTab, Row[]> = {
    open: pool.filter((g) => !isInvite(g) && ['open', 'rolling'].includes(normStatus(g))).sort((a, b) => dl(a) - dl(b)).map((g) => gRow(g, grantLabel(g))),
    upcoming: pool.filter((g) => !isInvite(g) && normStatus(g) === 'forthcoming').sort((a, b) => dl(a) - dl(b)).map((g) => gRow(g, 'Upcoming cycle')),
    invite: pool.filter((g) => isInvite(g) && normStatus(g) !== 'closed').map((g) => gRow(g, 'Invite only')),
    saved: saved.map((g) => gRow(g, grantLabel(g))),
    applying: apps
      .filter((a) => a.status === 'Drafting' || a.status === 'In review')
      .map((a) => {
        const pr = progressOf(a)
        const g = a.grant
        return {
          id: a.id,
          name: g?.title ?? (a.project.title || 'Untitled application'),
          sub: g ? g.funder : 'No grant selected',
          amount: a.project.amount ? `$${Number(a.project.amount.replace(/[^0-9.]/g, '') || 0).toLocaleString('en-US')} requested` : g ? amountLabel(g) || 'Not stated' : 'Not stated',
          amt: Number((a.project.amount ?? '').replace(/[^0-9.]/g, '')) || (g ? g.amountMax || g.amountMin || 0 : 0),
          dlt: g ? dl(g) : Infinity,
          status: `${a.status} (${pr.pct}%)`,
          tone: toneFor(a.status),
          deadline: g?.deadline ?? '',
          grant: g,
          appId: a.id,
        } as Row
      }),
  }

  const [pSort, setPSort] = useState<SortState>(null)

  // The pipeline can be filtered by fit score. Only grants that have had a fit analysis have a score.
  const [pFit, setPFit] = useState<'all' | 'analyzed' | '80' | '60' | 'low' | 'none'>('all')

  const fitOf = (r: Row): number | null => (r.grant ? fits[r.grant.id]?.score ?? null : null)

  const sortRows = (rows: Row[]) => {
    let list = rows
    if (pFit !== 'all') {
      list = list.filter((r) => {
        const f = fitOf(r)
        if (pFit === 'none') return f === null
        if (f === null) return false
        return pFit === 'analyzed' ? true : pFit === '80' ? f >= 80 : pFit === '60' ? f >= 60 : f < 60
      })
    }
    if (!pSort) return list
    const val = (r: Row): number | string | null => (pSort.k === 'name' ? r.name.toLowerCase() : pSort.k === 'deadline' ? (Number.isFinite(r.dlt) ? r.dlt : null) : pSort.k === 'amount' ? r.amt || null : pSort.k === 'fit' ? fitOf(r) : r.status.toLowerCase())
    return sortList(list, val, pSort.dir)
  }

  const PIPE_TABS: [PipeTab, string][] = [['open', 'Open grants'], ['upcoming', 'Upcoming cycle'], ['invite', 'Invite only'], ['saved', 'Saved'], ['applying', 'Under application']]


  const appHasBudget = (a: Application) => {
    const secsOf = a.tpl ? a.tpl.sections.map((x) => [x.key, x.title] as const) : SECTIONS
    return secsOf.some(([k, t]) => /budget/i.test(t) && (a.doc[k] ?? '').includes('|')) || (!secsOf.some(([, t]) => /budget/i.test(t)) && (a.doc['x_budget'] ?? '').includes('|'))
  }

  const wfSteps = [
    { id: 'profile', label: 'Complete your organization profile', hint: `${pct}% complete`, done: pct >= 80, cta: 'Open profile', go: () => setView('profile') },
    { id: 'find', label: 'Find grants that fit your profile', hint: 'Search and refresh your matches', done: saved.length > 0 || apps.length > 0 || (results?.length ?? 0) > 0, cta: 'Find grants', go: () => setView('find') },
    { id: 'save', label: 'Save a grant to your pipeline', hint: `${saved.length} saved`, done: saved.length > 0, cta: 'Open results', go: () => setView('find') },
    { id: 'apply', label: 'Start an application', hint: `${apps.length} started`, done: apps.length > 0, cta: 'Go to pipeline', go: () => setView('pipeline') },
    { id: 'guidance', label: 'Import the funder\'s guidance', hint: 'Inside an application', done: apps.some((a) => a.guidance), cta: 'Open applications', go: () => setView('applications') },
    { id: 'draft', label: 'Write every section', hint: 'Use AI write and AI improve', done: apps.some((a) => progressOf(a).pct === 100), cta: 'Open applications', go: () => setView('applications') },
    { id: 'budget', label: 'Prepare the budget', hint: 'Import the funder\'s budget template', done: apps.some(appHasBudget), cta: 'Open applications', go: () => setView('applications') },
    { id: 'review', label: 'Review before submitting', hint: 'Reviewer pass and checklist', done: apps.some((a) => !!a.review), cta: 'Open applications', go: () => setView('applications') },
    { id: 'submit', label: 'Submit and track the result', hint: 'Set the status in Applications', done: apps.some((a) => ['Submitted', 'Awarded', 'Declined'].includes(a.status)), cta: 'Open full table', go: () => setView('tracker') },
  ]

  const wfDone = wfSteps.filter((x) => x.done).length

  const wfNext = wfSteps.find((x) => !x.done)




  const [aSort, setASort] = useState<SortState>(null)

  const [aStatus, setAStatus] = useState<AppStatus | null>(null)

  const [aView, setAView] = useState<'list' | 'board'>('list')

  const [dragId, setDragId] = useState<string | null>(null)

  const moveApp = (id: string, st: AppStatus) => setApps((cur) => cur.map((x) => (x.id === id && x.status !== st ? { ...x, status: st, updated: Date.now() } : x)))

  const filteredApps = aStatus ? apps.filter((a) => a.status === aStatus) : apps

  const sortedApps = (() => {
    if (!aSort) return filteredApps
    const val = (a: Application): number | string | null => {
      switch (aSort.k) {
        case 'grant': return (a.grant?.title ?? (a.project.title || 'Untitled draft')).toLowerCase()
        case 'status': return STATUSES.indexOf(a.status)
        case 'progress': return progressOf(a).pct
        case 'deadline': return a.grant ? parseDate(a.grant.deadline)?.getTime() ?? null : null
        case 'updated': return a.updated || null
        default: return null
      }
    }
    return sortList(filteredApps, val, aSort.dir)
  })()


  // ---- Proposal quality checklist: checked by the portal where it can, ticked by you where it cannot ----

  // A short fingerprint of a text, used to see whether a field was edited after a check.
  const textHash = (t: string) => { let h = 5381; for (let c = 0; c < t.length; c++) h = ((h << 5) + h + t.charCodeAt(c)) | 0; return String(h) }

  // The checklist item's field was edited, by hand or by the AI, after the AI judged it: the old judgement no longer applies.
  const editedSince = (i: QItem): boolean => {
    const v = app?.audit?.results?.[i.id]
    const target = i.sec ? secs.find(([, t]) => i.sec!.test(t)) : undefined
    return !!v && !!v.sh && !!target && textHash(doc[target[0]] ?? '') !== v.sh
  }

  const contentHash = () => { const str = JSON.stringify([doc, app?.inputs, project, app?.facts]); let h = 5381; for (let c = 0; c < str.length; c++) h = ((h << 5) + h + str.charCodeAt(c)) | 0; return 'h' + (h >>> 0).toString(36) }

  const qDone = (i: QItem) => { const v = app?.audit?.results[i.id]; if (v && v.status !== 'unknown') return v.status === 'pass' || (i.auto === null && !!app?.quality?.[i.id]); return i.auto !== null ? i.auto : !!app?.quality?.[i.id] }

  // ---- Suggestions from the AI check, reflected into the relevant sections ----
  const [qSug, setQSug] = useState<Record<string, { busy?: boolean; data?: FixSuggestion; err?: string; sec?: string }>>({})

  // The item itself, and every item tied to the section that changed.
  const recheckIdsFor = (itemId: string, sectionKey?: string): string[] => {
    const title = sectionKey ? secs.find(([k]) => k === sectionKey)?.[1] : undefined
    const ids = new Set<string>([itemId])
    for (const [id, m] of Object.entries(Q_META)) if (title && m.sec && m.sec.test(title)) ids.add(id)
    return [...ids]
  }

  async function suggestForItem(i: QItem, v: AuditVerdict) {
    setQSug((c) => ({ ...c, [i.id]: { busy: true } }))
    try {
      const target = i.sec ? secs.find(([, t]) => i.sec!.test(t)) : undefined
      const r = await suggestFix({ data: {
        kind: 'quality checklist item',
        finding: `${i.text}. Review result: ${v.status}. Evidence: ${v.evidence}. What is needed: ${v.fix}`,
        hint: target?.[1],
        wordLimit: target ? meta(target[0])?.wordLimit || undefined : undefined,
        sections: reviewSections().map((x) => ({ title: x.title, text: x.text })),
        profile: profile as unknown as Record<string, any>,
        summary: app?.guidance ? guidanceText(app.guidance) : '',
        framework: selectedFramework(),
        amount: project.amount,
        months: project.months,
      } })
      setQSug((c) => ({ ...c, [i.id]: r.ok ? { data: r.suggestion, sec: r.suggestion.section || target?.[1] || '' } : { err: friendlyAiError(r.reason) } }))
    } catch {
      setQSug((c) => ({ ...c, [i.id]: { err: 'Something went wrong. Please try again.' } }))
    }
  }

  function applySuggestion(id: string) {
    const x = qSug[id]
    if (!x?.data) return
    const key = reviewSections().find((sx) => sx.title === x.sec)?.key
    if (!key) return
    snapshotDoc('Before applying a checklist suggestion')
    const text = tidy(x.data.text)
    setDoc((d) => ({ ...d, [key]: x.data!.mode === 'replace' ? text : d[key]?.trim() ? `${d[key].trim()}\n\n${text}` : text }))
    setQSug((c) => ({ ...c, [id]: {} }))
    patch((a) => ({ ...a, fixedAt: { ...(a.fixedAt ?? {}), [id]: Date.now() } }))
    setViewing((c) => ({ ...c, [key]: true }))
    setEditing((c) => ({ ...c, [key]: false }))
    setAuditNote(`Applied to "${x.sec}". The item is marked as solved, and the related items are being checked again...`)
    setRecheck(recheckIdsFor(id, key))
  }

  // ---- Review and improve: check, draft one fix per section, review the changes, apply, check again ----
  type FlowCard = { key: string; title: string; kind: 'findings' | 'answers'; notes: string[]; oldText: string; newText: string; status: 'pending' | 'applied' | 'skipped'; err?: string }

  const [qFlow, setQFlow] = useState<{ phase: 'idle' | 'checking' | 'drafting' | 'review' | 'done'; cards: FlowCard[]; before: number | null; note: string; prog: string }>({ phase: 'idle', cards: [], before: null, note: '', prog: '' })

  const [gaps, setGaps] = useState<{ section: string; question: string; answer: string }[]>([])

  const [gapBusy, setGapBusy] = useState(false)

  const [gapNote, setGapNote] = useState('')

  const [helpers, setHelpers] = useState<Record<string, { busy?: boolean; text?: string; err?: string }>>({})

  const sleepMs = (ms: number) => new Promise((r) => setTimeout(r, ms))

  const scoreOf = (results: Record<string, AuditVerdict>) => qualityItems().map((i) => ({ ...i, ...Q_META[i.id] })).filter((i) => { const v = results[i.id]; if (v && v.status !== 'unknown') return v.status === 'pass' || (i.auto === null && !!app?.quality?.[i.id]); return i.auto !== null ? i.auto : !!app?.quality?.[i.id] }).length

  // At most this many sections are drafted in one pass, and at most this many findings per section.
  // A short pass is faster and the AI keeps each rewrite focused. Press the button again for the next ones.
  const FLOW_MAX_SECTIONS = 4
  const FLOW_MAX_FIXES = 4
  const groupFindings = (results: Record<string, AuditVerdict>) => {
    const bad = qualityItems().map((i) => ({ ...i, ...Q_META[i.id] })).filter((i) => ['partial', 'fail'].includes(results[i.id]?.status ?? '') && results[i.id].fix)
    const sev = (id: string) => (results[id].status === 'fail' ? 2 : 1)
    const bySec = new Map<string, { title: string; items: { fix: string; sev: number }[] }>()
    const general: { fix: string; sev: number }[] = []
    for (const i of bad) {
      const t = i.sec ? secs.find(([, tt]) => i.sec!.test(tt)) : undefined
      const entry = { fix: `${i.text}: ${results[i.id].fix}`, sev: sev(i.id) }
      if (t && (doc[t[0]] ?? '').trim() && !isChoiceKey(t[0])) { const e = bySec.get(t[0]) ?? { title: t[1], items: [] }; e.items.push(entry); bySec.set(t[0], e) }
      else general.push({ fix: results[i.id].fix, sev: sev(i.id) })
    }
    const ranked = [...bySec].map(([key, v]) => {
      const items = [...v.items].sort((x, y) => y.sev - x.sev)
      return { key, title: v.title, fixes: items.slice(0, FLOW_MAX_FIXES).map((x) => x.fix), total: items.length, score: items.reduce((n, x) => n + x.sev, 0) }
    }).sort((x, y) => y.score - x.score)
    const chosen = ranked.slice(0, FLOW_MAX_SECTIONS)
    return { bad, bySec: new Map(chosen.map((c) => [c.key, { title: c.title, fixes: c.fixes }])), general: general.sort((x, y) => y.sev - x.sev).slice(0, 3).map((x) => x.fix), left: ranked.slice(FLOW_MAX_SECTIONS).length, skipped: ranked.reduce((n, c) => n + Math.max(0, c.total - c.fixes.length), 0) }
  }
  async function draftSection(key: string, title: string, instruction: string): Promise<{ text: string } | { err: string }> {
    try {
      const payload = { profile, section: title, context: /budget/i.test(title) ? budgetCtx() : ctx(key), current: doc[key] || undefined, grant: target ?? undefined, amount: project.amount, months: project.months, instruction, guidance: meta(key)?.guidance || undefined, wordLimit: meta(key)?.wordLimit || undefined, limit: limitOf(key)?.n, limitUnit: limitOf(key)?.unit, framework: selectedFramework(), rules: budgetRules() || undefined }
      let r: { ok: true; text: string } | { ok: false; reason: string }
      if (/budget/i.test(title)) r = await autoComplete({ data: payload })
      else {
        setFlowLive('')
        const sr = await streamWrite(payload, { delta: (d) => setFlowLive((x) => x + d), reset: () => setFlowLive(''), status: () => {} })
        setFlowLive('')
        r = sr.ok ? sr : (sr as any).network ? await autoComplete({ data: payload }) : sr
      }
      if (!r.ok) return { err: friendlyAiError(r.reason) }
      const fit = await fitText(key, title, tidy(r.text).trim())
      return { text: fit.text }
    } catch {
      return { err: 'Something went wrong while contacting the AI.' }
    }
  }

  // Fully automatic: check the proposal, draft a fix for each section that needs work, apply it at once (a copy of the earlier draft is saved in History),
  // then check again, for up to AUTO_ROUNDS rounds or until nothing needs work.
  const AUTO_ROUNDS = 3
  const autoRound = useRef(1)
  const [autoNext, setAutoNext] = useState(0)
  const [finalAudit, setFinalAudit] = useState(0)

  async function startFlow(cont = false) {
    stopRef.current = false
    if (!cont) autoRound.current = 1
    else autoRound.current += 1
    setQFlow((f) => ({ phase: 'checking', cards: cont ? f.cards : [], before: cont ? f.before : null, note: '', prog: cont ? `Checking again (round ${autoRound.current} of ${AUTO_ROUNDS})...` : 'Checking the proposal...' }))
    const results = await runAudit()
    if (!results) { setQFlow((f) => ({ ...f, phase: 'idle', prog: '' })); return }
    const now = scoreOf(results)
    const before = cont && qFlow.before !== null ? qFlow.before : now
    const { bySec, general, left } = groupFindings(results)
    if (!bySec.size) {
      setQFlow((f) => ({ phase: 'done', cards: cont ? f.cards : [], before, note: f.cards.some((c) => c.status === 'applied') ? 'Done. Every fix was applied automatically and the proposal was checked again. A copy of your earlier draft is in History.' : general.length ? 'No single section needs a rewrite. The remaining findings apply to the whole proposal: use "Fill the gaps" and the items below.' : 'Nothing needs work.', prog: '' }))
      return
    }
    let cards: FlowCard[] = (cont ? qFlow.cards : []).filter((c) => !bySec.has(c.key))
    let n = 0
    let applied = 0
    for (const [key, v] of bySec) {
      if (stopRef.current) break
      setQFlow((f) => ({ ...f, phase: 'drafting', before, prog: `Round ${autoRound.current} of ${AUTO_ROUNDS}. Improving ${n + 1} of ${bySec.size}: ${v.title}` }))
      // eslint-disable-next-line no-await-in-loop
      const instr = `Improve this section so that it fixes these findings from the proposal review:\n- ${v.fixes.join('\n- ')}\n${general.length ? `Also, across the proposal: ${general.slice(0, 4).join(' ')}\n` : ''}Keep everything that is correct and specific. Keep the structure and format (tables stay tables). Do not invent facts: use [bracketed placeholders] for missing data.`
      let d = await draftSection(key, v.title, instr)
      // A section is finished before the next one starts: a failed draft is retried, and the flow stops there instead of skipping it.
      for (let attempt = 0; attempt < 3 && 'err' in d && !stopRef.current; attempt++) {
        setQFlow((f) => ({ ...f, prog: `The AI did not finish ${v.title}. Retrying (${attempt + 1} of 3)...` }))
        // eslint-disable-next-line no-await-in-loop
        await sleepMs((attempt + 1) * 8000)
        // eslint-disable-next-line no-await-in-loop
        d = await draftSection(key, v.title, instr)
      }
      if ('err' in d && !stopRef.current) {
        setQFlow((f) => ({ ...f, phase: 'done', prog: '', note: `Stopped at "${v.title}" because the AI could not finish it. The sections before it were improved and the sections after it were not started. Press the button again to continue.` }))
        return
      }
      const card: FlowCard = { key, title: v.title, kind: 'findings', notes: v.fixes, oldText: doc[key] ?? '', newText: 'text' in d ? d.text : '', status: 'pending', err: 'err' in d ? d.err : undefined }
      cards = [...cards, card]
      setQFlow((f) => ({ ...f, cards }))
      if (card.newText) { applyCards([card]); applied++ }
      n++
      // eslint-disable-next-line no-await-in-loop
      await sleepMs(300)
    }
    if (stopRef.current) { setQFlow((f) => ({ ...f, phase: 'done', prog: '', note: applied ? 'Stopped. The fixes made so far were applied. A copy of your earlier draft is in History.' : 'Stopped.' })); return }
    if (applied > 0 && autoRound.current < AUTO_ROUNDS) {
      setQFlow((f) => ({ ...f, phase: 'checking', prog: `Applied ${applied} fix${applied === 1 ? '' : 'es'}. Checking again...` }))
      await sleepMs(1200)
      setAutoNext((x) => x + 1)
      return
    }
    if (applied > 0) { setQFlow((f) => ({ ...f, prog: 'Checking the whole proposal one last time to update the score...' })); await sleepMs(1000); setFinalAudit((x) => x + 1) }
    setQFlow((f) => ({ ...f, phase: 'done', prog: '', note: `${applied ? `Applied fixes to ${cards.filter((c) => c.status === 'applied').length} section${cards.filter((c) => c.status === 'applied').length === 1 ? '' : 's'} automatically. A copy of your earlier draft is in History.` : 'No fix could be drafted.'}${left > 0 || cards.some((c) => c.err) ? ' Some findings remain: press the button again to continue.' : ''}` }))
  }

  function applyCards(cs: FlowCard[]) {
    const ok = cs.filter((c) => c.newText && c.status === 'pending')
    if (!ok.length) return
    snapshotDoc(`Before applying ${ok.length} AI improvement${ok.length === 1 ? '' : 's'}`)
    setDoc((d) => ({ ...d, ...Object.fromEntries(ok.map((c) => [c.key, c.newText])) }))
    setViewing((c) => ({ ...c, ...Object.fromEntries(ok.map((x) => [x.key, true])) }))
    setEditing((c) => ({ ...c, ...Object.fromEntries(ok.map((x) => [x.key, false])) }))
    setQFlow((f) => ({ ...f, cards: f.cards.map((c) => (ok.some((o) => o.key === c.key) ? { ...c, status: 'applied' as const } : c)), note: 'Applied. Checking the related items again...' }))
    const ids = [...new Set(ok.flatMap((c) => recheckIdsFor('', c.key)))].filter(Boolean)
    patch((a) => ({ ...a, fixedAt: { ...(a.fixedAt ?? {}), ...Object.fromEntries(ids.filter((id) => ['partial', 'fail'].includes(a.audit?.results?.[id]?.status ?? '')).map((id) => [id, Date.now()])) } }))
    setRecheck(ids)
  }

  const skipCard = (key: string) => setQFlow((f) => ({ ...f, cards: f.cards.map((c) => (c.key === key ? { ...c, status: 'skipped' as const } : c)) }))

  async function findGaps() {
    setGapBusy(true)
    setGapNote('')
    let results = app?.audit?.results
    if (!results) results = (await runAudit()) ?? undefined
    const items = qualityItems().map((i) => ({ ...i, ...Q_META[i.id] }))
    const findings = items.filter((i) => results?.[i.id] && ['partial', 'fail'].includes(results[i.id].status) && results[i.id].fix).map((i) => ({ text: i.text, fix: results![i.id].fix, section: i.sec ? secs.find(([, t]) => i.sec!.test(t))?.[1] ?? '' : '' }))
    const placeholders = secs.flatMap(([k, t]) => { const text = doc[k] ?? ''; return [...text.matchAll(/\[[^\]\n]{2,}\]/g)].slice(0, 6).map((m) => ({ section: t, snippet: text.slice(Math.max(0, (m.index ?? 0) - 50), (m.index ?? 0) + m[0].length + 30).replace(/\s+/g, ' ') })) })
    try {
      const r = await gapQuestions({ data: { findings, placeholders, sections: secs.map(([, t]) => t), context: titleCtx() } })
      if (r.ok) setGaps(r.questions.map((q) => ({ ...q, answer: '' }))); else setGapNote(friendlyAiError(r.reason))
    } catch {
      setGapNote('Something went wrong. Please try again.')
    }
    setGapBusy(false)
  }

  async function writeAnswers() {
    const answered = gaps.filter((g) => g.answer.trim() && g.section)
    if (!answered.length) { setGapNote('Answer at least one question.'); return }
    setGapBusy(true)
    setGapNote('')
    const before = scoreOf(app?.audit?.results ?? {})
    const groups = new Map<string, { title: string; qa: string[] }>()
    for (const g of answered) { const t = secs.find(([, tt]) => tt === g.section); if (!t) continue; const e = groups.get(t[0]) ?? { title: t[1], qa: [] }; e.qa.push(`Q: ${g.question} A: ${g.answer.trim()}`); groups.set(t[0], e) }
    const cards: FlowCard[] = []
    let n = 0
    for (const [key, v] of groups) {
      setGapNote(`Writing your answers into the proposal: ${n + 1} of ${groups.size}, ${v.title}...`)
      // eslint-disable-next-line no-await-in-loop
      const d = await draftSection(key, v.title, `The applicant supplied these facts:\n- ${v.qa.join('\n- ')}\nPut each fact into the right place in this section: replace the matching [bracketed placeholder] or the weak wording, and use the facts exactly as given. Add no other facts. Keep everything else, including the structure and format (tables stay tables).`)
      cards.push({ key, title: v.title, kind: 'answers', notes: v.qa, oldText: doc[key] ?? '', newText: 'text' in d ? d.text : '', status: 'pending', err: 'err' in d ? d.err : undefined })
      n++
      // eslint-disable-next-line no-await-in-loop
      await sleepMs(300)
    }
    setQFlow({ phase: 'review', cards, before, note: 'These drafts use your answers.', prog: '' })
    setGapNote('')
    setGapBusy(false)
  }

  async function makeHelper(kind: string) {
    setHelpers((c) => ({ ...c, [kind]: { busy: true } }))
    const summary = (() => { const x = secs.find(([, t]) => /executive|abstract|^(?!.*budget).*summary/i.test(t)); return x ? (doc[x[0]] ?? '').trim().slice(0, 700) : '' })()
    const context = `Organization: ${profile.org || '[organization]'}${profile.country ? ', ' + profile.country : ''}\nProject: ${project.title || '[project title]'}\nFunder: ${app?.grant?.funder ?? '[funder]'}\nAmount: ${project.amount || '[amount]'} USD. Duration: ${project.months} months. Deadline: ${app?.grant?.deadline && app.grant.deadline !== 'Not stated' ? app.grant.deadline : '[deadline]'}\nPartners: ${facts.partners.trim() || '[partners]'}\n${summary ? 'Project summary: ' + summary : ''}`
    try {
      const r = await helperDraft({ data: { kind, context } })
      setHelpers((c) => ({ ...c, [kind]: r.ok ? { text: r.text } : { err: friendlyAiError(r.reason) } }))
    } catch {
      setHelpers((c) => ({ ...c, [kind]: { err: 'Something went wrong. Please try again.' } }))
    }
  }

  // Documents in the Library tick the matching compliance items of the profile. Nothing you ticked yourself is removed.
  useEffect(() => {
    const proven = libraryCompliance(lib.docs).valid
    if (!proven.length) return
    const have = csv((profile.compliance ?? '').toString())
    const add = proven.filter((x) => !have.includes(x))
    if (add.length) setProfile({ ...profile, compliance: [...have, ...add].join(', ') })
  }, [lib.docs])
  // ---- Terminology, acronyms and language: plain checks first, then AI rewrites shown as review cards ----
  const [qa, setQa] = useState<{ acr: AcronymItem[] | null; terms: TermGroup[] | null; lang: LangReport | null; busy: string; note: string }>({ acr: null, terms: null, lang: null, busy: '', note: '' })
  const writtenSecs = () => secs.filter(([k]) => (doc[k] ?? '').trim().length > 40).map(([k, t]) => ({ key: k, title: t, text: doc[k] ?? '' }))
  async function runCards(list: { key: string; title: string; instruction: string; notes: string[] }[], note: string) {
    if (!list.length) { setQa((c) => ({ ...c, note: 'Nothing to change.' })); return }
    stopRef.current = false
    const before = scoreOf(app?.audit?.results ?? {})
    const cards: FlowCard[] = []
    let n = 0
    for (const it of list) {
      if (stopRef.current) break
      setQFlow({ phase: 'drafting', cards: [], before, note: '', prog: `Drafting ${n + 1} of ${list.length}: ${it.title}` })
      // eslint-disable-next-line no-await-in-loop
      const d = await draftSection(it.key, it.title, it.instruction)
      cards.push({ key: it.key, title: it.title, kind: 'findings', notes: it.notes, oldText: doc[it.key] ?? '', newText: 'text' in d ? d.text : '', status: 'pending', err: 'err' in d ? d.err : undefined })
      n++
      // eslint-disable-next-line no-await-in-loop
      await sleepMs(300)
    }
    setQFlow({ phase: 'review', cards, before, note, prog: '' })
    document.getElementById('quality-flow')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
  async function runTerminologyCheck() {
    const sections = writtenSecs()
    if (!sections.length) { setQa((c) => ({ ...c, note: 'Write some sections first.' })); return }
    setQa({ acr: acronymReport(sections), terms: null, lang: qa.lang, busy: 'terms', note: '' })
    try {
      const r = await terminologyCheck({ data: { parts: sections.map((x) => ({ title: x.title, text: x.text })) } })
      setQa((c) => ({ ...c, busy: '', terms: r.ok ? r.groups : [], note: r.ok ? '' : friendlyAiError(r.reason) }))
    } catch {
      setQa((c) => ({ ...c, busy: '', note: 'Something went wrong while checking the terms. The acronym check above is complete.' }))
    }
  }
  const fixAcronymsAI = () => {
    const bad = (qa.acr ?? []).filter((x) => !x.defined)
    const by = new Map<string, { title: string; acrs: string[] }>()
    for (const x of bad) { const e = by.get(x.sectionKey) ?? { title: x.section, acrs: [] }; e.acrs.push(x.acr); by.set(x.sectionKey, e) }
    return runCards([...by].map(([key, v]) => ({ key, title: v.title, notes: v.acrs.map((a) => `Define ${a} at first use`), instruction: `Define each of these acronyms the first time it is used in the proposal, as "Full name (ACRONYM)", and use only the acronym afterwards: ${v.acrs.join(', ')}. Work out the full name from the project context; if you cannot tell what an acronym stands for, write [full name of ACRONYM] as a placeholder. Do not change anything else: keep every fact, number, name and the structure and tables.` })), 'Acronyms are defined at first use in these drafts.')
  }
  const fixTermsAI = () => {
    const groups = qa.terms ?? []
    const list = writtenSecs().map((s) => {
      const hit = groups.filter((g) => g.variants.some((v) => new RegExp(`\\b${v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(s.text)))
      return { s, hit }
    }).filter((x) => x.hit.length)
    return runCards(list.map(({ s, hit }) => ({ key: s.key, title: s.title, notes: hit.map((g) => `Use "${g.preferred}" instead of ${g.variants.join(', ')}`), instruction: `Use one term for each concept across the whole proposal. In this section replace the other terms with the preferred one: ${hit.map((g) => `"${g.preferred}" instead of ${g.variants.map((v) => `"${v}"`).join(', ')}`).join('; ')}. Fix the grammar around each replacement. Change nothing else: keep every fact, number, name and the structure and tables.` })), 'Terms are now consistent in these drafts.')
  }
  function runLanguageCheck() {
    const sections = writtenSecs()
    if (!sections.length) { setQa((c) => ({ ...c, note: 'Write some sections first.' })); return }
    setQa((c) => ({ ...c, lang: languageReport(sections), note: '' }))
  }
  const fixLanguageAI = () => {
    const rep = qa.lang
    if (!rep) return Promise.resolve()
    const spell = rep.spelling.dominant === 'UK' ? 'British' : 'American'
    const minority = new Set(rep.spelling.minority.map((m) => m.title))
    const list = rep.sections.filter((x) => x.flags.length || minority.has(x.title)).map((x) => ({ key: x.key, title: x.title, notes: [...x.flags, ...(minority.has(x.title) ? [`Mixed spelling: use ${spell}`] : [])], instruction: `Improve the language only. Problems found: ${[...x.flags, ...(minority.has(x.title) ? [`mixed spelling`] : [])].join('; ')}. Rewrite long sentences as shorter ones (aim for 15 to 22 words), prefer the active voice, replace jargon and filler with plain precise words, use ${spell} spelling throughout and keep one tense. Do not change any fact, number, name, place, date or the structure and tables.` }))
    return runCards(list, 'Only the language is changed in these drafts.')
  }
  // ---- One click per field: every issue found by every kind of check in that field is fixed in one rewrite ----
  const [fixBusy, setFixBusy] = useState('')

  // All the open issues of one field, from the AI checklist, the length limit, placeholders, acronyms, language and spelling, terminology and sources.
  const fieldIssues = (key: string, title: string, termGroups: TermGroup[] | null = qa.terms): { notes: string[]; ids: string[] } => {
    const text = doc[key] ?? ''
    if (isChoiceKey(key) || text.trim().length < 20) return { notes: [], ids: [] }
    const notes: string[] = []
    const ids: string[] = []
    const results = app?.audit?.results ?? {}
    for (const it of qualityItems()) {
      const v = results[it.id]
      if (v && ['partial', 'fail'].includes(v.status) && v.fix && Q_META[it.id]?.sec?.test(title) && !editedSince(it) && !((app?.fixedAt?.[it.id] ?? 0) > (app?.audit?.at ?? 0))) { notes.push(`${it.text}: ${v.fix}`); ids.push(it.id) }
    }
    const lim = limitOf(key)
    if (lim && !/budget/i.test(title) && measure(text, lim.unit) > lim.n) notes.push(`Shorten the section to at most ${lim.n} ${lim.unit === 'words' ? 'words' : lim.unit === 'characters' ? 'characters including spaces' : 'characters excluding spaces'}`)
    const ph = [...new Set(text.match(/\[[^\]\n]{2,}\]/g) ?? [])].slice(0, 8)
    if (ph.length) { notes.push(`Replace these [placeholders] with the real facts from the applicant's information wherever they are available, and keep a placeholder only where the information is truly missing: ${ph.join(' ')}`); ids.push('g3') }
    const sec = [{ key, title, text }]
    const acr = acronymReport(sec).filter((x) => !x.defined || x.redefined)
    if (acr.length) notes.push(`Define each acronym once, at first use, as "Full name (ACRONYM)" and use only the acronym afterwards: ${acr.map((x) => x.acr).join(', ')}`)
    const lang = languageReport(sec).sections[0]
    const all = languageReport(writtenSecs())
    const spell = all.spelling.dominant === 'UK' ? 'British' : 'American'
    const mixed = all.spelling.minority.some((m) => m.title === title)
    if (lang?.flags.length || mixed) { notes.push(`Language: ${[...(lang?.flags ?? []), ...(mixed ? [`mixed spelling, use ${spell} spelling throughout`] : [])].join('; ')}. Use short, active sentences of 15 to 22 words.`); ids.push('h1', 'h3') }
    const hit = (termGroups ?? []).filter((g) => g.variants.some((v) => new RegExp(`\\b${v.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(text)))
    if (hit.length) { notes.push(`Terminology: ${hit.map((g) => `use "${g.preferred}" instead of ${g.variants.map((v) => `"${v}"`).join(', ')}`).join('; ')}`); ids.push('h2', 'h3') }
    const unsourced = (app?.sources ?? []).filter((x) => !x.sourced && x.section === title).slice(0, 6)
    if (unsourced.length) { notes.push(`Give the source and year of these claims when the applicant's information provides them, and otherwise mark [source and year needed]: ${unsourced.map((x) => x.claim).join(' | ')}`); ids.push('g1') }
    return { notes, ids }
  }

  const getTermGroups = async (): Promise<TermGroup[]> => {
    if (qa.terms) return qa.terms
    const sections = writtenSecs()
    if (sections.length < 2) return []
    try {
      const r = await terminologyCheck({ data: { parts: sections.map((x) => ({ title: x.title, text: x.text })) } })
      if (r.ok) { setQa((c) => ({ ...c, terms: r.groups })); return r.groups }
    } catch {}
    return []
  }

  async function fixField(key: string, title: string, groups?: TermGroup[]): Promise<boolean> {
    const { notes, ids } = fieldIssues(key, title, groups ?? qa.terms)
    if (!notes.length) return true
    const instruction = `Fix ALL of these issues in this section in a single rewrite, and return the complete improved section:\n- ${notes.join('\n- ')}\nKeep everything that is correct and specific, keep the structure and format (tables stay tables), do not invent facts, and stay inside the length limit.`
    const ok = await untilDone(() => complete(key, title, instruction))
    if (ok) patch((a) => ({ ...a, fixedAt: { ...(a.fixedAt ?? {}), ...Object.fromEntries(ids.map((id) => [id, Date.now()])) } }))
    return ok
  }

  async function fixOneField(key: string, title: string) {
    if (fixBusy) return
    setFixBusy(key)
    stopRef.current = false
    const groups = await getTermGroups()
    const ok = await fixField(key, title, groups)
    if (ok) setRecheck(recheckIdsFor('', key))
    else if (!stopRef.current) setMsg(`The AI could not finish "${title}". Press the button again to retry.`)
    setFixBusy('')
  }

  async function fixAllFields() {
    if (fixBusy) return
    setFixBusy('all')
    stopRef.current = false
    bulkRef.current = true
    try {
      const groups = await getTermGroups()
      const todo = secs.filter(([k, t]) => fieldIssues(k, t, groups).notes.length)
      let n = 0
      for (const [k, t] of todo) {
        if (stopRef.current) break
        n++
        setAllProg(`Fixing all issues, field ${n} of ${todo.length}: ${t}`)
        // eslint-disable-next-line no-await-in-loop
        const ok = await fixField(k, t, groups)
        if (!ok) { setMsg(`Stopped at "${t}" because the AI could not finish it. The fields after it were not started. Press the button again to continue.`); break }
        // eslint-disable-next-line no-await-in-loop
        await sleepMs(300)
      }
      if (!stopRef.current && n) setFinalAudit((x) => x + 1)
      if (!n) setMsg('No open issues were found in the written fields.')
    } finally {
      bulkRef.current = false
      setAllProg('')
      setFixBusy('')
    }
  }

  const [packBusy, setPackBusy] = useState(false)

  const [auditBusy, setAuditBusy] = useState(false)

  const [recheck, setRecheck] = useState<string[]>([])

  // After a section is improved, the items that depend on it are checked again, once the new text is in place.
  useEffect(() => {
    if (recheck.length && !auditBusy && !busy) { const ids = recheck; setRecheck([]); runAudit(ids) }
  }, [recheck, doc])

  useEffect(() => {
    if (autoNext > 0 && !auditBusy && !busy && !recheck.length) { setAutoNext(0); startFlow(true) }
    if (finalAudit > 0 && !auditBusy && !busy && !recheck.length) { setFinalAudit(0); runAudit().then(() => setQFlow((f) => ({ ...f, prog: '' }))) }
  }, [autoNext, finalAudit, auditBusy, busy, recheck, doc])


  const [auditNote, setAuditNote] = useState('')

  // When a field related to an AI-checked item is edited, the item is checked again a few seconds after the editing stops, so a solved issue is marked as solved.
  useEffect(() => {
    if (!app?.audit || auditBusy || busy || recheck.length || qFlow.phase === 'drafting' || qFlow.phase === 'checking') return
    const ids = qualityItems().filter((i) => Q_META[i.id]?.ai && editedSince(i)).map((i) => i.id)
    if (!ids.length) return
    const t = setTimeout(() => { runAudit(ids) }, 6000)
    return () => clearTimeout(t)
  }, [doc, app?.audit, auditBusy, busy, qFlow.phase])

  async function runAudit(only?: string[]): Promise<Record<string, AuditVerdict> | null> {
    const all = qualityItems().filter((i) => Q_META[i.id]?.ai && (!only || only.includes(i.id))).map((i) => ({ id: i.id, text: i.text }))
    if (!all.length) return null
    const written = secs.filter(([k]) => (doc[k] ?? '').trim().length > 20)
    if (!written.length) { setAuditNote('Write some sections first, then run the AI check.'); return null }
    const proposal = [...written.map(([k, t]) => `## ${t}\n${(doc[k] ?? '').trim().slice(0, 1100)}`), (doc['x_budget'] ?? '').trim() ? `## Budget\n${(doc['x_budget'] ?? '').trim().slice(0, 900)}` : ''].filter(Boolean).join('\n\n')
    const areas = (app?.inputs?.areas ?? []).filter(areaFilled).map(areaLabel).join('; ')
    const context = [
      app?.grant && `Grant: ${app.grant.title}, funder ${app.grant.funder}`,
      app?.guidance?.priorities?.length ? `Funder priorities: ${app.guidance.priorities.slice(0, 8).join('; ')}` : '',
      app?.guidance?.criteria?.length ? `Assessment criteria: ${app.guidance.criteria.slice(0, 8).join('; ')}` : '',
      tpl ? `Funder sections: ${tpl.sections.map((x) => x.title).join('; ')}` : '',
      `Project: ${project.title || 'untitled'}; duration ${project.months} months; amount ${project.amount} USD`,
      areas && `Planned target areas: ${areas}`,
      factsCtx().replace(/\n+/g, ' '),
      inputs.needs.trim() && `Needs assessment input: ${inputs.needs.trim().slice(0, 500)}`,
      (app?.plan ?? '').trim() && `Planned project information: ${(app?.plan ?? '').trim().slice(0, 700)}`,
    ].filter(Boolean).join('\n')
    setAuditBusy(true)
    setAuditNote('')
    let merged: Record<string, AuditVerdict> | null = null
    try {
      const hash = contentHash()
      const r = await qualityAudit({ data: { items: all, proposal, context } })
      if (r.ok) {
        const fresh = Object.fromEntries(Object.entries(r.results).map(([id, v]) => { const item = qualityItems().find((x) => x.id === id); const tg = item?.sec ? secs.find(([, t]) => item.sec!.test(t)) : undefined; return [id, { ...v, h: hash, ...(tg ? { sh: textHash(doc[tg[0]] ?? '') } : {}) }] }))
        // Results for items that were not re-checked stay as they are.
        merged = only ? { ...(app?.audit?.results ?? {}), ...fresh } : fresh
        patch((a) => ({ ...a, audit: { at: Date.now(), hash, results: only ? { ...(a.audit?.results ?? {}), ...fresh } : fresh } }))
        setAuditNote('')
      }
      else setAuditNote(friendlyAiError(r.reason))
    } catch {
      setAuditNote('Something went wrong. Please try again.')
    }
    setAuditBusy(false)
    return merged
  }

  const qualityItems = (): QItem[] => {
    const sec = (re: RegExp) => secs.find(([, t]) => re.test(t))
    const body = (re: RegExp) => { const x = sec(re); return x ? (doc[x[0]] ?? '').trim() : '' }
    const words = (re: RegExp) => wc(body(re))
    const written = (re: RegExp, n = 60): boolean => words(re) >= n
    const allText = secs.map(([k]) => doc[k] ?? '').join('\n') + '\n' + (doc['x_budget'] ?? '')
    const placeholders = (allText.match(/\[[^\]\n]{2,}\]/g) ?? []).length
    const overLimit = secs.filter(([k]) => { const l = limitOf(k); return !!l && !isChoiceKey(k) && measure(doc[k] ?? '', l.unit) > l.n }).map(([, t]) => t)
    const budgetText = (doc['x_budget'] ?? '') || body(/budget/i)
    const budgetWarn = budgetText.includes('|') ? (budgetCheck(parseBlocks(budgetText), project.amount) ?? []) : null
    const g = app?.grant
    const rz = g ? realism(g, profile, lib.docs) : null
    const elig = app?.eligibility ?? []
    const areas = inputs.areas.filter(areaFilled)
    const expired = lib.docs.filter((d) => docState(d) === 'expired')
    const X = (id: string, group: string, text: string, auto: boolean | null = null, note?: string): QItem => ({ id, group, text, auto, note })
    return [
      X('a1', 'A. Eligibility and fit', 'Your legal status, registration and country are eligible', elig.length ? (elig.some((e) => e.status === 'not_met') ? false : elig.some((e) => e.status === 'unclear') ? null : true) : null, elig.length ? (elig.some((e) => e.status === 'not_met') ? `Not met: ${elig.filter((e) => e.status === 'not_met').map((e) => e.requirement).slice(0, 2).join('; ')}` : elig.some((e) => e.status === 'unclear') ? 'Some requirements are unclear. Check them and tick this when you are sure.' : undefined) : 'Run the AI eligibility checklist to check this.'),
      X('a2', 'A. Eligibility and fit', 'Award size suits your budget and there is time before the deadline', rz ? !rz.flags.some((f) => f.tone === 'bad') : null, rz?.flags.filter((f) => f.tone === 'bad').map((f) => f.text).join('. ')),
      X('a3', 'A. Eligibility and fit', 'Required registrations and documents are in place (SAM.gov, EU PIC and similar)', elig.length ? !elig.some((e) => e.status === 'document') : null),
      X('a4', 'A. Eligibility and fit', "The funder's priorities match your mission and track record", app?.framework ? Object.values(app.framework.selected).some((v) => (v?.length ?? 0) > 0) : null, app?.framework ? undefined : 'Pick the grant priorities and objectives you respond to.'),
      X('a5', 'A. Eligibility and fit', 'You decided to go ahead after weighing the effort'),
      X('b1', 'B. Preparation', 'You read the call at least three times and marked the scoring criteria'),
      X('b2', 'B. Preparation', "You collected the funder's template, guidance, word limits and attachment list", !!tpl || !!app?.guidance),
      X('b3', 'B. Preparation', 'Your profile is complete and your library has your key documents', completeness(profile) >= 80 && lib.docs.length > 0, `Profile ${completeness(profile)}% complete, ${lib.docs.length} document${lib.docs.length === 1 ? '' : 's'} in the library.`),
      X('b4', 'B. Preparation', 'Roles and deadlines are agreed with your team and partners'),
      X('b5', 'B. Preparation', 'Letters of support and MOUs are collected'),
      X('c1', 'C. Evidence and inputs', 'The needs assessment has current local data with sources and years', inputs.needs.trim().length > 200 && /\b(19|20)\d{2}\b/.test(inputs.needs) && /\d/.test(inputs.needs), 'Add numbers and the year of each source.'),
      X('c2', 'C. Evidence and inputs', 'The need is split by who is affected (gender, age, income, disability, place)', /women|girls|men\b|youth|children|age|disab|income|poor|gender|rural|urban/i.test(inputs.needs)),
      X('c3', 'C. Evidence and inputs', 'Target areas are listed with the country, governorate and district where they apply', areas.length > 0 && areas.every((a) => a.country.trim()), 'Every planned area needs a country.'),
      X('c4', 'C. Evidence and inputs', 'Field findings and community voices are recorded', inputs.primary.trim().length > 100),
      X('c5', 'C. Evidence and inputs', 'The key project numbers (people, sites, places, months, amount, partners) are fixed once and match in every section', facts.direct.trim() && facts.partners.trim() ? factCoverage().rows.every((r) => r.found > 0 || factCoverage().total === 0) : null, 'Fill in the Key project facts and press the button under them.'),
      X('d1', 'D. Structure', "Headings, order, wording and word limits follow the funder's template, and every prompt is answered", tpl ? (tpl.sections.every((x) => (doc[x.key] ?? '').trim().length > (isChoiceKey(x.key) ? 0 : 20)) && !overLimit.length) : overLimit.length ? false : null, tpl ? ([...(tpl.sections.some((x) => (doc[x.key] ?? '').trim().length <= (isChoiceKey(x.key) ? 0 : 20)) ? [`Not yet answered: ${tpl.sections.filter((x) => (doc[x.key] ?? '').trim().length <= (isChoiceKey(x.key) ? 0 : 20)).map((x) => x.title).slice(0, 3).join('; ')}`] : []), ...(overLimit.length ? [`Over the limit: ${overLimit.join(', ')}`] : [])].join('. ') || undefined) : overLimit.length ? `Over the limit: ${overLimit.join(', ')}.` : 'Import the funder form to check this automatically.'),
      X('d3', 'D. Structure', 'Sections use short subtitles and clear paragraphs'),
      X('e1', 'E. Content', 'Executive summary: need, solution, outcomes, amount and fit, with the ask first', written(/executive|abstract|^(?!.*budget).*summary/i, 80)),
      X('e2', 'E. Content', 'Organization: mission, track record with numbers, governance, reach', written(/organi[sz]ation(?!al)|background|introduction/i, 80)),
      X('e3', 'E. Content', 'Needs: urgency, causes and barriers, demand, equity', written(/need|problem/i, 120)),
      X('e4', 'E. Content', 'Objectives are SMART, each with a number, a deadline and an indicator', (() => { if (!written(/goal|objective/i, 60)) return false; const lines = body(/goal|objective/i).split(/\n+/).filter((l) => /^\s*(?:[-•]\s*)?objective\s*\d+/i.test(l)); const set = lines.length ? lines : [body(/goal|objective/i)]; return set.every((l) => /\d/.test(l) && /month|year|week|quarter|within|by /i.test(l)) })(), 'Every objective needs a number and a deadline.'),
      X('e5', 'E. Content', 'Activities: methods, dosage, staffing and partner roles, numbered', written(/activit|description|method/i, 120)),
      X('e6', 'E. Content', 'Timeline by months or quarters with owners and milestones', written(/timeline|work ?plan|schedule/i, 20)),
      X('e7', 'E. Content', 'Evaluation: indicators, baselines, targets, tools and frequency', written(/evaluation|outcome|monitor/i, 40)),
      X('e8', 'E. Content', 'Budget: itemized with unit rates and quantities, direct and indirect separated, arithmetic correct, and the total equals the requested amount', budgetText.trim().length > 80 ? (budgetWarn ? budgetWarn.length === 0 : null) : false, budgetWarn?.length ? budgetWarn.join(' ') : undefined),
      X('e9', 'E. Content', 'Capacity: team, fiscal controls, procurement, data security, board', written(/capacity|governance|management/i, 60)),
      X('e10', 'E. Content', 'Sustainability and dissemination: what continues, replication, sharing results', written(/sustainab|dissemination/i, 60)),
      X('e11', 'E. Content', 'Risks, safeguarding, privacy, accessibility and environmental practice are covered', /risk/i.test(allText) && /safeguard|privacy|accessib|inclusi/i.test(allText), 'Mention risks with mitigations and safeguarding or accessibility.'),
      X('f1', 'F. Alignment', 'Every objective has an activity, a timeline step, a budget line and an indicator'),
      X('f4', 'F. Alignment', "The funder's priorities appear in the objectives and the evaluation"),
      X('g1', 'G. Accuracy', 'Every claim has evidence or a source, with the year', app?.sources?.length ? !app.sources.some((x) => !x.sourced) : null, app?.sources?.length ? `${app.sources.filter((x) => !x.sourced).length} statistic(s) have no source. See Sources and references.` : 'Scan the proposal under Sources and references.'),
      X('g2', 'G. Accuracy', 'There are no invented facts, names or figures'),
      X('g3', 'G. Accuracy', 'No [placeholder] is left in the proposal', allText.trim() ? placeholders === 0 : null, placeholders ? `${placeholders} placeholder${placeholders === 1 ? '' : 's'} left in: ${secs.map(([k, t]) => [t, ((doc[k] ?? '').match(/\[[^\]\n]{2,}\]/g) ?? []).length] as const).filter(([, n]) => n > 0).map(([t, n]) => `${t} (${n})`).join(', ')}.` : undefined),
      X('g4', 'G. Accuracy', "Dates, names, amounts and your organization's details are verified"),
      X('h1', 'H. Language and style', 'Precise, professional wording in the active voice with short sentences'),
      X('h2', 'H. Language and style', 'No jargon, filler or repetition across sections'),
      X('h3', 'H. Language and style', 'One spelling standard and one tense throughout, and terms and acronyms used consistently and defined at first use'),
      X('i1', 'I. Supporting documents', 'Logical framework, MEAL plan and implementation plan match the proposal', !!(app?.extras?.logframe && app?.extras?.meal && app?.extras?.implementation), 'Generate them under Project documents.'),
      X('i2', 'I. Supporting documents', 'Reporting templates are ready', Object.keys(app?.extras ?? {}).some((k) => k.startsWith('report:')), 'Generate them under Project documents.'),
      X('i3', 'I. Supporting documents', 'Attachments are complete, current and correctly named'),
      X('j1', 'J. Review', 'The reviewer pass is run against the scoring criteria', !!app?.review, 'Open Review and run the reviewer score.'),
      X('j2', 'J. Review', 'Someone outside the team read it for sense and typos'),
      X('j3', 'J. Review', 'Proofread in passes: content, budget math, formatting, grammar'),
      X('k1', 'K. Submission', 'Limits, fonts, file names, signatures and attachments are checked'),
      X('k2', 'K. Submission', 'No library document has expired', lib.docs.length ? expired.length === 0 : null, expired.length ? `Expired: ${expired.map((d) => d.name).join(', ')}.` : undefined),
      X('k3', 'K. Submission', 'The PDF and Word files are exported and checked'),
      X('k4', 'K. Submission', 'Submitted 48 to 72 hours early, with the receipt kept', app ? ['Submitted', 'Awarded', 'Declined'].includes(app.status) : null),
      X('k5', 'K. Submission', 'The final version is saved and follow-up is planned'),
      X('k6', 'K. Submission', 'Board, partner or legal sign-off is in place'),
      X('e0', 'E. Content', 'Every proposal section is written', app ? progressOf(app).pct === 100 : null),
      ...(app?.framework ? [X('f6', 'F. Alignment', 'Every selected funder framework item is reflected in the draft', !!frameworkCoverage && frameworkCoverage.missing.length === 0, frameworkCoverage?.missing.length ? `Missing: ${frameworkCoverage.missing.slice(0, 3).join('; ')}` : undefined)] : []),
      ...elig.filter((e) => e.status !== 'met').slice(0, 10).map((e, n) => X('elig' + n, 'A. Eligibility and fit', `Resolve: ${e.requirement}`)),
      ...(app?.guidance?.format ?? []).slice(0, 10).map((f, n) => X('fmt' + n, 'D. Structure', `Funder format rule: ${f}`)),
      ...(app?.guidance?.dates ?? []).slice(0, 8).map((f, n) => X('date' + n, 'K. Submission', `Key date: ${f}`)),
      ...lib.docs.slice(0, 12).map((d) => { const st = docState(d); return X('doc-' + d.id, 'I. Supporting documents', `Attach: ${d.name}`, null, st === 'expired' ? 'Expired. Renew it first.' : st === 'soon' ? 'Expires soon.' : undefined) }),
    ].map(mergeQuality).sort(qualityOrder)
  }

  const upd = (k: keyof Profile) => (v: string) => setProfile({ ...profile, [k]: v })

  const multi = (k: keyof Profile, options: readonly Opt[], aria: string, placeholder = 'Select one or more', search?: boolean) => (
    <MultiSelect options={options} value={csv((profile[k] ?? '').toString())} onChange={(v) => upd(k)(v.join(', '))} placeholder={placeholder} label={aria} search={search} />
  )

  const inp = (k: keyof Profile) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setProfile({ ...profile, [k]: e.target.value })

  const readiness: [string, boolean][] = [
    ['Sectors you work in', csv(profile.focus).length > 0],
    ['Countries you work in', !!profile.country || csv(profile.opCountries).length > 0],
    ['Populations you serve', csv(profile.populations).length > 0],
    ['Funding range you want', !!(profile.amountMin || profile.amountMax)],
    ['Grant types you seek', csv(profile.grantTypes).length > 0],
    ['Registration status', !!profile.registered],
    ['Mission and track record', !!(profile.mission && profile.pastFunding)],
  ]


  // ---------- Grants tracker ----------
  const [trBusy, setTrBusy] = useState(false)

  const [trNote, setTrNote] = useState('')

  // Re-reads everything the other pages changed (this browser's saved data and, when signed in, your online copy) and recalculates the tracker.
  async function refreshTracker() {
    setTrBusy(true)
    setTrNote('')
    let appsNow = apps
    try {
      const rawApps = localStorage.getItem('ngw_apps')
      if (rawApps) { appsNow = JSON.parse(rawApps) as Application[] }
      const rawSaved = localStorage.getItem('ngw_saved')
      if (rawSaved) setSaved(JSON.parse(rawSaved) as Grant[])
      const rawFits = localStorage.getItem('ngw_fits')
      if (rawFits) setFits(JSON.parse(rawFits) as Record<string, Fit>)
    } catch {}
    let online_note = ''
    try {
      if (online?.signedIn && online.dbReady) {
        const r = await listSaved()
        if (r.ok) appsNow = mergeRemoteApps(appsNow, liveRemote(r.items))
        else online_note = ' Online copy could not be reached.'
      }
    } catch {
      online_note = ' Online copy could not be reached.'
    }
    setApps(appsNow)
    setTq(''); setTApp([]); setTGrant([])
    setTrNote(`Tracker refreshed at ${new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}.${online_note}`)
    window.whop?.track?.('tracker_refreshed')
    setTrBusy(false)
  }

  const [tq, setTq] = useState('')

  const [tApp, setTApp] = useState<string[]>([])

  const [tGrant, setTGrant] = useState<string[]>([])

  const [tSort, setTSort] = useState<{ k: string; dir: 1 | -1 }>({ k: 'deadline', dir: 1 })

  // A new sort order starts again on the first page.
  useEffect(() => { setPages({}) }, [hSort, pSort, aSort, tSort, pFit])


  const T_STATUS = ['Not started', ...STATUSES]

  const trackerAll: TRow[] = (() => {
    const mk = (g: Grant | null, a: Application | null): TRow => {
      const d = g ? parseDate(g.deadline) : null
      const f = g ? fits[g.id] : undefined
      return {
        key: a ? 'a-' + a.id : 'g-' + g!.id,
        g, a,
        title: g?.title ?? (a?.project.title || 'Untitled application'),
        funder: g?.funder ?? 'Not specified',
        source: g?.source ?? 'Custom',
        gtype: g?.gtype ?? '',
        gStatus: g ? normStatus(g) : 'unknown',
        aStatus: a ? a.status : 'Not started',
        deadline: g?.deadline ?? 'Not stated',
        days: d ? Math.ceil((d.getTime() - Date.now()) / 864e5) : null,
        award: g ? amountLabel(g) : '',
        requested: a ? Number((a.project.amount ?? '').replace(/[^0-9.]/g, '')) || 0 : 0,
        prob: a ? (a.probability ?? STAGE_PROB[a.status] ?? 0) : null,
        exp: a ? Math.round(((Number((a.project.amount ?? '').replace(/[^0-9.]/g, '')) || 0) * (a.probability ?? STAGE_PROB[a.status] ?? 0)) / 100) : 0,
        fit: f ? f.score : g ? quickMatch(g, profile).score : null,
        fitAi: !!f,
        prog: a ? progressOf(a) : null,
        updated: a ? a.updated : 0,
      }
    }
    const rows = apps.map((a) => mk(a.grant ?? null, a))
    for (const g of saved) if (!apps.some((a) => a.grant?.id === g.id)) rows.push(mk(g, null))
    return rows
  })()

  const trackerRows = (() => {
    let list = trackerAll
    if (tq.trim()) { const w = tq.toLowerCase(); list = list.filter((r) => `${r.title} ${r.funder} ${r.source} ${r.gtype}`.toLowerCase().includes(w)) }
    if (tApp.length) list = list.filter((r) => tApp.includes(r.aStatus))
    if (tGrant.length) list = list.filter((r) => tGrant.includes(r.gStatus))
    const val = (r: TRow): number | string | null => {
      switch (tSort.k) {
        case 'title': return r.title.toLowerCase()
        case 'funder': return r.funder.toLowerCase()
        case 'status': return T_STATUS.indexOf(r.aStatus)
        case 'deadline': return r.days
        case 'award': return r.g ? r.g.amountMax || r.g.amountMin || null : null
        case 'requested': return r.requested || null
        case 'prob': return r.prob
        case 'exp': return r.exp || null
        case 'fit': return r.fit
        case 'progress': return r.prog?.pct ?? null
        case 'updated': return r.updated || null
        default: return null
      }
    }
    return sortList(list, val, tSort.dir)
  })()

  const tStats = (() => {
    const by = (st: string) => trackerAll.filter((r) => r.aStatus === st)
    const sum = (rows: TRow[]) => rows.reduce((t, r) => t + r.requested, 0)
    const pipeline = [...by('Drafting'), ...by('In review'), ...by('Submitted')]
    const won = by('Awarded'), lost = by('Declined')
    const next = trackerAll.filter((r) => r.days !== null && r.days >= 0 && !['Submitted', 'Awarded', 'Declined'].includes(r.aStatus)).sort((x, y) => (x.days as number) - (y.days as number))[0]
    return {
      total: trackerAll.length,
      active: by('Drafting').length + by('In review').length,
      submitted: by('Submitted').length,
      pipelineValue: sum(pipeline),
      expected: pipeline.reduce((t, r) => t + r.exp, 0),
      awardedValue: sum(won),
      awardedCount: won.length,
      rate: won.length + lost.length ? Math.round((won.length / (won.length + lost.length)) * 100) : null,
      next,
    }
  })()

  const usd = (n: number) => (n ? '$' + n.toLocaleString('en-US') : 'Not set')

  const sortBy = (k: string) => setTSort((cur) => (cur.k === k ? { k, dir: (cur.dir * -1) as 1 | -1 } : { k, dir: 1 }))

  const th = (k: string, text: string, right = false) => (
    <th scope="col" aria-sort={tSort.k === k ? (tSort.dir === 1 ? 'ascending' : 'descending') : 'none'} className={`border-b-2 border-ink bg-card px-3 py-2.5 text-xs font-semibold tracking-wide whitespace-nowrap uppercase ${right ? 'text-right' : 'text-left'}`}>
      <button type="button" onClick={() => sortBy(k)} className="inline-flex items-center gap-1 uppercase hover:text-accent">{text}<span aria-hidden className="text-[10px]">{tSort.k === k ? (tSort.dir === 1 ? '▲' : '▼') : '↕'}</span></button>
    </th>
  )

  async function exportTrackerExcel() {
    const mod: any = await import('exceljs')
    const ExcelJS = mod.default ?? mod
    const wb = new ExcelJS.Workbook()
    wb.creator = profile.org || 'Global NGO Grants Writer'
    wb.created = new Date()
    const ws = wb.addWorksheet('Grants tracker', { views: [{ state: 'frozen', ySplit: 4, xSplit: 2 }] })
    const ink = 'FF12302F'
    const thin = { style: 'thin', color: { argb: 'FFBBBBBB' } }
    const box = { top: thin, left: thin, bottom: thin, right: thin }
    ws.addRow([`Grants tracker: ${profile.org || 'Organization'}`])
    ws.getRow(1).font = { bold: true, size: 14, color: { argb: ink } }
    ws.addRow([`Exported ${new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}. ${trackerRows.length} of ${trackerAll.length} records. Amounts in USD.`])
    ws.getRow(2).font = { italic: true, color: { argb: 'FF5B6B68' } }
    ws.addRow([])
    const cols: [string, number][] = [['No.', 6], ['Grant', 44], ['Funder', 30], ['Source', 18], ['Type', 16], ['Grant status', 14], ['Application status', 18], ['Deadline', 14], ['Days left', 10], ['Award range', 22], ['Requested (USD)', 16], ['Fit score', 10], ['Fit basis', 22], ['Sections written', 11], ['Sections total', 11], ['Progress', 10], ['Last updated', 14], ['Link', 40], ['Win chance', 11], ['Expected value (USD)', 16]]
    const hdr = ws.addRow(cols.map(([c]) => c))
    hdr.height = 30
    hdr.eachCell((c: any) => {
      c.font = { bold: true, color: { argb: 'FFFFFFFF' } }
      c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: ink } }
      c.alignment = { vertical: 'middle', wrapText: true }
      c.border = box
    })
    cols.forEach(([, w], i) => { ws.getColumn(i + 1).width = w })
    const first = ws.rowCount + 1
    trackerRows.forEach((r, i) => {
      const d = r.g ? parseDate(r.g.deadline) : null
      const row = ws.addRow([
        i + 1, r.title, r.funder, r.source, r.gtype || '', r.gStatus === 'forthcoming' ? 'upcoming' : r.gStatus, r.aStatus,
        d ?? (r.deadline === 'Not stated' ? '' : r.deadline), r.days ?? '', r.award, r.requested || null,
        r.fit ?? '', r.fit === null ? '' : r.fitAi ? 'AI fit analysis' : 'Profile match estimate (%)',
        r.prog?.done ?? '', r.prog?.total ?? '', r.prog ? r.prog.pct / 100 : '', r.updated ? new Date(r.updated) : '', r.g?.url ?? '', r.prob === null ? '' : r.prob / 100, r.a ? r.exp : '',
      ])
      row.eachCell({ includeEmpty: true }, (c: any) => { c.border = box; c.alignment = { vertical: 'top', wrapText: true } })
      if (i % 2) row.eachCell({ includeEmpty: true }, (c: any) => { c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF7F4EC' } } })
      row.getCell(8).numFmt = 'dd mmm yyyy'
      row.getCell(11).numFmt = '$#,##0'
      row.getCell(16).numFmt = '0%'
      row.getCell(17).numFmt = 'dd mmm yyyy'
      for (const n of [1, 9, 11, 12, 14, 15, 16]) row.getCell(n).alignment = { vertical: 'top', horizontal: 'right' }
      if (r.g?.url) row.getCell(18).value = { text: r.g.url, hyperlink: r.g.url }
      row.getCell(19).numFmt = '0%'
      row.getCell(20).numFmt = '$#,##0'
    })
    const last = ws.rowCount
    if (trackerRows.length) {
      const tot = ws.addRow(['', `Total, ${trackerRows.length} record${trackerRows.length === 1 ? '' : 's'}`, '', '', '', '', '', '', '', '', { formula: `SUBTOTAL(109,K${first}:K${last})` }])
      tot.eachCell({ includeEmpty: true }, (c: any) => { c.font = { bold: true }; c.border = box; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFEADC' } } })
      tot.getCell(11).numFmt = '$#,##0'
      ws.autoFilter = { from: { row: 4, column: 1 }, to: { row: last, column: cols.length } }
    }
    const sm = wb.addWorksheet('Summary')
    sm.columns = [{ width: 34 }, { width: 22 }]
    const sh = sm.addRow(['Measure', 'Value'])
    sh.eachCell((c: any) => { c.font = { bold: true, color: { argb: 'FFFFFFFF' } }; c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: ink } }; c.border = box })
    const lines: [string, string | number][] = [
      ['Tracked grants', tStats.total],
      ['Applications in progress', tStats.active],
      ['Applications submitted', tStats.submitted],
      ['Pipeline value (USD, requested, undecided)', tStats.pipelineValue],
      ['Awarded (USD)', tStats.awardedValue],
      ['Awards received', tStats.awardedCount],
      ['Success rate (awarded of decided)', tStats.rate === null ? 'n/a' : tStats.rate / 100],
    ]
    lines.forEach(([k, v]) => {
      const r = sm.addRow([k, v])
      r.eachCell((c: any) => { c.border = box })
      r.getCell(2).alignment = { horizontal: 'right' }
    })
    sm.getCell('B5').numFmt = '$#,##0'
    sm.getCell('B6').numFmt = '$#,##0'
    if (tStats.rate !== null) sm.getCell('B8').numFmt = '0%'
    const buf = await wb.xlsx.writeBuffer()
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }))
    a.download = `${(profile.org || 'org').replace(/[^a-z0-9]+/gi, '-').replace(/^-+|-+$/g, '').toLowerCase()}-grants-tracker-${new Date().toISOString().slice(0, 10)}.xlsx`
    a.click()
    window.whop?.track?.('tracker_exported')
  }

  const dueTone = (d: number | null) => (d === null ? 'text-muted' : d < 0 ? 'text-muted' : d <= 14 ? 'font-semibold text-red-800' : d <= 45 ? 'text-amber-800' : 'text-green-800')


  // Deadlines coming up, shown on every page until dismissed for the day.
  const todayKey = new Date().toISOString().slice(0, 10)

  const [remDismissed, setRemDismissed] = useState(false)

  useEffect(() => { try { setRemDismissed(sessionStorage.getItem('ngw_rem') === todayKey) } catch {} }, [todayKey])

  const reminders = (() => {
    const out: { title: string; days: number }[] = []
    const dl2 = (g: Grant | null) => { const d = g ? parseDate(g.deadline) : null; return d ? Math.ceil((d.getTime() - Date.now()) / 864e5) : null }
    for (const a of apps) {
      if (a.status !== 'Drafting' && a.status !== 'In review') continue
      const d = dl2(a.grant)
      if (d !== null && d >= 0 && d <= 14) out.push({ title: a.grant?.title ?? (a.project.title || 'Untitled application'), days: d })
    }
    for (const g of saved) {
      if (apps.some((a) => a.grant?.id === g.id)) continue
      const d = dl2(g)
      if (d !== null && d >= 0 && d <= 7) out.push({ title: g.title, days: d })
    }
    for (const d of lib.docs) { const st = docState(d); if (st === 'soon' || st === 'expired') { const dd = Math.ceil((new Date(d.expiry).getTime() - Date.now()) / 864e5); if (dd <= 30) out.push({ title: `Document ${st === 'expired' ? 'expired' : 'expiring'}: ${d.name}`, days: Math.max(0, dd) }) } }
    return out.sort((x, y) => x.days - y.days)
  })()


  const sourcePicker = () => {
    const hasG = !!guidanceSource().trim()
    const link = sourceLink()
    const gWords = hasG ? guidanceSource().trim().split(/\s+/).length : 0
    const opts: [SrcMode, string, boolean, string][] = [
      ['guidance', 'Imported guidance', hasG, hasG ? `${gWords} words imported` : 'Not imported yet. Add it in Funder information, under Guidance.'],
      ['link', 'Website link', !!link, link ? link : 'No link yet. Add it below.'],
      ['both', 'Both', hasG && !!link, 'Reads the guidance first, then adds the website.'],
    ]
    const eff: SrcMode = srcMode === 'auto' ? (hasG && link ? 'both' : hasG ? 'guidance' : link ? 'link' : 'auto') : srcMode
    const run = (m: SrcMode) => setSrcMode(m)
    return (
      <div className="mt-3 rounded-card border border-line bg-paper p-3 text-sm">
        <p className="font-semibold">Base it on</p>
        <div role="radiogroup" aria-label="Source" className="mt-2 flex flex-wrap gap-2">
          {opts.map(([m, text, ok, tip]) => (
            <button key={m} type="button" role="radio" aria-checked={eff === m} disabled={!ok || modalBusy} title={tip} onClick={() => run(m)} className={`rounded-full border px-4 py-1.5 text-sm font-semibold disabled:opacity-40 ${eff === m ? 'border-accent bg-accent text-accent-ink' : 'border-accent/60 text-accent hover:bg-accent/10'}`}>{text}</button>
          ))}
        </div>
        <p className="mt-2 text-xs text-muted">Guidance: {hasG ? `imported (${gWords} words)` : 'not imported'}. Website link: {link ? link : 'none'}.{srcUsed ? ` This result is based on ${srcUsed}.` : ''}</p>
        {!link && (
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <input type="url" className={`${field} min-w-0 flex-1 py-2 text-sm`} placeholder="Paste the funder's website link, for example https://funder.org/call" value={linkInput} onChange={(e) => setLinkInput(e.target.value)} aria-label="Funder website link" />
            <button type="button" className={ghost} disabled={modalBusy || !/^https?:\/\/\S+\.\S+/.test(linkInput.trim())} onClick={() => { const v = linkInput.trim(); patch((a) => ({ ...a, grantLink: v })); setLinkInput(''); setSrcMode('link') }}>Save link</button>
          </div>
        )}
      </div>
    )
  }

  const modalPanelEl = modal && app ? (
          <div className="mt-3 flex flex-col rounded-card border border-line bg-white" role="region" aria-labelledby="modal-title">
            <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 md:px-6">
              <div className="min-w-0">
                <h2 id="modal-title" className="font-display text-lg font-semibold">{modal === 'elig' ? 'AI eligibility checklist' : 'Grant priorities, objectives and budget ceilings'}</h2>
                <p className="mt-1 text-sm text-muted">{app.grant?.title ?? (app.project.title || 'This application')}</p>
              </div>
              <button type="button" aria-label="Close" className="shrink-0 rounded-full px-3 py-1 text-xl leading-none text-muted hover:text-ink" onClick={() => setModal(null)}>×</button>
            </div>
            <div className="px-5 py-4 md:px-6">
              {modal === 'elig' ? (
                <>
                  <p className="text-sm text-muted">AI compares the funder's eligibility rules, taken from the guidance or the funder's website, with your organization profile{profile.org ? ` (${profile.org})` : ''}. Review each line, change the status if you know better, and add a note. Complete your profile for more accurate answers.</p>
                  {sourcePicker()}
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <button type="button" className={ghost} disabled={modalBusy} onClick={() => runEligibility()}>{modalBusy ? 'AI is checking...' : eligDraft.length ? 'Analyze again' : 'Analyze'}</button>
                    {eligDraft.length > 0 && <span className="text-sm text-muted">{eligDraft.filter((x) => x.status === 'met').length} of {eligDraft.length} met · {eligDraft.filter((x) => x.status === 'not_met').length} not met · {eligDraft.filter((x) => x.status === 'document' || x.status === 'unclear').length} to resolve</span>}
                  </div>
                  {!modalBusy && eligDraft.length === 0 && !modalNote && <p className="mt-4 text-sm text-muted">Choose what to base the check on, then press Analyze.</p>}
                  {modalBusy && eligDraft.length === 0 && <p className="mt-4 text-sm text-muted">AI is reading the source and your profile...</p>}
                  {modalNote && <p className="mt-3 text-sm text-accent">{modalNote}</p>}
                  <ul className="mt-4 space-y-3">
                    {eligDraft.map((it, i) => (
                      <li key={i} className="rounded-card border border-line bg-white p-4">
                        <div className="flex flex-wrap items-start justify-between gap-3">
                          <p className="min-w-0 flex-1 font-semibold">{it.requirement}</p>
                          <select aria-label="Status" className={`rounded-full border-0 px-3 py-1.5 text-xs font-semibold ${ELIG_TONE[it.status]}`} value={it.status} onChange={(e) => setEligDraft((cur) => cur.map((x, j) => (j === i ? { ...x, status: e.target.value as EligibilityItem['status'] } : x)))}>
                            {Object.entries(ELIG_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                          </select>
                        </div>
                        {it.evidence && <p className="mt-1 text-sm text-muted">{it.evidence}</p>}
                        {it.action && it.status !== 'met' && <p className="mt-1 text-sm"><span className="font-semibold">Next step:</span> {it.action}</p>}
                        <input className={`${field} mt-2 py-2 text-sm`} placeholder="Your note" value={it.note ?? ''} onChange={(e) => setEligDraft((cur) => cur.map((x, j) => (j === i ? { ...x, note: e.target.value } : x)))} />
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <>
                  <p className="text-sm text-muted">AI listed what the funder names in the guidance or on its website. Open each list and tick everything your project responds to. You can pick several. Your choices are saved with this application and guide the AI when it writes.</p>
                  {sourcePicker()}
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <button type="button" className={ghost} disabled={modalBusy} onClick={() => runFramework()}>{modalBusy ? 'AI is reading...' : frameDraft ? 'Analyze again' : 'Analyze'}</button>
                  </div>
                  {modalNote && <p className="mt-3 text-sm text-accent">{modalNote}</p>}
                  {!modalBusy && !frameDraft && !modalNote && <p className="mt-4 text-sm text-muted">Choose what to base the lists on, then press Analyze.</p>}
                  {modalBusy && !frameDraft && <p className="mt-4 text-sm text-muted">AI is reading the source...</p>}
                  {frameDraft && (
                    <div className="mt-4 grid gap-4 md:grid-cols-2">
                      {FRAME_FIELDS.map(([k, title, hint]) => (
                        <div key={k} className="min-w-0 text-sm font-semibold">
                          <p>{title}<Hint>{hint}</Hint></p>
                          {frameDraft.options[k].length ? (
                            <MultiSelect label={title} placeholder={`Select ${title.toLowerCase()}`} options={frameDraft.options[k]} value={frameDraft.selected[k] ?? []} onChange={(v) => setFrameDraft((cur) => (cur ? { ...cur, selected: { ...cur.selected, [k]: v } } : cur))} search={frameDraft.options[k].length > 8} />
                          ) : <p className="mt-1 text-sm font-normal text-muted">Nothing found in the guidance.</p>}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 border-t border-line bg-paper px-5 py-4 md:px-6">
              <button type="button" className={ghost} onClick={() => setModal(null)}>Close</button>
              <button type="button" className={primary} disabled={modalBusy || (modal === 'elig' ? eligDraft.length === 0 : !frameDraft)} onClick={saveModal}>Save</button>
            </div>
          </div>
  ) : null


  const NAV: [View, string, string][] = [
    ['dashboard', 'Dashboard', '▦'],
    ['pipeline', 'Grants pipeline', '☰'],
    ['find', 'Find grants', '⌕'],
    ['applications', `Applications${apps.length ? ' (' + apps.length + ')' : ''}`, '✎'],
    ['library', 'Library', '▥'],
    ['profile', 'Organization profile', '◉'],
    ['plans', 'Plans', '★'],
    ...(billing?.plan === 'owner' ? ([['admin', 'Owner dashboard', '◈']] as [View, string, string][]) : []),
  ]
  return {
    aiAsk,
    askBusy,
    askLocked,
    setAskLocked,
    askNote,
    setAskNote,
    removeGrant,
    deleteApplication,
    runFitBulk,
    fitBulkBusy,
    fitStopRef,
    pFit,
    setPFit,
    fitOf,
    setGenNote,
    needLocked,
    setNeedLocked,
    importedGrants,
    setImportedGrants,
    flowLive,
    live,
    liveStatus,
    billing,
    refreshBilling,
    onlineLimit,
    qa,
    runTerminologyCheck,
    runLanguageCheck,
    fixAcronymsAI,
    fixTermsAI,
    fixLanguageAI,
    Badge,
    NAV,
    PIPE_TABS,
    PageHead,
    Stat,
    T_STATUS,
    aAll,
    aAny,
    aCats,
    aElig,
    aEu,
    aFunder,
    aInstr,
    aNot,
    aPosted,
    aSort,
    aSources,
    aStatus,
    aView,
    accent,
    accentOk,
    activeApps,
    activeId,
    addByLink,
    aiInfo,
    aiSecs,
    aiText,
    aiUseProfile,
    allProg,
    analyzeDoc,
    app,
    appOpen,
    applyCards,
    applySuggestion,
    apps,
    areasKey,
    areasStale,
    auditBusy,
    auditNote,
    avgFit,
    bdBusy,
    bdFile,
    bdNote,
    bdPick,
    bdSrc,
    budgetLinesFor,
    budgetLinkWarnings,
    budgetRules,
    buildReferences,
    busy,
    cancelAi,
    checkSearches,
    cmpIds,
    cmpOpen,
    cmpRows,
    complete,
    completeAll,
    completeMyProfile,
    condenseNeedsText,
    contentHash,
    daysLeft,
    deadlineItems,
    detailBusy,
    detailErr,
    detailGrant,
    detailsCache,
    doc,
    docBusy,
    docFileRef,
    docNote,
    downloadExcel,
    downloadExtraExcel,
    downloadExtraWord,
    downloadFilledWorkbook,
    downloadPdf,
    downloadWord,
    dragId,
    dueTone,
    editing,
    exEditing,
    exportOpen,
    exportPackage,
    exportProfile,
    exportTrackerExcel,
    extracted,
    fAmax,
    fAmin,
    fCountry,
    fDeadline,
    fSector,
    fSource,
    fStatus,
    fText,
    fType,
    fUnknownAmt,
    factCoverage,
    facts,
    fiTab,
    fillBudgetWorkbookFrom,
    filteredApps,
    findGaps,
    fitProgress,
    fits,
    flashKey,
    focusTags,
    frameworkCoverage,
    full,
    gapBusy,
    gapNote,
    gaps,
    gdBusy,
    gdNote,
    genBusy,
    genNote,
    genProjectDoc,
    aiNeed,
    aiPast,
    pastBusy,
    pastLocked,
    setPastLocked,
    pastNote,
    setPastNote,
    findSimilar,
    goSearch,
    hSort,
    hasBudgetSection,
    hasWritten,
    helpers,
    hideDead,
    historyOpen,
    impBusy,
    impDone,
    impHeaders,
    impMap,
    impName,
    impNote,
    impOpen,
    impRows,
    impSaveAll,
    importBudgetTemplate,
    importGuidance,
    importNeeds,
    editedSince,
    fieldIssues,
    fixOneField,
    fixAllFields,
    fixBusy,
    limitOf,
    fitText,
    suggestChoice,
    choiceBusy,
    generateBudgetLinesBreakdown,
    abBusy,
    importPlan,
    planBusy,
    planNote,
    removePlan,
    importExperience,
    removeExperience,
    expBusy,
    expNote,
    importTemplate,
    improveAll,
    inp,
    inputs,
    isSaved,
    lib,
    linkBusy,
    linkGrant,
    linkNote,
    linkText,
    linkUrl,
    loadDetails,
    loadImportFile,
    makeHelper,
    makeWordBlob,
    meta,
    modal,
    modalBusy,
    modalPanelEl,
    modes,
    moveApp,
    msg,
    multi,
    needPaste,
    needsBackup,
    needsBusy,
    needsNote,
    nextAction,
    nextDeadline,
    notes,
    notesBy,
    online,
    onlyDated,
    open,
    openDetails,
    openEligibility,
    openFramework,
    openSaved,
    pSort,
    packBusy,
    pageOf,
    pageStart,
    pager,
    patch,
    pct,
    pdBusy,
    pdNote,
    pipeMode,
    pipeOpen,
    pipeRows,
    pipeTab,
    prevTitle,
    privacyOpen,
    profBusy,
    profNote,
    profile,
    progressOf,
    project,
    q,
    qFlow,
    reflectAndDownload,
    setAutoNext,
    qSug,
    qualityItems,
    readiness,
    reflectInputs,
    refreshMatches,
    refreshTracker,
    remDismissed,
    reminders,
    restoreVersion,
    results,
    resultsAt,
    reviewOpen,
    reviewSections,
    runAudit,
    runCombined,
    runFit,
    runFitAll,
    runImport,
    runProfileSearch,
    runSearch,
    runTitles,
    saveOnline,
    saveProfile,
    saveStatus,
    saved,
    saving,
    scanSources,
    searches,
    secMsg,
    secOpen,
    secs,
    selectedFramework,
    setAAll,
    setAAny,
    setACats,
    setAElig,
    setAEu,
    setAFunder,
    setAInstr,
    setANot,
    setAPosted,
    setASort,
    setASources,
    setAStatus,
    setAView,
    setAccent,
    setActiveId,
    setAiText,
    setAiUseProfile,
    setAllProg,
    setAppOpen,
    setApps,
    setAuditNote,
    setBdBusy,
    setBdFile,
    setBdNote,
    setBdPick,
    setCmpIds,
    setCmpOpen,
    setDetailGrant,
    setDoc,
    setDocNote,
    setDragId,
    setEditing,
    setExEditing,
    setExportOpen,
    setExtracted,
    setFAmax,
    setFAmin,
    setFCountry,
    setFDeadline,
    setFSector,
    setFSource,
    setFStatus,
    setFText,
    setFType,
    setFUnknownAmt,
    setFacts,
    setFiTab,
    setGaps,
    setHSort,
    setHideDead,
    setHistoryOpen,
    setImpMap,
    setImpName,
    setImpOpen,
    setImpRows,
    setImpSaveAll,
    setInputs,
    setLib,
    setLinkText,
    setLinkUrl,
    setModal,
    setModes,
    setMsg,
    setNeedsBackup,
    setNotesBy,
    setOnlyDated,
    setOpen,
    setPSort,
    setPackBusy,
    setPdNote,
    setPipeMode,
    setPipeOpen,
    setPipeTab,
    setPrevTitle,
    setPrivacyOpen,
    setProfile,
    setProject,
    setQ,
    setQSug,
    setRemDismissed,
    setReviewOpen,
    setSaved,
    setSearches,
    setSecMsg,
    setSecOpen,
    setShareOpen,
    setSort,
    setSource,
    setSrcRow,
    setStorageFull,
    setTApp,
    setTGrant,
    setTheme,
    setTitleNote,
    setTitleOpts,
    setTpl,
    setTplNote,
    setTplPaste,
    setTq,
    setView,
    setViewing,
    shareOpen,
    shownFinal,
    skipCard,
    snapshotDoc,
    sortRows,
    sortedApps,
    sortedFinal,
    source,
    sources,
    srcBusy,
    srcNote,
    ssBusy,
    startApplication,
    startFlow,
    statusTone,
    stopRef,
    storageFull,
    suggestForItem,
    tApp,
    tGrant,
    tStats,
    target,
    th,
    theme,
    titleBusy,
    titleNote,
    titleOpts,
    todayKey,
    toggleCmp,
    toggleSave,
    toggleSec,
    tpl,
    tplBusy,
    tplNote,
    tplPaste,
    tq,
    trBusy,
    trNote,
    trackerAll,
    trackerRows,
    updateFromLibrary,
    updateFromWebsite,
    usd,
    view,
    viewing,
    wc,
    webNote,
    wfDone,
    wfNext,
    wfSteps,
    writeAnswers,
  }
}

export type HomeState = ReturnType<typeof useHome>


// Checklists C to H are one checklist: one group, ordered by area, with a subheading for each area. Later groups move up by three letters.
const QUALITY_GROUP = 'C. Proposal quality'
const QUALITY_SUBS = ['Evidence and inputs', 'Structure and format', 'Content', 'Alignment', 'Accuracy', 'Language and style']
function mergeQuality(it: QItem): QItem {
  const m = it.group.match(/^([C-H])\./)
  if (m) return { ...it, group: QUALITY_GROUP, sub: QUALITY_SUBS['CDEFGH'.indexOf(m[1])] }
  const later = it.group.match(/^([IJK])\.\s*(.*)$/)
  if (later) return { ...it, group: `${'DEF'['IJK'.indexOf(later[1])]}. ${later[2]}` }
  return it
}
const groupRank = (g: string) => (g.startsWith('A.') ? 0 : g.startsWith('B.') ? 1 : g === QUALITY_GROUP ? 2 : 3)
const qualityOrder = (x: QItem, y: QItem) => groupRank(x.group) - groupRank(y.group) || (x.sub ? QUALITY_SUBS.indexOf(x.sub) : 0) - (y.sub ? QUALITY_SUBS.indexOf(y.sub) : 0)
