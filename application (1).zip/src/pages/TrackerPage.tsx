import type { TRow } from '../lib/types'
import { showDate } from '../lib/options'
import { MultiSelect, field, ghost, primary } from '../components/ui'
import { type AppStatus, STATUSES } from '../lib/types'
import { fmtDate } from '../lib/text'
import { type HomeState } from './use-home'

export function TrackerView(h: HomeState) {
  const {
    PageHead,
    T_STATUS,
    dueTone,
    exportTrackerExcel,
    pageOf,
    pageStart,
    pager,
    profile,
    refreshTracker,
    removeGrant,
    setActiveId,
    setAppOpen,
    setApps,
    setTApp,
    setTGrant,
    setTq,
    setView,
    startApplication,
    statusTone,
    tApp,
    tGrant,
    tStats,
    th,
    tq,
    trBusy,
    trNote,
    trackerAll,
    trackerRows,
    usd,
  } = h
  return (
    <div>
      <PageHead title="Grants pipeline: full table" sub={`${profile.org || 'Your organization'}: every grant you track and every application, with status, deadline, funding and progress in one register.`}>
        <div className="flex flex-wrap gap-3">
          <button type="button" className={ghost} disabled={trBusy} onClick={refreshTracker}>{trBusy ? 'Refreshing...' : 'Refresh tracker'}</button>
          <button type="button" className={ghost} disabled={!trackerRows.length} onClick={exportTrackerExcel}>Export Excel</button>
        </div>
      </PageHead>
      {trNote && <p className="-mt-4 mb-4 text-sm text-accent" aria-live="polite">{trNote}</p>}
      <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 [&>*]:min-w-0">
        {([
          ['Tracked grants', String(tStats.total), `${tStats.active} in progress, ${tStats.submitted} submitted`],
          ['Pipeline value', usd(tStats.pipelineValue), 'Requested, not yet decided'],
          ['Awarded', usd(tStats.awardedValue), `${tStats.awardedCount} award${tStats.awardedCount === 1 ? '' : 's'}`],
          ['Success rate', tStats.rate === null ? 'n/a' : tStats.rate + '%', 'Awarded of decided'],
          ['Next deadline', tStats.next ? `${tStats.next.days}d` : 'None', tStats.next ? tStats.next.title.slice(0, 40) : 'No upcoming dated grants'],
          ['Expected value', usd(tStats.expected), 'Requested times win chance'],
        ] as [string, string, string][]).map(([l, v, h]) => (
          <div key={l} className="rounded-card border border-line bg-card p-4">
            <dt className="text-xs font-semibold tracking-wide text-muted uppercase">{l}</dt>
            <dd className="mt-1 font-display text-2xl font-semibold tabular-nums">{v}</dd>
            <dd className="mt-0.5 truncate text-xs text-muted">{h}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-4 grid gap-3 md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]">
        <label className="block text-sm font-semibold">Search<input className={`${field} mt-1`} placeholder="Grant, funder, source or type" value={tq} onChange={(e) => setTq(e.target.value)} /></label>
        <div className="text-sm font-semibold">Application status<MultiSelect label="Filter by application status" placeholder="All statuses" value={tApp} onChange={setTApp} options={T_STATUS} /></div>
        <div className="text-sm font-semibold">Grant status<MultiSelect label="Filter by grant status" placeholder="All grant statuses" value={tGrant} onChange={setTGrant} options={[['open', 'Open'], ['forthcoming', 'Upcoming'], ['rolling', 'Rolling'], ['closed', 'Closed'], ['unknown', 'Unknown']]} /></div>
      </div>
      <p className="mt-3 text-sm text-muted" aria-live="polite">Showing {trackerRows.length} of {trackerAll.length} record{trackerAll.length === 1 ? '' : 's'}. Select a column heading to sort.</p>

      {trackerAll.length === 0 ? (
        <div className="mt-4 rounded-card border border-dashed border-ink/30 p-8 text-center">
          <p className="font-display text-2xl font-semibold">Nothing tracked yet</p>
          <p className="mx-auto mt-2 max-w-md text-muted">Save a grant from Find grants or start an application. It will appear here automatically.</p>
          <button className={`${primary} mt-4`} onClick={() => setView('find')}>Find grants</button>
        </div>
      ) : (
        <>
        <div className="mt-3 hidden overflow-hidden rounded-card border border-line bg-white xl:block">
          <table className="w-full table-auto border-collapse text-xs">
            <caption className="sr-only">Grants tracker register</caption>
            <thead>
              <tr>
                <th scope="col" className="border-b-2 border-ink bg-card px-2 py-2.5 text-left text-xs font-semibold tracking-wide uppercase">No.</th>
                {th('title', 'Grant and funder')}
                {th('status', 'Application')}
                {th('deadline', 'Deadline')}
                {th('award', 'Award range')}
                {th('requested', 'Requested', true)}
                {th('prob', 'Win %', true)}
                {th('exp', 'Expected', true)}
                {th('fit', 'Fit', true)}
                {th('progress', 'Progress')}
                {th('updated', 'Updated')}
                <th scope="col" className="border-b-2 border-ink bg-card px-2 py-2.5 text-right text-xs font-semibold tracking-wide uppercase">Action</th>
              </tr>
            </thead>
            <tbody>
              {trackerRows.length === 0 && <tr><td colSpan={12} className="px-3 py-5 text-center text-muted">No records match these filters.</td></tr>}
              {pageOf(trackerRows, 'tracker').map((r, i) => (
                <tr key={r.key} className="border-b border-line align-top even:bg-paper/60">
                  <td className="px-2 py-2.5 tabular-nums text-muted">{pageStart('tracker', trackerRows.length) + i + 1}</td>
                  <td className="max-w-[18rem] px-2 py-2.5">
                    <p className="font-semibold">{r.g?.url ? <a href={r.g.url} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4 hover:decoration-ink">{r.title}</a> : r.title}</p>
                    <p className="text-xs text-muted">{r.funder} · {r.source}{r.gtype ? ` · ${r.gtype}` : ''}</p>
                  </td>
                  <td className="px-2 py-2.5">
                    {r.a ? (
                      <select aria-label={`Application status for ${r.title}`} value={r.a.status} onChange={(e) => { const v = e.target.value as AppStatus; const id = r.a!.id; setApps((cur) => cur.map((x) => (x.id === id ? { ...x, status: v, updated: Date.now() } : x))) }} className={`rounded-full border-0 px-2.5 py-1 text-xs font-semibold ${statusTone[r.a.status]}`}>
                        {STATUSES.map((st) => <option key={st}>{st}</option>)}
                      </select>
                    ) : <span className="rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-muted">Not started</span>}
                    <p className="mt-1 text-[11px] text-muted capitalize">Call: {r.gStatus === 'forthcoming' ? 'upcoming' : r.gStatus}</p>
                  </td>
                  <td className="px-2 py-2.5">
                    <p>{showDate(r.deadline)}</p>
                    {r.days !== null && !['Awarded', 'Declined'].includes(r.aStatus) && <p className={`text-xs ${dueTone(r.days)}`}>{r.days < 0 ? 'Closed' : r.days === 0 ? 'Due today' : `${r.days} days left`}</p>}
                    {r.g?.prevDeadline && <p className="text-[11px] font-semibold text-amber-800">Changed from {r.g.prevDeadline}</p>}
                    {r.g?.checkedAt && <p className="text-[11px] text-muted">Verified {new Date(r.g.checkedAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</p>}
                  </td>
                  <td className="px-2 py-2.5">{r.award || <span className="text-muted">Not stated</span>}</td>
                  <td className="px-2 py-2.5 text-right tabular-nums">{r.requested ? usd(r.requested) : <span className="text-muted">Not set</span>}</td>
                  <td className="px-2 py-2.5 text-right tabular-nums">
                    {r.a ? <input aria-label={`Win chance for ${r.title}`} type="number" min={0} max={100} className="w-14 rounded-md border border-line bg-white px-1.5 py-1 text-right text-xs" value={r.prob ?? 0} onChange={(e) => { const v = Math.max(0, Math.min(100, Number(e.target.value) || 0)); const id = r.a!.id; setApps((cur) => cur.map((x) => (x.id === id ? { ...x, probability: v, updated: Date.now() } : x))) }} /> : <span className="text-muted">n/a</span>}
                  </td>
                  <td className="px-2 py-2.5 text-right tabular-nums">{r.a ? usd(r.exp) : <span className="text-muted">n/a</span>}</td>
                  <td className="px-2 py-2.5 text-right tabular-nums" title={r.fit === null ? '' : r.fitAi ? 'AI fit analysis' : 'Estimate from your profile. Run a fit analysis for a detailed score.'}>
                    {r.fit === null ? <span className="text-muted">n/a</span> : <><span className="font-semibold">{r.fitAi ? r.fit : '~' + r.fit}</span><span className="text-xs text-muted">{r.fitAi ? '/100' : '%'}</span></>}
                  </td>
                  <td className="min-w-[5rem] px-2 py-2.5">
                    {r.prog ? (
                      <>
                        <div className="h-2 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={r.prog.pct}><div className="h-full bg-accent" style={{ width: `${r.prog.pct}%` }} /></div>
                        <p className="mt-1 text-xs text-muted">{r.prog.done}/{r.prog.total} sections</p>
                      </>
                    ) : <span className="text-muted">n/a</span>}
                  </td>
                  <td className="px-2 py-2.5 text-muted">{r.updated ? fmtDate(r.updated) : 'n/a'}</td>
                  <td className="px-2 py-2.5 text-right">
                    {r.a
                      ? <button className="text-sm font-semibold underline" onClick={() => { setActiveId(r.a!.id); setAppOpen(true); setView('applications') }}>Open</button>
                      : <span className="inline-flex gap-3"><button className="text-sm font-semibold underline" onClick={() => startApplication(r.g)}>Start</button>{r.g && <button className="text-sm text-muted underline" onClick={() => removeGrant(r.g!)}>Remove</button>}</span>}
                  </td>
                </tr>
              ))}
            </tbody>
            {trackerRows.length > 0 && (
              <tfoot>
                <tr className="bg-card font-semibold">
                  <td colSpan={5} className="border-t-2 border-ink px-2 py-2.5 text-right text-xs tracking-wide uppercase">Total, {trackerRows.length} record{trackerRows.length === 1 ? '' : 's'}</td>
                  <td className="border-t-2 border-ink px-2 py-2.5 text-right tabular-nums">{usd(trackerRows.reduce((t, r) => t + r.requested, 0))}</td>
                  <td className="border-t-2 border-ink" />
                  <td className="border-t-2 border-ink px-2 py-2.5 text-right tabular-nums">{usd(trackerRows.reduce((t, r) => t + r.exp, 0))}</td>
                  <td colSpan={4} className="border-t-2 border-ink" />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
        {pager('tracker', trackerRows.length)}
        <ul className="mt-3 space-y-3 xl:hidden">
          {trackerRows.length === 0 && <li className="rounded-card border border-line bg-white p-6 text-center text-muted">No records match these filters.</li>}
          {pageOf(trackerRows, 'tracker').map((r, i) => (
            <li key={r.key} className="min-w-0 rounded-card border border-line bg-white p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-xs text-muted tabular-nums">#{pageStart('tracker', trackerRows.length) + i + 1} · {r.source}{r.gtype ? ` · ${r.gtype}` : ''}</p>
                  <p className="mt-0.5 font-semibold">{r.g?.url ? <a href={r.g.url} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4">{r.title}</a> : r.title}</p>
                  <p className="text-sm text-muted">{r.funder}</p>
                </div>
                {r.a ? (
                  <select aria-label={`Application status for ${r.title}`} value={r.a.status} onChange={(e) => { const v = e.target.value as AppStatus; const id = r.a!.id; setApps((cur) => cur.map((x) => (x.id === id ? { ...x, status: v, updated: Date.now() } : x))) }} className={`shrink-0 rounded-full border-0 px-2.5 py-1 text-xs font-semibold ${statusTone[r.a.status]}`}>
                    {STATUSES.map((st) => <option key={st}>{st}</option>)}
                  </select>
                ) : <span className="shrink-0 rounded-full bg-card px-2.5 py-1 text-xs font-semibold text-muted">Not started</span>}
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm [&>div]:min-w-0">
                <div><dt className="text-xs text-muted">Deadline</dt><dd>{showDate(r.deadline)}{r.days !== null && !['Awarded', 'Declined'].includes(r.aStatus) && <span className={`block text-xs ${dueTone(r.days)}`}>{r.days < 0 ? 'Closed' : r.days === 0 ? 'Due today' : `${r.days} days left`}</span>}</dd></div>
                <div><dt className="text-xs text-muted">Grant status</dt><dd className="capitalize">{r.gStatus === 'forthcoming' ? 'upcoming' : r.gStatus}</dd></div>
                <div><dt className="text-xs text-muted">Award range</dt><dd>{r.award || 'Not stated'}</dd></div>
                <div><dt className="text-xs text-muted">Requested</dt><dd className="tabular-nums">{usd(r.requested)}</dd></div>
                <div><dt className="text-xs text-muted">Win chance</dt><dd className="tabular-nums">{r.prob === null ? 'n/a' : `${r.prob}%`}</dd></div>
                <div><dt className="text-xs text-muted">Expected value</dt><dd className="tabular-nums">{r.a ? usd(r.exp) : 'n/a'}</dd></div>
                <div><dt className="text-xs text-muted">Fit</dt><dd className="tabular-nums">{r.fit === null ? 'n/a' : r.fitAi ? `${r.fit}/100` : `~${r.fit}%`}</dd></div>
                <div><dt className="text-xs text-muted">Updated</dt><dd>{r.updated ? fmtDate(r.updated) : 'n/a'}</dd></div>
              </dl>
              {r.prog && (
                <div className="mt-3">
                  <div className="h-2 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${r.prog.pct}%` }} /></div>
                  <p className="mt-1 text-xs text-muted">{r.prog.done}/{r.prog.total} sections written</p>
                </div>
              )}
              <div className="mt-3 text-right">
                {r.a
                  ? <button className="text-sm font-semibold underline" onClick={() => { setActiveId(r.a!.id); setAppOpen(true); setView('applications') }}>Open application</button>
                  : <span className="inline-flex gap-4"><button className="text-sm font-semibold underline" onClick={() => startApplication(r.g)}>Start application</button>{r.g && <button className="text-sm text-muted underline" onClick={() => removeGrant(r.g!)}>Remove</button>}</span>}
              </div>
            </li>
          ))}
          {trackerRows.length > 0 && <li className="rounded-card bg-card p-4 text-sm font-semibold">Total requested, {trackerRows.length} record{trackerRows.length === 1 ? '' : 's'}: <span className="tabular-nums">{usd(trackerRows.reduce((t, r) => t + r.requested, 0))}</span></li>}
        </ul>
        </>
      )}
      {trackerAll.length > 0 && (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <section className="rounded-card border border-line bg-white p-5" aria-label="Requested amount by stage">
            <h3 className="font-display text-xl font-semibold">Requested amount by stage</h3>
            <ul className="mt-3 space-y-3">
              {(() => {
                const rows = STATUSES.map((st) => ({ st, n: trackerAll.filter((r) => r.aStatus === st).length, v: trackerAll.filter((r) => r.aStatus === st).reduce((t, r) => t + r.requested, 0) }))
                const max = Math.max(1, ...rows.map((r) => r.v))
                return rows.map((r) => (
                  <li key={r.st}>
                    <div className="flex justify-between text-sm"><span className="font-semibold">{r.st} <span className="font-normal text-muted">({r.n})</span></span><span className="tabular-nums">{usd(r.v)}</span></div>
                    <div className="mt-1 h-2.5 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${(r.v / max) * 100}%` }} /></div>
                  </li>
                ))
              })()}
            </ul>
          </section>
          <section className="rounded-card border border-line bg-white p-5" aria-label="Applications by funder">
            <h3 className="font-display text-xl font-semibold">Outcomes by funder</h3>
            {(() => {
              const by = new Map<string, TRow[]>()
              for (const r of trackerAll.filter((x) => x.a)) by.set(r.funder, [...(by.get(r.funder) ?? []), r])
              const top = [...by.entries()].sort((a, b) => b[1].length - a[1].length).slice(0, 6)
              if (!top.length) return <p className="mt-3 text-sm text-muted">Start an application to see results by funder.</p>
              const color: Record<string, string> = { Drafting: 'bg-gray-400', 'In review': 'bg-amber-500', Submitted: 'bg-sky-500', Awarded: 'bg-green-600', Declined: 'bg-red-600' }
              const max = Math.max(...top.map(([, v]) => v.length))
              return (
                <>
                  <ul className="mt-3 space-y-3">
                    {top.map(([f, rows]) => (
                      <li key={f}>
                        <div className="flex justify-between gap-3 text-sm"><span className="min-w-0 truncate font-semibold">{f}</span><span className="tabular-nums text-muted">{rows.length}</span></div>
                        <div className="mt-1 flex h-2.5 overflow-hidden rounded-full bg-line" style={{ width: `${(rows.length / max) * 100}%` }}>
                          {STATUSES.map((st) => { const n = rows.filter((r) => r.aStatus === st).length; return n ? <div key={st} className={color[st]} style={{ width: `${(n / rows.length) * 100}%` }} title={`${st}: ${n}`} /> : null })}
                        </div>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-3 flex flex-wrap gap-3 text-xs text-muted">{STATUSES.map((st) => <span key={st} className="inline-flex items-center gap-1"><span className={`inline-block size-2.5 rounded-full ${color[st]}`} />{st}</span>)}</p>
                </>
              )
            })()}
          </section>
        </div>
      )}
      <div className="mt-4 max-w-3xl space-y-1 text-xs text-muted">
        <p><span className="font-semibold">Win %:</span> your own estimate of the chance of success. It starts from the stage (Drafting 10, In review 20, Submitted 30, Awarded 100, Declined 0) and you can edit it. <span className="font-semibold">Expected value</span> is the requested amount times the win chance.</p>
        <p><span className="font-semibold">Application:</span> your own stage for each grant. Change it from the drop-down. <span className="font-semibold">Grant status:</span> the funder's call status taken from the listing.</p>
        <p><span className="font-semibold">Requested:</span> the amount entered in the application. <span className="font-semibold">Pipeline value</span> adds drafting, in review and submitted applications; awarded and declined are excluded.</p>
        <p><span className="font-semibold">Fit:</span> a score out of 100 once you run a fit analysis; otherwise a percentage estimate from your profile, marked with ~. <span className="font-semibold">Progress:</span> sections written out of all sections in the application.</p>
      </div>
    </div>
  )
}
