import { useState } from 'react'
import { type HomeState } from './use-home'
import { ghost, primary } from '../components/ui'
import { AVAILABLE, CHECKOUT, DUE_TODAY, PLAN_LIMITS, PRICES, TRIAL_DAYS, type PlanKey } from '../plans'

const TIERS: { key: 'free' | 'starter' | 'pro'; blurb: string; perks: string[] }[] = [
  { key: 'free', blurb: 'Try every tool on one proposal.', perks: ['30 AI credits a month', '1 project kept online', 'Funder search, drafting and quality checks', 'Word and PDF export'] },
  { key: 'starter', blurb: 'For small NGOs writing a few proposals a year.', perks: ['300 AI credits a month', '3 projects kept online', 'Everything in Free', 'Room for several full review passes'] },
  { key: 'pro', blurb: 'For NGOs and consultants writing many proposals.', perks: ['1,500 AI credits a month', 'Unlimited projects kept online', 'Everything in Starter', 'Review and improve on every proposal'] },
]

export function PlansPage({ h }: { h: HomeState }) {
  const { PageHead, billing, online } = h
  const [cycle, setCycle] = useState<'month' | 'year'>('month')
  const plan: PlanKey = billing?.plan ?? 'free'
  const signedIn = !!billing?.signedIn
  const left = billing ? Math.max(0, billing.limit - billing.used) : 0
  const pct = billing && plan !== 'owner' ? Math.min(100, Math.round((billing.used / billing.limit) * 100)) : 0
  const reset = billing ? new Date(billing.resetsAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }) : ''

  return (
    <>
      <PageHead title="Plans" sub="Start free. Upgrade when you need more AI credits or more projects kept online." />
      {signedIn && billing && (
        <section className="mb-5 rounded-card border border-line bg-card p-5" aria-label="Your plan">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-sm text-muted">Your plan</p>
              <p className="font-display text-2xl font-semibold">{PLAN_LIMITS[plan].name}</p>
            </div>
            {plan === 'owner' ? <p className="text-sm text-muted">You own this site, so your AI credits are unlimited.</p> : <p className="text-sm text-muted">Credits reset on {reset}</p>}
          </div>
          {plan !== 'owner' && (
            <div className="mt-4">
              <div className="flex justify-between text-sm"><span><span className="font-semibold">{left}</span> of {billing.limit} AI credits left this month</span><span className="text-muted">{billing.used} used</span></div>
              <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-ink/10" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="AI credits used">
                <div className={`h-full rounded-full ${pct >= 90 ? 'bg-red-600' : 'bg-accent'}`} style={{ width: pct + '%' }} />
              </div>
            </div>
          )}
        </section>
      )}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div role="tablist" aria-label="Billing period" className="inline-flex overflow-hidden rounded-full border border-accent/60 text-sm font-semibold">
          {([['month', 'Monthly'], ['year', 'Yearly (2 months free)']] as const).map(([k, t]) => (
            <button key={k} type="button" role="tab" aria-selected={cycle === k} onClick={() => setCycle(k)} className={`px-5 py-1.5 ${cycle === k ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{t}</button>
          ))}
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {TIERS.map((t) => {
          const mine = signedIn && plan === t.key
          const price = t.key === 'free' ? 0 : PRICES[t.key][cycle]
          const trial = t.key === 'free' ? 0 : TRIAL_DAYS[t.key][cycle]
          const due = t.key === 'free' ? 0 : DUE_TODAY[t.key][cycle]
          const canBuy = t.key === 'free' ? true : AVAILABLE[t.key][cycle]
          return (
            <section key={t.key} className={`flex flex-col rounded-card border p-5 ${t.key === 'pro' ? 'border-accent bg-card shadow-lg' : 'border-line bg-card'}`} aria-label={PLAN_LIMITS[t.key].name + ' plan'}>
              <div className="flex items-center justify-between"><h2 className="font-display text-xl font-semibold">{PLAN_LIMITS[t.key].name}</h2>{t.key === 'pro' && <span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold text-accent-ink">Best value</span>}</div>
              <p className="mt-3"><span className="font-display text-4xl font-semibold">${price}</span><span className="text-muted">{t.key === 'free' ? '' : cycle === 'month' ? ' / month' : ' / year'}</span></p>
              {trial > 0 && <p className="mt-1 text-sm font-semibold text-accent">{trial}-day trial, then ${price} / {cycle}.{due > 0 ? ` $${due} is charged today.` : ' Nothing is charged today.'}</p>}
              <p className="mt-2 text-sm text-muted">{t.blurb}</p>
              <ul className="mt-4 flex-1 space-y-2 text-sm">{t.perks.map((p) => <li key={p} className="flex gap-2"><span aria-hidden className="text-accent">✓</span>{p}</li>)}</ul>
              <div className="mt-5">
                {mine ? <span className="inline-block rounded-full border border-accent px-4 py-2 text-sm font-semibold text-accent">Your current plan</span>
                  : t.key === 'free' ? <a className={ghost + ' inline-block text-center'} href={CHECKOUT.free}>Start free</a>
                  : !canBuy ? <span className="inline-block rounded-full border border-line px-4 py-2 text-sm font-semibold text-muted" title="This plan cannot be bought online yet.">Not available yet</span>
                  : <a className={primary + ' inline-block text-center'} href={CHECKOUT[t.key][cycle]}>{trial > 0 && (plan === 'free' || plan === 'owner') ? `Start ${trial}-day trial of ` : (plan === 'free' || plan === 'owner' ? 'Choose ' : 'Switch to ')}{PLAN_LIMITS[t.key].name}</a>}
              </div>
            </section>
          )
        })}
      </div>
      <section className="mt-5 rounded-card border border-line bg-card p-5 text-sm">
        <h2 className="font-display text-lg font-semibold">How AI credits work</h2>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-muted">
          <li>One credit is one AI request. Writing one section uses 1 credit. A full Review and improve pass on a proposal uses about 6 to 12.</li>
          <li>Credits reset on the 1st of every month. Unused credits do not roll over.</li>
          <li>Starter (monthly or yearly) and Pro (yearly) start with a 7-day trial, and nothing is charged until the trial ends. Pro monthly has no trial.</li>
          <li>Everything else in the portal, such as the pipeline, tracker, library and exports, never uses credits.</li>
          <li>Payment is handled securely on Whop. Manage or cancel your subscription from your Whop account. You keep your plan until the end of the period you paid for.</li>
        </ul>
      </section>
      {!online?.dbReady && online && <p className="mt-3 text-xs text-muted">Online saving is not set up on this site yet.</p>}
    </>
  )
}
