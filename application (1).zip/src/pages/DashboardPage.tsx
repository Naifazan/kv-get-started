import { type HomeState } from './use-home'
import { showDate } from '../lib/options'

export function DashboardView(h: HomeState) {
  const {
    Badge,
    PIPE_TABS,
    PageHead,
    Stat,
    activeApps,
    apps,
    avgFit,
    deadlineItems,
    focusTags,
    goSearch,
    nextAction,
    nextDeadline,
    openSaved,
    pct,
    pipeRows,
    profile,
    progressOf,
    saved,
    setActiveId,
    setAppOpen,
    setPipeTab,
    setView,
    startApplication,
    statusTone,
    wfDone,
    wfNext,
    wfSteps,
  } = h
  return (
    <div>
      <PageHead title="Dashboard" sub={profile.org ? `${profile.org}${profile.country ? ', ' + profile.country : ''}. Your grant pipeline at a glance.` : 'Your grant pipeline at a glance. Start by completing your organization profile.'} />
      <div className="mb-5 rounded-card bg-ink p-6 text-paper break-words md:p-8">
        <p className="text-xs font-semibold tracking-wide text-paper/60 uppercase">Recommended next step</p>
        <h2 className="mt-2 font-display text-3xl font-semibold text-balance">{nextAction.title}</h2>
        <p className="mt-2 max-w-xl text-paper/80">{nextAction.body}</p>
        <a href="https://whop.com/checkout/ch_m7dvzb8WxH3ZUbq/" className="mt-5 inline-flex min-h-11 items-center rounded-full bg-accent px-6 font-semibold text-accent-ink hover:brightness-110">Start writing grants for $29/mo</a>
      </div>
      <section className="mb-5 rounded-card border border-line bg-card p-5" aria-label="Grant workflow">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-2xl font-semibold">Your grant workflow</h2>
          <p className="text-sm font-semibold tabular-nums">{wfDone} of {wfSteps.length} steps done</p>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuemin={0} aria-valuemax={wfSteps.length} aria-valuenow={wfDone}><div className="h-full bg-accent transition-all" style={{ width: `${(wfDone / wfSteps.length) * 100}%` }} /></div>
        <ol className="mt-4 grid gap-2 md:grid-cols-2">
          {wfSteps.map((st, i) => {
            const next = wfNext?.id === st.id
            return (
              <li key={st.id} className={`flex items-center gap-3 rounded-lg border px-3 py-2.5 ${next ? 'border-accent bg-white' : 'border-transparent'}`}>
                <span aria-hidden className={`inline-flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${st.done ? 'bg-green-600 text-white' : next ? 'bg-accent text-accent-ink' : 'border border-ink/30 text-muted'}`}>{st.done ? '✓' : i + 1}</span>
                <div className="min-w-0 flex-1"><p className={`text-sm ${st.done ? 'text-muted line-through' : 'font-semibold'}`}>{st.label}</p><p className="truncate text-xs text-muted">{st.hint}</p></div>
                {next && <button type="button" className="shrink-0 text-sm font-semibold text-accent underline" onClick={st.go}>{st.cta}</button>}
              </li>
            )
          })}
        </ol>
      </section>
      <div className="grid min-w-0 gap-4 sm:grid-cols-2 lg:grid-cols-4 [&>*]:min-w-0">
        <Stat label="Saved grants" value={saved.length} hint={avgFit !== null ? `Average fit ${avgFit}/100` : 'No fit analysis yet'} onClick={openSaved} />
        <Stat label="Active applications" value={activeApps.length} hint={`${apps.length} in total`} onClick={() => setView('applications')} />
        <Stat label="Next deadline" value={nextDeadline ? `${nextDeadline.days}d` : 'None'} hint={nextDeadline ? nextDeadline.g.title.slice(0, 48) : 'No dated grants saved'} onClick={() => setView('pipeline')} />
        <Stat label="Profile complete" value={`${pct}%`} hint={pct < 100 ? 'Tap to finish it' : 'Fully filled in'} onClick={() => setView('profile')} />
      </div>

      <div className="mt-5 grid gap-8 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <section className="min-w-0">
          <h2 className="font-display text-2xl font-semibold">Upcoming deadlines</h2>
          {deadlineItems.length === 0 ? (
            <p className="mt-3 text-muted">No dated grants yet. Saved grants and applications with a deadline appear here.</p>
          ) : (
            <ul className="mt-3 divide-y divide-line border-y border-line">
              {deadlineItems.slice(0, 6).map(({ g, days }) => {
                const a = apps.find((x) => x.grant?.id === g.id)
                return (
                  <li key={g.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{g.title}</p>
                      <p className="text-sm text-muted">{g.funder} · {showDate(g.deadline)}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge days={days} />
                      <button className="text-sm font-semibold underline" onClick={() => startApplication(g)}>{a ? 'Open' : 'Start'}</button>
                    </div>
                  </li>
                )
              })}
            </ul>
          )}

          <h2 className="mt-4 font-display text-2xl font-semibold">Applications in progress</h2>
          {activeApps.length === 0 ? (
            <p className="mt-3 text-muted">No applications in progress.</p>
          ) : (
            <ul className="mt-3 space-y-3">
              {activeApps.slice(0, 5).map((a) => {
                const pr = progressOf(a)
                return (
                  <li key={a.id}>
                    <button className="w-full rounded-card border border-line p-4 text-left hover:border-accent/60" onClick={() => { setActiveId(a.id); setAppOpen(true); setView('applications') }}>
                      <div className="flex items-center justify-between gap-3">
                        <p className="truncate font-semibold">{a.grant?.title ?? (a.project.title || 'Untitled draft')}</p>
                        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${statusTone[a.status]}`}>{a.status}</span>
                      </div>
                      <div className="mt-3 h-2 overflow-hidden rounded-full bg-line"><div className="h-full bg-accent" style={{ width: `${pr.pct}%` }} /></div>
                      <p className="mt-2 text-xs text-muted">{pr.done} of {pr.total} sections written</p>
                    </button>
                  </li>
                )
              })}
            </ul>
          )}
        </section>

        <aside className="min-w-0 space-y-5">
          <section>
            <h2 className="font-display text-2xl font-semibold">Grants pipeline</h2>
            <ul className="mt-3 divide-y divide-line border-y border-line text-sm">
              {PIPE_TABS.map(([k, t]) => (
                <li key={k}>
                  <button className="flex w-full items-center justify-between py-3 text-left hover:text-accent" onClick={() => { setPipeTab(k); setView('pipeline') }}>
                    <span className="font-semibold">{t}</span>
                    <span className="font-display text-xl font-semibold tabular-nums">{pipeRows[k].length}</span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
          <section>
            <h2 className="font-display text-2xl font-semibold">Search for your focus areas</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {(focusTags.length ? focusTags : ['education', 'health', 'climate', 'youth']).slice(0, 8).map((t) => (
                <button key={t} onClick={() => goSearch(t)} className="min-h-10 rounded-full border border-accent/50 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10">{t}</button>
              ))}
            </div>
            {focusTags.length === 0 && <p className="mt-2 text-xs text-muted">Add focus areas to your profile to personalize these.</p>}
          </section>
        </aside>
      </div>
    </div>
  )
}
