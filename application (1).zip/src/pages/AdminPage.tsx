import { useEffect, useState } from 'react'
import { type HomeState } from './use-home'
import { field, ghost } from '../components/ui'
import { COMPANY_ID, PLAN_LIMITS } from '../plans'
import { getAdminStats, type AdminStats } from '../server/admin'

type Load = { state: 'loading' } | { state: 'ok'; stats: AdminStats } | { state: 'error'; reason: string }

// Owner dashboard: who uses the AI tools, on which plan, and roughly what it costs. Only the site owner can open it.
export function AdminPage({ h }: { h: HomeState }) {
  const { PageHead, billing } = h
  const [load, setLoad] = useState<Load>({ state: 'loading' })
  const [rate, setRate] = useState('0.003')
  const run = () => {
    setLoad({ state: 'loading' })
    getAdminStats().then((r) => setLoad(r.ok ? { state: 'ok', stats: r.stats } : { state: 'error', reason: r.reason === 'forbidden' ? 'Only the site owner can open this page.' : r.reason === 'signed_out' ? 'Sign in as the site owner to open this page.' : 'The usage data could not be read right now.' })).catch(() => setLoad({ state: 'error', reason: 'Something went wrong. Try again.' }))
  }
  useEffect(() => { try { const v = localStorage.getItem('ngw_ai_rate'); if (v) setRate(v) } catch {} ; run() }, [])
  const setRateSaved = (v: string) => { setRate(v); try { localStorage.setItem('ngw_ai_rate', v) } catch {} }

  if (billing && billing.plan !== 'owner') return <><PageHead title="Owner dashboard" sub="This page is for the site owner." /><p className="text-muted">Only the site owner can open this page.</p></>
  const perCredit = Number(rate.replace(',', '.')) || 0
  const usd = (n: number) => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return (
    <>
      <PageHead title="Owner dashboard" sub="How people use the AI tools, which plan they are on, and about what it costs you." >
        <button type="button" className={ghost} onClick={run} disabled={load.state === 'loading'}>{load.state === 'loading' ? 'Loading...' : 'Refresh'}</button>
      </PageHead>
      {load.state === 'error' && <p role="alert" className="rounded-card border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-950">{load.reason}</p>}
      {load.state === 'loading' && <p className="text-muted">Loading the numbers...</p>}
      {load.state === 'ok' && (() => {
        const s = load.stats
        const cards: [string, string, string][] = [
          ['AI credits used', s.creditsThisMonth.toLocaleString('en-US'), `this month (${s.month})`],
          ['People using AI', String(s.activeUsers), 'this month'],
          ['Near their limit', String(s.nearLimit), '80% or more of their credits'],
          ['Saved projects', String(s.projects.apps), `from ${s.projects.users} signed-in ${s.projects.users === 1 ? 'person' : 'people'}`],
        ]
        return (
          <>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {cards.map(([t, v, sub]) => (
                <div key={t} className="rounded-card border border-line bg-card p-4"><p className="text-xs font-semibold tracking-wide text-muted uppercase">{t}</p><p className="mt-1 font-display text-3xl font-semibold tabular-nums">{v}</p><p className="text-xs text-muted">{sub}</p></div>
              ))}
            </div>
            <section className="mt-5 rounded-card border border-line bg-card p-5">
              <h2 className="font-display text-lg font-semibold">Estimated AI cost</h2>
              <p className="mt-1 text-sm text-muted">The portal counts credits, not money. Enter what one credit costs you on your AI plan, and the estimate follows. Free AI keys cost nothing until their limits run out.</p>
              <div className="mt-3 flex flex-wrap items-end gap-4">
                <label className="text-xs font-semibold">Cost of one credit (USD)<input className={`${field} mt-1 w-32 py-2`} inputMode="decimal" value={rate} onChange={(e) => setRateSaved(e.target.value)} /></label>
                <p className="text-sm"><span className="font-display text-2xl font-semibold">{usd(s.creditsThisMonth * perCredit)}</span> <span className="text-muted">this month, estimate</span></p>
              </div>
            </section>
            <section className="mt-5 overflow-x-auto rounded-card border border-line">
              <table className="w-full min-w-[34rem] border-collapse text-sm">
                <caption className="border-b border-line bg-card px-4 py-3 text-left font-display text-lg font-semibold">People using AI this month</caption>
                <thead><tr className="bg-ink text-left text-xs tracking-wide text-paper uppercase"><th scope="col" className="px-4 py-2.5">Person</th><th scope="col" className="px-4 py-2.5">Plan</th><th scope="col" className="px-4 py-2.5">Credits used</th></tr></thead>
                <tbody className="divide-y divide-line bg-white">
                  {s.users.length === 0 && <tr><td colSpan={3} className="px-4 py-5 text-center text-muted">Nobody has used the AI tools this month yet.</td></tr>}
                  {s.users.map((u) => {
                    const pct = u.plan === 'owner' ? 0 : Math.min(100, Math.round((u.used / u.limit) * 100))
                    return (
                      <tr key={u.id}>
                        <td className="px-4 py-2.5"><span className="font-semibold">{u.name}</span>{u.name !== u.id && <span className="block text-xs text-muted">{u.id}</span>}</td>
                        <td className="px-4 py-2.5">{PLAN_LIMITS[u.plan].name}</td>
                        <td className="px-4 py-2.5">
                          <span className="tabular-nums">{u.used}{u.plan === 'owner' ? '' : ` of ${u.limit}`}</span>
                          {u.plan !== 'owner' && <span className="mt-1 block h-1.5 w-40 overflow-hidden rounded-full bg-ink/10"><span className={`block h-full rounded-full ${pct >= 80 ? 'bg-red-600' : 'bg-accent'}`} style={{ width: pct + '%' }} /></span>}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </section>
            <section className="mt-5 overflow-x-auto rounded-card border border-line">
              <table className="w-full min-w-[26rem] border-collapse text-sm">
                <caption className="border-b border-line bg-card px-4 py-3 text-left font-display text-lg font-semibold">Month by month</caption>
                <thead><tr className="bg-ink text-left text-xs tracking-wide text-paper uppercase"><th scope="col" className="px-4 py-2.5">Month</th><th scope="col" className="px-4 py-2.5">People</th><th scope="col" className="px-4 py-2.5">Credits</th><th scope="col" className="px-4 py-2.5">Estimated cost</th></tr></thead>
                <tbody className="divide-y divide-line bg-white">
                  {s.monthly.map((m) => <tr key={m.month}><td className="px-4 py-2.5 font-semibold">{m.month}</td><td className="px-4 py-2.5 tabular-nums">{m.users}</td><td className="px-4 py-2.5 tabular-nums">{m.credits.toLocaleString('en-US')}</td><td className="px-4 py-2.5 tabular-nums">{usd(m.credits * perCredit)}</td></tr>)}
                  {s.monthly.length === 0 && <tr><td colSpan={4} className="px-4 py-5 text-center text-muted">No usage recorded yet.</td></tr>}
                </tbody>
              </table>
            </section>
            <section className="mt-5 rounded-card border border-line bg-card p-5 text-sm">
              <h2 className="font-display text-lg font-semibold">Subscribers and revenue</h2>
              <p className="mt-1 text-muted">Paying subscribers, payments and payouts are kept by Whop, and the portal cannot read them. Open your Whop dashboard to see them. Credits are counted per person per month, in UTC, and reset on the 1st.</p>
              <p className="mt-3"><a className="font-semibold text-accent underline" href={`https://whop.com/dashboard/${COMPANY_ID}/`} target="_blank" rel="noreferrer">Open the Whop dashboard</a></p>
            </section>
          </>
        )
      })()}
    </>
  )
}
