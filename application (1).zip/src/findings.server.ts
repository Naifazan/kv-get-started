import { sql } from './db.server'
import { heuristic, profileSearch } from './server/grants'
import type { Grant, Profile } from './server/grants'

export type Finding = { g: Grant; score: number; firstSeen: number }
export type FindingsData = { updatedAt: number; viewedAt: number; items: Finding[] }

const STALE_MS = 6 * 3600 * 1000
export const FINDINGS_ID = '__findings__'

function isClosed(g: Grant) {
  if (/closed|archived/i.test(g.status)) return true
  const m = g.deadline.match(/^(\d{4})-(\d{2})-(\d{2})/)
  if (m) return new Date(`${m[1]}-${m[2]}-${m[3]}`).getTime() < Date.now() - 864e5
  return false
}

export async function readFindings(userId: string): Promise<FindingsData | null> {
  const rows = await sql()`select data from saved_applications where user_id = ${userId} and app_id = ${FINDINGS_ID} limit 1`
  if (!rows.length) return null
  const d = rows[0].data as Partial<FindingsData>
  return { updatedAt: Number(d.updatedAt) || 0, viewedAt: Number(d.viewedAt) || 0, items: Array.isArray(d.items) ? (d.items as Finding[]) : [] }
}

export const isStale = (d: FindingsData | null) => !d || Date.now() - d.updatedAt > STALE_MS

/** Searches the grant sources for this profile, scores each result and stores the best matches. */
export async function refreshFindings(userId: string, profile: Profile): Promise<FindingsData> {
  if (!(profile.focus ?? '').trim() && !(profile.mission ?? '').trim()) throw new Error('Add sectors or a mission to your profile first.')
  const prev = await readFindings(userId)
  const first = new Map((prev?.items ?? []).map((f) => [f.g.id, f.firstSeen]))
  const r = await profileSearch('', profile, true)
  const now = Date.now()
  const items: Finding[] = r.grants
    .filter((g) => !isClosed(g))
    .map((g) => ({ g: { ...g, details: undefined }, score: heuristic(profile, g).score, firstSeen: first.get(g.id) ?? now }))
    .filter((f) => f.score >= 30)
    .sort((a, b) => b.score - a.score)
    .slice(0, 25)
  const data: FindingsData = { updatedAt: now, viewedAt: prev ? prev.viewedAt : now, items }
  await sql()`insert into saved_applications (user_id, app_id, title, data, updated_at)
    values (${userId}, ${FINDINGS_ID}, 'Matched grants', ${JSON.stringify(data)}::jsonb, now())
    on conflict (user_id, app_id) do update set data = excluded.data, updated_at = now()`
  return data
}

export async function markViewed(userId: string) {
  await sql()`update saved_applications set data = jsonb_set(data, '{viewedAt}', to_jsonb(${Date.now()}::bigint)) where user_id = ${userId} and app_id = ${FINDINGS_ID}`
}

/** Postpones the next attempt for a user whose refresh failed, so one bad profile cannot block the queue. */
export async function deferFindings(userId: string) {
  const empty: FindingsData = { updatedAt: Date.now(), viewedAt: Date.now(), items: [] }
  await sql()`insert into saved_applications (user_id, app_id, title, data, updated_at)
    values (${userId}, ${FINDINGS_ID}, 'Matched grants', ${JSON.stringify(empty)}::jsonb, now())
    on conflict (user_id, app_id) do update set updated_at = now(), data = jsonb_set(saved_applications.data, '{updatedAt}', to_jsonb(${Date.now()}::bigint))`
}
