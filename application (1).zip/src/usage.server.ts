import { getRequest } from '@tanstack/react-start/server'
import { sql } from './db.server'
import { currentUser } from './lib/session'
import { COMPANY_ID, PLAN_LIMITS, PRODUCT_IDS, type PlanKey } from './plans'

let ready = false
export async function ensureTable() {
  if (ready) return
  await sql()`create table if not exists ai_usage (user_id text not null, month text not null, n integer not null default 0, primary key (user_id, month))`
  ready = true
}

const monthKey = () => new Date().toISOString().slice(0, 7)
export const nextReset = () => { const d = new Date(); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1) }

async function hasAccess(userId: string, resource: string): Promise<{ has_access: boolean; access_level: string }> {
  try {
    const r = await fetch(`${process.env.WHOP_API_ORIGIN}/api/v1/users/${userId}/access/${resource}`)
    if (!r.ok) return { has_access: false, access_level: 'no_access' }
    return (await r.json()) as any
  } catch {
    return { has_access: false, access_level: 'no_access' }
  }
}

// The plan is looked up in Whop and remembered for two minutes per person, so every AI call does not repeat the check.
const planCache = new Map<string, { plan: PlanKey; at: number }>()
export async function planOf(userId: string, fresh = false): Promise<PlanKey> {
  const hit = planCache.get(userId)
  if (!fresh && hit && Date.now() - hit.at < 120_000) return hit.plan
  const [biz, pro, starter] = await Promise.all([hasAccess(userId, COMPANY_ID), hasAccess(userId, PRODUCT_IDS.pro), hasAccess(userId, PRODUCT_IDS.starter)])
  const plan: PlanKey = biz.access_level === 'admin' ? 'owner' : pro.has_access ? 'pro' : starter.has_access ? 'starter' : 'free'
  planCache.set(userId, { plan, at: Date.now() })
  if (planCache.size > 2000) planCache.clear()
  return plan
}

export async function usedThisMonth(userId: string): Promise<number> {
  await ensureTable()
  const rows = await sql()`select n from ai_usage where user_id = ${userId} and month = ${monthKey()}`
  return rows.length ? Number((rows[0] as any).n) : 0
}

// Takes one AI credit. Throws a clear message when the person is signed out or out of credits.
// The scheduled refresh runs on the server's own schedule and is not counted.
export async function chargeAi(): Promise<void> {
  let path = ''
  try { path = new URL(getRequest().url).pathname } catch {}
  if (path.startsWith('/api/cron/')) return
  const u = await currentUser()
  if (!u) throw new Error('Sign in to use the AI tools. The Free plan includes 30 AI credits a month.')
  const plan = await planOf(u.sub)
  if (plan === 'owner') return
  const limit = PLAN_LIMITS[plan].credits
  await ensureTable()
  const rows = await sql()`insert into ai_usage (user_id, month, n) values (${u.sub}, ${monthKey()}, 1)
    on conflict (user_id, month) do update set n = ai_usage.n + 1 where ai_usage.n < ${limit} returning n`
  if (!rows.length) throw new Error(`You have used all ${limit} AI credits on the ${PLAN_LIMITS[plan].name} plan this month. Open Plans to upgrade, or wait until the 1st of next month.`)
}

export async function projectLimitReached(userId: string, appId: string): Promise<{ limited: boolean; max: number }> {
  const plan = await planOf(userId)
  const max = PLAN_LIMITS[plan].projects
  const rows = await sql()`select app_id from saved_applications where user_id = ${userId} and left(app_id, 2) <> '__'`
  const ids = rows.map((r: any) => String(r.app_id))
  return { limited: !ids.includes(appId) && ids.length >= max, max }
}
