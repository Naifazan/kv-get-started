import { getRequest, getRequestHeader } from '@tanstack/react-start/server'

// A simple per-visitor limit on AI calls, so one visitor cannot use up the site's AI allowance.
// It is kept in memory per server instance, so it is a safety net and not an exact count.
const hits = new Map<string, number[]>()
const WINDOW = 10 * 60 * 1000
const MAX = 120

export function aiRateLimit(): string | null {
  try {
    const req = getRequest()
    // The scheduled refresh runs on the server's own schedule and is not limited here.
    if (new URL(req.url).pathname.startsWith('/api/cron/')) return null
    const ip = getRequestHeader('cf-connecting-ip') || (getRequestHeader('x-forwarded-for') ?? '').split(',')[0].trim() || 'unknown'
    const now = Date.now()
    const list = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW)
    if (list.length >= MAX) { hits.set(ip, list); return 'The AI service has reached its usage limit for your connection. Wait a few minutes and try again.' }
    list.push(now)
    hits.set(ip, list)
    if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < WINDOW)) hits.delete(k)
    return null
  } catch {
    return null
  }
}
