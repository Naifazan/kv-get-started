import { MEAL_TOOLS, REPORT_TEMPLATES, type DocKind } from '../lib/project-docs'
import { createServerFn } from '@tanstack/react-start'
import { matchTitle } from '../lib/match-title'
import { ALL_SOURCES, type Src } from '../lib/sources'

export type Grant = {
  id: string
  title: string
  funder: string
  source: string
  deadline: string
  status: string
  url: string
  summary?: string
  details?: string
  countries?: string[]
  gtype?: string
  sectors?: string[]
  amountMin?: number
  amountMax?: number
  inviteOnly?: boolean
  checkedAt?: number
  prevDeadline?: string
}

export const SECTOR_LIST = ['Education', 'Health', 'Water & sanitation', 'Climate & environment', 'Women & girls', 'Youth', 'Human rights', 'Food security & agriculture', 'Livelihoods & economic development', 'Refugees & migration', 'Disability', 'Arts & culture', 'Technology & research', 'Humanitarian & disaster relief', 'Energy', 'Community development']

const SECTOR_KEYS: [string, RegExp][] = [
  ['Education', /educat|school|learn|literacy|teacher|student|university|scholar|training/i],
  ['Health', /health|medic|disease|hiv|malaria|nutrition|mental|hospital|vaccin|clinic/i],
  ['Water & sanitation', /water|sanitation|hygiene|wash\b/i],
  ['Climate & environment', /climate|environment|biodivers|conservation|forest|ocean|marine|emission|carbon|pollution|wildlife|ecosystem/i],
  ['Women & girls', /\bwomen|\bgirl|gender|female/i],
  ['Youth', /\byouth|young people|adolescen|children|child\b/i],
  ['Human rights', /human rights|democra|justice|civil society|civic|rule of law|freedom|peace/i],
  ['Food security & agriculture', /food|agricultur|farm|crop|livestock|fisher|nutrition/i],
  ['Livelihoods & economic development', /livelihood|employment|jobs|entrepreneur|small business|economic|microfinance|workforce|income/i],
  ['Refugees & migration', /refugee|migra|displac|asylum/i],
  ['Disability', /disabilit|accessib/i],
  ['Arts & culture', /\barts?\b|cultur|heritage|museum|music|creative/i],
  ['Technology & research', /technolog|digital|\bai\b|artificial intelligence|research|innovation|science|stem|cyber/i],
  ['Humanitarian & disaster relief', /humanitarian|disaster|emergency|relief|resilien|crisis/i],
  ['Energy', /energy|solar|renewable|electrif/i],
  ['Community development', /communit|rural|urban|housing|development/i],
]
export function inferSectors(text: string): string[] {
  return SECTOR_KEYS.filter(([, re]) => re.test(text)).map(([n]) => n).slice(0, 4)
}
const US_CAT_SECTOR: Record<string, string> = { ED: 'Education', HL: 'Health', ENV: 'Climate & environment', AG: 'Food security & agriculture', CD: 'Community development', ELT: 'Livelihoods & economic development', DPR: 'Humanitarian & disaster relief', EN: 'Energy', NR: 'Climate & environment', ST: 'Technology & research', BC: 'Livelihoods & economic development' }
const US_INSTR: Record<string, string> = { G: 'Grant', CA: 'Cooperative agreement', PC: 'Procurement contract', O: 'Other funding' }

export type Profile = {
  // A short description of the funding the organization is looking for. Written or improved with AI and used by the profile-based search.
  fundingNeed?: string
  org: string
  country: string
  mission: string
  focus: string
  size: string
  orgType?: string
  founded?: string
  registered?: string
  budget?: string
  regions?: string
  beneficiaries?: string
  pastFunding?: string
  website?: string
  regCountry?: string
  taxStatus?: string
  opCountries?: string
  scope?: string
  populations?: string
  sdgs?: string
  languages?: string
  amountMin?: string
  amountMax?: string
  grantTypes?: string
  purposes?: string
  duration?: string
  partner?: string
  compliance?: string
  largestGrant?: string
}

export type { Src } from '../lib/sources'
export type UsFilters = { eligibilities?: string[]; categories?: string[]; instruments?: string[]; postedWithin?: number }
type SearchInput = { keyword: string; sources: Src[]; us?: UsFilters; euStatus?: 'open' | 'forthcoming' | 'both' }

const DIRECTORY: Grant[] = [
  { id: 'dir-gates', inviteOnly: true, countries: ['Global'], gtype: 'Funder program', sectors: ['Health','Education','Women & girls','Food security & agriculture'], title: 'Gates Foundation grant opportunities', funder: 'Gates Foundation', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://www.gatesfoundation.org/about/how-we-work/grant-opportunities', summary: 'Global health, development, education and gender equality. Many programs are by invitation or open calls.' },
  { id: 'dir-osf', inviteOnly: true, countries: ['Global'], gtype: 'Funder program', sectors: ['Human rights','Technology & research','Health'], title: 'Open Society Foundations grants', funder: 'Open Society Foundations', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://www.opensocietyfoundations.org/grants', summary: 'Human rights, justice, democracy, independent media and public health worldwide.' },
  { id: 'dir-ford', inviteOnly: true, countries: ['Global'], gtype: 'Funder program', sectors: ['Human rights','Women & girls','Technology & research'], title: 'Ford Foundation grants', funder: 'Ford Foundation', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://www.fordfoundation.org/work/our-grants/', summary: 'Inequality, civic engagement, gender and racial justice, technology and society.' },
  { id: 'dir-wellcome', countries: ['Global'], gtype: 'Funder program', sectors: ['Health','Climate & environment','Technology & research'], title: 'Wellcome funding schemes', funder: 'Wellcome', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://wellcome.org/grant-funding', summary: 'Health research, climate and health, and mental health.' },
  { id: 'dir-globalgiving', countries: ['Global'], gtype: 'Crowdfunding', sectors: ['Education','Health','Community development','Humanitarian & disaster relief'], title: 'GlobalGiving project fundraising', funder: 'GlobalGiving', source: 'Crowdfunding platform', deadline: 'Rolling', status: 'ongoing', url: 'https://www.globalgiving.org/nonprofits/', summary: 'Vetted nonprofits worldwide can raise funds from individual and corporate donors.' },
  { id: 'dir-mozilla', countries: ['Global'], gtype: 'Funder program', sectors: ['Technology & research','Human rights'], title: 'Mozilla Foundation funding', funder: 'Mozilla Foundation', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://foundation.mozilla.org/en/what-we-fund/', summary: 'Trustworthy AI, internet health and digital rights.' },
  { id: 'dir-undp', countries: ['Global'], gtype: 'Small grants program', sectors: ['Climate & environment','Community development'], title: 'UNDP Global Environment Facility Small Grants Programme', funder: 'UNDP / GEF', source: 'UN program', deadline: 'Varies by country', status: 'ongoing', url: 'https://sgp.undp.org/', summary: 'Small grants to community and civil society groups for biodiversity, climate and land protection in 125+ countries.' },
  { id: 'dir-oak', countries: ['Global'], gtype: 'Funder program', sectors: ['Human rights','Climate & environment','Youth'], title: 'Oak Foundation programmes', funder: 'Oak Foundation', source: 'Global funder', deadline: 'Varies', status: 'ongoing', url: 'https://oakfnd.org/', summary: 'Child abuse prevention, environment, housing and homelessness, international human rights.' },
  { id: 'dir-fundsforngos', countries: ['Global'], gtype: 'Listings', sectors: [], title: 'fundsforNGOs opportunity listings', funder: 'fundsforNGOs', source: 'Listings', deadline: 'Varies', status: 'ongoing', url: 'https://www2.fundsforngos.org/', summary: 'Regularly updated calls for NGOs, many open to organizations in developing countries.' },
  { id: 'dir-candid', countries: ['Global'], gtype: 'Funder database', sectors: [], title: 'Candid Foundation Directory', funder: 'Candid', source: 'Funder database', deadline: 'Rolling', status: 'ongoing', url: 'https://candid.org/find-funding', summary: 'Searchable database of foundations and grants. Free access at Candid Funding Information Network locations.' },
]

async function searchUS(keyword: string, f: UsFilters = {}): Promise<Grant[]> {
  const body: Record<string, unknown> = { keyword, oppStatuses: 'forecasted|posted', rows: 25 }
  if (f.eligibilities?.length) body.eligibilities = f.eligibilities.join('|')
  if (f.categories?.length) body.fundingCategories = f.categories.join('|')
  if (f.instruments?.length) body.fundingInstruments = f.instruments.join('|')
  if (f.postedWithin) body.dateRange = String(f.postedWithin)
  const r = await fetch('https://api.grants.gov/v1/api/search2', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-whop-inject-key': 'none' },
    body: JSON.stringify(body),
  })
  if (!r.ok) throw new Error('Grants.gov ' + r.status)
  const j: any = await r.json()
  const farYear = new Date().getFullYear() + 5
  return (j.data?.oppHits ?? []).map((h: any): Grant => ({
    id: 'us-' + h.id,
    title: decodeEntities(String(h.title ?? '')).trim(),
    funder: decodeEntities(String(h.agency || h.agencyCode || '')).trim() || 'US federal agency',
    source: 'Grants.gov (US federal)',
    // A close date more than five years away is a data entry error on the listing, so it is not shown as a real deadline.
    deadline: h.closeDate && !(Number(String(h.closeDate).slice(-4)) > farYear) ? h.closeDate : 'No close date listed',
    status: h.oppStatus,
    url: `https://www.grants.gov/search-results-detail/${h.id}`,
    countries: ['United States'],
    gtype: 'Grant or cooperative agreement',
    sectors: inferSectors(String(h.title ?? '')),
  }))
}

// Turns HTML entities such as &rsquo; and &#8211; into the characters they stand for.
const NAMED: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '–', mdash: '—', rsquo: '’', lsquo: '‘', rdquo: '”', ldquo: '“', hellip: '…', eacute: 'é', egrave: 'è', agrave: 'à', ccedil: 'ç', ntilde: 'ñ', uuml: 'ü', ouml: 'ö', auml: 'ä', copy: '©', reg: '®', trade: '™', bull: '•', middot: '·', euro: '€', pound: '£' }
export const decodeEntities = (t: string) =>
  String(t ?? '')
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&([a-z]+);/gi, (m, n) => NAMED[n.toLowerCase()] ?? m)

const stripHtml = (h: string) => decodeEntities(h.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim()

export async function enrichUS(grants: Grant[], limit = 12): Promise<Grant[]> {
  const todo = grants.filter((g) => g.id.startsWith('us-') && g.amountMax === undefined && !g.details).slice(0, limit)
  const byId = new Map<string, Partial<Grant>>()
  for (let i = 0; i < todo.length; i += 6) {
    await Promise.all(
      todo.slice(i, i + 6).map(async (g) => {
        try {
          const r = await fetch('https://api.grants.gov/v1/api/fetchOpportunity', {
            method: 'POST',
            headers: { 'content-type': 'application/json', 'x-whop-inject-key': 'none' },
            body: JSON.stringify({ opportunityId: Number(g.id.slice(3)) }),
          })
          if (!r.ok) return
          const syn: any = ((await r.json()) as any)?.data?.synopsis
          if (!syn) return
          const cats: string[] = (syn.fundingActivityCategories ?? []).map((c: any) => US_CAT_SECTOR[c.id]).filter(Boolean)
          const instr: string[] = (syn.fundingInstruments ?? []).map((c: any) => US_INSTR[c.id]).filter(Boolean)
          const desc = stripHtml(String(syn.synopsisDesc ?? '')).slice(0, 420)
          const who = (syn.applicantTypes ?? []).map((a: any) => a.description).filter(Boolean).join('; ').slice(0, 260)
          const ceil = Number(syn.awardCeiling) || 0
          const floor = Number(syn.awardFloor) || 0
          byId.set(g.id, {
            amountMax: ceil || undefined,
            amountMin: floor || undefined,
            gtype: instr.length ? [...new Set(instr)].join(' / ') : undefined,
            sectors: [...new Set([...cats, ...inferSectors(g.title + ' ' + desc)])].slice(0, 4),
            summary: [desc, who && 'Eligible applicants: ' + who].filter(Boolean).join(' '),
            details: ceil || floor ? undefined : undefined,
          })
        } catch {}
      }),
    )
  }
  return grants.map((g) => {
    const e = byId.get(g.id)
    return e ? { ...g, ...Object.fromEntries(Object.entries(e).filter(([, v]) => v !== undefined)), amountMax: e.amountMax ?? 0 } : g
  })
}

async function searchEU(keyword: string, status: 'open' | 'forthcoming' | 'both' = 'both'): Promise<Grant[]> {
  const codes = status === 'open' ? ['31094501'] : status === 'forthcoming' ? ['31094503'] : ['31094501', '31094503']
  const fd = new FormData()
  fd.append(
    'query',
    new Blob([JSON.stringify({ bool: { must: [{ terms: { type: ['1', '2', '8'] } }, { terms: { status: codes } }] } })], { type: 'application/json' }),
  )
  fd.append('languages', new Blob([JSON.stringify(['en'])], { type: 'application/json' }))
  const r = await fetch(
    `https://api.tech.ec.europa.eu/search-api/prod/rest/search?apiKey=SEDIA&text=${encodeURIComponent(keyword)}&pageSize=40&pageNumber=1`,
    { method: 'POST', body: fd, headers: { 'x-whop-inject-key': 'none' } },
  )
  if (!r.ok) throw new Error('EU portal ' + r.status)
  const j: any = await r.json()
  const today = new Date().toISOString().slice(0, 10)
  const seen = new Set<string>()
  const rows: any[] = []
  for (const x of j.results ?? []) {
    const m = x.metadata ?? {}
    const id = m.identifier?.[0] ?? x.reference
    if (!id || seen.has(id)) continue
    // Several deadlines: use the next one that has not passed. A call whose deadlines have all passed is closed and is not listed.
    const dates: string[] = (m.deadlineDate ?? []).map((d: string) => new Date(d).toISOString().slice(0, 10)).sort()
    if (dates.length && !dates.some((d) => d >= today)) continue
    seen.add(id)
    rows.push({ x, m, id, dl: dates.find((d) => d >= today) })
  }
  return rows.slice(0, 20).map(({ x, m, id, dl }): Grant => {
    return {
      id: 'eu-' + id,
      title: decodeEntities(String(m.title?.[0] ?? x.summary ?? '')).trim(),
      funder: 'European Commission',
      source: 'EU Funding & Tenders',
      deadline: dl ?? 'See call page',
      status: m.status?.[0] === '31094503' ? 'forthcoming' : 'open',
      countries: ['European Union & associated countries'],
      gtype: 'Grant (EU call)',
      sectors: inferSectors(String(m.title?.[0] ?? x.summary ?? '')),
      url: `https://ec.europa.eu/info/funding-tenders/opportunities/portal/screen/opportunities/topic-details/${id}`,
    }
  })
}

const NGO = ['Women & girls', 'Education', 'Health', 'Humanitarian & disaster relief', 'Community development', 'Human rights', 'Youth', 'Climate & environment', 'Food security & agriculture', 'Technology & research']
const fund = (id: string, title: string, funder: string, source: string, url: string, summary: string, sectors: string[], countries: string[], gtype = 'Funder program', extra: Partial<Grant> = {}): Grant => ({
  id, title, funder, source, url, summary, sectors: sectors.filter((x) => NGO.includes(x)), countries, gtype, deadline: 'Varies', status: 'ongoing', ...extra,
})

// Funders that work in the Middle East and the Arab region. Open calls change, so every entry points to the funder's own page.
const MENA: Grant[] = [
  fund('mena-qfffd', 'Qatar Fund for Development partnerships', 'Qatar Fund for Development', 'Arab donor', 'https://qatarfund.org.qa/', 'Qatar\'s development and humanitarian fund. It works with partner organizations on education, health, relief and livelihoods, including in Yemen and the wider Arab region. Check the site for how partners are selected.', ['Education', 'Health', 'Humanitarian & disaster relief', 'Community development'], ['Middle East & North Africa', 'Global']),
  fund('mena-ksrelief', 'KSrelief humanitarian projects', 'King Salman Humanitarian Aid and Relief Centre (KSrelief)', 'Arab donor', 'https://www.ksrelief.org/', 'Saudi Arabia\'s humanitarian agency. It funds relief, health, education and food projects in Yemen and many other countries, often through registered partner organizations.', ['Humanitarian & disaster relief', 'Health', 'Food security & agriculture', 'Education'], ['Yemen', 'Middle East & North Africa', 'Global']),
  fund('mena-eaa', 'Education Above All programmes', 'Education Above All Foundation', 'Arab donor', 'https://educationaboveall.org/', 'Qatar-based foundation for education of children and youth in poverty and conflict, working with partner organizations.', ['Education', 'Youth'], ['Middle East & North Africa', 'Global']),
  fund('mena-dubaicares', 'Dubai Cares education programmes', 'Dubai Cares', 'Arab donor', 'https://www.dubaicares.ae/', 'Funds education programmes for children and youth in developing countries through partner organizations.', ['Education', 'Youth'], ['Middle East & North Africa', 'Global']),
  fund('mena-zayed', 'Zayed Sustainability Prize', 'Zayed Sustainability Prize', 'Prize', 'https://www.zayedsustainabilityprize.com/', 'A prize for organizations with impact in health, food, energy, water and climate action, including a category for small and medium enterprises and non-profits.', ['Health', 'Food security & agriculture', 'Climate & environment', 'Community development'], ['Global'], 'Prize'),
  fund('mena-alf', 'Anna Lindh Foundation calls for civil society', 'Anna Lindh Foundation', 'Euro-Mediterranean funder', 'https://www.annalindhfoundation.org/', 'Supports civil society organizations in the Euro-Mediterranean region with calls for intercultural, youth and citizenship projects.', ['Youth', 'Human rights', 'Community development', 'Education'], ['Middle East & North Africa', 'European Union & associated countries']),
  fund('mena-sfd', 'Social Fund for Development, Yemen', 'Social Fund for Development (Yemen)', 'Yemen institution', 'https://sfd-yemen.org/', 'Yemen\'s national development fund. It supports community projects, small enterprises and local organizations across the country with donor funding.', ['Community development', 'Education', 'Health', 'Food security & agriculture'], ['Yemen']),
]

// United Nations and multilateral funds that give grants to civil society organizations.
const UN: Grant[] = [
  fund('un-cbpf', 'OCHA country-based pooled funds', 'UN OCHA', 'UN fund', 'https://cbpf.unocha.org/', 'Humanitarian pooled funds in crisis countries, including Yemen, that allocate money to local and international NGOs and UN agencies through allocation rounds. Check the fund page for your country.', ['Humanitarian & disaster relief', 'Health', 'Food security & agriculture'], ['Yemen', 'Global']),
  fund('un-untf', 'UN Trust Fund to End Violence against Women', 'UN Women', 'UN fund', 'https://untf.unwomen.org/', 'Grants to civil society organizations, especially women\'s organizations, working to prevent and respond to violence against women and girls.', ['Women & girls', 'Human rights'], ['Global']),
  fund('un-wphf', 'Women\'s Peace and Humanitarian Fund', 'WPHF', 'UN fund', 'https://wphfund.org/', 'Supports local women\'s organizations in conflict and crisis settings with peacebuilding and humanitarian grants.', ['Women & girls', 'Human rights', 'Humanitarian & disaster relief'], ['Global']),
  fund('un-undef', 'UN Democracy Fund', 'United Nations Democracy Fund', 'UN fund', 'https://www.un.org/democracyfund/', 'Funds civil society projects that strengthen democracy, human rights and civic participation.', ['Human rights', 'Community development'], ['Global']),
  fund('un-pbf', 'UN Peacebuilding Fund', 'UN Peacebuilding Fund', 'UN fund', 'https://www.un.org/peacebuilding/fund', 'Supports peacebuilding in countries at risk of or recovering from conflict. Civil society organizations take part as implementing partners.', ['Community development', 'Human rights', 'Youth'], ['Global']),
  fund('un-ecw', 'Education Cannot Wait', 'Education Cannot Wait', 'Multilateral fund', 'https://www.educationcannotwait.org/', 'Global fund for education in emergencies and protracted crises. Grants go through UN agencies, NGOs and civil society partners.', ['Education', 'Youth', 'Humanitarian & disaster relief'], ['Global']),
  fund('un-gpe-eol', 'Education Out Loud', 'Global Partnership for Education', 'Multilateral fund', 'https://educationoutloud.org/', 'GPE\'s fund for civil society advocacy and social accountability in education.', ['Education', 'Human rights'], ['Global']),
  fund('un-start', 'Start Fund', 'Start Network', 'Humanitarian fund', 'https://startnetwork.org/start-fund', 'Fast funding for NGOs responding to small and medium crises, released within days of an alert. Open to members and their local partners.', ['Humanitarian & disaster relief'], ['Global']),
  fund('un-gf', 'Global Greengrants Fund', 'Global Greengrants Fund', 'Global funder', 'https://www.greengrants.org/', 'Small grants to grassroots groups for environmental and climate justice, through local advisors.', ['Climate & environment', 'Community development'], ['Global']),
  fund('un-fghr', 'Fund for Global Human Rights', 'Fund for Global Human Rights', 'Global funder', 'https://globalhumanrights.org/', 'Supports grassroots human rights groups in many countries. Grantees are usually found through the fund\'s own outreach.', ['Human rights'], ['Global'], 'Funder program', { inviteOnly: true }),
  fund('un-gfw', 'Global Fund for Women grants', 'Global Fund for Women', 'Global funder', 'https://www.globalfundforwomen.org/', 'Flexible funding for women-led and gender-justice organizations worldwide.', ['Women & girls', 'Human rights'], ['Global']),
  fund('un-mamacash', 'Mama Cash grants', 'Mama Cash', 'Global funder', 'https://www.mamacash.org/', 'Funds feminist organizations led by women, girls, trans and intersex people.', ['Women & girls', 'Human rights'], ['Global']),
  fund('un-pcf', 'Prince Claus Fund', 'Prince Claus Fund', 'Global funder', 'https://princeclausfund.org/', 'Supports culture and the arts as a way to create more open and fair societies, with a focus on the Global South.', ['Community development', 'Youth'], ['Global']),
]

const decode = (t: string) => decodeEntities(t.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim()

const parseDeadline = (t: string): string | null => {
  const m = t.match(/Deadline:?\s*(\d{1,2}\s+[A-Za-z]+\s+\d{4}|[A-Za-z]+\s+\d{1,2},?\s+\d{4})/i)
  if (!m) return null
  const d = new Date(m[1] + ' UTC')
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10)
}

// Live listings from two public NGO funding sites, searched with the person's keyword.
async function searchWp(site: 'fundsforngos' | 'opportunitydesk', keyword: string): Promise<Grant[]> {
  const base = site === 'fundsforngos' ? 'https://www.fundsforngos.org' : 'https://opportunitydesk.org'
  const url = `${base}/wp-json/wp/v2/posts?per_page=20&_fields=id,date,link,title,excerpt${keyword ? '&search=' + encodeURIComponent(keyword) : ''}`
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 9000)
  try {
    const r = await fetch(url, { signal: ctrl.signal, headers: { 'x-whop-inject-key': 'none', 'user-agent': 'Mozilla/5.0 (compatible; GlobalNGOGrantsWriter/1.0)', accept: 'application/json' } })
    if (!r.ok) throw new Error(site + ' ' + r.status)
    const j: any[] = await r.json()
    const today = new Date().toISOString().slice(0, 10)
    const out: Grant[] = []
    for (const x of j) {
      const title = decode(String(x.title?.rendered ?? ''))
      const text = decode(String(x.excerpt?.rendered ?? ''))
      if (!title) continue
      if (site === 'opportunitydesk') {
        if (/currently open|opportunities?\s+(?:open|list)|^\d+\s/i.test(title)) continue
        if (/scholarship|fellow|internship|conference|summit|job|webinar|master|phd|undergraduate|leadership|fully[- ]funded|\(funded\)|exchange|training|course|visiting/i.test(title)) continue
        if (!/grant|funding|call for|proposal|rfp|seed|award|prize|challenge|competition|fund\b/i.test(title)) continue
      }
      const dl = parseDeadline(text)
      if (dl && dl < today) continue
      const summary = text.replace(/Deadline:?\s*[^.]{0,30}\d{4}/i, '').trim().slice(0, 420)
      const fm = summary.match(/^(?:The |An? )?([A-Z][\w&'’.,\- ]{2,70}?) (?:is|are|has|have|invites?|offers?|announces?|seeks?|calls?|launched|opens?)\b/)
      out.push({
        id: `${site === 'fundsforngos' ? 'ffn' : 'od'}-${x.id}`,
        title,
        funder: fm && !/^(applications?|proposals?|submissions?|nominations?|entries|registration|the call)$/i.test(fm[1].trim()) ? fm[1].trim() : 'See the listing',
        source: site === 'fundsforngos' ? 'fundsforNGOs listing' : 'Opportunity Desk listing',
        deadline: dl ?? 'See the call page',
        status: 'open',
        url: String(x.link ?? base),
        countries: ['Global'],
        gtype: 'Call listed by a third-party site',
        sectors: inferSectors(title + ' ' + summary),
        summary,
      })
    }
    return out
  } finally {
    clearTimeout(timer)
  }
}

// US private foundations, found in the IRS exempt organization records through ProPublica's free Nonprofit Explorer.
// The IRS search page itself (apps.irs.gov/app/eos) has no public interface that a program may use.
const NTEE_SECTOR: Record<string, string> = { A: 'Community development', B: 'Education', C: 'Climate & environment', D: 'Climate & environment', E: 'Health', F: 'Health', G: 'Health', H: 'Health', I: 'Human rights', J: 'Community development', K: 'Food security & agriculture', L: 'Community development', M: 'Humanitarian & disaster relief', N: 'Youth', O: 'Youth', P: 'Community development', Q: 'Community development', R: 'Human rights', S: 'Community development', U: 'Technology & research', V: 'Technology & research' }
const irsCache = new Map<string, { at: number; v: any }>()
const moneyShort = (n: number) => (n >= 1e9 ? `$${(n / 1e9).toFixed(1)} billion` : n >= 1e6 ? `$${(n / 1e6).toFixed(1)} million` : `$${Math.round(n / 1000).toLocaleString('en-US')},000`)

async function pp(path: string): Promise<any> {
  const hit = irsCache.get(path)
  if (hit && Date.now() - hit.at < 6 * 3600_000) return hit.v
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), 8000)
  try {
    const r = await fetch('https://projects.propublica.org/nonprofits/api/v2/' + path, { signal: ctrl.signal, headers: { 'x-whop-inject-key': 'none', accept: 'application/json', 'user-agent': 'Mozilla/5.0 (compatible; GlobalNGOGrantsWriter/1.0)' } })
    if (r.status === 404) return { organizations: [] }
    if (!r.ok) throw new Error('IRS records ' + r.status)
    const v = await r.json()
    irsCache.set(path, { at: Date.now(), v })
    if (irsCache.size > 500) irsCache.clear()
    return v
  } finally {
    clearTimeout(timer)
  }
}

async function searchIRS(keyword: string): Promise<Grant[]> {
  const kw = keyword.trim().slice(0, 60)
  if (!kw) return []
  const longest = kw.split(/\s+/).sort((a, b) => b.length - a.length)[0]
  const qs = [...new Set([`${kw} foundation`, `${kw} charitable`, ...(kw.includes(' ') ? [`${longest} foundation`] : [])])]
  const pages = await Promise.all(qs.map((q) => pp(`search.json?q=${encodeURIComponent(q)}&c_code%5Bid%5D=3&ntee%5Bid%5D=7`).catch(() => null)))
  if (pages.every((x) => !x)) throw new Error('IRS records unavailable')
  const seen = new Set<number>()
  // NTEE codes T20 to T29 are private grantmaking and operating foundations, the ones that give money to other organizations.
  const orgs = pages.flatMap((x) => x?.organizations ?? []).filter((o: any) => /^T2/.test(String(o.ntee_code ?? '')) && !seen.has(o.ein) && (seen.add(o.ein), true)).slice(0, 12)
  const details = await Promise.all(orgs.map((o: any) => pp(`organizations/${o.ein}.json`).then((d) => d?.organization).catch(() => null)))
  return orgs.map((o: any, i: number): Grant => {
    const d = details[i] ?? {}
    const ein = String(o.strein ?? o.ein)
    const name = decodeEntities(String(o.name ?? '')).replace(/\s+/g, ' ').trim()
    const assets = Number(d.asset_amount) || 0
    const income = Number(d.income_amount) || 0
    const place = [o.city, o.state].filter(Boolean).join(', ')
    const sec = NTEE_SECTOR[String(o.ntee_code ?? '')[0]]
    return {
      id: 'irs-' + o.ein,
      title: name + ' (private foundation)',
      funder: name,
      source: 'IRS records (US private foundation)',
      deadline: 'Check the foundation',
      status: 'ongoing',
      url: `https://projects.propublica.org/nonprofits/organizations/${o.ein}`,
      countries: ['United States'],
      gtype: 'Private foundation',
      sectors: [...new Set([sec, ...inferSectors(name)].filter(Boolean) as string[])].slice(0, 3),
      summary: `US private foundation${place ? ' in ' + place : ''}, EIN ${ein}.${assets ? ` Assets about ${moneyShort(assets)}.` : ''}${income ? ` Yearly income about ${moneyShort(income)}.` : ''} The IRS record does not say what it funds or whether it takes applications. Many private foundations give only to organizations they already know, and some give only inside the United States. Read its Form 990-PF on the linked page and its own website before you apply. IRS record: search EIN ${ein} at apps.irs.gov/app/eos.`,
    }
  })
}

async function runSearchCore(kw: string, sources: Src[], us?: UsFilters, euStatus?: 'open' | 'forthcoming' | 'both', enrich = true) {
  const errors: string[] = []
  const out: Grant[] = []
  const words = kw.toLowerCase().split(/\s+/).filter(Boolean)
  const jobs: Promise<void>[] = []
  if (sources.includes('us')) jobs.push(searchUS(kw, us).then((g) => void out.push(...g)).catch(() => void errors.push('US federal grants are unavailable right now.')))
  if (sources.includes('eu') && kw) jobs.push(searchEU(kw, euStatus).then((g) => void out.push(...g)).catch(() => void errors.push('EU grants are unavailable right now.')))
  if (sources.includes('fundsforngos')) jobs.push(searchWp('fundsforngos', kw).then((g) => void out.push(...g)).catch(() => void errors.push('The fundsforNGOs listings are unavailable right now.')))
  if (sources.includes('opportunitydesk')) jobs.push(searchWp('opportunitydesk', kw).then((g) => void out.push(...g)).catch(() => void errors.push('The Opportunity Desk listings are unavailable right now.')))
  if (sources.includes('irs')) jobs.push(searchIRS(kw).then((g) => void out.push(...g)).catch(() => void errors.push('The IRS foundation records are unavailable right now.')))
  await Promise.all(jobs)
  if (enrich) {
    const e = await enrichUS(out, 12)
    out.splice(0, out.length, ...e)
  }
  if (sources.includes('directory')) {
    const hits = DIRECTORY.filter((g) => !words.length || words.some((w) => `${g.title} ${g.summary} ${g.funder}`.toLowerCase().includes(w)))
    out.unshift(...(hits.length ? hits : sources.length === 1 ? DIRECTORY : []))
  }
  for (const [key, list] of [['mena', MENA], ['un', UN]] as const) {
    if (!sources.includes(key)) continue
    const hits = list.filter((g) => !words.length || words.some((w) => `${g.title} ${g.summary} ${g.funder} ${(g.sectors ?? []).join(' ')}`.toLowerCase().includes(w)))
    out.unshift(...(hits.length ? hits : sources.length === 1 ? list : []))
  }
  const seenIds = new Set<string>()
  const unique = out.filter((g) => (seenIds.has(g.id) ? false : (seenIds.add(g.id), true)))
  return { grants: unique, errors }
}

export const searchGrants = createServerFn({ method: 'POST' })
  .validator((d: SearchInput) => d)
  .handler(async ({ data }) => {
    const kw = data.keyword.trim().slice(0, 120)
    const sources = (data.sources?.length ? data.sources : ALL_SOURCES) as Src[]
    return runSearchCore(kw, sources, data.us, data.euStatus)
  })

export async function profileSearch(req: string, profile: Profile, useProfile: boolean, libraryNote = '') {
    const request = req.trim().slice(0, 600)
    const prof = useProfile ? profile : null
    let queries: string[] = []
    let categories: string[] = []
    let note = ''
    let usedAi = false
    try {
      const txt = await llm(
        `You turn an NGO's description of the grants it wants into search plans for grant databases (Grants.gov, EU Funding & Tenders portal, global funder lists). Reply with JSON: {"queries": string[] (6 to 8 short search phrases of 1 to 3 words each, no punctuation. Make them DIVERSE and creative: the core theme; a synonym or the funder's likely wording (for example resilience for climate adaptation); the target group; the approach or intervention; the donor-style programme name; and one or two adjacent angles that a funder of this work might also file it under, such as livelihoods, innovation, capacity building, humanitarian or localisation), "categories": string[] (zero to 3 of: AG, BC, CD, DPR, ED, ELT, EN, ENV, HL, NR, RT, ST, T), "note": string (one sentence saying how you interpreted the request)}. Never include the organization's name in queries.`,
        `Request: ${request || '(none, use the organization profile)'}\n${prof ? 'Organization profile: ' + JSON.stringify({ country: prof.country, operatesIn: prof.opCountries, focus: prof.focus, populations: prof.populations, sdgs: prof.sdgs, mission: prof.mission, beneficiaries: prof.beneficiaries, regions: prof.regions, type: prof.orgType, grantTypesSought: prof.grantTypes, purposes: prof.purposes, amountRangeUSD: [prof.amountMin, prof.amountMax] }) : ''}${libraryNote ? '\nFrom the organization\'s own documents (real past work and facts; use them to choose themes, geographies and funder wording): ' + libraryNote.slice(0, 1500) : ''}`,
        true,
        800,
      )
      if (txt) {
        const p = parseJson(txt)
        queries = (Array.isArray(p.queries) ? p.queries : []).map((x: any) => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 8)
        const valid = ['AG', 'BC', 'CD', 'DPR', 'ED', 'ELT', 'EN', 'ENV', 'HL', 'NR', 'RT', 'ST', 'T']
        categories = (Array.isArray(p.categories) ? p.categories : []).map((x: any) => String(x).toUpperCase()).filter((x: string) => valid.includes(x)).slice(0, 3)
        note = String(p.note ?? '').slice(0, 240)
        usedAi = queries.length > 0
      }
    } catch {
      /* fall back below */
    }
    if (!queries.length) {
      const base = (request + ' ' + (prof?.focus ?? '')).split(/[,;\n]+/).map((x) => x.trim()).filter((x) => x.length > 2)
      queries = [...new Set(base.length ? base : ['community development'])].slice(0, 4).map((x) => x.split(/\s+/).slice(0, 3).join(' '))
      note = 'AI is not available right now, so I searched on the words from your request and focus areas.'
    }
    const runs = await Promise.all(queries.map((q, qi) => runSearchCore(q, qi < 4 ? ALL_SOURCES : ALL_SOURCES.filter((x) => x !== 'fundsforngos' && x !== 'opportunitydesk'), categories.length ? { categories } : undefined, 'both', false)))
    const errors = [...new Set(runs.flatMap((r) => r.errors))]
    const map = new Map<string, { g: Grant; score: number }>()
    const profWords = new Set(((prof?.focus ?? '') + ' ' + (prof?.mission ?? '') + ' ' + (prof?.populations ?? '')).toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3))
    runs.forEach((r, qi) => {
      for (const g of r.grants) {
        const hay = `${g.title} ${g.summary ?? ''}`.toLowerCase()
        const qWords = queries[qi].toLowerCase().split(/\s+/)
        const hit = qWords.filter((w) => hay.includes(w)).length / qWords.length
        const pHit = [...profWords].filter((w) => hay.includes(w)).length
        const prev = map.get(g.id)
        const score = (prev?.score ?? 0) + 1 + hit * 2 + Math.min(pHit, 3) * 0.5
        map.set(g.id, { g, score })
      }
    })
    const top = [...map.values()].sort((a, b) => b.score - a.score).slice(0, 40).map((x) => x.g)
    const grants = await enrichUS(top, 12)
    return { grants, errors, queries, categories, note, usedAi }
}

export const aiSearchGrants = createServerFn({ method: 'POST' })
  .validator((d: { request: string; profile: Profile; useProfile: boolean; libraryNote?: string }) => d)
  .handler(async ({ data }) => profileSearch(data.request, data.profile, data.useProfile, data.libraryNote ?? ''))


export function heuristic(profile: Profile, grant: Grant) {
  const list = (v?: string) => (v ?? '').split(',').map((x) => x.trim()).filter(Boolean)
  const toks = (t: string) => new Set(t.toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3))
  const mine = toks(`${profile.focus} ${profile.mission} ${profile.beneficiaries ?? ''} ${profile.populations ?? ''} ${profile.regions ?? ''}`)
  const theirs = toks(`${grant.title} ${grant.summary ?? ''}`)
  const overlap = [...mine].filter((w) => theirs.has(w))
  const mySectors = list(profile.focus)
  const sharedSectors = (grant.sectors ?? []).filter((x) => mySectors.includes(x))
  let score = Math.min(60, 20 + overlap.length * 8 + sharedSectors.length * 14)
  if (!mine.size) score = 15
  const strengths: string[] = []
  const gaps: string[] = []
  if (sharedSectors.length) strengths.push(`Sector match: ${sharedSectors.join(', ')}.`)
  else if (overlap.length) strengths.push(`Your profile overlaps with this call on: ${overlap.slice(0, 5).join(', ')}.`)
  else gaps.push('No clear overlap between your focus areas and this call.')

  const comp = list(profile.compliance)
  const myCountries = [profile.country, ...list(profile.regCountry), ...list(profile.opCountries)].filter(Boolean) as string[]
  const cs = grant.countries ?? []
  if (cs.length && myCountries.length) {
    const global = cs.some((x) => /global|worldwide|all countries/i.test(x))
    const direct = cs.some((x) => myCountries.some((m) => m.toLowerCase() === x.toLowerCase()))
    if (global || direct) { score += 15; strengths.push(global ? 'Open to organizations worldwide.' : 'Your country is eligible.') }
    else { score -= 10; gaps.push(`This call lists ${cs.join(', ')}. Check whether organizations from ${myCountries[0]} can apply or join as partners.`) }
  }
  const lo = Number((profile.amountMin ?? '').replace(/[^0-9.]/g, '')) || 0
  const hi = Number((profile.amountMax ?? '').replace(/[^0-9.]/g, '')) || Infinity
  const gTop = grant.amountMax || grant.amountMin || 0
  const gBottom = grant.amountMin || 0
  if (gTop && (lo || hi !== Infinity)) {
    if (gTop >= lo && gBottom <= hi) { score += 10; strengths.push('Award size fits the range you are looking for.') }
    else gaps.push(`Awards run ${gBottom ? gBottom.toLocaleString('en-US') : '0'} to ${gTop.toLocaleString('en-US')} USD, outside your target range.`)
  }
  if (/us federal/i.test(grant.source) && !comp.some((c) => /sam/i.test(c))) gaps.push('US federal grants require SAM.gov registration with a UEI number. Your profile does not list it.')
  if (/eu funding/i.test(grant.source) && !comp.some((c) => /pic/i.test(c))) gaps.push('EU calls require a Participant Identification Code (PIC). Your profile does not list it.')
  if (profile.registered === 'no' && !/crowdfunding/i.test(grant.source)) { score -= 10; gaps.push('Most funders require a legally registered organization. Consider a fiscal sponsor while you register.') }
  if (profile.budget && /Over \$2M|\$500k to \$2M/.test(profile.budget) && !comp.some((c) => /audit/i.test(c))) gaps.push('Larger funders usually ask for audited financial statements.')
  const gt = (grant.gtype ?? '').toLowerCase()
  const wanted = list(profile.grantTypes)
  if (gt && wanted.length && !wanted.some((w) => gt.includes(w.toLowerCase().split(' ')[0]))) gaps.push(`This is a ${grant.gtype}. You said you are looking for: ${wanted.join(', ')}.`)
  if (/forthcoming|forecast/i.test(grant.status)) strengths.push('Not open yet, so you have time to prepare.')
  score = Math.max(5, Math.min(95, score))
  const tips = ['Read the full eligibility section before investing time.', 'Match your project title and outcomes to the funder\u2019s own wording.']
  return { score, strengths, gaps, tips, mode: 'keyword' as const }
}

export function parseJson(txt: string) {
  const a = txt.indexOf('{')
  const b = txt.lastIndexOf('}')
  const body = a >= 0 ? (b > a ? txt.slice(a, b + 1) : txt.slice(a)) : txt
  try {
    return JSON.parse(body)
  } catch {
    return JSON.parse(repairJson(a >= 0 ? txt.slice(a) : txt))
  }
}

/** Repairs JSON that was cut off or has raw line breaks inside strings, keeping everything that is complete. */
function repairJson(src: string): string {
  let out = ''
  let inStr = false
  let esc = false
  const stack: string[] = []
  const cuts: { len: number; stack: string[] }[] = []
  for (const ch of src) {
    if (inStr) {
      if (esc) { out += ch; esc = false; continue }
      if (ch === '\\') { out += ch; esc = true; continue }
      if (ch === '"') { out += ch; inStr = false; continue }
      if (ch === '\n') { out += '\\n'; continue }
      if (ch === '\r') continue
      if (ch === '\t') { out += '\\t'; continue }
      out += ch
      continue
    }
    if (ch === '"') { inStr = true; out += ch; continue }
    if (ch === '{' || ch === '[') { stack.push(ch === '{' ? '}' : ']'); out += ch; continue }
    if (ch === '}' || ch === ']') { stack.pop(); out += ch; continue }
    if (ch === ',') cuts.push({ len: out.length, stack: [...stack] })
    out += ch
  }
  const close = (st: string[]) => [...st].reverse().join('')
  const tryParse = (t: string) => { try { JSON.parse(t); return true } catch { return false } }
  let whole = out
  if (inStr) whole += '"'
  whole = whole.replace(/[\s,:]+$/, '') + close(stack)
  if (tryParse(whole)) return whole
  for (let i = cuts.length - 1; i >= 0; i--) {
    const cand = out.slice(0, cuts[i].len).replace(/[\s,:]+$/, '') + close(cuts[i].stack)
    if (tryParse(cand)) return cand
  }
  return whole
}

type Cand = { url: string; key: string; model: string }

// Every AI key the site owner added, in order of preference. When one service is out of allowance or busy, the next one answers.
function aiCandidates(): Cand[] {
  const keys = [process.env.AI_API_KEY, process.env.OPENAI_API_KEY, process.env.GROQ_API_KEY, process.env.GEMINI_API_KEY]
    .map((k) => (k ?? '').trim())
    .filter((k, i, a) => k && a.indexOf(k) === i)
  const out: Cand[] = []
  for (const key of keys) {
    const provider = key.startsWith('AIza') || key.startsWith('AQ.')
      ? { url: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions', models: ['gemini-3.5-flash', 'gemini-3-flash-preview', 'gemini-3.1-flash-lite'] }
      : key.startsWith('gsk_')
        ? { url: 'https://api.groq.com/openai/v1/chat/completions', models: ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'qwen/qwen3.8-27b'] }
        : { url: 'https://api.openai.com/v1/chat/completions', models: ['gpt-4o-mini'] }
    const models = process.env.AI_MODEL && !key.startsWith('gsk_') && !key.startsWith('AIza') && !key.startsWith('AQ.') ? [process.env.AI_MODEL] : provider.models
    for (const model of models) out.push({ url: provider.url, key, model })
  }
  return out
}

// Models that just hit a usage limit are skipped until they recover, so one exhausted model does not slow every request.
const modelCooldown = new Map<string, number>()

// Applied to every AI text: proposal text is impersonal, never in the first person.
const STYLE_RULE = ' STYLE RULE (always follow): in any text you write for a grant application, proposal section, project document, justification or description, never use the first-person pronouns "I", "we", "our", "ours", "us", "my" or "me" (and no "let us"). Write impersonally in the third person and use the organization\'s name, "the organization", "the project", "the consortium" or "the partners" as the subject, or use passive or subject-less constructions. Exceptions: a letter, message or form that is clearly meant to be written in the first person by the applicant, and the short conversational reply to the user in a chat.'

export async function llm(system: string, user: string, json = false, maxTokens?: number, temperature = 0.4): Promise<string | null> {
  system += STYLE_RULE
  const all = aiCandidates()
  if (!all.length) return null
  const limited = await import('../limits.server').then((m) => m.aiRateLimit()).catch(() => null)
  if (limited) throw new Error(limited)
  await import('../usage.server').then((m) => m.chargeAi())
  const isOss = (m: string) => m.includes('gpt-oss')
  let tokens = maxTokens ?? (json ? 1800 : 1200)
  const isGroq = (c: Cand) => c.url.includes('groq')
  // Free-tier usage limits per minute for each model. A request is sized to fit, or handed to a model with more room.
  const tpm = (c: Cand) => (isGroq(c) ? (c.model.includes('qwen') ? 8000 : 8000) : 1_000_000)
  // The qwen model on the free Groq plan also caps output at about 1,000 tokens per minute.
  const maxOut = (c: Cand) => (isGroq(c) && c.model.includes('qwen') ? 900 : 100000)
  const estPrompt = Math.ceil((system.length + user.length + 200) / 3.4)
  const cid = (c: Cand) => c.url + '|' + c.model
  const call = (c: Cand, ms: number, maxTok = tokens) => {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), ms)
    return fetch(c.url, {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${c.key}`, 'x-whop-inject-key': 'none' },
      body: JSON.stringify({
        model: c.model,
        temperature,
        max_tokens: maxTok,
        ...(isOss(c.model) || c.model.startsWith('gemini') ? { reasoning_effort: 'low' } : {}),
        ...(json && !isOss(c.model) ? { response_format: { type: 'json_object' } } : {}),
        messages: [
          { role: 'system', content: system + (json ? ' Respond with a single valid JSON object only, no prose, no code fences.' : '') },
          { role: 'user', content: user },
        ],
      }),
    }).finally(() => clearTimeout(timer))
  }
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
  const waitFrom = async (r: Response) => {
    try {
      const h = Number(r.headers.get('retry-after'))
      if (h > 0) return h * 1000
      const m = (await r.clone().text()).match(/try again in (?:(\d+)m)?([\d.]+)(ms|s)/i)
      if (m) return m[3].toLowerCase() === 'ms' ? Number(m[2]) : (Number(m[1] || 0) * 60 + Number(m[2])) * 1000
    } catch {}
    return 0
  }
  // Each model has its own usage limit. A slow, busy or failing model hands over to the next one quickly.
  const run = async (): Promise<{ r: Response | null; wait: number; cand: Cand; tooBig: boolean }> => {
    let r: Response | null = null
    let wait = 0
    let tooBig = false
    const now = Date.now()
    const ready = all.filter((c) => (modelCooldown.get(cid(c)) ?? 0) <= now)
    const order = ready.length ? ready : all
    let used = order[0]
    for (let i = 0; i < order.length; i++) {
      const c = order[i]
      used = c
      const room = Math.min(maxOut(c), Math.floor(tpm(c) * 0.9 - estPrompt))
      if (room < 500) { tooBig = true; continue }
      try { r = await call(c, i === 0 ? 35000 : 40000, Math.min(tokens, room)) } catch { r = null; continue }
      if (r.ok) { tooBig = false; break }
      if (r.status === 429) { const w = await waitFrom(r); if (w > 0) { wait = wait > 0 ? Math.min(wait, w) : w; modelCooldown.set(cid(c), Date.now() + Math.min(w, 600000)) } continue }
      if ([401, 403, 404].includes(r.status)) { modelCooldown.set(cid(c), Date.now() + 600000); continue }
      if (![408, 500, 502, 503, 504].includes(r.status)) break
    }
    return { r, wait, cand: used, tooBig }
  }
  let { r, wait, cand, tooBig } = await run()
  // Every model is at its usage limit: wait for the shortest recovery time and try again, a few times at most.
  for (let round = 0; round < 3 && r && r.status === 429 && !tooBig && wait <= 30000; round++) {
    await sleep(Math.min(20000, Math.max(wait, 1500)) + 300)
    wait = 0
    ;({ r, wait, cand, tooBig } = await run())
  }
  if (!r && tooBig) throw new Error('This request is too large for the AI service. Shorten the text or pick a smaller part of it and try again.')
  if (!r) throw new Error('The AI service took too long to answer. Please try again in a moment.')
  if (!r.ok) {
    let detail = ''
    try {
      detail = ((await r.json()) as any)?.error?.message ?? ''
    } catch {}
    if (r.status === 429 || r.status === 413) throw new Error('The AI service has reached its usage limit for the moment. Wait about a minute and try again.')
    throw new Error(`AI provider error ${r.status}: ${detail.replace(/(sk-|gsk_|AIza)[A-Za-z0-9_-]+/g, '[key]').slice(0, 200)}`)
  }
  let j: any = await r.json()
  let out: string = j.choices?.[0]?.message?.content ?? ''
  // An answer that is empty or cut off (the thinking used up the allowance) is asked for again with more room.
  if ((!out.trim() || j.choices?.[0]?.finish_reason === 'length') && tokens < 7000) {
    tokens = Math.min(8000, tokens * 2 + 800)
    try {
      const r2 = await call(cand, 40000, Math.min(maxOut(cand), tokens, Math.max(500, Math.floor(tpm(cand) * 0.9 - estPrompt))))
      if (r2.ok) { j = await r2.json(); const o2: string = j.choices?.[0]?.message?.content ?? ''; if (o2.trim()) out = o2 }
    } catch {}
  }
  if (!out.trim()) throw new Error('The AI returned an empty answer. Please try again.')
  return out
}

// Same checks as llm(): the per-connection limit and one AI credit. Streaming calls use this once, before the answer starts.
export async function guardAi(): Promise<void> {
  const limited = await import('../limits.server').then((m) => m.aiRateLimit()).catch(() => null)
  if (limited) throw new Error(limited)
  await import('../usage.server').then((m) => m.chargeAi())
}

// Hides a model's own "thinking" text, including a half-arrived opening tag.
function visibleOnly(raw: string): string {
  let t = raw.replace(/<think>[\s\S]*?<\/think>/g, '')
  const open = t.indexOf('<think>')
  if (open >= 0) t = t.slice(0, open)
  for (let k = Math.min(6, t.length); k > 0; k--) if ('<think>'.startsWith(t.slice(-k))) { t = t.slice(0, -k); break }
  return t.replace(/^\s+/, '')
}

// Like llm(), but hands the text over piece by piece while it is being written.
export async function llmStream(
  system: string,
  user: string,
  maxTokens: number,
  on: { delta: (s: string) => void; reset: () => void; status: (s: string) => void },
  signal?: AbortSignal,
  temperature = 0.4,
): Promise<string> {
  system += STYLE_RULE
  const all = aiCandidates()
  if (!all.length) throw new Error('AI is not switched on yet. The site owner needs to add an AI key.')
  const isOss = (m: string) => m.includes('gpt-oss')
  const isGroq = (c: Cand) => c.url.includes('groq')
  const tpm = (c: Cand) => (isGroq(c) ? 8000 : 1_000_000)
  const maxOut = (c: Cand) => (isGroq(c) && c.model.includes('qwen') ? 900 : 100000)
  const estPrompt = Math.ceil((system.length + user.length + 200) / 3.4)
  const cid = (c: Cand) => c.url + '|' + c.model
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))
  for (let round = 0; round < 3; round++) {
    if (signal?.aborted) throw new Error('Stopped.')
    const now = Date.now()
    const ready = all.filter((c) => (modelCooldown.get(cid(c)) ?? 0) <= now)
    const order = ready.length ? ready : all
    let wait = 0
    for (const c of order) {
      const room = Math.min(maxOut(c), Math.floor(tpm(c) * 0.9 - estPrompt))
      if (room < 500) continue
      const ctrl = new AbortController()
      const link = () => ctrl.abort()
      signal?.addEventListener('abort', link)
      const headerTimer = setTimeout(() => ctrl.abort(), 40000)
      const totalTimer = setTimeout(() => ctrl.abort(), 110000)
      try {
        let msgs: { role: string; content: string }[] = [{ role: 'system', content: system }, { role: 'user', content: user }]
        const doFetch = (messages: { role: string; content: string }[]) => fetch(c.url, {
          method: 'POST',
          signal: ctrl.signal,
          headers: { 'content-type': 'application/json', authorization: `Bearer ${c.key}`, 'x-whop-inject-key': 'none' },
          body: JSON.stringify({
            model: c.model,
            temperature,
            max_tokens: Math.min(maxTokens, room),
            stream: true,
            ...(isOss(c.model) || c.model.startsWith('gemini') ? { reasoning_effort: 'low' } : {}),
            messages,
          }),
        })
        let raw = ''
        let shown = ''
        let started = false
        let failed = false
        // When the model stops because it ran out of room, it is asked to continue from where it stopped, so the whole field is always written.
        for (let part = 0; part < 6; part++) {
          const r = await doFetch(msgs)
          clearTimeout(headerTimer)
          if (!r.ok || !r.body) {
            if (r.status === 429) {
              let w = Number(r.headers.get('retry-after')) * 1000
              if (!(w > 0)) { const m = (await r.text().catch(() => '')).match(/try again in (?:(\d+)m)?([\d.]+)(ms|s)/i); w = m ? (m[3].toLowerCase() === 'ms' ? Number(m[2]) : (Number(m[1] || 0) * 60 + Number(m[2])) * 1000) : 0 }
              if (w > 0) { wait = wait > 0 ? Math.min(wait, w) : w; modelCooldown.set(cid(c), Date.now() + Math.min(w, 600000)) }
            } else if ([401, 403, 404].includes(r.status)) modelCooldown.set(cid(c), Date.now() + 600000)
            failed = true
            break
          }
          const reader = r.body.getReader()
          const dec = new TextDecoder()
          let buf = ''
          let chunk = ''
          let finish = ''
          for (;;) {
            const { done, value } = await reader.read()
            if (done) break
            buf += dec.decode(value, { stream: true })
            let nl: number
            while ((nl = buf.indexOf('\n')) >= 0) {
              const line = buf.slice(0, nl).trim()
              buf = buf.slice(nl + 1)
              if (!line.startsWith('data:')) continue
              const payload = line.slice(5).trim()
              if (!payload || payload === '[DONE]') continue
              let piece = ''
              try { const j = JSON.parse(payload); piece = j?.choices?.[0]?.delta?.content ?? ''; if (j?.choices?.[0]?.finish_reason) finish = String(j.choices[0].finish_reason) } catch { continue }
              if (!piece) continue
              chunk += piece
              raw += piece
              const vis = visibleOnly(raw)
              if (vis.length > shown.length && vis.startsWith(shown)) { started = true; on.delta(vis.slice(shown.length)); shown = vis }
            }
          }
          if (finish !== 'length' || !visibleOnly(raw).trim()) break
          msgs = [...msgs.slice(0, 2), { role: 'assistant', content: visibleOnly(chunk) || visibleOnly(raw) }, { role: 'user', content: 'You stopped before the end. Continue exactly from the last word, without repeating anything you already wrote and without any introduction, and finish the whole text.' }]
          if (/\n$/.test(raw) === false && !/\s$/.test(visibleOnly(raw))) { /* the next piece continues the same sentence */ }
        }
        if (failed) continue
        const finalText = visibleOnly(raw)
        if (finalText.trim()) return finalText
        if (started) on.reset()
      } catch {
        if (signal?.aborted) throw new Error('Stopped.')
      } finally {
        clearTimeout(headerTimer)
        clearTimeout(totalTimer)
        signal?.removeEventListener('abort', link)
      }
    }
    if (wait > 0 && wait <= 20000) { on.status('The AI service is busy. Waiting a few seconds...'); await sleep(wait + 300); continue }
    break
  }
  throw new Error('The AI service is busy or did not answer. Please try again in a moment.')
}

export type CompleteInput = { current?: string; template?: string; rules?: string; framework?: Partial<Record<string, string[]>>; profile: Profile; section: string; context: string; grant?: Grant; instruction?: string; amount?: string; months?: string; guidance?: string; wordLimit?: number; limit?: number; limitUnit?: 'words' | 'characters' | 'characters_nospace' }

const FW_LABEL: Record<string, string> = { priorities: 'Funder priorities', objectives: 'Funder objectives', subObjectives: 'Sub-objectives', outcomes: 'Expected outcomes', outputs: 'Expected outputs', activities: 'Activities', indicators: 'Indicators', budgetCeilings: 'Budget ceilings' }

// Which of the applicant's selected framework items belong in which section.
function frameworkKeysFor(section: string): string[] {
  if (/summary|abstract|overview/i.test(section)) return ['priorities', 'objectives', 'outcomes', 'budgetCeilings']
  if (/budget|cost|financ|resource/i.test(section)) return ['budgetCeilings', 'activities', 'outputs']
  if (/timeline|schedule|work ?plan/i.test(section)) return ['activities', 'outputs', 'subObjectives']
  if (/goal|objective/i.test(section) && !/evaluation/i.test(section)) return ['objectives', 'subObjectives', 'outcomes', 'indicators']
  if (/outcome|evaluation|result|monitor|indicator|logframe|impact|learning/i.test(section)) return ['objectives', 'subObjectives', 'outcomes', 'outputs', 'indicators']
  if (/activit|method|approach|implement|intervention|design/i.test(section)) return ['activities', 'outputs', 'subObjectives', 'objectives']
  if (/beneficiar|target|participant|population/i.test(section)) return ['priorities', 'subObjectives', 'outcomes']
  if (/sustain|exit|scal|continu/i.test(section)) return ['outcomes', 'priorities', 'indicators']
  if (/need|background|context|problem|rationale|justif/i.test(section)) return ['priorities', 'objectives', 'subObjectives']
  return ['priorities', 'objectives', 'subObjectives', 'outcomes']
}

function frameworkBrief(section: string, fw?: Partial<Record<string, string[]>>) {
  if (!fw) return ''
  const lines = frameworkKeysFor(section)
    .filter((k) => (fw[k] ?? []).length)
    .map((k) => `- ${FW_LABEL[k]}: ${(fw[k] ?? []).map((x, i) => `[${i + 1}] ${x}`).join(' ; ')}`)
  if (!lines.length) return ''
  const extra = /outcome|evaluation|result|monitor|indicator|logframe|impact|learning/i.test(section)
    ? ' For the results table, use the header row "| Objective or sub-objective | Output or outcome | Indicator | Baseline | Target | Means of verification |" instead of any other header, with one row for each selected indicator and a row for every selected outcome and output that has no indicator yet.'
    : /timeline|schedule|work ?plan/i.test(section)
      ? ' The timeline table must include every selected activity by name, in a logical order.'
      : ''
  return `\nSELECTED FUNDER FRAMEWORK for this section (the applicant chose these as relevant to the project). Build the section around them:\n${lines.join('\n')}\nUse the funder's exact wording for each item you address and refer to items by their number or name. Address every item listed here. Do not add priorities, objectives, outcomes or indicators the applicant did not select. Keep activities, outputs, outcomes and objectives traceable: each activity leads to an output, each output to an outcome, each outcome to an objective. If the applicant's information does not allow a specific claim for an item, write a [bracketed placeholder] instead of inventing it. Never break a budget ceiling.${extra}\n`
}

const CORE_ROLE = ' ROLE AND RULES: You act as an expert grant-writing specialist, technical subject-matter expert and compliance editor. Draft submission-ready text based strictly on the funder\'s application template and guidance and on the project information supplied. The template (structure, headings, limits) and the guidance (eligibility, priorities, scoring criteria, budget rules, compliance rules) are controlling. If they conflict, follow the guidance. Never fabricate facts, data, citations, partners, budgets, timelines or outcomes. Where information is missing write a clearly marked placeholder such as [TO BE CONFIRMED: the specific item], and use [XXX] or [%] for an unknown figure. Define acronyms at first use. Keep objectives, activities, timeline, deliverables, budget, personnel and evaluation consistent with each other. If a required point does not apply, say why in one sentence. Align the text explicitly with the funder\'s priorities and evaluation criteria, and write precisely, technically and coherently without boilerplate or unsupported claims.'
const WRITING_STANDARDS = ' Write in a precise, technical and professional grant-writing register, with a logical structure, clear subtitles, cohesive transitions and consistent terminology across the whole proposal. State objectives and results in measurable terms. Define every indicator with its unit, baseline, target and means of verification where the information exists, and use [bracketed placeholders] where it does not. Be specific and concrete, avoid filler and generic claims, and stay within the funder\'s limits.'

// Proposal-writing guidance applied to every section: easy to score, mirrors the funder, cohesive.
const GENERAL_GUIDE = ' SCORING-FIRST RULES: Write so that reviewers can award points easily. Mirror the funder\'s headings, vocabulary and priority phrases exactly, and answer every prompt the funder lists, in order, under the funder\'s own subheadings. Front-load the numbers and put metrics up front. Write objectives to be SMART: Specific, Measurable (with a number and a unit), Achievable within the budget and staffing, Relevant to the funder\'s priority, Time-bound (for example "within 12 months from launch"). Keep needs, goals, methods, timeline, budget and evaluation tightly aligned: every activity serves an objective, has a cost line and an indicator. Attribute each statistic to its source and year; never invent a source.'

function sectionGuide(section: string): string {
  const t = section.toLowerCase()
  if (/executive|summary|abstract|overview/.test(t))
    return ' SECTION PURPOSE: a tight, data-backed snapshot read first and written last. Follow the order Need, Solution, Outcomes, Amount, Fit. The very first sentence of the section, before any subtitle, states the ask, for example "We request $X over N months to ...", with the number of people served, the key activities or hours of delivery, and the headline target. Name the main partners, align to the funder\'s priorities using its own key phrases, and end by promising follow-through through the evaluation and sustainability plans. This is the one section where the amount and duration are stated.'
  if (/capacity|governance|management|partnership/.test(t))
    return ' SECTION PURPOSE: prove the organization can run the grant. Cover team qualifications relevant to the scope, systems (fiscal controls, procurement, data security, reporting), partners with their roles, resources and the letters of agreement or MOUs that commit them, and governance (board oversight, conflict-of-interest policy, audit readiness). Use only facts from the profile and documents; use [placeholders] for the rest.'
  if (/introduction|organi[sz]ation|background|about us|who we are/.test(t))
    return ' SECTION PURPOSE: establish who the organization is and why it can deliver. Cover mission, relevant experience and track record with numbers, governance, geographic reach and fit with the funder\'s priorities. Use only facts from the profile and the organization\'s documents.'
  if (/need|problem|rationale/.test(t))
    return ' SECTION PURPOSE: make the reviewer feel the urgency and see that the problem can be solved. Use current, local data with its source and year; segment the need by the groups most affected (age, gender, income, disability, location); explain the drivers and barriers and link each to the solution; show demand and readiness (waiting lists, surveys, letters from stakeholders) where the user supplied them; address equity and access. Where useful, present key statistics as a table "| Statistic | Source | Implication |". One short human example may be included only if the user supplied it, otherwise leave a [bracketed placeholder for a short real example].'
  if (/goal|objective/.test(t) && !/evaluation/.test(t))
    return ' SECTION PURPOSE: state the overall goal and 3 to 5 SMART objectives, each as "Objective N:" with a specific action, a number and unit, the target group, the place and a deadline, and the indicator that will prove it (for example "Enroll 1,000 youth and 400 caregivers within 6 months"). Make the objectives add up to the outcomes in the evaluation plan and fit inside the budget and timeline.'
  if (/evaluation|outcome|monitor|indicator|logic|learning|results/.test(t))
    return ' SECTION PURPOSE: define outputs (activities and participation) and outcomes (changes), then for each objective give the indicator, baseline, target, data source or tool and frequency. Describe the learning loop: collect, review, adjust, with quarterly reflections that adapt dosage, outreach or tools based on the data. Name who is responsible for data quality and mention an external evaluator only if the budget has one.'
  if (/project description|description|activit|method|approach|implementation|intervention/.test(t) && !/timeline/.test(t))
    return ' SECTION PURPOSE: show the "how", not only the "what". Convert each objective into activities with dosage (how many, how often, for how long), curricula or tools, staffing and roles, and partner responsibilities. Include a workplan with milestones by quarter and who owns each, the main risks (staffing, procurement, data) with a mitigation for each, and accessibility measures (language access, disability access, inclusive recruitment). Number the activities so the timeline and budget can use the same numbers.'
  if (/sustainab|dissemination|exit|scal/.test(t))
    return ' SECTION PURPOSE: explain what continues after the grant (funding, partners, local ownership, policies), how the approach can be replicated or scaled, and how results will be shared (reports, learning events, publications) with whom.'
  if (/compliance|risk|ethic|safeguard|privacy/.test(t))
    return ' SECTION PURPOSE: cover eligibility and registrations, human-subjects protection and data privacy, accessibility and equity, risk management with mitigations, and environmental practice, in the funder\'s terms.'
  if (/conclusion/.test(t))
    return ' SECTION PURPOSE: restate Need, Solution, Outcomes, Fit and Stewardship in a few sentences and close with a call to action such as "With your support, we will ...".'
  return ''
}

function formatHint(section: string, amount?: string, months?: string) {
  if (/timeline/i.test(section))
    return `Build the timeline at the level of EACH ACTIVITY. Take every activity listed in the "Project activities" section above (if that section is empty, define 6 to 10 concrete activities from the project). Output ONE markdown table with the header row "| # | Activity | Responsible | Start month | End month | Deliverable |", a separator row, and exactly one row per activity, in logical order. Start and end month are whole numbers between 1 and ${months || '12'} (end >= start); activities may overlap. Responsible is a role, such as Project manager, Field team or M&E officer. Deliverable is one concrete output. Include setup at the start and evaluation or reporting at the end. One short sentence before the table is allowed; nothing after it.`
  if (/budget/i.test(section))
    return `Output ONE markdown table with the header row "| Item | Cost (USD) | Justification |", a separator row, 5 to 8 cost lines (personnel with percent effort and fringe, equipment, supplies, travel, contractual, other direct, indirect), and a final row "| **Total** | total | |". Every line has a one-line justification that names the unit rate and quantity and the activity it serves. Amounts are plain numbers with thousands separators and no currency symbol, and the Total MUST equal the sum of the lines${amount ? ` and equal ${amount}` : ''}. Add 2 to 3 sentences of justification after the table. Cost lines are estimates, so mark them clearly as such.`
  if (/outcome|evaluation/i.test(section))
    return `Output ONE markdown table with the header row "| Objective | Indicator | Baseline | Target | Data source or tool | Frequency |", a separator row, and 3 to 6 rows with SMART targets. Use [baseline to confirm] where you lack data. After the table write 2 to 3 sentences on the learning loop: collect, review, adjust, with quarterly reflection.`
  return ''
}


const money = (n: number) => n.toLocaleString('en-US', { maximumFractionDigits: 2, minimumFractionDigits: Number.isInteger(n) ? 0 : 2 })

async function buildBudget(data: CompleteInput): Promise<{ ok: true; text: string } | { ok: false; reason: string } | null> {
  const asked = Number((data.amount ?? '').replace(/[^0-9.]/g, '')) || 0
  const tpl = (data.template ?? '').trim()
  const system = tpl
    ? `You are a senior NGO budget officer. The funder supplied a budget template. Prepare the grant budget in that template's own structure. Reply with JSON only: {"lines":[{"activity":string,"item":string,"unit":string,"qty":number,"unitCost":number}],"indirectRate":number,"notes":string}. Rules: (1) "activity" holds the template's budget category or heading; use the template's own categories, in the SAME order and with the SAME names. (2) Follow the template's rules on eligible and excluded costs, caps and currency. (3) Each line is one concrete cost: item, unit (day, month, person, item, workshop, trip), whole-number qty, and a realistic unitCost in USD for the project's country, consistent with the project's activities, scale and duration. (4) indirectRate is the indirect or overhead rate the template allows as a fraction, for example 0.1 for 10 percent; 0 if indirect costs are not allowed; 0.1 if the template does not say. Name each item so that it shows which activity it serves, for example \"Trainer fee (Activity 3)\". Do NOT add indirect lines or totals; they are added automatically. (5) Aim for direct costs of about ${asked ? Math.round(asked / (1 + 0.1)) : 'a realistic amount'} USD. (6) Up to 40 lines. notes: 3 to 4 sentences: the unit-rate and quantity assumptions (and their basis), any match or in-kind contribution if the rules mention one, and any template rule you applied. The written proposal sections are given as context: every cost line must serve an activity, output or staffing need described there, every activity that needs funding must have cost lines, quantities and scale must match the figures stated (beneficiaries, sites, workshops, months, staff), and nothing may be budgeted for work the proposal does not describe. Never invent facts about the organization.`
    : `You are a senior NGO budget officer. Build an activity-based grant budget. Reply with JSON only: {"lines":[{"activity":string,"item":string,"unit":string,"qty":number,"unitCost":number}],"notes":string}. Rules: (1) Use the SAME activities, in the SAME order and with the SAME numbering and names as the timeline/activities provided; give each activity its own cost lines. If a "project management, monitoring and evaluation" activity is not listed, add it as the last activity. (2) Each line is one concrete cost: item (for example "Trainer fee"), unit (day, month, person, item, workshop, trip), whole-number qty, and a realistic unitCost in USD for the project's country. (3) Qty and unitCost must be consistent with the duration and scale of the project. (4) Do NOT include indirect or overhead lines and do NOT include totals; they are added automatically. (5) Aim for direct costs of about ${asked ? Math.round(asked / 1.1) : 'a realistic amount'} USD. (6) Up to 40 lines. notes: 3 to 4 sentences: the unit-rate and quantity assumptions and their basis, any match or in-kind contribution if the rules mention one, and the cost principles followed (every line maps to an activity, direct and indirect costs separated). The written proposal sections are given as context: every cost line must serve an activity, output or staffing need described there, every activity that needs funding must have cost lines, quantities and scale must match the figures stated (beneficiaries, sites, workshops, months, staff), and nothing may be budgeted for work the proposal does not describe. Never invent facts about the organization.`
  type L = { activity: string; item: string; unit: string; qty: number; unitCost: number }
  const userPrompt = `${data.current?.trim() ? 'EXISTING BUDGET TO IMPROVE (keep its categories and cost lines unless there is a clear reason to change them; correct unrealistic quantities and unit costs, add missing costs the activities need, and keep the total in line with the amount requested and the rules):\n' + data.current.slice(0, 3000) + '\n\n' : ''}Organization: ${JSON.stringify(data.profile)}\nProject duration: ${data.months || '12'} months\nAmount requested: ${asked || 'not set'} USD\n${data.guidance ? "Funder guidance: " + data.guidance + '\n' : ''}${data.rules ? 'Funder budget rules: ' + data.rules + '\n' : ''}${tpl ? "\nFunder budget template:\n" + tpl.slice(0, 7000) + '\n' : ''}\n${data.context.slice(0, 6000)}`
  const num = (v: any) => {
    if (typeof v === 'number') return Number.isFinite(v) ? v : 0
    const n = Number(String(v ?? '').replace(/[^0-9.\-]/g, ''))
    return Number.isFinite(n) ? n : 0
  }
  const toLines = (p: any): L[] => {
    const raw: any[] = Array.isArray(p) ? p
      : Array.isArray(p?.lines) ? p.lines
      : Array.isArray(p?.items) ? p.items
      : Array.isArray(p?.budget) ? p.budget
      : Array.isArray(p?.budget?.lines) ? p.budget.lines
      : Array.isArray(p?.cost_lines) ? p.cost_lines
      : Array.isArray(p?.costLines) ? p.costLines
      : []
    return raw
      .map((x: any) => {
        const item = String(x?.item ?? x?.description ?? x?.name ?? x?.cost_item ?? x?.line ?? '').trim().slice(0, 120)
        let qty = Math.round(num(x?.qty ?? x?.quantity ?? x?.units ?? x?.count))
        let unitCost = Math.max(0, num(x?.unitCost ?? x?.unit_cost ?? x?.unitPrice ?? x?.unit_price ?? x?.cost ?? x?.price ?? x?.rate))
        const total = Math.max(0, num(x?.total ?? x?.amount ?? x?.subtotal ?? x?.total_cost ?? x?.totalCost))
        if (!unitCost && total) { qty = qty > 0 ? qty : 1; unitCost = total / qty }
        if (!qty && unitCost) qty = 1
        return {
          activity: String(x?.activity ?? x?.category ?? x?.group ?? x?.heading ?? x?.section ?? 'General').trim().slice(0, 120) || 'General',
          item,
          unit: String(x?.unit ?? x?.uom ?? '').trim().slice(0, 30),
          qty: Math.max(0, qty),
          unitCost,
        }
      })
      .filter((x: L) => x.item && x.qty > 0 && x.unitCost > 0)
      .slice(0, 40)
  }
  let p: any = {}
  let lines: L[] = []
  let gotText = false
  for (let attempt = 0; attempt < 2 && !lines.length; attempt++) {
    const txt = await llm(
      system + (attempt ? ' IMPORTANT: your previous reply contained no usable cost lines. Return the full list now: at least 5 cost lines, every one with a non-empty item, a whole-number qty above 0 and a unitCost above 0, under the key \"lines\". Never return an empty list.' : ''),
      userPrompt,
      true,
      attempt ? 4200 : 3500,
    )
    if (!txt) { if (attempt === 0) return null; break }
    gotText = true
    p = parseJson(txt)
    lines = toLines(p)
  }
  if (!gotText) return null
  if (!lines.length) return { ok: false, reason: 'The AI did not return usable budget lines. Try again.' }
  const sum = (ls: L[]) => ls.reduce((a, l) => a + l.qty * l.unitCost, 0)
  const RATE = tpl ? Math.min(0.3, Math.max(0, Number(p.indirectRate) || 0)) : 0.1
  const GL = tpl ? 'Category' : 'Activity'
  const gl = GL.toLowerCase()
  if (asked) {
    const k = asked / (1 + RATE) / sum(lines)
    lines = lines.map((l) => {
      const c = l.unitCost * k
      return { ...l, unitCost: c >= 20 ? Math.round(c) : Math.round(c * 100) / 100 }
    })
  }
  const direct = Math.round(sum(lines) * 100) / 100
  let indirect = Math.round(direct * RATE * 100) / 100
  if (asked) {
    const diff = asked - (direct + indirect)
    if (Math.abs(diff) <= asked * 0.03) indirect = Math.round((indirect + diff) * 100) / 100
  }
  const total = Math.round((direct + indirect) * 100) / 100
  const groups: { name: string; lines: L[] }[] = []
  for (const l of lines) {
    let g = groups.find((x) => x.name === l.activity)
    if (!g) groups.push((g = { name: l.activity, lines: [] }))
    g.lines.push(l)
  }
  const cell = (t: string) => t.replace(/\|/g, '/')
  const rows: string[] = [`| # | ${GL} | Cost item | Unit | Qty | Unit cost (USD) | Total (USD) |`, '|---|---|---|---|---|---|---|']
  groups.forEach((g, gi) => {
    g.lines.forEach((l, li) => rows.push(`| ${li === 0 ? gi + 1 : ''} | ${li === 0 ? cell(g.name.replace(/^\d+[.)]?\s*/, '')) : ''} | ${cell(l.item)} | ${cell(l.unit)} | ${money(l.qty)} | ${money(l.unitCost)} | ${money(Math.round(l.qty * l.unitCost * 100) / 100)} |`))
    const sub = Math.round(sum(g.lines) * 100) / 100
    rows.push(`| | **Subtotal, ${gl} ${gi + 1}** | | | | | **${money(sub)}** |`)
  })
  rows.push(`| | **Direct costs** | | | | | **${money(direct)}** |`)
  rows.push(`| | Indirect and administrative costs (about ${direct ? Math.round((indirect / direct) * 100) : 0}%) | | | | | ${money(indirect)} |`)
  rows.push(`| | **TOTAL** | | | | | **${money(total)}** |`)
  const summary = [`| ${GL} | Subtotal (USD) | Share of total |`, '|---|---|---|']
  groups.forEach((g, gi) => {
    const sub = sum(g.lines)
    summary.push(`| ${gi + 1}. ${cell(g.name.replace(/^\d+[.)]?\s*/, ''))} | ${money(Math.round(sub * 100) / 100)} | ${((sub / total) * 100).toFixed(1)}% |`)
  })
  summary.push(`| Indirect and administrative | ${money(indirect)} | ${((indirect / total) * 100).toFixed(1)}% |`)
  summary.push(`| **TOTAL** | **${money(total)}** | **100%** |`)
  const note = String(p.notes ?? '').trim()
  const text = `Budget by ${gl}${tpl ? ', following the funder\'s template' : ''} (USD). All totals are calculated from quantity x unit cost.\n\n${rows.join('\n')}\n\nSummary by ${gl}\n\n${summary.join('\n')}\n\n${note ? 'Assumptions: ' + note + ' ' : ''}Unit costs are estimates: replace them with your own quotes and local rates before submitting.${asked && Math.abs(total - asked) > 0.5 ? ` Note: the total differs from the requested amount of ${money(asked)} USD.` : ''}`
  return { ok: true, text }
}

export const budgetFromTemplate = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; text: string; context: string; amount?: string; months?: string; rules?: string }) => d)
  .handler(async ({ data }) => {
    try {
      const b = await buildBudget({ profile: data.profile, section: 'Budget summary and justification', context: data.context, amount: data.amount, months: data.months, template: data.text, rules: data.rules })
      if (!b) return { ok: false as const, reason: 'AI is not switched on yet.' }
      if (!b.ok) return { ok: false as const, reason: b.reason }
      return { ok: true as const, text: tidyText(b.text) }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not prepare the budget.') }
    }
  })

export type WorkbookFill = { sheet: string; cell: string; value: string | number; kind: 'line' | 'qty' | 'unitcost' | 'text' | 'rate' | 'total'; label?: string; sumRange?: string }

type FillInput = { profile: Profile; description: string; context: string; amount?: string; months?: string; rules?: string; sheetNames?: string[]; mainSheet?: string }

export async function runFillWorkbook(data: FillInput) {
    try {
      const asked = Number((data.amount ?? '').replace(/[^0-9.]/g, '')) || 0
      const names = data.sheetNames ?? []
      const kinds = ['line', 'qty', 'unitcost', 'text', 'rate', 'total']
      const system = `You are a senior NGO budget officer. The funder supplied a budget workbook. Below is a map of each sheet: cells as REF="text", formulas as REF=<formula ...>, and blank styled cells as REF=[blank] (likely input cells). Fill in the workbook for the applicant's project. Reply with JSON only: {"fills":[{"sheet":string,"cell":string,"value":string|number,"kind":"line"|"qty"|"unitcost"|"text"|"rate"|"total","label":string,"sumRange":string}],"indirectRate":number,"indirectInFormulas":boolean,"notes":string}. Rules: (1) Keep the template exactly as it is: use its sheets, categories, cost lines and column meanings; fill only input cells. Never write into a cell that holds a formula or a fixed label. You may fill a cell that is not listed when it clearly sits in an input column of the template's table, in the row of a cost line. (2) kind "line" is a money amount for a cost line in USD (a number). "qty" is a quantity or count, "unitcost" a unit cost in USD, "text" a description, justification, name or date, "rate" a percentage as a fraction (0.1 for 10 percent), "total" a total you must write because the template left it blank, with sumRange like "C5:C20" naming the cells it adds up. "label" is the cost line's name, as written in the template. (3) Follow the template's own rules on eligible costs, caps and notes. (4) Use realistic costs in USD for the project's country. Every cost line must serve an activity, output or staffing need in the written proposal sections given as project context, every activity that needs funding must have a line, quantities must match the figures stated there, and description cells should name the activity served. Aim for the grand total to equal the requested amount (${asked || 'not set'} USD). (5) indirectRate is the indirect or overhead rate the template allows as a fraction (0 if not allowed, 0.1 if unstated). indirectInFormulas is true when the template calculates indirect costs or totals by formula, so you must not enter them. (6) Fill EVERY sheet that has input cells, not only the first one: cover or information sheets (names, dates, project title, country, duration), budget tables, summaries and any other sheet. At most 900 fills. notes: 2 to 3 sentences on assumptions and the template rules you applied. Never invent facts about the organization.`
      const ask = async (retry: boolean) => {
        const txt = await llm(
          system + (names.length ? ` The workbook sheets are named exactly: ${names.map((n) => `"${n}"`).join(', ')}. Use these names in "sheet".` : '') + (data.mainSheet ? ` Fill ONLY the main budget sheet "${data.mainSheet}" and put every fill on it. The other sheets are context for the funder's rules and lists, so do not fill them. Cells marked LINKED TO ANOTHER SHEET must receive fixed numbers (kind line, or total with a sumRange), because the other sheets will not be kept: work out each figure from the project, so that the category lines add up and the grand total equals the requested amount.` : ''),
          `Organization: ${JSON.stringify(Object.fromEntries(Object.entries(data.profile).filter(([, v]) => v !== '' && v != null)))}\nProject duration: ${data.months || '12'} months\nAmount requested: ${asked || 'not set'} USD\n${data.rules ? 'Funder budget rules: ' + data.rules + '\n' : ''}\nProject context:\n${data.context.slice(0, 4200)}\n\nFunder budget workbook:\n${data.description.slice(0, 15000)}${retry ? '\n\nYour previous answer contained no usable cells. This workbook does have a budget table: find its header row, then fill the money, quantity, unit cost and description cells in the rows of each cost line, in the columns under the headers, even when those cells are not listed above. Return at least one fill for every cost line. Each fill needs a sheet name and a cell reference such as C7.' : ''}`,
          true,
          6500,
        )
        if (!txt) return null
        const p = parseJson(txt)
        const rawList: any[] = Array.isArray(p.fills) ? p.fills : p.fills && typeof p.fills === 'object' ? Object.values(p.fills) : []
        const fills: WorkbookFill[] = rawList
          .map((x: any) => {
            let cell = String(x.cell ?? x.ref ?? x.address ?? '').toUpperCase().replace(/\$/g, '').trim()
            let sheetRaw = String(x.sheet ?? '')
            if (cell.includes('!')) { const [sh, c] = cell.split('!'); sheetRaw = sheetRaw || sh.replace(/^'|'$/g, ''); cell = c }
            const sheet = names.length ? (matchTitle(names, sheetRaw) || (names.length === 1 ? names[0] : '')) : sheetRaw
            const kind = kinds.includes(x.kind) ? x.kind : typeof x.value === 'number' ? 'line' : 'text'
            const num = typeof x.value === 'number' ? x.value : Number(String(x.value ?? '').replace(/[^0-9.\-]/g, ''))
            return {
              sheet,
              cell,
              value: kind !== 'text' ? (Number.isFinite(num) ? num : 0) : tidyText(String(x.value ?? '').slice(0, 600)),
              kind,
              label: x.label ? String(x.label).slice(0, 120) : undefined,
              sumRange: x.sumRange ? String(x.sumRange).toUpperCase().replace(/\$/g, '') : undefined,
            } as WorkbookFill
          })
          .filter((x: WorkbookFill) => x.sheet && (!data.mainSheet || x.sheet === data.mainSheet) && /^[A-Z]{1,3}\d{1,5}$/.test(x.cell))
          .slice(0, 900)
        return { fills, p }
      }
      let got = await ask(false)
      if (!got) return { ok: false as const, reason: 'AI is not switched on yet.' }
      if (!got.fills.length) got = (await ask(true)) ?? got
      if (!got.fills.length) return { ok: false as const, noInputs: true as const, reason: 'The AI did not find input cells to fill in that workbook.' }
      return {
        ok: true as const,
        fills: got.fills,
        indirectRate: Math.min(0.3, Math.max(0, Number(got.p.indirectRate) || 0)),
        indirectInFormulas: got.p.indirectInFormulas === true,
        notes: tidyText(String(got.p.notes ?? '').slice(0, 600)),
      }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not prepare the budget workbook.') }
    }
}

export const fillBudgetWorkbook = createServerFn({ method: 'POST' })
  .validator((d: FillInput) => d)
  .handler(async ({ data }) => runFillWorkbook(data))

const tidyText = (t: string) =>
  t
    .replace(/\[\s*(?:percentage|percent|pct|x{1,3})\s*%\s*\]/gi, '[%]')
    .replace(/\[\s*percentage\s*\]/gi, '[%]')
    .replace(/\[\s*x{1,3}(?:[,.\s]x{3})+\s*\]/gi, '[XXX]')
    .replace(/\[\s*x{1,2},?x{3}\s*\]/gi, '[XXX]')
    .replace(/^(\s*)\*\s+/gm, '$1- ')
    .replace(/\*/g, '')

export function buildAutoPrompt(data: CompleteInput): { system: string; user: string; tokens: number } {
      const lim = data.limit && data.limit > 0 ? data.limit : 0
      const wl = lim ? Math.round(data.limitUnit === 'characters' ? lim / 5.5 : data.limitUnit === 'characters_nospace' ? lim / 4.6 : lim) : data.wordLimit || 0
      const limitLine = lim ? `HARD LIMIT: the finished text must not exceed ${lim} ${data.limitUnit === 'characters' ? 'characters including spaces' : data.limitUnit === 'characters_nospace' ? 'characters excluding spaces' : 'words'}. Aim for about 90% of the limit and never go over it; count carefully, and prioritise the most important content.` : data.wordLimit ? `Hard limit: at most ${data.wordLimit} words.` : ''
      const tabular = /timeline|outcome|evaluation|result|indicator/i.test(data.section)
      const curWords = (data.current ?? '').trim() ? data.current!.trim().split(/\s+/).length : 0
      const autoTokens = Math.min(5000, Math.max(tabular ? 1800 : 900, wl ? Math.round(wl * 1.6) + 500 : 0, curWords ? Math.round(curWords * 2) + 700 : 0))
  const system =
        'You are an expert grant writer for NGOs worldwide. Write clear, specific, funder-ready text in plain English. Never invent statistics, names or facts; use [bracketed placeholders] where the user must supply data. Placeholder rules: write [%] for an unknown percentage (never [percentage %]) and [XXX] for an unknown number or amount (never [X,XXX]). Formatting rules: never use asterisks or markdown bold or italics; for lists use lines starting with "- ". Structure longer sections with short subtitles (3 to 8 words, Title Case, no punctuation at the end, no symbols) each on its own line with a blank line before and after it, and put paragraphs under them. Each section must add NEW information. Do not restate the organization name, mission, location, project title, amount or duration in every section, and do not repeat facts already written in other sections: refer to them briefly instead. If the user supplied a needs assessment, target areas or primary information, treat them as the factual base: use their specifics (places, numbers, findings, local context) and never contradict them or add facts they do not support. Return only the section text, without a heading.' + CORE_ROLE + (data.framework ? WRITING_STANDARDS : '') + GENERAL_GUIDE + sectionGuide(data.section)
  const user =
        `Organization: ${JSON.stringify(Object.fromEntries(Object.entries(data.profile).filter(([, v]) => v !== '' && v != null)))}\nTarget grant: ${data.grant ? JSON.stringify({ ...data.grant, details: (data.grant.details ?? '').slice(0, 700) }) : 'none'}\nSection to write: ${data.section}\nAmount requested: ${data.amount || 'not set'} USD. Duration: ${data.months || 'not set'} months.\nWhat the user has so far:\n${data.context.slice(0, 3800)}\n${data.current?.trim() ? 'EXISTING TEXT OF THIS SECTION (improve all of it and keep its facts; return the COMPLETE improved section from start to end, not only the parts you changed):\n' + data.current.slice(0, 14000) + '\n' : 'Write the COMPLETE section from start to end.\n'}${data.instruction ? 'Extra instruction: ' + data.instruction : ''}\n${data.guidance ? "The funder's own instructions for this section (follow them closely): " + data.guidance : ''}\n${limitLine}\n${formatHint(data.section, data.amount, data.months)}${frameworkBrief(data.section, data.framework)}`
  return { system, user, tokens: autoTokens }
}

// Cleans the finished text: drops a first line that only repeats the section title.
export function finishAutoText(txt: string, data: CompleteInput): string {
  const norm = (x: string) => x.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
  let body = txt.trim()
  const nl = body.indexOf('\n')
  if (nl > 0 && norm(body.slice(0, nl)) === norm(data.section)) body = body.slice(nl + 1).trim()
  return tidyText(body)
}

export async function runAutoComplete(data: CompleteInput) {
    try {
      if (/budget/i.test(data.section)) {
        const b = await buildBudget(data)
        if (b && b.ok) return { text: tidyText(b.text), ok: true as const }
        if (b && !b.ok) return { text: '', ok: false as const, reason: b.reason }
      }
      const { system, user, tokens } = buildAutoPrompt(data)
      const txt = await llm(system, user, false, tokens)
      if (txt) {
        return { text: finishAutoText(txt, data), ok: true as const }
      }
    } catch (e: any) {
      return { text: '', ok: false as const, reason: String(e?.message ?? 'The AI service returned an error.') }
    }
    return { text: '', ok: false as const, reason: 'AI is not switched on yet. The site owner needs to add an AI key.' }
}

export const autoComplete = createServerFn({ method: 'POST' })
  .validator((d: CompleteInput) => d)
  .handler(async ({ data }) => runAutoComplete(data))

async function extractProfileFromText(text: string) {
    try {
      const txt = await llm(
        `You read an NGO's document (profile, annual report, strategy, website text) and extract facts for a grant-matching profile. Reply with JSON using only these keys: org, country (headquarters country), regCountry (country of registration), orgType (one of: "NGO / nonprofit","Community-based organization","Social enterprise","Faith-based organization","Research or university group","Informal group"), taxStatus (for example "501(c)(3)", "Registered charity", "Tax exempt", or ""), founded (year), registered ("yes","pending","no" or ""), budget (one of: "Under $25k","$25k to $100k","$100k to $500k","$500k to $2M","Over $2M" or ""), size, website, focus (comma separated, only from: ${SECTOR_LIST.join(', ')}), populations (comma separated people groups served, such as Women, Girls, Youth, Children, Refugees, Persons with disabilities, Indigenous peoples, Smallholder farmers, Rural communities, Elderly), sdgs (comma separated, like "SDG 4, SDG 5"), opCountries (comma separated countries where it works), regions, scope (one of: "Local","National","Regional","International" or ""), beneficiaries, mission (1 to 2 sentences), languages (comma separated), largestGrant (largest grant managed, in USD, text), pastFunding (key results and funders, short). Use "" for anything the document does not clearly state. Never guess or invent.`,
        text.slice(0, 9000),
        true,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const keys = ['org', 'country', 'regCountry', 'orgType', 'taxStatus', 'founded', 'registered', 'budget', 'size', 'website', 'focus', 'populations', 'opCountries', 'scope', 'mission', 'largestGrant', 'pastFunding']
      const out: Record<string, string> = {}
      for (const k of keys) if (typeof p[k] === 'string' && p[k].trim()) out[k] = p[k].trim()
      return { ok: true as const, fields: out }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the document.') }
    }
}

export const extractProfile = createServerFn({ method: 'POST' })
  .validator((d: { text: string }) => d)
  .handler(async ({ data }) => extractProfileFromText(data.text))

export const profileFromWebsite = createServerFn({ method: 'POST' })
  .validator((d: { url: string }) => d)
  .handler(async ({ data }) => {
    let url = (data.url ?? '').trim()
    if (!url) return { ok: false as const, reason: 'Add your website address first.' }
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url
    const home = await fetchPage(url)
    if (home.error && !home.text) return { ok: false as const, reason: `I could not read that website: ${home.error}.` }
    let text = home.text
    // Add one or two pages that usually describe the organization.
    const base = new URL(url)
    const extra = home.links.filter((l) => {
      try { return new URL(l.url).hostname === base.hostname && /about|mission|who we are|our work|what we do|impact|programs?|projects?/i.test(`${l.label} ${l.url}`) } catch { return false }
    }).slice(0, 2)
    for (const l of extra) {
      const pg = await fetchPage(l.url)
      if (pg.text) text += '\n\n' + pg.text.slice(0, 5000)
    }
    text = text.trim()
    if (text.length < 200) return { ok: false as const, reason: 'The website has very little readable text (some sites load content with scripts). Upload a document instead.' }
    const r = await extractProfileFromText(text.slice(0, 12000))
    if (!r.ok) return r
    const fields = { ...r.fields }
    if (!fields.website) fields.website = url
    return { ok: true as const, fields, pages: 1 + extra.length }
  })

export const completeProfile = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; missing: string[]; options: Record<string, string[]> }) => d)
  .handler(async ({ data }) => {
    try {
      const keys = data.missing.filter((k) => ['focus', 'populations', 'scope', 'opCountries', 'grantTypes', 'orgType', 'mission'].includes(k))
      if (!keys.length) return { ok: true as const, fields: {} as Record<string, string> }
      const txt = await llm(
        `You help complete an NGO's grant-matching profile. You get the profile as it stands and a list of missing fields. Propose a value ONLY for a missing field that follows directly from facts already in the profile (its name, mission, focus, beneficiaries, past funding, regions). Never guess facts that are not supported, and never invent numbers, places, dates or funders. Return \"\" for any field you cannot support. For fields with allowed options, choose ONLY from the options given and join several with \", \". Free-text fields (mission, regions, beneficiaries, opCountries) must be short, factual and based on the profile. Reply with JSON using only these keys: ${keys.join(', ')}.`,
        `Profile: ${JSON.stringify(data.profile)}\nMissing fields: ${keys.join(', ')}\nAllowed options: ${JSON.stringify(Object.fromEntries(Object.entries(data.options).filter(([k]) => keys.includes(k))))}`,
        true,
        1200,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const out: Record<string, string> = {}
      for (const k of keys) {
        let v = typeof p[k] === 'string' ? p[k].trim() : Array.isArray(p[k]) ? p[k].join(', ') : ''
        const opts = data.options[k]
        if (v && opts?.length) v = v.split(',').map((x: string) => x.trim()).filter((x: string) => opts.includes(x)).join(', ')
        if (v) out[k] = v
      }
      return { ok: true as const, fields: out }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not complete the profile.') }
    }
  })

export const parseTemplate = createServerFn({ method: 'POST' })
  .validator((d: { text: string }) => d)
  .handler(async ({ data }) => {
    try {
      const txt = await llm(
        `You read a funder's grant application form or guidelines and reproduce its structure exactly, so an applicant can fill it in inside a portal. List every field the applicant must answer, in the order the funder asks them. Reply with JSON: {"funder": string, "overview": string (at most 120 words summarising the funder's priorities, who is eligible, how applications are scored, and any budget, length or format rules; use only what the text says), "sections": [{"group": string, "title": string, "guidance": string, "type": "text"|"yesno"|"select"|"multiselect"|"number"|"date"|"table", "options": string[], "explain": boolean, "required": boolean, "unit": string, "limit": integer, "limitUnit": "words"|"characters"|"characters_nospace", "wordLimit": integer}]}. Rules: (1) "group" is the funder's own part or heading that the field sits under (for example "Part A: Project summary" or "Section 3. Organisation"), copied as written; use "" if the form has no parts, and give consecutive fields of one part the identical group text. (2) "title" is the funder's own wording of the heading or question, kept faithful (short questions verbatim, long ones shortened without changing the meaning), with its numbering if it has one. (3) "type" reflects how the funder wants the answer given: "yesno" for yes/no, true/false or tick-one-of-two questions; "select" for a drop-down list or a choose-one list (radio buttons) with options; "multiselect" for tick-all-that-apply checkboxes; "number" for a figure, amount, count or percentage; "date" for a date; "table" when the funder asks for a table, matrix or schedule; otherwise "text" for narrative answers. (4) "options" holds the funder's exact choices in the funder's order and wording for select and multiselect (and ["Yes","No"] for yesno, or other exact labels such as "Yes","No","Not applicable" if shown); empty for other types. Never invent options that are not in the text; if a drop-down is mentioned but its list is not given, use type "text". (5) "explain" is true when the funder asks for an explanation, justification or details together with a yes/no or choice (for example "If yes, please explain"). (6) "required" is true when the form marks it as mandatory (asterisk, "required", "must"). (7) "unit" is the unit or currency for a number field ("USD", "%", "months", "people") or "". (8) "guidance" is the funder's instruction for the field, condensed to at most 2 sentences (include required content and criteria). (9) "limit" is the funder\'s stated maximum length of the answer as a number (0 if none) and "limitUnit" is "words", "characters" (with spaces, also when the funder just says characters) or "characters_nospace" (when the funder says excluding spaces); copy the funder\'s own number and unit exactly, never convert them. "wordLimit" is the same limit converted to words (characters / 6), or 0 if none. (10) Include every answerable field, including budget, timeline, eligibility and declaration questions with yes/no or choices. Exclude only pure identity fields such as contact details, addresses, signatures and bank details, and instructions that ask nothing. Never invent fields that are not in the text. Maximum 45 fields.`,
        data.text.slice(0, 20000),
        true,
        6000,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const types = ['text', 'yesno', 'select', 'multiselect', 'number', 'date', 'table']
      const sections = (Array.isArray(p.sections) ? p.sections : [])
        .map((x: any) => {
          let type = types.includes(String(x.type)) ? String(x.type) : 'text'
          let options: string[] = (Array.isArray(x.options) ? x.options : []).map((o: any) => String(o).trim().slice(0, 120)).filter(Boolean).slice(0, 40)
          if (type === 'yesno' && options.length < 2) options = ['Yes', 'No']
          if ((type === 'select' || type === 'multiselect') && options.length < 2) type = 'text'
          if (type !== 'select' && type !== 'multiselect' && type !== 'yesno') options = []
          return {
            group: String(x.group ?? '').trim().slice(0, 140),
            title: String(x.title ?? '').trim().slice(0, 200),
            guidance: String(x.guidance ?? '').trim().slice(0, 600),
            wordLimit: Math.max(0, Math.round(Number(x.wordLimit) || 0)) || (Number(x.limit) > 0 ? Math.round(Number(x.limit) / (x.limitUnit === 'characters_nospace' ? 4.6 : x.limitUnit === 'characters' ? 5.5 : 1)) : 0),
            limit: Math.max(0, Math.round(Number(x.limit) || 0)),
            limitUnit: ['words', 'characters', 'characters_nospace'].includes(String(x.limitUnit)) ? String(x.limitUnit) : 'words',
            type,
            options,
            explain: x.explain === true,
            required: x.required === true,
            unit: String(x.unit ?? '').trim().slice(0, 20),
          }
        })
        .filter((x: any) => x.title)
        .slice(0, 45)
      if (!sections.length) return { ok: false as const, reason: 'I could not find application sections in that document.' }
      return { ok: true as const, funder: String(p.funder ?? '').slice(0, 120), overview: String(p.overview ?? '').trim().slice(0, 900), sections }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the template.') }
    }
  })

export const suggestAnswer = createServerFn({ method: 'POST' })
  .validator((d: { question: string; guidance?: string; type: string; options: string[]; unit?: string; explain?: boolean; context: string }) => d)
  .handler(async ({ data }) => {
    try {
      const opts = data.options ?? []
      const out = await llm(
        'You help an NGO complete a funder\'s application form. Answer ONE form field using only facts in the applicant\'s information below. Reply with JSON only: {"value": string|string[], "explanation": string, "confident": boolean}. Rules: for "yesno" and "select" give exactly one of the allowed options, copied exactly; for "multiselect" give an array of allowed options, copied exactly; for "number" give only the number (no unit, no thousands separators); for "date" give YYYY-MM-DD; "explanation" is 1 to 3 precise sentences justifying the answer from the information (empty if no explanation is needed). If the information does not support an answer, set "confident" to false, give the most cautious option and say in "explanation" what the applicant must check. Never invent facts.',
        `Field: ${data.question}\nType: ${data.type}\n${opts.length ? 'Allowed options: ' + opts.map((o) => `"${o}"`).join(', ') + '\n' : ''}${data.unit ? 'Unit: ' + data.unit + '\n' : ''}${data.guidance ? "Funder's instruction: " + data.guidance + '\n' : ''}${data.explain ? 'The funder also asks for an explanation.\n' : ''}\nAPPLICANT INFORMATION:\n${data.context.slice(0, 9000)}`,
        true,
        700,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(out)
      const pick = (v: any) => matchTitle(opts, String(v ?? ''))
      let value = ''
      if (data.type === 'multiselect') value = (Array.isArray(p.value) ? p.value : String(p.value ?? '').split(/[;,]/)).map(pick).filter(Boolean).filter((x: string, i: number, a: string[]) => a.indexOf(x) === i).join('; ')
      else if (data.type === 'yesno' || data.type === 'select') value = pick(Array.isArray(p.value) ? p.value[0] : p.value)
      else if (data.type === 'number') { const n = String(p.value ?? '').replace(/[^0-9.\-]/g, ''); value = n }
      else value = String(Array.isArray(p.value) ? p.value[0] : p.value ?? '').trim().slice(0, 40)
      return { ok: true as const, value, explanation: tidyText(String(p.explanation ?? '').trim().slice(0, 600)), confident: p.confident !== false }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not suggest an answer.') }
    }
  })

export type GrantGuidance = {
  funder: string
  summary: string
  priorities: string[]
  eligibility: string[]
  criteria: string[]
  budget: string[]
  format: string[]
  dates: string[]
  checks: string[]
  limits?: { section: string; limit: number; unit: 'words' | 'characters' | 'characters_nospace' }[]
}

export const analyzeGuidance = createServerFn({ method: 'POST' })
  .validator((d: { text: string; profile: Profile }) => d)
  .handler(async ({ data }) => {
    try {
      const pr = data.profile
      const txt = await llm(
        `You read a funder's grant guidance (call for proposals, guidelines, eligibility rules or scoring criteria) and extract what an applicant must know. Reply with JSON using only these keys: funder (string), summary (at most 80 words, plain English), priorities (string[]: themes, sectors and outcomes the funder wants), eligibility (string[]: who may apply, countries, legal status, partnerships), criteria (string[]: how applications are assessed, with weights if stated), budget (string[]: award size, co-funding, allowed and excluded costs, indirect cost limits), format (string[]: length, language, required attachments, structure), dates (string[]: deadlines and key dates, as written), checks (string[]: places where the applicant organization described below may not meet a stated requirement, or must prepare something; empty if none). limits (array of {"section": string, "limit": integer, "unit": "words"|"characters"|"characters_nospace"}: every length limit the guidance states for a named section or answer, with the funder\'s own number and unit; use section "" for a limit that applies to every section or the whole proposal; empty array if none). Each list has at most 8 short items. Use ONLY what the text says. Never invent facts, dates, amounts or rules. Use an empty list when the text does not say.`,
        `Applicant organization: ${JSON.stringify({ country: pr.country, registeredIn: pr.regCountry, type: pr.orgType, registered: pr.registered, budget: pr.budget, compliance: pr.compliance, sectors: pr.focus })}\n\nGuidance text:\n${data.text.slice(0, 10000)}`,
        true,
        2000,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const list = (v: any) => (Array.isArray(v) ? v : []).map((x: any) => String(x).trim().slice(0, 240)).filter(Boolean).slice(0, 8)
      const g: GrantGuidance = {
        funder: String(p.funder ?? '').trim().slice(0, 120),
        summary: String(p.summary ?? '').trim().slice(0, 700),
        priorities: list(p.priorities), eligibility: list(p.eligibility), criteria: list(p.criteria),
        budget: list(p.budget), format: list(p.format), dates: list(p.dates), checks: list(p.checks),
        limits: (Array.isArray(p.limits) ? p.limits : []).map((x: any) => ({ section: String(x.section ?? '').trim().slice(0, 140), limit: Math.round(Number(x.limit) || 0), unit: (['words', 'characters', 'characters_nospace'].includes(String(x.unit)) ? String(x.unit) : 'words') as 'words' | 'characters' | 'characters_nospace' })).filter((x: any) => x.limit > 0).slice(0, 30),
      }
      const any = g.summary || g.priorities.length || g.eligibility.length || g.criteria.length || g.budget.length
      if (!any) return { ok: false as const, reason: 'I could not find grant guidance in that document.' }
      return { ok: true as const, guidance: g }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the guidance.') }
    }
  })

export type EligibilityItem = { requirement: string; status: 'met' | 'not_met' | 'document' | 'unclear'; evidence: string; action: string }

export const eligibilityChecklist = createServerFn({ method: 'POST' })
  .validator((d: { text: string; profile: Profile; library?: string }) => d)
  .handler(async ({ data }) => {
    try {
      const txt = await llm(
        `You check a grant's eligibility rules against an organization's profile. The text below is the funder's guidance, the funder's website page, or both (the website is marked FUNDER WEBSITE). From it, list each eligibility requirement: who may apply, countries, legal status and registration, organization type, age or track record, budget size, partnerships or consortium rules, co-funding, required documents, policies and systems. For each one judge it using ONLY the organization profile: status "met" (the profile clearly satisfies it), "not_met" (the profile clearly conflicts with it), "document" (it is a document, registration or policy the profile does not show), or "unclear" (the profile lacks the information). evidence is one short sentence naming the profile detail or saying what is missing. action is one short step the applicant should take (empty when met). Reply with JSON: {"items":[{"requirement":string,"status":string,"evidence":string,"action":string}]}. At most 25 items. Never invent requirements that the text does not state.`,
        `Organization profile: ${JSON.stringify(data.profile)}\n${data.library ? `\nThe organization's own documents on file (use them as evidence: say which document proves a requirement, and flag a missing or expired one):\n${data.library.slice(0, 1800)}\n` : ''}\nGuidance text:\n${data.text.slice(0, 9000)}`,
        true,
        2600,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const ok = ['met', 'not_met', 'document', 'unclear']
      const items: EligibilityItem[] = (Array.isArray(p.items) ? p.items : [])
        .map((x: any) => ({ requirement: String(x.requirement ?? '').trim().slice(0, 300), status: ok.includes(x.status) ? x.status : 'unclear', evidence: String(x.evidence ?? '').trim().slice(0, 300), action: String(x.action ?? '').trim().slice(0, 300) }))
        .filter((x: EligibilityItem) => x.requirement)
        .slice(0, 25)
      if (!items.length) return { ok: false as const, reason: 'I could not find eligibility requirements in the guidance.' }
      return { ok: true as const, items }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not prepare the checklist.') }
    }
  })

export type FrameworkOptions = { priorities: string[]; objectives: string[]; subObjectives: string[]; outcomes: string[]; outputs: string[]; activities: string[]; indicators: string[]; budgetCeilings: string[] }

export const extractFramework = createServerFn({ method: 'POST' })
  .validator((d: { text: string }) => d)
  .handler(async ({ data }) => {
    try {
      const txt = await llm(
        `You read a funder's grant guidance or website page (marked FUNDER WEBSITE) and list its results framework so an applicant can choose what their project contributes to. Reply with JSON using only these keys, each a list of short strings in the funder's own wording: priorities (funding priorities, themes, focus areas), objectives (general and specific objectives), subObjectives (sub-objectives or result areas under the objectives), outcomes (expected outcomes or results), outputs (expected outputs or deliverables), activities (eligible or example activities), indicators (indicators or measures the funder names), budgetCeilings (budget limits: maximum or minimum award, indirect cost cap, co-funding share, per-category caps, duration limits, each written as a clear sentence with the figure). At most 20 items per list and at most 200 characters per item. Use ONLY what the text says. Use an empty list when the text does not say. Never invent items.`,
        data.text.slice(0, 10000),
        true,
        2600,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const list = (v: any) => [...new Set((Array.isArray(v) ? v : []).map((x: any) => String(x).trim().slice(0, 200)).filter(Boolean))].slice(0, 20)
      const o: FrameworkOptions = { priorities: list(p.priorities), objectives: list(p.objectives), subObjectives: list(p.subObjectives), outcomes: list(p.outcomes), outputs: list(p.outputs), activities: list(p.activities), indicators: list(p.indicators), budgetCeilings: list(p.budgetCeilings) }
      if (!Object.values(o).some((v) => v.length)) return { ok: false as const, reason: 'I could not find a priorities and objectives framework in the guidance.' }
      return { ok: true as const, options: o }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not read the framework.') }
    }
  })

function blockedHost(h: string) {
  const x = h.toLowerCase()
  return (
    !x.includes('.') ||
    x === 'localhost' ||
    x.endsWith('.local') ||
    x.endsWith('.internal') ||
    x.startsWith('[') ||
    /^(127\.|10\.|0\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(x)
  )
}

function htmlToText(html: string) {
  return html
    .replace(/<(script|style|noscript|svg|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<\/(p|div|li|h[1-6]|tr|br|section|article)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&[a-z]+;/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim()
}

export const addGrantFromLink = createServerFn({ method: 'POST' })
  .validator((d: { url?: string; text?: string }) => d)
  .handler(async ({ data }) => {
    let url = (data.url ?? '').trim()
    let text = (data.text ?? '').trim()
    if (url && !/^https?:\/\//i.test(url)) url = 'https://' + url
    let u: URL | null = null
    if (url) {
      try {
        u = new URL(url)
      } catch {
        return { ok: false as const, reason: 'That does not look like a valid link.' }
      }
      if (blockedHost(u.hostname)) return { ok: false as const, reason: 'That link cannot be opened.' }
    }
    if (!text && u) {
      try {
        const r = await fetch(u.toString(), {
          redirect: 'follow',
          headers: { 'user-agent': 'Mozilla/5.0 (compatible; GrantsWriterBot/1.0)', accept: 'text/html,application/xhtml+xml,text/plain', 'x-whop-inject-key': 'none' },
        })
        if (!r.ok) return { ok: false as const, reason: `The website answered with error ${r.status}. Paste the page text instead.` }
        const ct = r.headers.get('content-type') ?? ''
        if (/pdf|word|octet/i.test(ct)) return { ok: false as const, reason: 'That link is a file download. Download it and use the template import, or paste the text here.' }
        const raw = (await r.text()).slice(0, 1_500_000)
        text = /html/i.test(ct) || raw.trimStart().startsWith('<') ? htmlToText(raw) : raw
      } catch {
        return { ok: false as const, reason: 'I could not open that page. Paste the page text instead.' }
      }
    }
    if (text.length < 1500 && /verify (?:you are|that you are) (?:a )?human|captcha|access denied|just a moment|enable javascript|checking your browser/i.test(text)) return { ok: false as const, reason: 'That website blocks automatic reading. Open the page, copy its text and paste it into the field instead.' }
    if (text.length < 1500 && /verify (?:you are|that you are) (?:a )?human|captcha|access denied|just a moment|enable javascript|checking your browser/i.test(text)) return { ok: false as const, reason: 'That website blocks automatic reading. Open the page, copy its text and paste it into the field instead.' }
    if (text.length < 200) return { ok: false as const, reason: 'The page has very little readable text (some sites load their content with scripts). Paste the page text instead.' }
    try {
      const out = await llm(
        `You read a grant or funding opportunity web page and extract its facts. Reply with JSON: {"title": string, "funder": string, "deadline": string (YYYY-MM-DD if a date is stated, otherwise "Not stated"), "status": "open" | "forthcoming" | "closed" | "unknown", "amount": string, "eligibility": string (who can apply, max 3 sentences), "summary": string (what it funds and priorities, max 3 sentences), "countries": string[] (countries or regions whose organizations can apply, [\"Global\"] if open to all, [] if not stated), "type": string (for example Grant, Fellowship, Prize, Loan, Cooperative agreement), "sectors": string[] (from: ${SECTOR_LIST.join(', ')}), "amountMin": number (USD, 0 if not stated or not in USD), "amountMax": number (USD, 0 if not stated or not in USD), "isGrant": boolean}. Use only what the page says. Set isGrant true for any page that describes funding, a grant programme, a call for proposals or applications, a fellowship, award, prize, tender or funding window, even if it is a general programme page or some details are missing. Set isGrant false only when the page is clearly unrelated to funding, such as a news story, a shop or a login page.`,
        text.slice(0, 9000),
        true,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(out)
      // The AI can be too strict with programme pages, so a page that talks a lot about funding is accepted anyway.
      const fundingHits = (text.match(/\b(grants?|funding|funds?|fellowships?|call for (?:proposals|applications|concept notes)|awards?|rfp|rfa|apply|applicants?|deadline|eligib\w+|scholarships?|prizes?|financing|tenders?)\b/gi) ?? []).length
      if (p.isGrant === false && fundingHits < 6) return { ok: false as const, reason: 'That page does not look like a grant or funding opportunity. If it is one, paste the page text into the field instead.' }
      const host = u?.hostname.replace(/^www\./, '') ?? 'pasted text'
      let h = 0
      for (const ch of url || text.slice(0, 200)) h = (h * 31 + ch.charCodeAt(0)) | 0
      const summary = [p.summary, p.eligibility && 'Eligibility: ' + p.eligibility, p.amount && p.amount !== 'Not stated' && 'Amount: ' + p.amount].filter(Boolean).join(' ')
      const grant: Grant = {
        id: 'link-' + Math.abs(h).toString(36),
        title: String(p.title || host).slice(0, 200),
        funder: String(p.funder || host).slice(0, 120),
        source: 'Added by link',
        deadline: String(p.deadline || 'Not stated'),
        status: String(p.status || 'unknown'),
        url: url || '',
        summary: summary.slice(0, 900),
        details: text.slice(0, 4000),
        countries: (Array.isArray(p.countries) ? p.countries : []).map((x: any) => String(x).slice(0, 60)).slice(0, 12),
        gtype: String(p.type || '').slice(0, 40) || undefined,
        sectors: (Array.isArray(p.sectors) ? p.sectors : []).filter((x: any) => SECTOR_LIST.includes(x)).slice(0, 4),
        amountMin: Number(p.amountMin) > 0 ? Number(p.amountMin) : undefined,
        amountMax: Number(p.amountMax) > 0 ? Number(p.amountMax) : undefined,
        inviteOnly: p.inviteOnly === true ? true : undefined,
      }
      return { ok: true as const, grant }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the page.') }
    }
  })

export type GrantDetail = {
  funder: string
  deadline: string
  amount: string
  amountNote: string
  countries: string[]
  sectors: string[]
  eligibility: string[]
  applicationSummary: string
  effort: string
  steps: string[]
  requiredDocuments: string[]
  contact: string
  reporting: string
  execution: { staffing: string; expertise: string; facilities: string; partners: string; scale: string }
  capacityGaps: string[]
  addToProfile: string[]
  fitSummary: string
  funderContact: { email: string; phone: string; address: string; website: string; registration: string }
  leadership: string[]
  requirements: string[]
  howToApply: string[]
  importantDates: string[]
  additionalNotes: string[]
  links: { label: string; url: string }[]
  sourceNote: string
}

async function fetchPage(url: string): Promise<{ text: string; links: { label: string; url: string }[]; error?: string }> {
  let u: URL
  try {
    u = new URL(url)
  } catch {
    return { text: '', links: [], error: 'invalid link' }
  }
  if (!/^https?:$/.test(u.protocol) || blockedHost(u.hostname)) return { text: '', links: [], error: 'blocked link' }
  try {
    const r = await fetch(u.toString(), {
      redirect: 'follow',
      headers: { 'user-agent': 'Mozilla/5.0 (compatible; GrantsWriterBot/1.0)', accept: 'text/html,application/xhtml+xml,text/plain', 'x-whop-inject-key': 'none' },
    })
    if (!r.ok) return { text: '', links: [], error: `the page answered with error ${r.status}` }
    const ct = r.headers.get('content-type') ?? ''
    if (/pdf|word|octet/i.test(ct)) return { text: '', links: [], error: 'the link is a file download' }
    const raw = (await r.text()).slice(0, 1_500_000)
    const isHtml = /html/i.test(ct) || raw.trimStart().startsWith('<')
    const links: { label: string; url: string }[] = []
    if (isHtml) {
      const re = /<a\s[^>]*href=["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi
      let m: RegExpExecArray | null
      const seen = new Set<string>()
      while ((m = re.exec(raw)) && links.length < 60) {
        try {
          const abs = new URL(m[1], u).toString()
          const label = htmlToText(m[2]).slice(0, 80)
          if (!/^https?:/.test(abs) || seen.has(abs) || !label) continue
          seen.add(abs)
          links.push({ label, url: abs })
        } catch {}
      }
    }
    return { text: isHtml ? htmlToText(raw) : raw, links }
  } catch {
    return { text: '', links: [], error: 'the page could not be opened' }
  }
}

export async function runReadGrantLink(data: { url: string }) {
    let url = (data.url ?? '').trim()
    if (url && !/^https?:\/\//i.test(url)) url = 'https://' + url
    const first = await fetchPage(url)
    if (first.error || first.text.trim().length < 200) {
      return { ok: false as const, reason: first.error ? `I could not read that link: ${first.error}.` : 'That page has too little text to read. If it is a PDF or needs a login, import the guidance file instead.' }
    }
    let text = first.text.replace(/\s+/g, ' ').trim().slice(0, 7000)
    // Pages that usually hold the rules: eligibility, guidelines, criteria, priorities, budget.
    const base = new URL(url)
    const extra = first.links
      .filter((l) => /eligib|guideline|criteri|priorit|who can apply|how to apply|call for|budget|funding rules|terms/i.test(l.label) && new URL(l.url).hostname === base.hostname && l.url.split('#')[0] !== url.split('#')[0])
      .slice(0, 2)
    for (const l of extra) {
      const pg = await fetchPage(l.url)
      if (!pg.error && pg.text.trim().length > 200) text += `\n\nLINKED PAGE "${l.label}" (${l.url}):\n` + pg.text.replace(/\s+/g, ' ').trim().slice(0, 4000)
    }
    return { ok: true as const, text: text.slice(0, 14000), pages: 1 + extra.length }
}

export const readGrantLink = createServerFn({ method: 'POST' })
  .validator((d: { url: string }) => d)
  .handler(async ({ data }) => runReadGrantLink(data))

type ProjectDocInput = { kind: DocKind; variant?: string; profile: Profile; proposal: string; title: string; amount?: string; months?: string; funder?: string; framework?: string; instruction?: string }

const DOC_BRIEFS: Record<string, string> = {
  meal: 'Prepare the project\'s MEAL (monitoring, evaluation, accountability and learning) plan. Use these headings, each as a line starting with "## ": 1. Purpose and approach; 2. Indicator performance tracking table (ONE markdown table with the header "| Level | Indicator | Definition and unit | Baseline | Target | Data source | Method | Frequency | Responsible |", covering every outcome and output of the proposal, with SMART indicators and targets that match the proposal\'s figures); 3. Data collection, quality assurance and management; 4. Evaluation plan (baseline, midline and endline or final evaluation, timing and method); 5. Accountability and feedback mechanism (including safeguarding and complaints); 6. Learning plan (review meetings, reflection and how findings change the work); 7. MEAL roles and responsibilities (a table); 8. MEAL calendar by month (a table) and the MEAL share of the budget.',
  logframe: 'Prepare the project\'s logical framework (logframe). Start with ONE markdown table with the header "| Level | Narrative summary | Indicators (with baseline and target) | Means of verification | Assumptions and risks |" and rows for: Goal (impact), each Outcome, each Output under its outcome, and the main Activities under each output. Number them (Outcome 1, Output 1.1, Activity 1.1.1). Take the goal, outcomes, outputs, activities and figures from the proposal. After the table add a "## " heading "Key assumptions and risks" with a short table "| Risk | Likelihood | Impact | Mitigation |".',
  matrix: 'Prepare the project\'s Activities Matrix, with the budget at the level of each activity. Use "## " headings. 1. Overview: two sentences naming the project goal, its outcomes, the number of activities and the total budget. 2. Activities matrix: ONE markdown table with the header "| # | Outcome or output | Activity | Key tasks | Location | Target group and number | Responsible | Partners | Start month | End month | Expected output | Linked indicator | Budget (USD) | Share of budget |", one row for EVERY activity of the proposal, numbered 1.1, 1.2, 2.1 and so on under its outcome or output, in logical order, with locations, numbers and months taken from the proposal and whole-number months between 1 and the project duration. The Budget (USD) of each activity is its cost taken from the proposal\'s budget (its activity subtotal; when the budget is not organised by activity, allocate the budget lines to the activity they serve and say so in the notes). Add a final row "**Direct costs**", a row for indirect and administrative costs if the budget has them, and a row "**TOTAL**" that equals the total budget. Shares are percentages of the total and must add up to 100%. 3. Narrative budget breakdown by activity: for EVERY activity, in the same order, a heading "## Activity <number>: <name> (<amount> USD)", then ONE short paragraph that explains what the money is spent on and why it is needed to deliver the activity, followed by a table "| Cost item | Unit | Qty | Unit cost (USD) | Total (USD) |" listing its cost lines (Qty x Unit cost = Total) and a final row "**Subtotal**". The lines of an activity must add up exactly to the amount in the matrix; use the budget\'s own cost lines when they exist, otherwise derive realistic lines from the activity and the budget total. 4. Dependencies and sequencing: a short bullet list of which activities must finish before others start. 5. Assumptions and risks: a table "| Activity | Assumption or risk | Mitigation |", and a short note on the budget assumptions (rates, exchange rate, indirect rate). Use [bracketed placeholders] for anything the proposal does not state, and never contradict the budget.',
  implementation: 'Prepare the project\'s implementation plan. Use "## " headings: 1. Implementation approach (a short paragraph); 2. Detailed work plan: ONE markdown table with the header "| # | Activity | Key tasks | Responsible | Start month | End month | Output or deliverable | Resources |", one row per activity of the proposal in logical order, months as whole numbers between 1 and the project duration; 3. Key milestones (a table "| Milestone | Month | Verification |"); 4. Management and coordination arrangements (roles, meetings, decision making, reporting lines); 5. Risk management (a table "| Risk | Mitigation | Owner |"); 6. Procurement and partner arrangements where the proposal implies them.',
}

const TOOL_BRIEF = (label: string) =>
  `Prepare a complete, ready-to-use MEAL data collection tool: "${label}". It must be built for THIS project: use the project's own beneficiaries, locations, activities and indicators from the proposal, and link each question or field to the indicator it measures. Include: purpose and target respondents; how and when to use it; an informed-consent and confidentiality script; the questions or fields in numbered order with answer options (closed questions use tables or lists of choices, open questions leave space); skip logic where needed; enumerator or facilitator instructions; and, at the end, a short table "| Indicator | Question or field | How it is analysed |". Use "## " for headings and markdown tables where useful.`

const REPORT_BRIEF = (label: string) =>
  `Prepare a complete, ready-to-fill reporting template: "${label}". Build it for THIS project: follow the proposal's outcomes, outputs, activities, indicators, targets, timeline and budget lines so the person filling it in reports against the plan. Include a cover block (project title, organization, funder, reporting period, prepared by, date), sections with guidance prompts in brackets such as [describe progress against Activity 1], progress tables with "planned / achieved / % achieved" columns for each indicator and activity, challenges and mitigation, lessons learned, beneficiary and gender-disaggregated data where relevant, and next steps. For a financial report include a budget versus actual table by budget line with variance and a comment column. Use "## " for headings and markdown tables.`

export async function runGenerateProjectDoc(data: ProjectDocInput) {
  try {
    if (data.kind === 'tool' && data.variant === 'indicator-tracker') {
      const months = Math.max(1, Number(data.months) || 12)
      const periods = Math.min(12, Math.max(1, Math.ceil(months / 3)))
      const sys = `You are a senior MEAL specialist. Build the project's Indicator Performance Tracking Table (IPTT) from the written proposal. Reply with JSON only: {"indicators":[{"level":"Goal"|"Outcome"|"Output","indicator":string,"definition":string,"unit":string,"disaggregation":string,"baseline":string,"target":number,"periodTargets":number[],"source":string,"method":string,"frequency":string,"responsible":string}],"notes":string}. Rules: (1) Cover the goal, every outcome and every output of the proposal, with 1 or 2 SMART indicators each; 8 to 25 indicators in total, ordered by level (Goal, Outcomes, then Outputs under their outcome). (2) Name each indicator so that it shows the outcome or output it belongs to, for example "Outcome 1: % of farmers adopting two or more practices". (3) "target" is the life-of-project target as a number taken from the proposal's figures (a percentage is the number, for example 60 for 60%; a count is the count). (4) "periodTargets" has exactly ${periods} numbers, the planned result for each quarter of the ${months}-month project; for cumulative counts they add up to the target; for percentages they are the planned level reached by that quarter. (5) "baseline" is a value or "[to be collected]" when unknown. (6) "unit" is number, %, USD or similar. (7) "source", "method", "frequency" and "responsible" are concrete, for example "Attendance sheets", "Participant registration", "Per activity", "M&E officer". (8) Never invent facts about the organization. notes: one sentence.`
      const usr = `Project title: ${data.title || 'not set'}\nOrganization: ${JSON.stringify(Object.fromEntries(Object.entries(data.profile).filter(([, v]) => v !== '' && v != null)))}\n${data.funder ? 'Funder: ' + data.funder + '\n' : ''}Duration: ${months} months (${periods} quarters)\n${data.framework ? 'Funder framework: ' + data.framework.slice(0, 1200) + '\n' : ''}\nWRITTEN PROJECT PROPOSAL:\n${data.proposal.slice(0, 9000)}`
      const raw = await llm(sys, usr, true, 3600)
      if (!raw) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(raw)
      const num = (v: any) => { const n = Number(String(v ?? '').replace(/[^0-9.\-]/g, '')); return Number.isFinite(n) ? n : 0 }
      const list = (Array.isArray(p.indicators) ? p.indicators : Array.isArray(p.items) ? p.items : [])
        .map((x: any) => {
          const pt = (Array.isArray(x.periodTargets) ? x.periodTargets : []).map(num).slice(0, periods)
          while (pt.length < periods) pt.push(0)
          return {
            level: /goal|impact/i.test(String(x.level)) ? 'Goal' : /out(put)/i.test(String(x.level)) ? 'Output' : 'Outcome',
            indicator: String(x.indicator ?? '').trim().slice(0, 300),
            definition: String(x.definition ?? '').trim().slice(0, 300),
            unit: String(x.unit ?? '').trim().slice(0, 30),
            disaggregation: String(x.disaggregation ?? '').trim().slice(0, 120),
            baseline: String(x.baseline ?? '[to be collected]').trim().slice(0, 60),
            target: num(x.target),
            periodTargets: pt,
            source: String(x.source ?? '').trim().slice(0, 150),
            method: String(x.method ?? '').trim().slice(0, 150),
            frequency: String(x.frequency ?? '').trim().slice(0, 60),
            responsible: String(x.responsible ?? '').trim().slice(0, 80),
          }
        })
        .filter((x: any) => x.indicator)
        .slice(0, 30)
      if (!list.length) return { ok: false as const, reason: 'The AI did not return usable indicators. Try again.' }
      const c = (t: string) => t.replace(/\|/g, '/')
      const head = ['#', 'Level', 'Indicator', 'Definition and unit', 'Baseline', 'Target (project)', ...Array.from({ length: periods }, (_, i) => `Q${i + 1} target`), 'Data source', 'Method', 'Frequency', 'Responsible']
      const rows = [`| ${head.join(' | ')} |`, `|${head.map(() => '---').join('|')}|`]
      list.forEach((x: any, i: number) => rows.push(`| ${i + 1} | ${x.level} | ${c(x.indicator)} | ${c([x.definition, x.unit].filter(Boolean).join(' (') + (x.definition && x.unit ? ')' : ''))} | ${c(x.baseline)} | ${x.target} | ${x.periodTargets.join(' | ')} | ${c(x.source)} | ${c(x.method)} | ${c(x.frequency)} | ${c(x.responsible)} |`))
      const text = `Indicator Performance Tracking Table (IPTT) for ${data.title || 'the project'}. Targets are taken from the proposal. Download the Excel file to record actual results each quarter: the totals and the percentage of the target are calculated automatically.\n\n${rows.join('\n')}${p.notes ? '\n\n' + String(p.notes).slice(0, 300) : ''}`
      return { ok: true as const, text: tidyText(text), data: JSON.stringify({ periods, indicators: list }) }
    }
    const tool = MEAL_TOOLS.find((t) => t.id === data.variant)
    const rep = REPORT_TEMPLATES.find((t) => t.id === data.variant)
    const brief = data.kind === 'tool' ? TOOL_BRIEF(tool?.label ?? 'Data collection tool') : data.kind === 'report' ? REPORT_BRIEF(rep?.label ?? 'Reporting template') : DOC_BRIEFS[data.kind]
    if (!brief) return { ok: false as const, reason: 'Unknown document type.' }
    const system = `You are a senior monitoring, evaluation, accountability and learning (MEAL) and programme management specialist for NGOs and donor-funded projects. You prepare documents that fit the funder's requirements and match the written project proposal exactly: the same activities, outcomes, outputs, indicators, targets, locations, beneficiaries, timeline and budget. Never contradict the proposal and never invent facts about the organization; use [bracketed placeholders] where information is missing. Write in plain professional English. Formatting: headings are lines starting with "## "; tables use markdown pipe format with a header row and a separator row; bullets start with "- "; do not use asterisks, bold or code fences. Do not repeat the instructions. ${brief}`
    const user = `Project title: ${data.title || 'not set'}\nOrganization: ${JSON.stringify(Object.fromEntries(Object.entries(data.profile).filter(([, v]) => v !== '' && v != null)))}\n${data.funder ? 'Funder: ' + data.funder + '\n' : ''}Duration: ${data.months || '12'} months\nAmount requested: ${data.amount || 'not set'} USD\n${data.framework ? 'Funder framework the project responds to: ' + data.framework.slice(0, 1200) + '\n' : ''}\n${data.instruction?.trim() ? `APPLICANT'S INSTRUCTIONS FOR THIS DOCUMENT (follow them, as long as they do not contradict the proposal): ${data.instruction.trim().slice(0, 800)}\n` : ''}\nWRITTEN PROJECT PROPOSAL (the source for everything above):\n${data.proposal.slice(0, data.kind === 'matrix' ? 15000 : 9000)}`
    const txt = await llm(system, user, false, data.kind === 'matrix' ? 6500 : data.kind === 'tool' || data.kind === 'report' ? 3200 : 3600)
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    return { ok: true as const, text: tidyText(txt.trim()).replace(/\s*<br\s*\/?>\s*/gi, '; ').replace(/;\s*•/g, ' •') }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not prepare the document.') }
  }
}

export const generateProjectDoc = createServerFn({ method: 'POST' })
  .validator((d: ProjectDocInput) => d)
  .handler(async ({ data }) => runGenerateProjectDoc(data))

export async function runDetectLibraryDoc(data: { name: string; text: string; types: string[] }) {
  try {
    const txt = await llm(
      `You classify an organization's document for a grants library. Reply with JSON only: {"type": string, "issued": string, "expiry": string, "notes": string, "facts": string}. "type" must be exactly one of: ${data.types.join(' | ')}. "issued" and "expiry" are dates as YYYY-MM-DD, or "" when the document does not clearly state them (expiry is the validity end date, not the financial year end unless it is the only date). "notes" is at most 100 characters: what the document is, the period it covers or the issuing body. "facts" is at most 450 characters of the key facts about the ORGANIZATION that the document states: legal name, registration number and year, country, annual budget or income, sectors, regions or countries of work, beneficiaries reached, past funders and projects, staff numbers, policies it holds. Use only what the document says, and leave out anything not stated: never write what is missing or absent. Never invent dates.`,
      `File name: ${data.name}\n\nStart of the document:\n${data.text.slice(0, 4500)}`,
      true,
      800,
      0,
    )
    if (!txt) return { ok: false as const }
    const p = parseJson(txt)
    const date = (v: any) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '').trim()) ? String(v).trim() : '')
    return { ok: true as const, type: data.types.includes(p.type) ? String(p.type) : '', issued: date(p.issued), expiry: date(p.expiry), notes: String(p.notes ?? '').trim().slice(0, 140), facts: String(p.facts ?? '').trim().slice(0, 600) }
  } catch {
    return { ok: false as const }
  }
}

export const detectLibraryDoc = createServerFn({ method: 'POST' })
  .validator((d: { name: string; text: string; types: string[] }) => d)
  .handler(async ({ data }) => runDetectLibraryDoc(data))

export type SourceItem = { claim: string; section: string; source: string; year: string; sourced: boolean }

export async function runExtractSources(data: { parts: { title: string; text: string }[] }) {
  try {
    const body = data.parts.map((p) => `## ${p.title}\n${p.text.slice(0, 1800)}`).join('\n\n').slice(0, 9500)
    if (body.trim().length < 80) return { ok: false as const, reason: 'Write the needs assessment or some sections first, then look for the statistics and sources.' }
    const txt = await llm(
      'You audit a grant proposal for evidence. Find every factual claim that rests on outside data: statistics, percentages, counts of people or places, rates, dates of surveys and named studies. Do NOT list the applicant\'s own project targets or plans (for example "we will train 40 trainers"). Reply with JSON only: {"items":[{"claim":string,"section":string,"source":string,"year":string,"sourced":boolean}]}. "claim" is the statistic as written, at most 140 characters. "section" is the exact section title it appears in. "source" is the source exactly as the text names it (organization, survey, report, study), or "" when the text names none. "year" is the year the text gives, or "". "sourced" is true only when the text itself names a source. Never invent a source or a year. At most 30 items, most important first.',
      body,
      true,
      2600,
      0,
    )
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    const p = parseJson(txt)
    const items: SourceItem[] = (Array.isArray(p.items) ? p.items : [])
      .map((x: any) => ({ claim: String(x.claim ?? '').trim().slice(0, 200), section: String(x.section ?? '').trim().slice(0, 120), source: String(x.source ?? '').trim().slice(0, 200), year: String(x.year ?? '').replace(/[^0-9]/g, '').slice(0, 4), sourced: x.sourced === true && String(x.source ?? '').trim().length > 1 }))
      .filter((x: SourceItem) => x.claim)
      .slice(0, 30)
    return { ok: true as const, items }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not scan the proposal.') }
  }
}

export const extractSources = createServerFn({ method: 'POST' })
  .validator((d: { parts: { title: string; text: string }[] }) => d)
  .handler(async ({ data }) => runExtractSources(data))

export async function runProjectTitles(data: { mode: 'suggest' | 'improve'; current: string; context: string }) {
  try {
    const suggest = data.mode === 'suggest'
    const txt = await llm(
      `You name grant-funded projects. Reply with JSON only: {"titles": string[]}. ${suggest ? 'Give exactly 4 different titles.' : 'Give exactly 1 title: an improved version of the current title.'} Rules: each title is specific and outcome-focused, 6 to 14 words, names the main change or approach plus the target group or place when they are known, uses the funder's own vocabulary and priorities, and sounds professional. No quotation marks, no colons unless it reads naturally, no invented facts, no acronyms unless they come from the context. ${suggest ? 'Make the four titles clearly different in angle: for example one outcome-led, one approach-led, one place-led, one group-led.' : 'Keep the intent of the current title, and sharpen it using what the written proposal now says. If the current title is already strong, change it only a little.'}`,
      `${data.current ? 'Current title: ' + data.current + '\n' : ''}${data.context.slice(0, 5000)}`,
      true,
      500,
      0.5,
    )
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    const p = parseJson(txt)
    const titles = [...new Set((Array.isArray(p.titles) ? p.titles : []).map((x: any) => String(x).replace(/["“”]/g, '').replace(/\s+/g, ' ').trim().slice(0, 160)).filter((x: string) => x.length > 8))].slice(0, suggest ? 4 : 1) as string[]
    if (!titles.length) return { ok: false as const, reason: 'The AI did not return a usable title. Try again.' }
    return { ok: true as const, titles }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not prepare titles.') }
  }
}

export const projectTitles = createServerFn({ method: 'POST' })
  .validator((d: { mode: 'suggest' | 'improve'; current: string; context: string }) => d)
  .handler(async ({ data }) => runProjectTitles(data))

export type AuditVerdict = { status: 'pass' | 'partial' | 'fail' | 'unknown'; evidence: string; fix: string; h?: string; sh?: string }

export async function runQualityAudit(data: { items: { id: string; text: string }[]; proposal: string; context: string }) {
  try {
    const out: Record<string, AuditVerdict> = {}
    const chunks: { id: string; text: string }[][] = []
    for (let i = 0; i < data.items.length; i += 13) chunks.push(data.items.slice(i, i + 13))
    for (const chunk of chunks) {
      const txt = await llm(
        'You are a strict, accurate grant reviewer checking a written proposal against a quality checklist. For EACH criterion decide: "pass" only when the text clearly meets it; "partial" when it is present but weak, vague or incomplete; "fail" when it is missing or contradicted; "unknown" when the text given cannot show it. Judge only from the proposal text and project information given: never assume, never reward intentions. "evidence" is a short quote or the section name that proves your verdict, at most 140 characters (empty for unknown). "fix" is one concrete instruction to reach "pass", at most 160 characters, empty when the verdict is pass. Reply with JSON only: {"results":[{"id":string,"status":"pass"|"partial"|"fail"|"unknown","evidence":string,"fix":string}]} with one entry per criterion id, in the same order.',
        `PROJECT INFORMATION:\n${data.context.slice(0, 2500)}\n\nWRITTEN PROPOSAL:\n${data.proposal.slice(0, 8200)}\n\nCRITERIA:\n${chunk.map((c) => `${c.id}: ${c.text}`).join('\n')}`,
        true,
        1800,
        0,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const ok = ['pass', 'partial', 'fail', 'unknown']
      for (const r of Array.isArray(p.results) ? p.results : []) {
        const id = String(r?.id ?? '').trim()
        if (!chunk.some((c) => c.id === id)) continue
        const status = ok.includes(r.status) ? r.status : 'unknown'
        out[id] = { status, evidence: String(r.evidence ?? '').trim().slice(0, 200), fix: status === 'pass' ? '' : String(r.fix ?? '').trim().slice(0, 220) }
      }
    }
    if (!Object.keys(out).length) return { ok: false as const, reason: 'The AI did not return usable results. Try again.' }
    return { ok: true as const, results: out }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not run the AI check.') }
  }
}

export const qualityAudit = createServerFn({ method: 'POST' })
  .validator((d: { items: { id: string; text: string }[]; proposal: string; context: string }) => d)
  .handler(async ({ data }) => runQualityAudit(data))

export type GapQuestion = { section: string; question: string }

export async function runGapQuestions(data: { findings: { text: string; fix: string; section: string }[]; placeholders: { section: string; snippet: string }[]; sections: string[]; context: string }) {
  try {
    if (!data.findings.length && !data.placeholders.length) return { ok: false as const, reason: 'There are no gaps to fill. Run Check with AI first, or the proposal has no placeholders left.' }
    const txt = await llm(
      'You help a grant applicant fill the gaps in a proposal. You get review findings and unresolved [placeholders]. Write at most 8 short, concrete questions for the applicant, and ask ONLY what the findings and placeholders below require. Do not ask for facts already given in the project information. Each question asks for ONE fact that only the applicant knows: a number, a source and year, a date, a name, a place, a role. Do not ask for anything you could write yourself, such as wording or style. Do not ask the same thing twice. Tie each question to the exact section title it belongs to, taken from the list. Reply with JSON only: {"questions":[{"section":string,"question":string}]}.',
      `PROJECT INFORMATION:\n${data.context.slice(0, 1500)}\n\nSECTION TITLES:\n${data.sections.join('\n')}\n\nFINDINGS:\n${data.findings.slice(0, 14).map((f) => `- [${f.section || 'general'}] ${f.text}. Needed: ${f.fix}`).join('\n')}\n\nPLACEHOLDERS:\n${data.placeholders.slice(0, 14).map((x) => `- [${x.section}] ...${x.snippet}...`).join('\n')}`,
      true,
      1200,
      0.2,
    )
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    const p = parseJson(txt)
    const questions: GapQuestion[] = (Array.isArray(p.questions) ? p.questions : [])
      .map((x: any) => ({ section: matchTitle(data.sections, String(x.section ?? '')) || '', question: String(x.question ?? '').trim().slice(0, 240) }))
      .filter((x: GapQuestion) => x.question.length > 8)
      .slice(0, 10)
    if (!questions.length) return { ok: false as const, reason: 'The AI did not return usable questions. Try again.' }
    return { ok: true as const, questions }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not prepare the questions.') }
  }
}

export const gapQuestions = createServerFn({ method: 'POST' })
  .validator((d: { findings: { text: string; fix: string; section: string }[]; placeholders: { section: string; snippet: string }[]; sections: string[]; context: string }) => d)
  .handler(async ({ data }) => runGapQuestions(data))

const HELPER_BRIEFS: Record<string, string> = {
  letter: 'Write a letter of support that a partner organization or local authority can sign. It states who the partner is [partner name], its relationship with the applicant, why the project matters locally, the specific commitment (resources, staff time, access, data) in numbers where known, and that the partner supports the application. One page, formal and warm, with [bracketed placeholders] for names, dates and figures.',
  mou: 'Write the outline of a Memorandum of Understanding between the applicant and a partner. Sections: purpose, parties, roles and responsibilities of each, contribution of each (money, staff, in-kind), project duration, reporting and communication, financial management, data protection, safeguarding, dispute resolution, changes and ending the agreement, signatures. Short numbered clauses with [bracketed placeholders].',
  signoff: 'Write a short email asking a board chair, partner director or legal adviser to review and sign off the grant application before submission. Say what is attached, what exactly they are asked to confirm (eligibility, budget, commitments, legal status), the deadline for their answer, and how to reply. Polite and brief, with [bracketed placeholders].',
  reader: 'Write a short email asking someone outside the project team to read the proposal as a fresh reviewer. Ask them to check: is the need clear, are objectives measurable, do the activities, budget and timeline match, and are there errors or unclear sentences. Give a deadline, a time estimate and how to return comments. Brief and friendly, with [bracketed placeholders].',
}

export async function runHelperDraft(data: { kind: string; context: string }) {
  try {
    const brief = HELPER_BRIEFS[data.kind]
    if (!brief) return { ok: false as const, reason: 'Unknown document.' }
    const txt = await llm(
      `You write practical grant-administration documents for NGOs in plain professional English. Use only the facts given; never invent names, figures or commitments: use [bracketed placeholders] instead. No asterisks or markdown. ${brief}`,
      data.context.slice(0, 3500),
      false,
      1400,
      0.4,
    )
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    return { ok: true as const, text: tidyText(txt.trim()) }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not write the draft.') }
  }
}

export const helperDraft = createServerFn({ method: 'POST' })
  .validator((d: { kind: string; context: string }) => d)
  .handler(async ({ data }) => runHelperDraft(data))

export type TermGroup = { preferred: string; variants: string[]; why: string }

export async function runTerminology(data: { parts: { title: string; text: string }[] }) {
  try {
    const body = data.parts.map((p) => `## ${p.title}\n${p.text.slice(0, 1600)}`).join('\n\n').slice(0, 9500)
    if (body.trim().length < 120) return { ok: false as const, reason: 'Write some sections first, then check the terminology.' }
    const txt = await llm(
      'You check a grant proposal for consistent terminology. Find ideas that the proposal names in more than one way, so a reviewer could think they are different things. Examples: participants, beneficiaries and trainees for the same people; project, programme and initiative; outcome and result; site, hub and centre. List ONLY real inconsistencies for the SAME thing. Do NOT list words that mean different things, such as outputs and outcomes, or direct and indirect beneficiaries. For each group give "preferred" (the most precise term, or the one the funder uses), "variants" (the other words, exactly as written in the text) and "why" (one short sentence). At most 8 groups. Reply with JSON only: {"groups":[{"preferred":string,"variants":string[],"why":string}]}.',
      body,
      true,
      1200,
      0,
    )
    if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
    const p = parseJson(txt)
    const groups: TermGroup[] = (Array.isArray(p.groups) ? p.groups : [])
      .map((g: any) => ({ preferred: String(g.preferred ?? '').trim().slice(0, 60), variants: (Array.isArray(g.variants) ? g.variants : []).map((v: any) => String(v).trim().slice(0, 60)).filter(Boolean).slice(0, 5), why: String(g.why ?? '').trim().slice(0, 200) }))
      .filter((g: TermGroup) => g.preferred && g.variants.length)
      .slice(0, 8)
    return { ok: true as const, groups }
  } catch (e: any) {
    return { ok: false as const, reason: String(e?.message ?? 'Could not check the terminology.') }
  }
}

export const terminologyCheck = createServerFn({ method: 'POST' })
  .validator((d: { parts: { title: string; text: string }[] }) => d)
  .handler(async ({ data }) => runTerminology(data))

export const grantDetails = createServerFn({ method: 'POST' })
  .validator((d: { grant: Grant; profile: Profile }) => d)
  .handler(async ({ data }) => {
    const { grant, profile } = data
    let source = ''
    let links: { label: string; url: string }[] = []
    let fetchNote = ''
    if (grant.id.startsWith('us-')) {
      try {
        const r = await fetch('https://api.grants.gov/v1/api/fetchOpportunity', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-whop-inject-key': 'none' },
          body: JSON.stringify({ opportunityId: Number(grant.id.slice(3)) }),
        })
        const syn: any = ((await r.json()) as any)?.data?.synopsis
        if (syn) {
          source = [
            `Opportunity: ${grant.title} (${grant.funder})`,
            `Posted: ${syn.postingDateStr ?? ''}  Closes: ${syn.responseDate ?? grant.deadline}`,
            `Award ceiling: ${syn.awardCeiling ?? 'n/a'}  Award floor: ${syn.awardFloor ?? 'n/a'}  Estimated total funding: ${syn.estimatedFunding ?? 'n/a'}  Expected number of awards: ${syn.numberOfAwards ?? 'n/a'}  Cost sharing required: ${syn.costSharing ?? 'n/a'}`,
            `Applicant types: ${(syn.applicantTypes ?? []).map((a: any) => a.description).join('; ')}`,
            `Funding instrument: ${(syn.fundingInstruments ?? []).map((a: any) => a.description).join('; ')}`,
            `Category: ${(syn.fundingActivityCategories ?? []).map((a: any) => a.description).join('; ')}`,
            `Eligibility notes: ${stripHtmlLite(String(syn.applicantEligibilityDesc ?? ''))}`,
            `Description: ${stripHtmlLite(String(syn.synopsisDesc ?? ''))}`,
            `Agency contact: ${syn.agencyContactName ?? ''} ${syn.agencyContactEmail ?? ''} ${syn.agencyContactPhone ?? ''}`,
            `Full announcement link: ${syn.fundingDescLinkUrl ?? ''} (${syn.fundingDescLinkDesc ?? ''})`,
          ].join('\n')
          if (syn.fundingDescLinkUrl) links.push({ label: syn.fundingDescLinkDesc || 'Full announcement', url: String(syn.fundingDescLinkUrl) })
        }
      } catch {}
    }
    if (grant.url) {
      const pg = await fetchPage(grant.url)
      if (pg.text) source += '\n\nPAGE TEXT FROM ' + grant.url + ':\n' + pg.text
      else if (!source) fetchNote = pg.error ?? ''
      links = [...links, ...pg.links]
    }
    if (!source.trim() && grant.details) source = grant.details
    if (!source.trim()) source = `${grant.title}\n${grant.funder}\n${grant.summary ?? ''}`
    const important = links.filter((l) => /appl|guid|faq|eligib|contact|about|team|board|leader|grant|fund|criteria|deadline|rules|instruction|how/i.test(l.label + ' ' + l.url)).slice(0, 25)
    const linkList = important.map((l) => `- ${l.label}: ${l.url}`).join('\n')

    try {
      const out = await llm(
        `You prepare a grant brief for an NGO from the funder's own page text. Use ONLY the supplied text and organization profile. Never invent amounts, dates, emails, phone numbers, names, addresses or rules. When something is not in the text, use "Not stated on the page" for strings and [] for lists. Reply with a single JSON object with exactly these keys: {"funder": string, "deadline": string, "amount": string (short, e.g. "Up to $50,000" or "Amount not specified"), "amountNote": string (what the text says about award sizes, max 3 sentences), "countries": string[], "sectors": string[], "eligibility": string[] (max 10 bullet sentences), "applicationSummary": string (2 sentences), "effort": "low"|"medium"|"high", "steps": string[] (max 8 ordered steps), "requiredDocuments": string[] (max 8), "contact": string (only emails and phones found in the text), "reporting": string, "execution": {"staffing": string, "expertise": string, "facilities": string, "partners": string, "scale": string} (what delivering the funded work demands, only if stated), "capacityGaps": string[] (max 5, gaps between what the call requires and the organization profile; if the profile lacks the needed data say so), "addToProfile": string[] (profile facts that would let the organization confirm fit), "fitSummary": string (2 to 3 honest sentences), "funderContact": {"email": string, "phone": string, "address": string, "website": string, "registration": string}, "leadership": string[] ("Name, role" only if listed), "requirements": string[] (max 8: matching funds, cost share, reporting, indirect cost limits, restrictions), "howToApply": string[] (max 8), "importantDates": string[] (max 6), "additionalNotes": string[] (max 6), "links": [{"label": string, "url": string}] (only URLs from the provided link list or the source text, max 8)}. Keep every item short and specific.`,
        `Organization profile: ${JSON.stringify(profile)}\n\nGrant: ${JSON.stringify({ title: grant.title, funder: grant.funder, deadline: grant.deadline, status: grant.status, url: grant.url })}\n\nLinks found on the page:\n${linkList || '(none)'}\n\nSOURCE TEXT:\n${source.slice(0, 8500)}`,
        true,
        3000,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(out)
      const arr = (x: any, n = 10) => (Array.isArray(x) ? x.map((v) => String(v).trim()).filter(Boolean).slice(0, n) : [])
      const str = (x: any, d = 'Not stated on the page') => (typeof x === 'string' && x.trim() ? x.trim() : d)
      const allowed = new Set([grant.url, ...links.map((l) => l.url)])
      const detail: GrantDetail = {
        funder: str(p.funder, grant.funder),
        deadline: str(p.deadline, grant.deadline),
        amount: str(p.amount, 'Amount not specified'),
        amountNote: str(p.amountNote),
        countries: arr(p.countries, 40),
        sectors: arr(p.sectors, 20),
        eligibility: arr(p.eligibility, 10),
        applicationSummary: str(p.applicationSummary),
        effort: ['low', 'medium', 'high'].includes(String(p.effort)) ? String(p.effort) : 'unknown',
        steps: arr(p.steps, 8),
        requiredDocuments: arr(p.requiredDocuments, 8),
        contact: str(p.contact),
        reporting: str(p.reporting),
        execution: {
          staffing: str(p.execution?.staffing),
          expertise: str(p.execution?.expertise),
          facilities: str(p.execution?.facilities),
          partners: str(p.execution?.partners),
          scale: str(p.execution?.scale),
        },
        capacityGaps: arr(p.capacityGaps, 5),
        addToProfile: arr(p.addToProfile, 8),
        fitSummary: str(p.fitSummary, ''),
        funderContact: {
          email: str(p.funderContact?.email),
          phone: str(p.funderContact?.phone),
          address: str(p.funderContact?.address),
          website: str(p.funderContact?.website, grant.url),
          registration: str(p.funderContact?.registration),
        },
        leadership: arr(p.leadership, 8),
        requirements: arr(p.requirements, 8),
        howToApply: arr(p.howToApply, 8),
        importantDates: arr(p.importantDates, 6),
        additionalNotes: arr(p.additionalNotes, 6),
        links: (Array.isArray(p.links) ? p.links : [])
          .map((l: any) => ({ label: String(l?.label ?? '').slice(0, 80), url: String(l?.url ?? '') }))
          .filter((l: any) => l.url && (allowed.has(l.url) || source.includes(l.url)))
          .slice(0, 8),
        sourceNote: fetchNote ? `The funder's page could not be read (${fetchNote}), so this brief uses the limited information already collected.` : '',
      }
      return { ok: true as const, detail }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not build the grant brief.') }
    }
  })

function stripHtmlLite(h: string) {
  return h.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim().slice(0, 3000)
}

export const condenseNeeds = createServerFn({ method: 'POST' })
  .validator((d: { text: string }) => d)
  .handler(async ({ data }) => {
    try {
      const out = await llm(
        'You condense a needs assessment for a grant proposal. Keep every concrete fact: places, population numbers, statistics with their source and year, root causes, priority needs, gaps in services and stakeholder findings. Remove methodology detail, repetition and filler. Do not add anything that is not in the text. Write 250 to 350 words in plain paragraphs and short bullet lists. Return only the condensed text.',
        data.text.slice(0, 12000),
        false,
        900,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: out.trim() }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not condense the text.') }
    }
  })

export const analyzeExperience = createServerFn({ method: 'POST' })
  .validator((d: { text: string; name: string }) => d)
  .handler(async ({ data }) => {
    try {
      const out = await llm(
        'You read a document about the previous experience of an NGO: reports, earlier proposals, project records, results tables. Extract the facts a grant writer can reuse in a new proposal. Use these headings, skipping any with nothing in the document: "Projects and programs" (title, place, years, donor, budget), "Results and figures" (numbers of people reached, outputs, outcomes, with years), "Methods and approach", "Partners and donors", "Lessons learned", "Capacity and track record". Keep every concrete name, date, place and number exactly as written. Do not add anything that is not in the document. Write at most 450 words as short bullet lists. Return only the extracted facts.',
        `Document: ${data.name}\n\n${data.text.slice(0, 14000)}`,
        false,
        1000,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: out.trim() }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the document.') }
    }
  })

export type ChatEdit = { section: string; mode: 'replace' | 'append'; text: string }

export const chatAssistant = createServerFn({ method: 'POST' })
  .validator((d: { messages: { role: 'user' | 'assistant'; content: string }[]; context: string; sections?: string[] }) => d)
  .handler(async ({ data }) => {
    try {
      const turns = (data.messages ?? []).slice(-10).map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${String(m.content).slice(0, 1500)}`).join('\n\n')
      const titles = (data.sections ?? []).slice(0, 40)
      const system =
        'You are the AI assistant inside a grant-writing portal for NGOs. You help the user with the grant application they are preparing: explain funder requirements, suggest how to strengthen sections, draft or rewrite passages, check logic, budget and indicators, and answer grant-writing questions. Answer about THIS specific application only (the one in the context below); never mix in other applications. Use the application context for real names, figures and the funder guidance. Never invent facts, figures or places about the organization; if something is missing, use a [bracketed placeholder] and tell the user what to supply. Be concise and practical, in plain language. Reply in the language the user writes in.\n\n' +
        'YOU CAN EDIT THE DRAFT. The portal applies your edits to the draft automatically. When the user asks you to improve, fix, rewrite, shorten, expand, write, add or change something in the proposal (or accepts your earlier suggestion), put the new text in "edits". When the user only asks a question or for advice, leave "edits" empty. Sections you may edit, exactly by these titles: ' + (titles.length ? titles.map((t) => `"${t}"`).join(', ') : 'none') + '. For each edit give "section" (an exact title from that list), "mode" ("replace" = the complete new text of the section, or "append" = text added after the existing text) and "text". Use "replace" only when the full current text of that section is shown in the context (not marked TRUNCATED); otherwise use "append". When replacing, keep every correct fact and figure and the existing structure; tables stay markdown tables. At most 3 edits. Write the text of an edit as plain section text with no heading, no asterisks and no markdown bold; use lines starting with "- " for lists. Do not paste the edited text again in "reply": in "reply" say briefly what you changed and why.\n\n' +
        'Reply with JSON only: {"reply": string, "edits": [{"section": string, "mode": "replace" | "append", "text": string}]}. In "reply", when you show tabular data write a markdown table (header row, a |---| separator row, one row per line, each line starting and ending with |, blank line before and after, not in a code block); otherwise use short paragraphs and lines starting with "- ", and **bold** sparingly.\n\n' +
        'APPLICATION CONTEXT (everything the applicant has filled in so far, read it fully before answering; quote exact figures and wording from it, point out contradictions or gaps between sections, and say which section a point comes from):\n' + data.context.slice(0, 26000)
      const out = await llm(system, turns, true, 3200)
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      let reply = ''
      let edits: ChatEdit[] = []
      try {
        const p = parseJson(out)
        reply = tidyText(String(p.reply ?? '')).trim()
        edits = (Array.isArray(p.edits) ? p.edits : [])
          .map((e: any) => ({ section: String(e.section ?? '').trim(), mode: e.mode === 'append' ? 'append' : 'replace', text: tidyText(String(e.text ?? '')).trim() }))
          .filter((e: ChatEdit) => e.section && e.text.length > 3)
          .slice(0, 3)
      } catch {
        reply = out.trim()
      }
      if (!reply) reply = edits.length ? 'I updated the draft.' : out.trim()
      return { ok: true as const, text: reply, edits }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'The assistant could not answer.') }
    }
  })

export type LineComponent = { component: string; description: string; unit: string; qty: number; unitCost: number }
export type LineBreakdown = { description: string; justification: string; basis: string; assumptions: string; verification: string; phasing: number[]; components: LineComponent[] }

const bnum = (v: any) => { const n = Number(String(v ?? '').replace(/[^0-9.\-]/g, '')); return Number.isFinite(n) ? n : 0 }

export const breakdownLine = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; category: string; item: string; unit: string; qty: number; unitCost: number; total: number; others: string; proposal: string; months?: string; periods: number; rules?: string; instruction?: string }) => d)
  .handler(async ({ data }) => {
    try {
      const periods = Math.max(1, Math.min(12, data.periods || 4))
      const system = `You are a senior NGO budget officer preparing the detailed breakdown of ONE budget line of a grant budget, for a donor financial reviewer. Reply with JSON only: {"description":string,"justification":string,"basis":string,"assumptions":string,"verification":string,"phasing":number[],"components":[{"component":string,"description":string,"unit":string,"qty":number,"unitCost":number}]}. Rules: (1) "description": one precise sentence saying what the line pays for. (2) "justification": 2 to 4 sentences linking the line to the project's activities, outputs and beneficiaries in the proposal, and explaining why it is necessary and cost-effective. (3) "basis": how the amount was estimated (rates, quotes, local market, standard donor or government rates) in 1 to 2 sentences. (4) "components": the elements that make up the line, 2 to 10 rows, each with a clear name, a precise description (who or what, how many days, sessions, sites or months, where), a unit, a whole-number or realistic "qty" and a realistic "unitCost" in USD for ${data.profile.country || 'the project country'}. The components MUST add up to about ${Math.round(data.total)} USD (the amount of this line in the approved budget), so choose quantities and unit costs accordingly, and keep them consistent with the line's own unit and quantity (${data.qty} ${data.unit || 'units'} at ${data.unitCost} USD). (5) "assumptions": 1 to 3 short assumptions (rates, exchange rate, number of participants, duration). (6) "verification": the documents that will support the cost (for example quotations, contracts, timesheets, attendance lists, invoices, receipts) and the procurement rule that applies. (7) "phasing": ${periods} numbers, the share in percent of this line spent in each of the ${periods} consecutive project periods, adding up to 100, based on when the related activities happen. Never invent facts about the organization or the project; use [bracketed placeholders] only for unknowns. Do not change the line's amount.`
      const user = `Organization: ${data.profile.org ?? ''}${data.profile.country ? ', ' + data.profile.country : ''}\nDuration: ${data.months || '12'} months (${periods} periods)\n${data.rules ? 'Funder budget rules: ' + data.rules + '\n' : ''}${data.instruction?.trim() ? `APPLICANT'S INSTRUCTIONS FOR THE LINE BREAKDOWNS (follow them, but never change the line's amount): ${data.instruction.trim().slice(0, 800)}\n` : ''}\nBUDGET LINE: ${data.item}\nMain budget category: ${data.category}\nUnit: ${data.unit || 'n/a'}; quantity ${data.qty}; unit cost ${data.unitCost} USD; line total ${data.total} USD\n\nOTHER LINES OF THE SAME BUDGET (do not duplicate their costs): ${data.others.slice(0, 1500)}\n\nPROPOSAL EXTRACT:\n${data.proposal.slice(0, 5500)}`
      const out = await llm(system, user, true, 2400)
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(out)
      const comps: LineComponent[] = (Array.isArray(p.components) ? p.components : []).map((x: any) => {
        let qty = bnum(x.qty ?? x.quantity)
        let unitCost = Math.max(0, bnum(x.unitCost ?? x.unit_cost ?? x.cost))
        const total = Math.max(0, bnum(x.total ?? x.amount))
        if (!unitCost && total) { qty = qty > 0 ? qty : 1; unitCost = total / qty }
        if (!qty && unitCost) qty = 1
        return { component: String(x.component ?? x.item ?? x.name ?? '').trim().slice(0, 120), description: tidyText(String(x.description ?? '').trim().slice(0, 300)), unit: String(x.unit ?? '').trim().slice(0, 24), qty: Math.max(0, qty), unitCost }
      }).filter((x: LineComponent) => x.component && x.qty > 0 && x.unitCost > 0).slice(0, 10)
      let phasing: number[] = (Array.isArray(p.phasing) ? p.phasing : []).map((v: any) => Math.max(0, bnum(v))).slice(0, periods)
      while (phasing.length < periods) phasing.push(0)
      const ps = phasing.reduce((t, v) => t + v, 0)
      phasing = ps > 0 ? phasing.map((v) => (v / ps) * 100) : phasing.map(() => 100 / periods)
      const f = (v: any, n: number) => tidyText(String(v ?? '').trim().slice(0, n))
      return { ok: true as const, breakdown: { description: f(p.description, 300), justification: f(p.justification, 700), basis: f(p.basis, 400), assumptions: f(p.assumptions, 500), verification: f(p.verification, 400), phasing, components: comps } as LineBreakdown }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not break down the budget line.') }
    }
  })

export const analyzeProjectInfo = createServerFn({ method: 'POST' })
  .validator((d: { text: string; name: string }) => d)
  .handler(async ({ data }) => {
    try {
      const out = await llm(
        'You read a document that describes a PLANNED project (a concept note, project idea, brief, plan, logframe or notes) that an NGO wants to write a grant proposal for. Extract everything a grant writer needs, organised under these headings, skipping any with nothing in the document: "Project idea and goal", "Objectives and expected outcomes", "Activities" (each with its timing, location and numbers), "Target groups and locations" (with numbers), "Partners and roles", "Results, outputs and indicators", "Timeline and duration", "Budget and funding figures", "Risks, sustainability and other details". Keep every concrete name, date, place and number exactly as written. Do not add anything that is not in the document and do not guess. Write at most 650 words as short bullet lists. Return only the extracted facts.',
        `Document: ${data.name}\n\n${data.text.slice(0, 16000)}`,
        false,
        1300,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: out.trim() }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not analyze the document.') }
    }
  })

export const fitToLimit = createServerFn({ method: 'POST' })
  .validator((d: { text: string; title: string; limit: number; unit: 'words' | 'characters' | 'characters_nospace'; attempt?: number }) => d)
  .handler(async ({ data }) => {
    try {
      const target = Math.floor(data.limit * (data.attempt ? 0.8 : 0.92))
      const unitTxt = data.unit === 'characters' ? 'characters including spaces' : data.unit === 'characters_nospace' ? 'characters excluding spaces' : 'words'
      const out = await llm(
        `You shorten a grant application section so that it fits the funder's length limit. The text must be AT MOST ${target} ${unitTxt} (the funder's hard limit is ${data.limit}). Keep every key fact, figure, name, date and the funder's priorities; remove repetition, filler, examples and the least important details first. Keep the existing structure (subtitles, lists, tables stay as they are, with shorter cell text). Do not add anything new. Return only the shortened text.`,
        `Section: ${data.title}\n\nTEXT TO SHORTEN:\n${data.text.slice(0, 16000)}`,
        false,
        Math.min(5000, Math.round(target / (data.unit === 'words' ? 0.7 : 3)) + 600),
        0.2,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: tidyText(out.trim()) }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not shorten the text.') }
    }
  })

export const generateFundingNeed = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; current?: string }) => d)
  .handler(async ({ data }) => {
    try {
      const cur = (data.current ?? '').trim()
      const { fundingNeed: _own, ...rest } = data.profile
      const out = await llm(
        'You write a short description of the funding an NGO is seeking, to be used as a grant search request. Use ONLY facts in the organization profile (and in the existing text, if one is given): what it does, where, for whom, the sectors, the funding type and the amount range if given. Write 2 to 4 plain sentences in the third person, with the organization as the subject (never "we" or "our"). Do not invent numbers, places or programs. If the amount range is empty, do not mention an amount. ' + (cur ? 'The organization already wrote a description. Improve it: keep every fact and number in it, fix the wording, and add relevant facts from the profile that are missing. ' : '') + 'Return only the text.',
        `Organization profile: ${JSON.stringify(rest)}${cur ? `\nExisting description to improve: ${cur.slice(0, 1500)}` : ''}`,
        false,
        400,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: out.trim().replace(/^["']|["']$/g, '') }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not write the description.') }
    }
  })

export const writePastFunding = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; current?: string; library?: string }) => d)
  .handler(async ({ data }) => {
    try {
      const cur = (data.current ?? '').trim()
      const { pastFunding: _a, fundingNeed: _b, ...rest } = data.profile
      const out = await llm(
        'You write the "Past funding and key results" part of an NGO profile for grant applications. Use ONLY facts from the organization profile, the organization\'s own documents and the existing text, if one is given. List past funders one per line starting with "- ", each with the amount, the year and what was delivered, with numbers where they are known. Never invent a funder, amount, year, number or result. Where a fact is missing write a [bracketed placeholder] such as [amount] or [year]. If there are no facts about past funding at all, write a short template of 2 to 3 lines with placeholders for the person to fill in. ' + (cur ? 'The organization already wrote a text. Improve it: keep every fact and number, fix the wording and the order, and add facts from the profile and documents that are missing. ' : '') + 'Keep it under 180 words, in plain text with no asterisks, using only the "- " list format. Return only the text.',
        `Organization profile: ${JSON.stringify(rest)}${data.library ? `\nThe organization's own documents:\n${data.library.slice(0, 2200)}` : ''}${cur ? `\nExisting text to improve: ${cur.slice(0, 2000)}` : ''}`,
        false,
        700,
      )
      if (!out) return { ok: false as const, reason: 'AI is not switched on yet.' }
      return { ok: true as const, text: out.trim().replace(/^[\"']|[\"']$/g, '').replace(/^(\s*)\*\s+/gm, '$1- ').replace(/\*/g, '') }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not write the text.') }
    }
  })

async function webSearch(query: string): Promise<{ title: string; url: string; text: string }[] | 'no_key'> {
  const tav = (process.env.TAVILY_API_KEY || '').trim()
  const brave = (process.env.BRAVE_API_KEY || '').trim()
  if (tav) {
    const r = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${tav}`, 'x-whop-inject-key': 'none' },
      body: JSON.stringify({ query, search_depth: 'basic', max_results: 10, include_answer: false }),
    })
    if (!r.ok) throw new Error(`Web search error ${r.status}`)
    const j: any = await r.json()
    return (j.results ?? []).map((x: any) => ({ title: String(x.title ?? ''), url: String(x.url ?? ''), text: String(x.content ?? '').slice(0, 600) }))
  }
  if (brave) {
    const r = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=10`, {
      headers: { accept: 'application/json', 'x-subscription-token': brave, 'x-whop-inject-key': 'none' },
    })
    if (!r.ok) throw new Error(`Web search error ${r.status}`)
    const j: any = await r.json()
    return (j.web?.results ?? []).map((x: any) => ({ title: String(x.title ?? ''), url: String(x.url ?? ''), text: String(x.description ?? '').replace(/<[^>]+>/g, '').slice(0, 600) }))
  }
  return 'no_key'
}

export const searchWebForGrants = createServerFn({ method: 'POST' })
  .validator((d: { keyword: string; profile: Profile }) => d)
  .handler(async ({ data }) => {
    const p = data.profile
    const kw = data.keyword.trim() || [p.focus?.split(',')[0], p.opCountries?.split(',')[0] || p.country].filter(Boolean).join(' ') || 'community development'
    const query = `${kw} grant open call for proposals NGOs nonprofits apply deadline ${new Date().getFullYear()}`
    let hits: Awaited<ReturnType<typeof webSearch>>
    try {
      hits = await webSearch(query)
    } catch (e: any) {
      return { ok: false as const, code: 'error', reason: /\b(401|403)\b/.test(String(e?.message)) ? 'Internet search is not available right now. The site owner needs to check the web search key.' : 'Internet search could not be reached. Try again in a moment.' }
    }
    if (hits === 'no_key') return { ok: false as const, code: 'no_key', reason: 'Internet search is not switched on yet. The site owner needs to add a search key.' }
    if (!hits.length) return { ok: true as const, grants: [] as Grant[], query }
    try {
      const out = await llm(
        `You review web search results and keep only real funding opportunities (grants, open calls, fellowships, prizes, funds) that NGOs or nonprofits could apply to. Skip news, blogs, lists of many grants, and pages that are not an opportunity. Reply with JSON: {"grants": [{"title": string, "funder": string, "deadline": string (YYYY-MM-DD if stated, otherwise "Not stated"), "status": "open"|"forthcoming"|"closed"|"unknown", "countries": string[] ([\\"Global\\"] if open to all, [] if not stated), "sectors": string[] (from: ${SECTOR_LIST.join(', ')}), "type": string, "amountMin": number (USD, 0 if not stated), "amountMax": number (USD, 0 if not stated), "summary": string (max 2 sentences), "inviteOnly": boolean, "url": string (exactly one of the result URLs)}]}. Use only what each result says. Never invent dates or amounts.`,
        hits.map((h, i) => `[${i + 1}] ${h.title}\\nURL: ${h.url}\\n${h.text}`).join('\\n\\n'),
        true,
        2000,
      )
      if (!out) return { ok: false as const, code: 'error', reason: 'AI is not switched on yet.' }
      const parsed = parseJson(out)
      const urls = new Set(hits.map((h) => h.url))
      const grants: Grant[] = []
      for (const x of Array.isArray(parsed.grants) ? parsed.grants : []) {
        const url = String(x.url ?? '')
        if (!urls.has(url) || !x.title) continue
        let hsh = 0
        for (const ch of url) hsh = (hsh * 31 + ch.charCodeAt(0)) | 0
        const status = ['open', 'forthcoming', 'closed'].includes(String(x.status)) ? String(x.status) : 'unknown'
        if (status === 'closed') continue
        grants.push({
          id: 'web-' + Math.abs(hsh).toString(36),
          title: String(x.title).slice(0, 200),
          funder: String(x.funder || new URL(url).hostname.replace(/^www\\./, '')).slice(0, 120),
          source: 'Web search',
          deadline: String(x.deadline || 'Not stated'),
          status,
          url,
          summary: String(x.summary ?? '').slice(0, 500) || undefined,
          countries: (Array.isArray(x.countries) ? x.countries : []).map((c: any) => String(c).slice(0, 60)).slice(0, 12),
          gtype: String(x.type ?? '').slice(0, 40) || undefined,
          sectors: (Array.isArray(x.sectors) ? x.sectors : []).filter((c: any) => SECTOR_LIST.includes(c)).slice(0, 4),
          amountMin: Number(x.amountMin) > 0 ? Number(x.amountMin) : undefined,
          amountMax: Number(x.amountMax) > 0 ? Number(x.amountMax) : undefined,
          inviteOnly: x.inviteOnly === true ? true : undefined,
        })
      }
      return { ok: true as const, grants, query }
    } catch (e: any) {
      return { ok: false as const, code: 'error', reason: String(e?.message ?? 'Could not read the search results.') }
    }
  })
