import { createServerFn } from '@tanstack/react-start'
import { llm, parseJson, type Grant, type Profile } from './grants'
import { csv, matchesCountry, normStatus, orgBudgetCeiling, parseDate } from '../lib/options'

// Fit score. Seven parts add up to 100, and the arithmetic is done in code, so the same grant and profile always give the same score.
// The AI only judges the two things that need reading: how close the grant's purpose is to the organization (theme),
// and whether the grant's own eligibility text allows an organization like this one (eligibility).
export type FitPart = { label: string; points: number; max: number; note: string }
export type FitResult = { score: number; strengths: string[]; gaps: string[]; tips: string[]; mode: 'ai' | 'keyword'; breakdown: FitPart[] }

type Verdict = { theme: number; eligibility: 'eligible' | 'likely' | 'unclear' | 'ineligible'; reason: string; strengths: string[]; gaps: string[]; tips: string[] }

const ELIG_POINTS = { eligible: 15, likely: 11, unclear: 7, ineligible: 0 } as const
const words = (t: string) => new Set(t.toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3))
const short = (v: unknown, n: number) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, n)

function parts(profile: Profile, g: Grant) {
  const out: FitPart[] = []
  const gaps: string[] = []
  const strengths: string[] = []
  // Geography, 15
  const mine = [profile.country, ...csv(profile.regCountry), ...csv(profile.opCountries)].filter(Boolean) as string[]
  const cs = g.countries ?? []
  let geoMismatch = false
  if (!cs.length || !mine.length) out.push({ label: 'Geography', points: 8, max: 15, note: !mine.length ? 'Your countries are not in your profile.' : 'The call does not list countries.' })
  else if (mine.some((c) => matchesCountry(g, c))) { out.push({ label: 'Geography', points: 15, max: 15, note: 'Your country is covered.' }); strengths.push('Your country is covered by this call.') }
  else {
    geoMismatch = true
    out.push({ label: 'Geography', points: 2, max: 15, note: `The call lists ${cs.slice(0, 3).join(', ')}.` })
    gaps.push(`The call lists ${cs.slice(0, 3).join(', ')}. Check whether organizations from ${mine[0]} can apply, or join with a partner.`)
  }
  // Funding size, 15
  const lo = Number((profile.amountMin ?? '').replace(/[^0-9.]/g, '')) || 0
  const hi = Number((profile.amountMax ?? '').replace(/[^0-9.]/g, '')) || Infinity
  const top = g.amountMax || g.amountMin || 0
  const bottom = g.amountMin || 0
  if (!top || (!lo && hi === Infinity)) out.push({ label: 'Funding size', points: 8, max: 15, note: !top ? 'The award size is not stated.' : 'You have not set a funding range.' })
  else if (top >= lo && bottom <= hi) { out.push({ label: 'Funding size', points: 15, max: 15, note: 'Award size is inside your range.' }); strengths.push('The award size is inside your range.') }
  else { out.push({ label: 'Funding size', points: 3, max: 15, note: 'Award size is outside your range.' }); gaps.push(`Awards run up to ${top.toLocaleString('en-US')} USD, outside the range you set.`) }
  // Timing, 10
  const st = normStatus(g)
  const d = parseDate(g.deadline)
  const days = d ? Math.ceil((d.getTime() - Date.now()) / 864e5) : null
  let tp = 5, tn = 'The timing is not clear.'
  if (st === 'closed' || (days !== null && days < 0)) { tp = 0; tn = 'The call has closed.'; gaps.push('This call has closed.') }
  else if (days !== null && days <= 7) { tp = 3; tn = `Only ${days} day${days === 1 ? '' : 's'} left.`; gaps.push(`Only ${days} day${days === 1 ? '' : 's'} left to apply.`) }
  else if (days !== null && days <= 14) { tp = 6; tn = `${days} days left, tight.` }
  else if (st === 'open' || st === 'rolling') { tp = 10; tn = days !== null ? `${days} days to prepare.` : 'Open with no fixed date.' }
  else if (st === 'forthcoming') { tp = 8; tn = 'Opens later, so there is time to prepare.' }
  out.push({ label: 'Timing', points: tp, max: 10, note: tn })
  // Capacity, 10
  const ceiling = orgBudgetCeiling(profile.budget)
  let cp = 5, cn = 'Your yearly budget is not in your profile.'
  if (ceiling && top) {
    const r = top / ceiling
    if (r > 1) { cp = 0; cn = `The award is about ${Math.round(r)} times your yearly budget.`; gaps.push('The award is larger than your yearly budget. Funders rarely grant that much to one organization.') }
    else if (r > 0.6) { cp = 4; cn = 'Large for your budget.'; gaps.push('Large for your budget, so expect strict capacity checks.') }
    else if (r >= 0.05) { cp = 10; cn = 'The award suits your budget.' }
    else if (r >= 0.03) { cp = 8; cn = 'A modest award for your size.' }
    else { cp = 6; cn = 'Small for the effort.' }
  } else if (ceiling) { cp = 7; cn = 'The award size is not stated, so the fit to your budget is unknown.' }
  if (profile.registered === 'no') { cp = Math.min(cp, 3); cn = 'Your organization is not legally registered yet.'; gaps.push('Most funders require a legally registered organization. A fiscal sponsor can help while you register.') }
  out.push({ label: 'Capacity', points: cp, max: 10, note: cn })
  // Type, 5
  const wanted = csv(profile.grantTypes)
  const gt = (g.gtype ?? '').toLowerCase()
  if (!wanted.length || !gt) out.push({ label: 'Funding type', points: 3, max: 5, note: 'Not enough information to compare.' })
  else if (wanted.some((w) => gt.includes(w.toLowerCase().split(' ')[0]))) out.push({ label: 'Funding type', points: 5, max: 5, note: 'The type is one you are looking for.' })
  else { out.push({ label: 'Funding type', points: 1, max: 5, note: `This is a ${g.gtype}.` }); gaps.push(`This is a ${g.gtype}. You said you want ${wanted.join(', ')}.`) }
  // Overlap of sectors and words, used with the AI's reading of the theme
  const mySectors = csv(profile.focus)
  const sharedSectors = (g.sectors ?? []).filter((x) => mySectors.includes(x))
  const so = mySectors.length ? Math.min(1, sharedSectors.length / Math.min(2, mySectors.length)) : 0
  const mineW = words(`${profile.focus} ${profile.mission} ${profile.populations ?? ''} ${profile.fundingNeed ?? ''}`)
  const theirs = words(`${g.title} ${g.summary ?? ''} ${(g.details ?? '').slice(0, 600)}`)
  const ko = mineW.size ? Math.min(1, [...mineW].filter((w) => theirs.has(w)).length / 6) : 0
  if (sharedSectors.length) strengths.push(`Sector match: ${sharedSectors.join(', ')}.`)
  return { out, gaps, strengths, geoMismatch, st, so, ko }
}

export function compose(profile: Profile, g: Grant, v: Verdict | null): FitResult {
  const p = parts(profile, g)
  const themeAi = v ? v.theme / 10 : null
  const themeFrac = themeAi === null ? 0.5 * p.so + 0.5 * p.ko : 0.7 * themeAi + 0.3 * Math.max(p.so, p.ko)
  const themePts = Math.round(30 * themeFrac)
  const eligKey = v ? v.eligibility : 'unclear'
  const eligPts = ELIG_POINTS[eligKey]
  const breakdown: FitPart[] = [
    { label: 'Theme', points: themePts, max: 30, note: v ? short(v.reason, 160) || 'How close the call\'s purpose is to your mission and sectors.' : 'Estimated from shared sectors and words. Run the AI analysis for a closer reading.' },
    { label: 'Eligibility', points: eligPts, max: 15, note: eligKey === 'eligible' ? 'The call\'s eligibility text includes organizations like yours.' : eligKey === 'likely' ? 'Likely allowed, but the text is not explicit.' : eligKey === 'ineligible' ? 'The call\'s eligibility text excludes organizations like yours.' : 'The call does not say clearly who can apply. Check the full rules.' },
    ...p.out,
  ]
  let score = breakdown.reduce((t, x) => t + x.points, 0)
  // Some facts decide the outcome whatever the other parts say. The lowest limit that applies wins, and it is named in the gaps.
  const limits: [number, string][] = []
  if (eligKey === 'ineligible') limits.push([20, 'Capped at 20: the eligibility text excludes organizations like yours.'])
  if (p.st === 'closed') limits.push([15, 'Capped at 15: the call has closed.'])
  if (g.inviteOnly) limits.push([35, 'Capped at 35: by invitation only, so you cannot apply unasked.'])
  if (p.geoMismatch && eligKey !== 'eligible') limits.push([50, 'Capped at 50: your country is not listed for this call.'])
  const caps: string[] = []
  const lowest = limits.sort((a, b) => a[0] - b[0])[0]
  if (lowest && score > lowest[0]) { score = lowest[0]; caps.push(lowest[1]) }
  const gaps = [...new Set([...(v?.gaps ?? []).map((x) => short(x, 260)), ...p.gaps])].filter(Boolean).slice(0, 6)
  const strengths = [...new Set([...(v?.strengths ?? []).map((x) => short(x, 260)), ...p.strengths])].filter(Boolean).slice(0, 5)
  const tips = (v?.tips ?? []).map((x) => short(x, 260)).filter(Boolean).slice(0, 4)
  if (!tips.length) tips.push('Read the full eligibility section before investing time.', 'Match your project title and outcomes to the funder\u2019s own wording.')
  if (caps.length) gaps.unshift(caps[0])
  return { score: Math.max(0, Math.min(100, Math.round(score))), strengths, gaps: gaps.slice(0, 7), tips, mode: v ? 'ai' : 'keyword', breakdown }
}

const slim = (profile: Profile) => {
  const keep = ['org', 'orgType', 'country', 'regCountry', 'opCountries', 'scope', 'registered', 'taxStatus', 'founded', 'budget', 'size', 'mission', 'focus', 'populations', 'grantTypes', 'amountMin', 'amountMax', 'partner', 'largestGrant', 'fundingNeed', 'pastFunding']
  return Object.fromEntries(keep.map((k) => [k, short((profile as any)[k], k === 'mission' || k === 'fundingNeed' || k === 'pastFunding' ? 500 : 160)]).filter(([, v]) => v))
}

const RUBRIC =
  'You help an NGO decide which grants are worth its time. For EACH grant, read only the facts given about it and judge two things about how it fits THIS organization.\n' +
  '1) theme: an integer from 0 to 10. 10 means the call\'s purpose directly matches the organization\'s mission, sectors, beneficiaries and funding need. 5 means partial overlap. 0 means unrelated.\n' +
  '2) eligibility: "eligible" only if the call\'s own text says organizations like this one can apply (type, country, registration). "likely" if nothing contradicts it and the call is open to NGOs. "unclear" if the text does not say who can apply. "ineligible" only if the text clearly excludes this organization (for example individuals only, universities only, a different country only).\n' +
  'Do NOT lower either score because a call is closed, past its date, or by invitation only: timing and invitations are scored separately. Judge eligibility only from who the text says may apply.\n' +
  'Never invent rules, amounts, dates or requirements that are not in the text. If something is unknown, say it needs checking. Also give strengths, gaps and next-step tips, each a short sentence, at most 3 each, specific to this grant and this organization.\n' +
  'Reply with JSON only: {"results":[{"id": string, "theme": integer, "eligibility": "eligible"|"likely"|"unclear"|"ineligible", "reason": string (one sentence on the theme score), "strengths": string[], "gaps": string[], "tips": string[]}]}. Include every grant id you were given.'

async function judge(profile: Profile, grants: Grant[], library: string): Promise<Map<string, Verdict>> {
  const payload = grants.map((g) => ({
    id: g.id, title: short(g.title, 200), funder: short(g.funder, 120), source: g.source, status: g.status, deadline: g.deadline, countries: (g.countries ?? []).slice(0, 8), type: g.gtype,
    sectors: g.sectors, awardMin: g.amountMin || undefined, awardMax: g.amountMax || undefined, inviteOnly: g.inviteOnly || undefined,
    summary: short(g.summary, 800), details: short(g.details, 700),
  }))
  const txt = await llm(RUBRIC, `Organization: ${JSON.stringify(slim(profile))}${library ? `\nIts own documents on file: ${short(library, 900)}` : ''}\n\nGrants:\n${JSON.stringify(payload)}`, true, Math.min(5200, 500 + grants.length * 650), 0)
  const out = new Map<string, Verdict>()
  if (!txt) return out
  const p = parseJson(txt)
  const ok = ['eligible', 'likely', 'unclear', 'ineligible']
  for (const x of Array.isArray(p.results) ? p.results : Array.isArray(p) ? p : []) {
    const id = String(x?.id ?? '')
    if (!id || !grants.some((g) => g.id === id)) continue
    const theme = Math.max(0, Math.min(10, Math.round(Math.round(Number(x.theme)) / 2) * 2))
    if (!Number.isFinite(theme)) continue
    // A model sometimes glues several short sentences into one string with stray quotes. Split them and clean them.
    const list = (v: any) => (Array.isArray(v) ? v.flatMap((s: any) => String(s).split(/["'\\]+\s*,\s*["'\\]+/)).map((s: string) => s.replace(/^[\s"'\\\[]+|[\s"'\\\]]+$/g, '').trim()).filter(Boolean) : [])
    out.set(id, { theme, eligibility: ok.includes(x.eligibility) ? x.eligibility : 'unclear', reason: String(x.reason ?? ''), strengths: list(x.strengths), gaps: list(x.gaps), tips: list(x.tips) })
  }
  return out
}

export async function scoreGrants(profile: Profile, list: Grant[], library = ''): Promise<{ ok: true; results: Record<string, FitResult> } | { ok: false; reason: string; results: Record<string, FitResult> }> {
  const grants = (list ?? []).slice(0, 6)
  let verdicts = new Map<string, Verdict>()
  try {
    verdicts = await judge(profile, grants, library)
    // A grant the AI skipped is asked about once more on its own.
    const missing = grants.filter((g) => !verdicts.has(g.id))
    if (missing.length && missing.length < grants.length) for (const [k, v] of await judge(profile, missing, library).catch(() => new Map<string, Verdict>())) verdicts.set(k, v)
  } catch (e: any) {
    const reason = String(e?.message ?? 'The AI could not analyze these grants.')
    // Out of credits, signed out or at a usage limit: nothing more can be analyzed now, so say so instead of guessing scores.
    if (/credits|sign in|usage limit|too large/i.test(reason)) return { ok: false, reason, results: {} }
  }
  const results: Record<string, FitResult> = {}
  for (const g of grants) results[g.id] = compose(profile, g, verdicts.get(g.id) ?? null)
  return { ok: true, results }
}

export const analyzeFitBatch = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; grants: Grant[]; library?: string }) => d)
  .handler(async ({ data }) => scoreGrants(data.profile, data.grants, data.library ?? ''))

export const analyzeFit = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; grant: Grant; library?: string }) => d)
  .handler(async ({ data }): Promise<FitResult> => {
    let v: Verdict | null = null
    try { v = (await judge(data.profile, [data.grant], data.library ?? '')).get(data.grant.id) ?? null } catch { /* scored from the facts alone */ }
    return compose(data.profile, data.grant, v)
  })
