import { createServerFn } from '@tanstack/react-start'
import { sql } from '../db.server'
import { currentUser } from '../lib/session'
import { PLAN_LIMITS, type PlanKey } from '../plans'
import { ensureTable, planOf } from '../usage.server'

export type AdminUser = { id: string; name: string; plan: PlanKey; used: number; limit: number }
export type AdminStats = {
  month: string
  creditsThisMonth: number
  activeUsers: number
  monthly: { month: string; credits: number; users: number }[]
  users: AdminUser[]
  projects: { users: number; apps: number; profiles: number }
  nearLimit: number
}

// Only the site owner (an admin of the business that owns the portal) can read this. The check is made here, on the server.
export const getAdminStats = createServerFn({ method: 'GET' }).handler(async (): Promise<{ ok: true; stats: AdminStats } | { ok: false; reason: 'signed_out' | 'forbidden' | 'db_error' }> => {
  const u = await currentUser()
  if (!u) return { ok: false, reason: 'signed_out' }
  if ((await planOf(u.sub, true)) !== 'owner') return { ok: false, reason: 'forbidden' }
  try {
    await ensureTable()
    const db = sql()
    const month = new Date().toISOString().slice(0, 7)
    const rows = (await db`select user_id, n from ai_usage where month = ${month} order by n desc limit 40`) as any[]
    const totals = (await db`select month, sum(n)::int as credits, count(*)::int as users from ai_usage group by month order by month desc limit 6`) as any[]
    const apps = (await db`select count(distinct user_id)::int as users, count(*)::int as apps from saved_applications where left(app_id, 2) <> '__' and user_id <> '__system__'`) as any[]
    const profs = (await db`select count(*)::int as c from saved_applications where app_id = '__profile__' and user_id <> '__system__'`) as any[]
    const origin = process.env.WHOP_API_ORIGIN
    const users: AdminUser[] = await Promise.all(
      rows.map(async (r) => {
        const id = String(r.user_id)
        const plan = await planOf(id).catch(() => 'free' as PlanKey)
        let name = id
        try {
          const x = await fetch(`${origin}/api/v1/users/${id}`)
          if (x.ok) { const j: any = await x.json(); name = String(j?.name || j?.username || id) }
        } catch {}
        return { id, name, plan, used: Number(r.n), limit: PLAN_LIMITS[plan].credits }
      }),
    )
    const cur = totals.find((t) => String(t.month) === month)
    return {
      ok: true,
      stats: {
        month,
        creditsThisMonth: Number(cur?.credits ?? 0),
        activeUsers: Number(cur?.users ?? 0),
        monthly: totals.map((t) => ({ month: String(t.month), credits: Number(t.credits), users: Number(t.users) })),
        users,
        projects: { users: Number(apps[0]?.users ?? 0), apps: Number(apps[0]?.apps ?? 0), profiles: Number(profs[0]?.c ?? 0) },
        nearLimit: users.filter((x) => x.plan !== 'owner' && x.used >= x.limit * 0.8).length,
      },
    }
  } catch {
    return { ok: false, reason: 'db_error' }
  }
})
