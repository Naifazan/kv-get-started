import { createServerFn } from '@tanstack/react-start'
import { sql } from '../db.server'
import { currentUser } from '../lib/session'
import { projectLimitReached } from '../usage.server'
import { isStale, markViewed, readFindings, refreshFindings } from '../findings.server'
import type { Profile } from './grants'

export type SavedApp = { id: string; title: string; updated: number; data: Record<string, any> }

// Who is signed in. Never throws, so the page works for signed-out visitors.
export const whoami = createServerFn({ method: 'GET' }).handler(async () => {
  try {
    const u = await currentUser()
    return { signedIn: !!u, name: u?.name || u?.preferred_username || '', dbReady: !!process.env.DATABASE_URL }
  } catch {
    return { signedIn: false, name: '', dbReady: !!process.env.DATABASE_URL }
  }
})

export const listSaved = createServerFn({ method: 'GET' }).handler(async () => {
  const u = await currentUser()
  if (!u) return { ok: false as const, reason: 'signed_out' as const }
  try {
    const rows = await sql()`select app_id, title, data, extract(epoch from updated_at) * 1000 as updated from saved_applications where user_id = ${u.sub} and left(app_id, 2) <> '__' order by updated_at desc limit 100`
    return { ok: true as const, items: rows.map((r: any) => ({ id: String(r.app_id), title: String(r.title), updated: Math.round(Number(r.updated)), data: (r.data ?? {}) as Record<string, any> })) as SavedApp[] }
  } catch {
    return { ok: false as const, reason: 'db_error' as const }
  }
})

export const saveApplication = createServerFn({ method: 'POST' })
  .validator((d: { id: string; title: string; data: Record<string, any> }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const, reason: 'signed_out' as const }
    const json = JSON.stringify(data.data ?? {})
    if (json.length > 2_000_000) return { ok: false as const, reason: 'too_big' as const }
    try {
      const lim = await projectLimitReached(u.sub, String(data.id).slice(0, 80))
      if (lim.limited) return { ok: false as const, reason: 'project_limit' as const, max: lim.max }
      await sql()`insert into saved_applications (user_id, app_id, title, data, updated_at)
        values (${u.sub}, ${String(data.id).slice(0, 80)}, ${String(data.title || 'Untitled application').slice(0, 200)}, ${json}::jsonb, now())
        on conflict (user_id, app_id) do update set title = excluded.title, data = excluded.data, updated_at = now()`
      return { ok: true as const }
    } catch {
      return { ok: false as const, reason: 'db_error' as const }
    }
  })

export const deleteSaved = createServerFn({ method: 'POST' })
  .validator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const }
    try {
      await sql()`delete from saved_applications where user_id = ${u.sub} and app_id = ${String(data.id)}`
      return { ok: true as const }
    } catch {
      return { ok: false as const }
    }
  })

export const saveProfileOnline = createServerFn({ method: 'POST' })
  .validator((d: { profile: Record<string, any> }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const, reason: 'signed_out' as const }
    const json = JSON.stringify(data.profile ?? {})
    if (json.length > 200_000) return { ok: false as const, reason: 'too_big' as const }
    try {
      await sql()`insert into saved_applications (user_id, app_id, title, data, updated_at)
        values (${u.sub}, '__profile__', 'Organization profile', ${json}::jsonb, now())
        on conflict (user_id, app_id) do update set data = excluded.data, updated_at = now()`
      return { ok: true as const }
    } catch {
      return { ok: false as const, reason: 'db_error' as const }
    }
  })

export const loadProfileOnline = createServerFn({ method: 'GET' }).handler(async () => {
  const u = await currentUser()
  if (!u) return { ok: false as const, reason: 'signed_out' as const }
  try {
    const rows = await sql()`select data from saved_applications where user_id = ${u.sub} and app_id = '__profile__' limit 1`
    if (!rows.length) return { ok: true as const, profile: null }
    return { ok: true as const, profile: (rows[0].data ?? {}) as Record<string, any> }
  } catch {
    return { ok: false as const, reason: 'db_error' as const }
  }
})

// Matched grants for the signed-in user. Refreshes when the stored matches are older than 6 hours or `force` is set.
export const getFindings = createServerFn({ method: 'POST' })
  .validator((d: { profile: Profile; force?: boolean }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const, reason: 'signed_out' as const }
    try {
      let f = await readFindings(u.sub)
      let refreshed = false
      let note = ''
      if (data.force || isStale(f)) {
        try {
          f = await refreshFindings(u.sub, data.profile)
          refreshed = true
        } catch (e: any) {
          note = String(e?.message ?? 'Could not refresh right now.')
        }
      }
      if (!f) return { ok: true as const, items: [] as { g: Record<string, any>; score: number; isNew: boolean }[], updatedAt: 0, refreshed, note }
      const items = f.items.map((x) => ({ g: x.g as unknown as Record<string, any>, score: x.score, isNew: x.firstSeen > f!.viewedAt }))
      try { await markViewed(u.sub) } catch {}
      return { ok: true as const, items, updatedAt: f.updatedAt, refreshed, note }
    } catch {
      return { ok: false as const, reason: 'db_error' as const }
    }
  })

// Small per-user data sets (document library, snippets, awards) kept in the same table.
const BLOB_KEYS = ['library', 'awards']

export const saveUserBlob = createServerFn({ method: 'POST' })
  .validator((d: { key: string; t: number; data: Record<string, any> }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const, reason: 'signed_out' as const }
    if (!BLOB_KEYS.includes(data.key)) return { ok: false as const, reason: 'bad_key' as const }
    const json = JSON.stringify({ t: data.t, d: data.data })
    if (json.length > 800_000) return { ok: false as const, reason: 'too_big' as const }
    try {
      await sql()`insert into saved_applications (user_id, app_id, title, data, updated_at)
        values (${u.sub}, ${'__blob_' + data.key}, ${data.key}, ${json}::jsonb, now())
        on conflict (user_id, app_id) do update set data = excluded.data, updated_at = now()`
      return { ok: true as const }
    } catch {
      return { ok: false as const, reason: 'db_error' as const }
    }
  })

export const loadUserBlob = createServerFn({ method: 'POST' })
  .validator((d: { key: string }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const }
    if (!BLOB_KEYS.includes(data.key)) return { ok: false as const }
    try {
      const rows = await sql()`select data from saved_applications where user_id = ${u.sub} and app_id = ${'__blob_' + data.key} limit 1`
      if (!rows.length) return { ok: true as const, blob: null }
      const b = rows[0].data as { t?: number; d?: Record<string, any> }
      return { ok: true as const, blob: { t: Number(b.t) || 0, d: (b.d ?? {}) as Record<string, any> } }
    } catch {
      return { ok: false as const }
    }
  })

export const deleteAllMyData = createServerFn({ method: 'POST' }).handler(async () => {
  const u = await currentUser()
  if (!u) return { ok: false as const }
  try {
    await sql()`delete from saved_applications where user_id = ${u.sub}`
    return { ok: true as const }
  } catch {
    return { ok: false as const }
  }
})

export const exportAllMyData = createServerFn({ method: 'POST' }).handler(async () => {
  const u = await currentUser()
  if (!u) return { ok: false as const }
  try {
    const rows = await sql()`select app_id, title, data, extract(epoch from updated_at) * 1000 as updated from saved_applications where user_id = ${u.sub} order by updated_at desc`
    return { ok: true as const, items: rows.map((r: any) => ({ id: String(r.app_id), title: String(r.title), updated: Math.round(Number(r.updated)), data: (r.data ?? {}) as Record<string, any> })) }
  } catch {
    return { ok: false as const }
  }
})

// ---- Read-only share links ----
const rand = (n: number) => {
  const a = crypto.getRandomValues(new Uint8Array(n))
  return Array.from(a, (b) => 'abcdefghijkmnpqrstuvwxyz23456789'[b % 32]).join('')
}

export type SharedProposal = { title: string; funder: string; org: string; amount: string; months: string; sections: { title: string; text: string }[]; createdAt: number; expiresAt: number }

export const createShare = createServerFn({ method: 'POST' })
  .validator((d: { token?: string; snapshot: Omit<SharedProposal, 'createdAt' | 'expiresAt'> }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const, reason: 'signed_out' as const }
    const snap = data.snapshot
    if (JSON.stringify(snap).length > 600_000) return { ok: false as const, reason: 'too_big' as const }
    try {
      const db = sql()
      let token = data.token ?? ''
      if (token) {
        const own = await db`select data from saved_applications where user_id = '__share__' and app_id = ${token} limit 1`
        if (!own.length || (own[0].data as { owner?: string }).owner !== u.sub) token = ''
      }
      if (!token) token = rand(24)
      const now = Date.now()
      const payload = { owner: u.sub, snapshot: { ...snap, createdAt: now, expiresAt: now + 30 * 864e5 } }
      await db`insert into saved_applications (user_id, app_id, title, data, updated_at)
        values ('__share__', ${token}, ${String(snap.title || 'Shared proposal').slice(0, 200)}, ${JSON.stringify(payload)}::jsonb, now())
        on conflict (user_id, app_id) do update set data = excluded.data, title = excluded.title, updated_at = now()`
      return { ok: true as const, token, expiresAt: now + 30 * 864e5 }
    } catch {
      return { ok: false as const, reason: 'db_error' as const }
    }
  })

export const revokeShare = createServerFn({ method: 'POST' })
  .validator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const u = await currentUser()
    if (!u) return { ok: false as const }
    try {
      await sql()`delete from saved_applications where user_id = '__share__' and app_id = ${data.token} and data->>'owner' = ${u.sub}`
      return { ok: true as const }
    } catch {
      return { ok: false as const }
    }
  })

// Public: anyone with the link can read the snapshot until it expires.
export const getShare = createServerFn({ method: 'POST' })
  .validator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    if (!/^[a-z0-9]{16,40}$/.test(data.token)) return { ok: false as const }
    try {
      const rows = await sql()`select data from saved_applications where user_id = '__share__' and app_id = ${data.token} limit 1`
      if (!rows.length) return { ok: false as const }
      const snap = (rows[0].data as { snapshot?: SharedProposal }).snapshot
      if (!snap || snap.expiresAt < Date.now()) return { ok: false as const, expired: true as const }
      return { ok: true as const, proposal: snap }
    } catch {
      return { ok: false as const }
    }
  })
