import { createServerFn } from '@tanstack/react-start'
import { currentUser } from '../lib/session'
import { PLAN_LIMITS, type Billing } from '../plans'
import { nextReset, planOf, usedThisMonth } from '../usage.server'

export const getBilling = createServerFn({ method: 'GET' })
  .validator((d: { fresh?: boolean } | undefined) => d ?? {})
  .handler(async ({ data }): Promise<Billing> => {
    const empty: Billing = { signedIn: false, plan: 'free', used: 0, limit: PLAN_LIMITS.free.credits, projects: PLAN_LIMITS.free.projects, resetsAt: nextReset() }
    try {
      const u = await currentUser()
      if (!u) return empty
      const plan = await planOf(u.sub, !!data.fresh)
      const used = plan === 'owner' ? 0 : await usedThisMonth(u.sub).catch(() => 0)
      return { signedIn: true, plan, used, limit: PLAN_LIMITS[plan].credits, projects: PLAN_LIMITS[plan].projects, resetsAt: nextReset() }
    } catch {
      return empty
    }
  })
