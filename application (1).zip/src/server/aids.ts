import { createServerFn } from '@tanstack/react-start'
import { llm, parseJson } from './grants'

let fxCache: { at: number; date: string; rates: Record<string, number> } | null = null

export const fxRates = createServerFn({ method: 'GET' }).handler(async () => {
  if (fxCache && Date.now() - fxCache.at < 6 * 3600 * 1000) return { ok: true as const, date: fxCache.date, rates: fxCache.rates }
  try {
    const r = await fetch('https://api.frankfurter.app/latest?from=USD', { headers: { accept: 'application/json', 'x-whop-inject-key': 'none' } })
    if (!r.ok) return { ok: false as const, reason: 'The exchange rate service did not answer. Try again in a moment.' }
    const j: any = await r.json()
    const rates: Record<string, number> = { USD: 1 }
    for (const [k, v] of Object.entries(j.rates ?? {})) if (typeof v === 'number') rates[k] = v
    fxCache = { at: Date.now(), date: String(j.date ?? ''), rates }
    return { ok: true as const, date: fxCache.date, rates }
  } catch {
    return { ok: false as const, reason: 'Could not reach the exchange rate service.' }
  }
})

export type Benchmark = { item: string; unit: string; low: number; high: number; note: string }

export const costBenchmarks = createServerFn({ method: 'POST' })
  .validator((d: { country: string; items: string[] }) => d)
  .handler(async ({ data }) => {
    try {
      const items = data.items.map((x) => x.trim()).filter(Boolean).slice(0, 15)
      if (!items.length) return { ok: false as const, reason: 'Add at least one cost item.' }
      const txt = await llm(
        `You are a senior NGO budget officer. For each cost item give a typical unit and a realistic price range in USD for the country given, as used in grant budgets by NGOs. Reply with JSON: {"rows":[{"item":string,"unit":string,"low":number,"high":number,"note":string}]}. unit is day, month, person, item, workshop, trip and so on. note is one short sentence on what drives the price. These are rough planning estimates, so keep ranges honest and never claim precision you do not have. One row per item, in the same order.`,
        `Country: ${data.country || 'not stated'}\nItems:\n${items.map((x, i) => `${i + 1}. ${x}`).join('\n')}`,
        true,
        2200,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const rows: Benchmark[] = (Array.isArray(p.rows) ? p.rows : []).map((x: any) => ({ item: String(x.item ?? '').slice(0, 120), unit: String(x.unit ?? '').slice(0, 30), low: Math.max(0, Number(x.low) || 0), high: Math.max(0, Number(x.high) || 0), note: String(x.note ?? '').slice(0, 200) })).filter((x: Benchmark) => x.item && x.high > 0).slice(0, 15)
      if (!rows.length) return { ok: false as const, reason: 'The AI did not return usable ranges. Try again.' }
      return { ok: true as const, rows }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not estimate the costs.') }
    }
  })
