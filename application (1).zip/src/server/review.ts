import { createServerFn } from '@tanstack/react-start'
import { llm, parseJson } from './grants'
import { matchTitle } from '../lib/match-title'

export type CriterionScore = { criterion: string; score: number; evidence: string; gaps: string; suggestion: string }
export type ReviewResult = { overall: number; criteria: CriterionScore[]; strengths: string[]; fixes: { section: string; fix: string }[] }
export type ConsistencyIssue = { severity: 'high' | 'medium' | 'low'; area: string; issue: string; fix: string }

type SectionIn = { title: string; text: string }
const packSections = (sections: SectionIn[], each = 1100) =>
  sections.map((s) => `## ${s.title}\n${(s.text || '[empty]').slice(0, each)}`).join('\n\n').slice(0, 9500)

const DEFAULT_CRITERIA = ['Relevance to the funder priorities', 'Statement of need', 'Objectives and expected outcomes', 'Methodology and activities', 'Monitoring, evaluation and indicators', 'Sustainability', 'Budget and value for money', 'Organizational capacity']

export const reviewDraft = createServerFn({ method: 'POST' })
  .validator((d: { sections: SectionIn[]; criteria: string[]; summary: string; framework?: Record<string, string[]>; titles: string[] }) => d)
  .handler(async ({ data }) => {
    try {
      const criteria = data.criteria.length ? data.criteria.slice(0, 12) : DEFAULT_CRITERIA
      const txt = await llm(
        `You are a strict senior grant reviewer scoring a proposal against the funder's assessment criteria. For every criterion give: score (0 to 10), evidence (a short quote from the draft, at most 160 characters, or "" if there is none), gaps (what is missing or weak, one sentence), suggestion (one concrete fix). Then give overall (0 to 100, weighting criteria by any stated weights), strengths (at most 5 short items) and fixes (at most 6 items: {"section": the exact title of the proposal section to change, copied from the list of section titles below, or "General" if it concerns the whole proposal, "fix": the most valuable change}). Use ONLY the draft text. Empty sections score 0. Reply with JSON: {"overall":number,"criteria":[{"criterion":string,"score":number,"evidence":string,"gaps":string,"suggestion":string}],"strengths":[string],"fixes":[{"section":string,"fix":string}]}.`,
        `Section titles of this proposal (use them exactly):\n${data.titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nCriteria:\n${criteria.map((c, i) => `${i + 1}. ${c}`).join('\n')}\n\nFunder summary: ${data.summary.slice(0, 900)}\n${data.framework ? 'Framework the applicant selected: ' + JSON.stringify(data.framework).slice(0, 1800) + '\n' : ''}\nProposal draft:\n${packSections(data.sections)}`,
        true,
        2600,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const clamp = (n: any, lo: number, hi: number) => Math.max(lo, Math.min(hi, Math.round(Number(n) || 0)))
      const result: ReviewResult = {
        overall: clamp(p.overall, 0, 100),
        criteria: (Array.isArray(p.criteria) ? p.criteria : []).map((x: any) => ({ criterion: String(x.criterion ?? '').slice(0, 200), score: clamp(x.score, 0, 10), evidence: String(x.evidence ?? '').slice(0, 220), gaps: String(x.gaps ?? '').slice(0, 300), suggestion: String(x.suggestion ?? '').slice(0, 300) })).filter((x: CriterionScore) => x.criterion).slice(0, 14),
        strengths: (Array.isArray(p.strengths) ? p.strengths : []).map((x: any) => String(x).slice(0, 200)).slice(0, 5),
        fixes: (Array.isArray(p.fixes) ? p.fixes : []).map((x: any) => ({ section: matchTitle(data.titles, String(x.section ?? '')) || 'General', fix: String(x.fix ?? '').slice(0, 300) })).filter((x: { fix: string }) => x.fix).slice(0, 6),
      }
      if (!result.criteria.length) return { ok: false as const, reason: 'The AI did not return a usable review. Try again.' }
      return { ok: true as const, result }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not review the draft.') }
    }
  })

export const consistencyCheck = createServerFn({ method: 'POST' })
  .validator((d: { sections: SectionIn[]; amount: string; months: string; framework?: Record<string, string[]>; rules?: string; titles: string[] }) => d)
  .handler(async ({ data }) => {
    try {
      const txt = await llm(
        `You check a grant proposal for internal consistency. Look for: (1) activities that are missing from the timeline or have no cost in the budget; (2) outputs or outcomes without an indicator; (3) objectives, outcomes and indicators that use different terms for the same thing; (4) numbers that disagree between sections (beneficiaries, duration, dates, amounts); (5) a budget total that differs from the requested amount, or breaks a stated ceiling; (6) selected funder framework items that no section addresses. Report only real problems and quote the conflicting values. Reply with JSON: {"issues":[{"severity":"high"|"medium"|"low","area":the exact title of the section where the fix belongs, copied from the list of section titles below, or "Across sections","issue":string,"fix":string}]}. At most 15 issues. Return an empty list if the draft is consistent.`,
        `Section titles of this proposal (use them exactly):\n${data.titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nRequested amount: ${data.amount || 'not set'} USD. Duration: ${data.months || 'not set'} months.\n${data.rules ? 'Budget rules and ceilings: ' + data.rules.slice(0, 900) + '\n' : ''}${data.framework ? 'Selected framework: ' + JSON.stringify(data.framework).slice(0, 1800) + '\n' : ''}\nProposal draft:\n${packSections(data.sections, 1100)}`,
        true,
        2000,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const sev = ['high', 'medium', 'low']
      const issues: ConsistencyIssue[] = (Array.isArray(p.issues) ? p.issues : []).map((x: any) => ({ severity: sev.includes(x.severity) ? x.severity : 'medium', area: matchTitle(data.titles, String(x.area ?? '')) || 'Across sections', issue: String(x.issue ?? '').slice(0, 400), fix: String(x.fix ?? '').slice(0, 300) })).filter((x: ConsistencyIssue) => x.issue).slice(0, 15)
      return { ok: true as const, issues }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not check the draft.') }
    }
  })

export type FixSuggestion = { section: string; mode: 'append' | 'replace'; text: string; rationale: string; steps: string[] }

const squash = (o: Record<string, any>) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== '' && v != null))

/** Turns one review finding into a concrete change the applicant can apply to a section or discard. */
export const suggestFix = createServerFn({ method: 'POST' })
  .validator((d: {
    kind: string
    finding: string
    hint?: string
    wordLimit?: number
    sections: { title: string; text: string }[]
    profile: Record<string, any>
    summary?: string
    framework?: Record<string, string[]>
    amount?: string
    months?: string
  }) => d)
  .handler(async ({ data }) => {
    try {
      const hintTitle = matchTitle(data.sections.map((s) => s.title), data.hint)
      const hintSec = hintTitle ? data.sections.find((s) => s.title === hintTitle) : undefined
      const body = data.sections
        .map((s) => `## ${s.title}\n${(s === hintSec ? s.text.slice(0, 6500) : s.text.slice(0, 420)) || '[empty]'}`)
        .join('\n\n')
        .slice(0, 10500)
      const txt = await llm(
        `You are a senior grant writer improving a proposal after a review. You get ONE finding and the proposal sections. Decide which section to change and how. The sections are numbered. Reply with JSON: {"sectionNumber": the number of the section to change, "mode": "append" or "replace", "text": string, "rationale": string, "steps": string[]}. Mode "append": text is new content (a paragraph or a short subsection with a subtitle line) to add at the end of that section. Mode "replace": text is the FULL improved text of that section; use it only for the HINT section, whose full text is given, keep every fact, number and table unless the finding requires changing it, and change as little as needed. Use ONLY facts from the proposal, the organization profile and the funder summary. Where a fact is missing write a [bracketed placeholder] such as [XXX] or [%], never an invented figure. Write in a precise, professional grant-writing register. Do not use asterisks or markdown bold. Put subtitles on their own line. ${data.wordLimit ? `Keep the section within ${data.wordLimit} words.` : ''} If the finding is about something that is not proposal text (a document, a sign-off, a registration), set text to "" and give steps (at most 4 short, concrete steps). rationale is one sentence saying what the change achieves.`,
        `Sections (choose by number):\n${data.sections.map((s, i) => `${i + 1}. ${s.title}`).join('\n')}\n\nFinding type: ${data.kind}\nFinding: ${data.finding.slice(0, 700)}\nHINT section: ${data.hint || 'none'}\nRequested amount: ${data.amount || 'not set'} USD. Duration: ${data.months || 'not set'} months.\nOrganization: ${JSON.stringify(squash(data.profile)).slice(0, 1800)}\nFunder summary: ${(data.summary ?? '').slice(0, 1200)}\n${data.framework ? 'Selected framework: ' + JSON.stringify(data.framework).slice(0, 1500) + '\n' : ''}\nProposal:\n${body}`,
        true,
        2800,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const titles = data.sections.map((s) => s.title)
      const n = Math.round(Number(p.sectionNumber))
      // The section comes from the number the AI chose, then from the hint. If neither fits, the applicant picks one.
      const section = (n >= 1 && n <= titles.length ? titles[n - 1] : '') || hintSec?.title || matchTitle(titles, String(p.section ?? '')) || ''
      let mode: 'append' | 'replace' = p.mode === 'replace' ? 'replace' : 'append'
      if (mode === 'replace' && section !== hintSec?.title) mode = 'append'
      const clean = (t: string) => t.replace(/\*/g, '').replace(/\[\s*(?:percentage|percent)\s*%?\s*\]/gi, '[%]').trim()
      const out: FixSuggestion = {
        section,
        mode,
        text: clean(String(p.text ?? '')).slice(0, 14000),
        rationale: String(p.rationale ?? '').trim().slice(0, 300),
        steps: (Array.isArray(p.steps) ? p.steps : []).map((x: any) => String(x).trim().slice(0, 220)).filter(Boolean).slice(0, 4),
      }
      if (!out.text && !out.steps.length) return { ok: false as const, reason: 'The AI did not return a usable suggestion. Try again.' }
      return { ok: true as const, suggestion: out }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not prepare a suggestion.') }
    }
  })

export type ComplianceItem = { requirement: string; source: 'Template' | 'Guidance'; section: string; status: 'covered' | 'partial' | 'missing'; note: string }
export type ComplianceResult = {
  matrix: ComplianceItem[]
  conflicts: { issue: string; template: string; guidance: string; decision: string }[]
  gaps: { item: string; section: string }[]
  questions: string[]
  checks: { check: string; result: 'pass' | 'attention'; note: string }[]
}

/** Compliance matrix, conflicts, gaps and quality checks for the whole draft against the template and the guidance. */
export const complianceReport = createServerFn({ method: 'POST' })
  .validator((d: { titles: string[]; sections: SectionIn[]; guidanceText: string; templateSpec: string; framework?: Record<string, string[]>; amount: string; months: string; profile: Record<string, any> }) => d)
  .handler(async ({ data }) => {
    try {
      const txt = await llm(
        `You are an expert grant-writing specialist and compliance editor. Check a proposal draft against the funder's application template and guidance, which are the controlling documents. If they conflict, the guidance wins and the conflict must be flagged. Reply with JSON: {"matrix":[{"requirement":string,"source":"Template"|"Guidance","section":string,"status":"covered"|"partial"|"missing","note":string}],"conflicts":[{"issue":string,"template":string,"guidance":string,"decision":string}],"gaps":[{"item":string,"section":string}],"questions":[string],"checks":[{"check":string,"result":"pass"|"attention","note":string}]}. matrix: one row per template section requirement and per guidance requirement (eligibility, priorities, scoring criteria, budget rules, compliance and submission rules), at most 30 rows; "section" is the exact title of the section where the draft addresses it, copied from the list of section titles, or "Not addressed". gaps: every missing fact or [TO BE CONFIRMED] item in the draft, with its section. questions: at most 5 targeted questions, only for information that blocks submission. checks: completeness, word limits, internal consistency across objectives, activities, timeline, budget and indicators, acronyms defined, and no unsupported claims; note the specific problem when result is "attention". Use ONLY the supplied texts. Never invent requirements.`,
        `Section titles (use them exactly):\n${data.titles.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\nTemplate (authoritative structure and limits):\n${data.templateSpec.slice(0, 2000)}\n\nGuidance (authoritative rules):\n${data.guidanceText.slice(0, 4800)}\n\nRequested amount: ${data.amount || 'not set'} USD. Duration: ${data.months || 'not set'} months.\n${data.framework ? 'Selected framework: ' + JSON.stringify(data.framework).slice(0, 900) + '\n' : ''}Organization: ${JSON.stringify(squash(data.profile)).slice(0, 700)}\n\nProposal draft:\n${packSections(data.sections, 650)}`,
        true,
        2400,
      )
      if (!txt) return { ok: false as const, reason: 'AI is not switched on yet.' }
      const p = parseJson(txt)
      const st = ['covered', 'partial', 'missing']
      const result: ComplianceResult = {
        matrix: (Array.isArray(p.matrix) ? p.matrix : []).map((x: any) => ({ requirement: String(x.requirement ?? '').slice(0, 260), source: x.source === 'Template' ? 'Template' : 'Guidance', section: matchTitle(data.titles, String(x.section ?? '')) || 'Not addressed', status: st.includes(x.status) ? x.status : 'partial', note: String(x.note ?? '').slice(0, 260) })).filter((x: ComplianceItem) => x.requirement).slice(0, 30),
        conflicts: (Array.isArray(p.conflicts) ? p.conflicts : []).map((x: any) => ({ issue: String(x.issue ?? '').slice(0, 260), template: String(x.template ?? '').slice(0, 220), guidance: String(x.guidance ?? '').slice(0, 220), decision: String(x.decision ?? '').slice(0, 220) })).filter((x: { issue: string }) => x.issue).slice(0, 8),
        gaps: (Array.isArray(p.gaps) ? p.gaps : []).map((x: any) => ({ item: String(x.item ?? '').slice(0, 220), section: matchTitle(data.titles, String(x.section ?? '')) || 'General' })).filter((x: { item: string }) => x.item).slice(0, 25),
        questions: (Array.isArray(p.questions) ? p.questions : []).map((x: any) => String(x).slice(0, 240)).filter(Boolean).slice(0, 5),
        checks: (Array.isArray(p.checks) ? p.checks : []).map((x: any) => ({ check: String(x.check ?? '').slice(0, 160), result: x.result === 'pass' ? 'pass' : 'attention', note: String(x.note ?? '').slice(0, 260) })).filter((x: { check: string }) => x.check).slice(0, 10),
      }
      if (!result.matrix.length) return { ok: false as const, reason: 'The AI did not return a usable compliance matrix. Try again.' }
      return { ok: true as const, result }
    } catch (e: any) {
      return { ok: false as const, reason: String(e?.message ?? 'Could not build the compliance report.') }
    }
  })
