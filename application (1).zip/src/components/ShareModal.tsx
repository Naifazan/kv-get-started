import { useEffect, useState } from 'react'
import { askConfirm } from '../lib/confirm'

type Props = { token?: string; at?: number; signedIn: boolean; onCreate: (token?: string) => Promise<{ token: string; expiresAt: number } | string>; onRevoke: (token: string) => Promise<boolean>; onClose: () => void; onSignIn: () => void }
const ghost = 'inline-flex min-h-10 items-center justify-center rounded-full border border-accent/60 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const primary = 'inline-flex min-h-10 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'

export default function ShareModal({ token, at, signedIn, onCreate, onRevoke, onClose, onSignIn }: Props) {
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [onClose])
  const url = token ? `${window.location.origin}/share/${token}` : ''
  const expired = at ? Date.now() - at > 30 * 864e5 : false
  async function make() {
    setBusy(true); setNote('')
    const r = await onCreate(token)
    setNote(typeof r === 'string' ? r : token ? 'The shared copy now matches your latest draft.' : 'Link created. Copy it and send it to your reviewer.')
    setBusy(false)
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="share-title" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="w-full max-w-lg rounded-card bg-paper shadow-2xl">
        <div className="border-b border-line px-5 py-4"><h2 id="share-title" className="font-display text-2xl font-semibold">Share for review</h2><p className="mt-1 text-sm text-muted">Anyone with the link can read a snapshot of this proposal. They cannot edit it or see your other work. The link stops working after 30 days, or when you turn it off.</p></div>
        <div className="space-y-3 px-5 py-4">
          {!signedIn ? (
            <><p className="text-sm">Sign in with Whop to create a link.</p><button type="button" className={primary} onClick={onSignIn}>Sign in</button></>
          ) : (
            <>
              {token && !expired && (
                <div className="rounded-card border border-line bg-white p-3"><p className="text-xs font-semibold text-muted">Your link</p><p className="mt-1 break-all text-sm">{url}</p>
                  <div className="mt-2 flex flex-wrap gap-2"><button type="button" className={ghost} onClick={async () => { try { await navigator.clipboard.writeText(url); setNote('Link copied.') } catch { setNote('Could not copy. Select the link and copy it.') } }}>Copy link</button><a className={ghost} href={url} target="_blank" rel="noreferrer">Open</a></div></div>
              )}
              {expired && <p className="text-sm text-amber-900">The old link has expired. Create a new one.</p>}
              <div className="flex flex-wrap gap-2">
                <button type="button" className={primary} disabled={busy} onClick={make}>{busy ? 'Working...' : token && !expired ? 'Update with my latest draft' : 'Create a link'}</button>
                {token && <button type="button" className={ghost} disabled={busy} onClick={async () => { if (!(await askConfirm('Turn off this link? Anyone who has it will lose access.', { title: 'Stop sharing?' }))) return; setBusy(true); const ok = await onRevoke(token); setNote(ok ? 'Sharing is off.' : 'Could not turn it off. Try again.'); setBusy(false) }}>Stop sharing</button>}
              </div>
            </>
          )}
          {note && <p className="text-sm text-accent" aria-live="polite">{note}</p>}
        </div>
        <div className="flex justify-end border-t border-line px-5 py-4"><button type="button" className={ghost} onClick={onClose}>Close</button></div>
      </div>
    </div>
  )
}
