import { ghost, primary } from './ui'
import { PRICING_LINKS } from '../plans'

const FREE = ['Basic grant search', 'Grant overview and details', 'Pipeline and tracker']
const PRO = ['Full automated grant writing', 'Structured proposals', 'Needs assessments', 'Donor query tools']

export default function PricingSection() {
  return (
    <section id="pricing" aria-labelledby="pricing-heading" className="mt-10 print:hidden">
      <h2 id="pricing-heading" className="font-display text-2xl font-semibold md:text-3xl">Pick the plan that fits your fundraising team</h2>
      <div className="mt-5 grid gap-4 md:grid-cols-2">
        <article data-plan="free" aria-label="Free plan" className="flex flex-col rounded-card border border-line bg-card p-5">
          <h3 className="font-display text-xl font-semibold">Free Plan</h3>
          <p className="mt-3"><span className="font-display text-4xl font-semibold">$0</span></p>
          <ul className="mt-4 flex-1 space-y-2 text-sm">{FREE.map((p) => <li key={p} className="flex gap-2"><span aria-hidden className="text-accent">✓</span>{p}</li>)}</ul>
          <a className={ghost + ' mt-5 text-center'} href={PRICING_LINKS.free}>Start Free</a>
        </article>
        <article data-plan="pro" aria-label="Pro plan" className="flex flex-col rounded-card border border-accent bg-card p-5 shadow-lg">
          <h3 className="font-display text-xl font-semibold">Pro Plan</h3>
          <p className="mt-3"><span className="font-display text-4xl font-semibold">$29</span><span className="text-muted"> / month</span></p>
          <ul className="mt-4 flex-1 space-y-2 text-sm">{PRO.map((p) => <li key={p} className="flex gap-2"><span aria-hidden className="text-accent">✓</span>{p}</li>)}</ul>
          <a className={primary + ' mt-5 text-center'} href={PRICING_LINKS.pro}>Get Pro Access</a>
        </article>
      </div>
    </section>
  )
}
