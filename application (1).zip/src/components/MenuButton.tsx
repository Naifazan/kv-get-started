import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'

export type MenuItem = { id: string; label: string; done?: boolean; hint?: string; disabled?: boolean }
export type MenuGroup = { title?: string; items: MenuItem[] }

type Pos = { left: number; width: number; top?: number; bottom?: number; maxH: number }

// A button that opens a tidy menu: grouped items, a tick for finished ones. The list is drawn on top of the whole page,
// so no section can hide it, and it opens upward when there is more room above.
export default function MenuButton({ label, groups, onPick, busy = false, busyLabel, className }: { label: string; groups: MenuGroup[]; onPick: (id: string) => void; busy?: boolean; busyLabel?: string; className: string }) {
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState<Pos | null>(null)
  const btn = useRef<HTMLButtonElement>(null)
  const panel = useRef<HTMLDivElement>(null)

  const place = () => {
    const el = btn.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const vw = window.innerWidth
    const vh = window.innerHeight
    const width = Math.min(340, vw - 16)
    const left = Math.min(Math.max(8, r.left), vw - width - 8)
    const below = vh - r.bottom - 14
    const above = r.top - 14
    const up = below < 280 && above > below
    setPos(up ? { left, width, bottom: vh - r.top + 6, maxH: Math.max(160, above) } : { left, width, top: r.bottom + 6, maxH: Math.max(160, below) })
  }
  useLayoutEffect(() => {
    if (!open) return
    place()
    const on = () => place()
    window.addEventListener('resize', on)
    window.addEventListener('scroll', on, true)
    return () => { window.removeEventListener('resize', on); window.removeEventListener('scroll', on, true) }
  }, [open])
  useEffect(() => {
    if (!open) return
    const down = (e: MouseEvent) => {
      const t = e.target as Node
      if (!btn.current?.contains(t) && !panel.current?.contains(t)) setOpen(false)
    }
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', down)
    document.addEventListener('keydown', key)
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('keydown', key) }
  }, [open])

  return (
    <div className="relative inline-block">
      <button ref={btn} type="button" className={className} disabled={busy} aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {busy ? busyLabel ?? 'Working...' : label}
        <span aria-hidden className={`ml-2 inline-block text-xs transition-transform ${open ? 'rotate-180' : ''}`}>▾</span>
      </button>
      {open && pos && typeof document !== 'undefined' && createPortal(
        <div
          ref={panel}
          role="menu"
          className="overflow-y-auto rounded-card border border-line bg-paper p-2 text-ink shadow-2xl"
          style={{ position: 'fixed', zIndex: 1000, left: pos.left, width: pos.width, top: pos.top, bottom: pos.bottom, maxHeight: pos.maxH, animation: 'pop-in 0.18s var(--ease)' }}
        >
          {groups.map((g, gi) => (
            <div key={gi} className={gi > 0 ? 'mt-2 border-t border-line pt-2' : ''}>
              {g.title && <p className="px-3 pt-1 pb-1 text-[11px] font-semibold tracking-wide text-muted uppercase">{g.title}</p>}
              {g.items.map((it) => (
                <button
                  key={it.id}
                  type="button"
                  role="menuitem"
                  disabled={it.disabled}
                  onClick={() => { setOpen(false); onPick(it.id) }}
                  className="flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left text-sm font-medium hover:bg-accent/10 focus-visible:bg-accent/10 disabled:opacity-40"
                >
                  <span>{it.label}</span>
                  {it.done && <span aria-label="Already generated" className="shrink-0 text-xs font-semibold text-green-700">✓ Done</span>}
                </button>
              ))}
            </div>
          ))}
        </div>,
        document.body,
      )}
    </div>
  )
}
