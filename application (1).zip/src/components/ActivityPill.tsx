import { useEffect, useState } from 'react'
import { useActivity } from '../lib/activity'

// A small note at the bottom of the screen that shows when the portal is working on something, on every page.
export default function ActivityPill({ label, force }: { label: string; force: boolean }) {
  const act = useActivity()
  const [slow, setSlow] = useState(false)
  const [secs, setSecs] = useState(0)
  useEffect(() => {
    if (act.n === 0) { setSlow(false); return }
    const t = setTimeout(() => setSlow(true), 2500)
    return () => clearTimeout(t)
  }, [act.n])
  const on = force || slow
  useEffect(() => {
    if (!on) { setSecs(0); return }
    const t0 = Date.now()
    const id = setInterval(() => setSecs(Math.floor((Date.now() - t0) / 1000)), 1000)
    return () => clearInterval(id)
  }, [on])
  if (!on) return null
  return (
    <div role="status" aria-live="polite" className="fixed right-4 bottom-4 z-[1500] flex max-w-[22rem] items-center gap-3 rounded-full border border-accent/40 bg-paper px-4 py-2.5 text-sm shadow-xl print:hidden">
      <span aria-hidden className="inline-block h-3 w-3 shrink-0 animate-spin rounded-full border-2 border-accent border-t-transparent" />
      <span className="min-w-0 truncate"><span className="font-semibold">{label || 'Working on your request...'}</span> <span className="text-muted tabular-nums">{secs}s</span></span>
    </div>
  )
}
