import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'

const show = (iso: string) => (/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso.slice(8)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : '')
const pad = (n: number) => String(n).padStart(2, '0')
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
const DAYS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su']

function toIso(text: string): string | null {
  const m = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  if (!m) return null
  const d = Number(m[1]), mo = Number(m[2]), y = Number(m[3])
  const dt = new Date(Date.UTC(y, mo - 1, d))
  if (y < 1900 || y > 2200 || dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return null
  return `${m[3]}-${m[2]}-${m[1]}`
}

// A date box that always reads dd/mm/yyyy in English, with an English calendar, whatever language the browser uses.
// The stored value stays yyyy-mm-dd.
export default function DateField({ value, onChange, className, label }: { value: string; onChange: (iso: string) => void; className: string; label: string }) {
  const [text, setText] = useState(show(value))
  const last = useRef(value)
  const [open, setOpen] = useState(false)
  const now = new Date()
  const start = /^\d{4}-\d{2}-\d{2}$/.test(value) ? { y: Number(value.slice(0, 4)), m: Number(value.slice(5, 7)) - 1 } : { y: now.getFullYear(), m: now.getMonth() }
  const [view, setView] = useState(start)
  const ref = useRef<HTMLDivElement>(null)
  const popRef = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState<{ left: number; top?: number; bottom?: number } | null>(null)
  const place = () => {
    const r = ref.current?.getBoundingClientRect()
    if (!r) return
    const vw = window.innerWidth
    const vh = window.innerHeight
    const left = Math.min(Math.max(8, r.right - 288), vw - 288 - 8)
    const up = vh - r.bottom < 360 && r.top > vh - r.bottom
    setPos(up ? { left, bottom: vh - r.top + 6 } : { left, top: r.bottom + 6 })
  }
  useLayoutEffect(() => {
    if (!open) return
    place()
    const on = () => place()
    window.addEventListener('resize', on)
    window.addEventListener('scroll', on, true)
    return () => { window.removeEventListener('resize', on); window.removeEventListener('scroll', on, true) }
  }, [open])
  useEffect(() => {
    if (value !== last.current) { last.current = value; setText(show(value)) }
  }, [value])
  useEffect(() => {
    if (!open) return
    const down = (e: MouseEvent) => { const t = e.target as Node; if (!ref.current?.contains(t) && !popRef.current?.contains(t)) setOpen(false) }
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', down)
    document.addEventListener('keydown', key)
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('keydown', key) }
  }, [open])
  const bad = text.length === 10 && toIso(text) === null
  const set = (iso: string) => { last.current = iso; setText(show(iso)); onChange(iso) }
  const first = new Date(Date.UTC(view.y, view.m, 1))
  const lead = (first.getUTCDay() + 6) % 7
  const dim = new Date(Date.UTC(view.y, view.m + 1, 0)).getUTCDate()
  const cells: (number | null)[] = [...Array(lead).fill(null), ...Array.from({ length: dim }, (_, i) => i + 1)]
  const today = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
  const shift = (d: number) => setView((v) => { const t = new Date(Date.UTC(v.y, v.m + d, 1)); return { y: t.getUTCFullYear(), m: t.getUTCMonth() } })
  return (
    <div ref={ref} className="relative">
      <input
        type="text"
        inputMode="numeric"
        autoComplete="off"
        aria-label={label}
        aria-invalid={bad}
        maxLength={10}
        placeholder="dd/mm/yyyy"
        title={bad ? 'Enter a real date as dd/mm/yyyy' : 'Day, month, year, for example 31/12/2027'}
        className={`${className} pr-12 ${bad ? 'border-red-600' : ''}`}
        value={text}
        onChange={(e) => {
          const digits = e.target.value.replace(/\D/g, '').slice(0, 8)
          const t = digits.length > 4 ? `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}` : digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits
          setText(t)
          const iso = t === '' ? '' : toIso(t) ?? ''
          last.current = iso
          onChange(iso)
        }}
      />
      <button
        type="button"
        aria-label={`Open the calendar for ${label}`}
        aria-expanded={open}
        onClick={(e) => { e.preventDefault(); if (!open) setView(/^\d{4}-\d{2}-\d{2}$/.test(value) ? { y: Number(value.slice(0, 4)), m: Number(value.slice(5, 7)) - 1 } : { y: now.getFullYear(), m: now.getMonth() }); setOpen((o) => !o) }}
        className="absolute top-1/2 right-2 flex size-9 -translate-y-1/2 items-center justify-center rounded-lg text-accent hover:bg-accent/10"
      >
        <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <rect x="3" y="5" width="18" height="16" rx="3" />
          <path d="M8 3v4M16 3v4M3 10h18" />
        </svg>
      </button>
      {open && pos && typeof document !== 'undefined' && createPortal(
        <div ref={popRef} role="dialog" aria-label="Calendar" className="w-72 rounded-card border border-line bg-paper p-3 text-ink shadow-2xl" style={{ position: 'fixed', zIndex: 1000, left: pos.left, top: pos.top, bottom: pos.bottom, animation: 'pop-in 0.18s var(--ease)' }}>
          <div className="flex items-center justify-between gap-2">
            <button type="button" aria-label="Previous month" className="size-8 rounded-lg text-lg hover:bg-accent/10" onClick={() => shift(-1)}>‹</button>
            <div className="flex items-center gap-1">
              <select aria-label="Month" className="rounded-lg border border-line bg-white px-2 py-1 text-sm font-semibold" value={view.m} onChange={(e) => setView({ ...view, m: Number(e.target.value) })}>
                {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
              </select>
              <select aria-label="Year" className="rounded-lg border border-line bg-white px-2 py-1 text-sm font-semibold" value={view.y} onChange={(e) => setView({ ...view, y: Number(e.target.value) })}>
                {Array.from({ length: 61 }, (_, i) => now.getFullYear() - 20 + i).map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
            <button type="button" aria-label="Next month" className="size-8 rounded-lg text-lg hover:bg-accent/10" onClick={() => shift(1)}>›</button>
          </div>
          <div className="mt-2 grid grid-cols-7 gap-1 text-center text-xs font-semibold text-muted">{DAYS.map((d) => <span key={d}>{d}</span>)}</div>
          <div className="mt-1 grid grid-cols-7 gap-1">
            {cells.map((d, i) => {
              if (d === null) return <span key={'e' + i} />
              const iso = `${view.y}-${pad(view.m + 1)}-${pad(d)}`
              const sel = iso === value
              return (
                <button
                  key={iso}
                  type="button"
                  aria-label={`${d} ${MONTHS[view.m]} ${view.y}`}
                  aria-pressed={sel}
                  onClick={() => { set(iso); setOpen(false) }}
                  className={`h-9 rounded-lg text-sm font-medium tabular-nums ${sel ? 'bg-accent text-accent-ink' : iso === today ? 'border border-accent text-accent hover:bg-accent/10' : 'hover:bg-accent/10'}`}
                >
                  {d}
                </button>
              )
            })}
          </div>
          <div className="mt-3 flex items-center justify-between text-sm font-semibold">
            <button type="button" className="text-accent underline" onClick={() => { set(today); setOpen(false) }}>Today</button>
            <button type="button" className="text-muted underline" onClick={() => { set(''); setOpen(false) }}>Clear</button>
          </div>
        </div>,
        document.body,
      )}
    </div>
  )
}
