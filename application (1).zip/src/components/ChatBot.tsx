import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { chatAssistant } from '../server/grants'
import { matchTitle } from '../lib/match-title'
import { tidy } from '../lib/text'
import { primary } from './ui'
import type { HomeState } from '../pages/use-home'

type Applied = { key: string; title: string; prev: string; mode: 'replace' | 'append'; undone?: boolean }
type Msg = { role: 'user' | 'assistant'; content: string; at?: number; applied?: Applied[] }

const STARTERS = ['What does this funder look for?', 'What is missing from my proposal?', 'Improve my project summary in the draft']

const isRow = (l: string) => /^\s*\|.*\|\s*$/.test(l)
const cellsOf = (l: string) => l.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim())
const isSep = (cs: string[]) => cs.length > 0 && cs.every((c) => /^:?-{2,}:?$/.test(c))

function inline(t: string) {
  return t.split(/(\*\*[^*]+\*\*)/g).map((part, i) => (/^\*\*[^*]+\*\*$/.test(part) ? <strong key={i}>{part.slice(2, -2)}</strong> : <span key={i}>{part.replace(/`/g, '')}</span>))
}

// Draws the assistant's text: pipe tables as real tables, plus lists, headings and bold.
function Rich({ text }: { text: string }) {
  const lines = text.replace(/\r/g, '').split('\n')
  const out: React.ReactNode[] = []
  for (let i = 0; i < lines.length; ) {
    const line = lines[i]
    if (isRow(line)) {
      const rows: string[][] = []
      let align: ('left' | 'right' | 'center')[] = []
      while (i < lines.length && isRow(lines[i])) {
        const cs = cellsOf(lines[i])
        if (isSep(cs)) align = cs.map((c) => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : 'left'))
        else rows.push(cs)
        i++
      }
      if (!rows.length) continue
      const w = Math.max(...rows.map((r) => r.length))
      const norm = rows.map((r) => [...r, ...Array(w - r.length).fill('')])
      out.push(
        <div key={out.length} className="my-2 overflow-x-auto rounded-lg border border-line">
          <table className="w-full border-collapse text-xs">
            <thead><tr>{norm[0].map((c, j) => <th key={j} style={{ textAlign: align[j] ?? 'left' }} className="border-b border-line bg-ink px-2 py-1.5 font-semibold text-paper">{inline(c)}</th>)}</tr></thead>
            <tbody>{norm.slice(1).map((r, ri) => <tr key={ri} className={/total/i.test(r.join(' ')) ? 'bg-accent/10 font-semibold' : ri % 2 ? 'bg-paper' : ''}>{r.map((c, j) => <td key={j} style={{ textAlign: align[j] ?? (/^[\s$€£]*-?[\d.,]+%?\s*$/.test(c) ? 'right' : 'left') }} className="border-t border-line px-2 py-1.5 align-top">{inline(c)}</td>)}</tr>)}</tbody>
          </table>
        </div>,
      )
      continue
    }
    if (/^\s*[-*•]\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*[-*•]\s+/, ''))
      out.push(<ul key={out.length} className="my-1 list-disc space-y-0.5 pl-5">{items.map((t, k) => <li key={k}>{inline(t)}</li>)}</ul>)
      continue
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      const items: string[] = []
      while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*\d+[.)]\s+/, ''))
      out.push(<ol key={out.length} className="my-1 list-decimal space-y-0.5 pl-5">{items.map((t, k) => <li key={k}>{inline(t)}</li>)}</ol>)
      continue
    }
    if (/^\s*#{1,4}\s+/.test(line)) { out.push(<p key={out.length} className="mt-2 font-semibold">{inline(line.replace(/^\s*#{1,4}\s+/, ''))}</p>); i++; continue }
    if (!line.trim()) { i++; continue }
    out.push(<p key={out.length} className="mt-1 whitespace-pre-wrap">{inline(line)}</p>)
    i++
  }
  return <>{out}</>
}

export default function ChatBot({ h }: { h: HomeState }) {
  const { app, project, secs, doc, inputs, patch, profile, setDoc, snapshotDoc, setViewing, setEditing, fitText } = h as any
  const [open, setOpen] = useState(false)
  // The conversation is saved on the application, so it comes back after a reload and syncs when signed in.
  // With an application open the chat is saved on it; elsewhere it is kept for the session.
  const [loose, setLoose] = useState<Msg[]>([])
  const msgs: Msg[] = (app ? (app.chat ?? []) : loose) as Msg[]
  const setMsgs = (m: Msg[]) => {
    if (!app) { setLoose(m.slice(-60)); return }
    patch((a: any) => ({ ...a, chat: m.slice(-60).map((x: any) => ({ role: x.role, content: String(x.content).slice(0, 6000), at: x.at ?? Date.now(), ...(x.applied ? { applied: x.applied } : {}) })) }))
  }
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const end = useRef<HTMLDivElement>(null)
  const panel = useRef<HTMLElement>(null)
  const toggle = useRef<HTMLButtonElement>(null)
  // A click or tap anywhere outside the chat box (and its button) closes it. Escape closes it too.
  useEffect(() => {
    if (!open) return
    const down = (e: Event) => {
      const t = e.target as Node
      if (panel.current?.contains(t) || toggle.current?.contains(t)) return
      setOpen(false)
    }
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', down)
    document.addEventListener('touchstart', down)
    document.addEventListener('keydown', key)
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('touchstart', down); document.removeEventListener('keydown', key) }
  }, [open])
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }) }, [msgs, busy, open])

  // Everything filled in on the application page, most important first, so the AI can answer from the real content.
  const context = () => {
    const parts: string[] = []
    const cap = (t: unknown, n: number) => String(t ?? '').trim().slice(0, n)
    const g = app?.grant
    if (g) parts.push(`TARGET GRANT: ${cap(g.title, 200)} | funder: ${cap(g.funder, 120)} | amount: ${cap(g.amountText ?? g.amount ?? '', 80)} | deadline: ${cap(g.deadline, 40)} | countries: ${cap(Array.isArray(g.countries) ? g.countries.join(', ') : g.countries, 200)}${g.summary ? `\nSummary: ${cap(g.summary, 500)}` : ''}${g.details ? `\nDetails: ${cap(g.details, 1200)}` : ''}`)
    parts.push(`PROJECT: title "${project?.title || 'not set'}"; amount requested ${project?.amount || 'not set'} USD; duration ${project?.months || 'not set'} months; stage ${app?.status ?? ''}${app?.probability != null ? `; win probability ${app.probability}%` : ''}`)
    if (app?.guidance) {
      const gd = app.guidance
      const L = (t: string, v?: string[]) => (v && v.length ? `${t}: ${v.join('; ')}` : '')
      parts.push('FUNDER GUIDANCE:\n' + [L('Priorities', gd.priorities), L('Eligibility', gd.eligibility), L('Assessment criteria', gd.criteria), L('Budget rules', gd.budget), L('Format and attachments', gd.format), L('Key dates', gd.dates)].filter(Boolean).join('\n').slice(0, 3000))
    } else if (app?.guidanceText) parts.push(`FUNDER GUIDANCE:\n${cap(app.guidanceText, 3000)}`)
    if (app?.tpl?.sections?.length) parts.push('FUNDER APPLICATION TEMPLATE SECTIONS:\n' + app.tpl.sections.map((x: any, i: number) => `${i + 1}. ${x.title}${x.wordLimit ? ` (limit ${x.wordLimit} words)` : ''}${x.guidance ? `: ${cap(x.guidance, 220)}` : ''}`).join('\n').slice(0, 2500))
    if (app?.framework?.selected) {
      const f = Object.entries(app.framework.selected).filter(([, v]: any) => v && v.length).map(([k, v]: any) => `${k}: ${v.join('; ')}`).join('\n')
      if (f) parts.push(`FRAMEWORK THE PROJECT RESPONDS TO:\n${f.slice(0, 1200)}`)
    }
    if (app?.eligibility?.length) parts.push('ELIGIBILITY CHECK:\n' + app.eligibility.map((e: any) => `- ${cap(e.requirement ?? e.label ?? e.title ?? '', 140)}: ${cap(e.status ?? '', 20)}${e.note ? ` (${cap(e.note, 120)})` : ''}`).join('\n').slice(0, 1500))
    if (app?.facts) parts.push(`KEY FACTS: direct beneficiaries ${cap(app.facts.direct, 120)}; indirect ${cap(app.facts.indirect, 120)}; partners ${cap(app.facts.partners, 160)}; targets ${cap(app.facts.targets, 200)}`)
    if (app?.plan?.trim()) parts.push(`PLANNED PROJECT INFORMATION (provided by the applicant):\n${cap(app.plan, 3500)}`)
    if (inputs?.needs?.trim()) parts.push(`NEEDS ASSESSMENT:\n${cap(inputs.needs, 2200)}`)
    const areas = (inputs?.areas ?? []).map((a: any) => a?.name || [a?.district, a?.governorate, a?.country].filter(Boolean).join(', ')).filter(Boolean)
    if (areas.length) parts.push(`PLANNED TARGET AREAS: ${areas.join(' | ')}`)
    if (inputs?.primary?.trim()) parts.push(`PRIMARY INFORMATION ABOUT THE TARGET AREAS:\n${cap(inputs.primary, 1200)}`)
    for (const x of app?.experience ?? []) parts.push(`PAST EXPERIENCE (${x.name}):\n${cap(x.summary, 1100)}`)
    const written = (secs ?? []).map(([k, t]: [string, string]) => (doc?.[k]?.trim() ? `## ${t}\n${cap(doc[k], 4000)}${String(doc[k]).trim().length > 4000 ? ' ...[TRUNCATED]' : ''}` : `## ${t}\n(not written yet)`)).join('\n\n')
    if (written) parts.push(`PROPOSAL SECTIONS AS WRITTEN:\n${written}`)
    if (doc?.x_budget?.trim()) parts.push(`BUDGET:\n${cap(doc.x_budget, 2500)}`)
    for (const [k, v] of Object.entries(app?.extras ?? {}) as [string, any][]) if (v?.text) parts.push(`PREPARED DOCUMENT "${cap(v.title || k, 80)}":\n${cap(v.text, 900)}`)
    if (app?.review) parts.push(`LAST AI REVIEW SCORE: ${app.review.overall}`)
    if (app?.notes?.trim()) parts.push(`APPLICANT NOTES:\n${cap(app.notes, 600)}`)
    const pr = profile ? Object.entries(profile).filter(([, v]) => v !== '' && v != null && !(Array.isArray(v) && !v.length) && typeof v !== 'object').map(([k, v]) => `${k}: ${cap(v, 220)}`).join('; ') : ''
    if (pr) parts.push(`APPLICANT ORGANIZATION PROFILE:\n${pr.slice(0, 2500)}`)
    return parts.join('\n\n')
  }

  async function send(q: string) {
    const content = q.trim()
    if (!content || busy) return
    const base = msgs
    const next: Msg[] = [...base, { role: 'user', content }]
    setMsgs(next)
    setText('')
    setBusy(true)
    try {
      const titles: string[] = (secs ?? []).map(([, t]: [string, string]) => t)
      const r = await chatAssistant({ data: { messages: next, context: context(), sections: titles } })
      if (!r.ok) { setMsgs([...next, { role: 'assistant', content: r.reason, at: Date.now() }]) }
      else {
        // The edits go straight into the draft. A copy of the earlier draft is saved in History, and each edit can be undone from the reply.
        const applied: Applied[] = []
        const writes: Record<string, string> = {}
        for (const e of r.edits ?? []) {
          const title = matchTitle(titles, e.section)
          const key = (secs ?? []).find(([, t]: [string, string]) => t === title)?.[0]
          if (!key || writes[key] !== undefined) continue
          const prev = String(doc?.[key] ?? '')
          const body = tidy(e.text)
          const merged = e.mode === 'append' && prev.trim() ? `${prev.trim()}\n\n${body}` : body
          // Edits made by the chat also stay inside the funder's length limit for that field.
          writes[key] = fitText ? (await fitText(key, title, merged)).text : merged
          applied.push({ key, title, prev: prev.slice(0, 12000), mode: e.mode })
        }
        if (applied.length) {
          snapshotDoc(`Before the AI assistant edited ${applied.length} section${applied.length === 1 ? '' : 's'}`)
          setDoc((d: Record<string, string>) => ({ ...d, ...writes }))
          setViewing?.((c: any) => ({ ...c, ...Object.fromEntries(applied.map((x) => [x.key, true])) }))
          setEditing?.((c: any) => ({ ...c, ...Object.fromEntries(applied.map((x) => [x.key, false])) }))
        }
        setMsgs([...next, { role: 'assistant', content: r.text, at: Date.now(), ...(applied.length ? { applied } : {}) }])
      }
    } catch {
      setMsgs([...next, { role: 'assistant', content: 'Something went wrong. Please try again.', at: Date.now() }])
    }
    setBusy(false)
  }

  function undo(mi: number, ai: number) {
    const m = msgs[mi]
    const a = m?.applied?.[ai]
    if (!a || a.undone) return
    setDoc((d: Record<string, string>) => ({ ...d, [a.key]: a.prev }))
    setMsgs(msgs.map((x, i) => (i === mi ? { ...x, applied: x.applied!.map((y, j) => (j === ai ? { ...y, undone: true } : y)) } : x)))
  }

  function download() {
    const body = msgs.map((m: any) => `${m.role === 'user' ? 'You' : 'AI assistant'}${m.at ? ' (' + new Date(m.at).toLocaleString() + ')' : ''}:\n${m.content}`).join('\n\n---\n\n')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([body], { type: 'text/plain;charset=utf-8' }))
    a.download = 'ai-chat-history.txt'
    a.click()
  }

  const ui = (
    <div className="print:hidden">
      {open && (
        <section ref={panel} role="dialog" aria-label="AI assistant" className="fixed right-2 bottom-20 z-[2147483000] flex h-[min(32rem,calc(100vh-7rem))] w-[calc(100vw-1rem)] max-w-md flex-col overflow-hidden rounded-card border border-line bg-paper text-ink shadow-2xl">
          <header className="flex items-center justify-between bg-ink px-4 py-3 text-paper">
            <div><p className="font-semibold">AI assistant</p><p className="text-xs text-paper/70">Edits your draft when you ask. 1 AI credit per reply.</p></div>
            <div className="flex items-center gap-3 text-sm">
              {msgs.length > 0 && <button type="button" className="underline" onClick={download}>Save .txt</button>}
              {msgs.length > 0 && <button type="button" className="underline" onClick={() => { if (window.confirm('Delete the saved chat history for this application?')) setMsgs([]) }}>Clear</button>}
              <button type="button" aria-label="Close assistant" className="text-lg leading-none" onClick={() => setOpen(false)}>✕</button>
            </div>
          </header>
          <div className="flex-1 space-y-3 overflow-y-auto p-4 text-sm" aria-live="polite">
            {msgs.length === 0 && (
              <div>
                <p className="text-muted">Ask anything about this proposal or about grant writing.</p>
                <div className="mt-3 flex flex-col gap-2">{STARTERS.map((s) => <button key={s} type="button" className="rounded-lg border border-line bg-card px-3 py-2 text-left hover:bg-accent/10" onClick={() => send(s)}>{s}</button>)}</div>
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={m.role === 'user' ? 'ml-8 rounded-lg bg-accent px-3 py-2 text-accent-ink' : 'mr-8 min-w-0 rounded-lg border border-line bg-card px-3 py-2'}>{m.role === 'user' ? m.content : <Rich text={m.content} />}
                {m.applied && m.applied.length > 0 && (
                  <ul className="mt-2 space-y-1 border-t border-line pt-2 text-xs">
                    {m.applied.map((a, j) => (
                      <li key={j} className="flex flex-wrap items-center justify-between gap-2">
                        <span className={a.undone ? 'text-muted line-through' : 'font-semibold text-green-800'}>{a.undone ? 'Undone' : a.mode === 'append' ? 'Added to' : 'Updated'}: {a.title}</span>
                        {!a.undone && <span className="flex gap-3"><button type="button" className="font-semibold text-accent underline" onClick={() => document.getElementById('sec-' + a.key)?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>Go to section</button><button type="button" className="font-semibold underline" onClick={() => undo(i, j)}>Undo</button></span>}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
            {busy && <div className="mr-8 rounded-lg border border-line bg-card px-3 py-2 text-muted">Thinking...</div>}
            <div ref={end} />
          </div>
          <form className="flex gap-2 border-t border-line p-3" onSubmit={(e) => { e.preventDefault(); send(text) }}>
            <input aria-label="Message" className="min-h-11 flex-1 rounded-full border border-line bg-card px-4 text-sm" value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask the assistant..." />
            <button type="submit" className={primary} disabled={busy || !text.trim()}>Send</button>
          </form>
        </section>
      )}
      <button
        ref={toggle}
        type="button"
        aria-label={open ? 'Close AI assistant' : 'Open AI assistant'}
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        style={{ position: 'fixed', right: 'max(0.5rem, env(safe-area-inset-right))', bottom: 'max(0.5rem, env(safe-area-inset-bottom))', zIndex: 2147483647, transform: 'translateZ(0)' }}
        className="inline-flex min-h-12 items-center gap-2 rounded-full bg-accent px-5 font-semibold text-accent-ink shadow-xl ring-2 ring-white hover:brightness-110"
      >
        <span aria-hidden>💬</span>{open ? 'Close' : 'Ask AI'}
      </button>
    </div>
  )
  // Drawn straight into the page body so no parent layout can move it: it stays fixed at the bottom left corner.
  return mounted ? createPortal(ui, document.body) : null
}
