import { Component } from 'react'
import type { ReactNode } from 'react'

type Props = { children: ReactNode; resetKey: string }
type State = { failed: boolean }

/** Keeps one broken page from taking down the whole portal. */
export default class ErrorBoundary extends Component<Props, State> {
  state: State = { failed: false }
  static getDerivedStateFromError(): State { return { failed: true } }
  componentDidUpdate(prev: Props) { if (prev.resetKey !== this.props.resetKey && this.state.failed) this.setState({ failed: false }) }
  render() {
    if (!this.state.failed) return this.props.children
    return (
      <div role="alert" className="rounded-card border border-line bg-card p-8 text-center">
        <p className="font-display text-2xl font-semibold">Something went wrong on this page</p>
        <p className="mx-auto mt-2 max-w-md text-muted">Your work is saved. Try the page again, or open another page from the menu.</p>
        <div className="mt-4 flex flex-wrap justify-center gap-3">
          <button type="button" className="inline-flex min-h-11 items-center rounded-full bg-accent px-6 font-semibold text-accent-ink" onClick={() => this.setState({ failed: false })}>Try again</button>
          <button type="button" className="inline-flex min-h-11 items-center rounded-full border border-accent/60 px-5 font-semibold text-accent" onClick={() => window.location.reload()}>Reload the portal</button>
        </div>
      </div>
    )
  }
}
