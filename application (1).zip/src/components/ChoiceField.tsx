import { field } from './ui'

type Props = {
  id: string
  type: 'yesno' | 'select' | 'multiselect' | 'number' | 'date'
  options: string[]
  value: string
  explain?: boolean
  unit?: string
  required?: boolean
  onChange: (v: string) => void
}

// The answer is stored as plain text: the choice on the first line and, when the funder asks for it, an explanation after a blank line.
// This keeps the exported Word and PDF files and the AI review working with it as before.
const split = (v: string) => { const i = v.indexOf('\n\n'); return i < 0 ? { head: v.trim(), tail: '' } : { head: v.slice(0, i).trim(), tail: v.slice(i + 2) } }

export default function ChoiceField({ id, type, options, value, explain, unit, required, onChange }: Props) {
  const { head, tail } = split(value)
  const join = (h: string, t: string) => (t.trim() || (explain && h) ? `${h}\n\n${t}` : h)
  const chosen = type === 'multiselect' ? head.split(';').map((x) => x.trim()).filter(Boolean) : [head]
  return (
    <div className="mt-3 rounded-card border border-line bg-white p-4">
      {(type === 'yesno' || (type === 'select' && options.length <= 4)) && (
        <fieldset>
          <legend className="sr-only">Choose one</legend>
          <div className="flex flex-wrap gap-3">
            {options.map((o) => (
              <label key={o} className={`inline-flex min-h-11 cursor-pointer items-center gap-2 rounded-full border px-5 text-sm font-semibold ${head === o ? 'border-accent bg-accent text-accent-ink' : 'border-line bg-card hover:border-accent/60'}`}>
                <input type="radio" className="sr-only" name={id} checked={head === o} onChange={() => onChange(join(o, tail))} />
                {head === o && <span aria-hidden>✓</span>}{o}
              </label>
            ))}
            {head && <button type="button" className="text-sm font-semibold underline" onClick={() => onChange('')}>Clear</button>}
          </div>
        </fieldset>
      )}
      {type === 'select' && options.length > 4 && (
        <select aria-label="Choose one" className={`${field} mt-0`} value={head} onChange={(e) => onChange(join(e.target.value, tail))}>
          <option value="">Choose an option</option>
          {head && !options.includes(head) && <option value={head}>{head}</option>}
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      )}
      {type === 'multiselect' && (
        <fieldset>
          <legend className="sr-only">Tick all that apply</legend>
          <div className="grid gap-2 md:grid-cols-2">
            {options.map((o) => (
              <label key={o} className="flex cursor-pointer items-start gap-2 text-sm">
                <input type="checkbox" className="mt-1 h-4 w-4 accent-[var(--color-accent)]" checked={chosen.includes(o)} onChange={(e) => { const next = e.target.checked ? [...chosen, o] : chosen.filter((x) => x !== o); onChange(join(options.filter((x) => next.includes(x)).join('; '), tail)) }} />
                <span>{o}</span>
              </label>
            ))}
          </div>
        </fieldset>
      )}
      {type === 'number' && (
        <div className="flex items-center gap-2">
          <input aria-label="Number" inputMode="decimal" className={`${field} mt-0 max-w-xs`} value={head} onChange={(e) => onChange(e.target.value.replace(/[^0-9.,\-]/g, ''))} placeholder="0" />
          {unit && <span className="text-sm font-semibold text-muted">{unit}</span>}
        </div>
      )}
      {type === 'date' && <input aria-label="Date" type="date" className={`${field} mt-0 max-w-xs`} value={/^\d{4}-\d{2}-\d{2}$/.test(head) ? head : ''} onChange={(e) => onChange(e.target.value)} />}
      {explain && (type === 'yesno' || type === 'select' || type === 'multiselect') && (
        <label className="mt-3 block text-xs font-semibold">Explanation or details the funder asks for
          <textarea rows={3} className={`${field} mt-1 font-normal`} value={tail} onChange={(e) => onChange(join(head, e.target.value))} placeholder="Explain your answer" />
        </label>
      )}
      {required && !head && <p className="mt-2 text-xs font-semibold text-red-800">Required by the funder.</p>}
    </div>
  )
}
