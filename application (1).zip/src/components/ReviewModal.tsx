import { useEffect, useState } from 'react'
import { complianceReport, consistencyCheck, reviewDraft, suggestFix } from '../server/review'
import type { ComplianceResult, ConsistencyIssue, FixSuggestion, ReviewResult } from '../server/review'
import { matchTitle } from '../lib/match-title'

export type RSection = { key: string; title: string; text: string; wordLimit: number }
export type CheckItem = { id: string; label: string; source: string; auto?: boolean; done: boolean }

type Props = {
  title: string
  sections: RSection[]
  criteria: string[]
  summary: string
  framework?: Record<string, string[]>
  amount: string
  months: string
  rules?: string
  onGoto: (key: string) => void
  onClose: () => void
  onReviewed: (overall: number) => void
  profile: Record<string, any>
  guidanceText: string
  templateSpec: string
  onApplyText: (key: string, mode: 'append' | 'replace', text: string) => void
  renderText?: (t: string) => React.ReactNode
}

type Tab = 'review' | 'consistency' | 'compliance'
const TABS: [Tab, string][] = [['review', 'Reviewer score'], ['consistency', 'Consistency'], ['compliance', 'Compliance matrix']]
const ghost = 'inline-flex min-h-10 items-center justify-center rounded-full border border-accent/60 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const primary = 'inline-flex min-h-10 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'
const words = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0)

type Sug = { busy?: boolean; error?: string; data?: FixSuggestion; key?: string; mode?: 'append' | 'replace'; text?: string; applied?: string; discarded?: boolean }

function SuggestionPanel({ s, sections, onChange, onApply, onDiscard, onGoto, extra, render }: {
  s: Sug
  sections: RSection[]
  onChange: (patch: Partial<Sug>) => void
  onApply: () => void
  onDiscard: () => void
  onGoto: (key: string) => void
  extra?: React.ReactNode
  render?: (t: string) => React.ReactNode
}) {
  if (s.discarded) return <p className="mt-2 text-xs text-muted">Suggestion discarded.</p>
  if (s.busy) return <p className="mt-2 text-sm text-muted" aria-live="polite">AI is preparing a suggestion...</p>
  if (s.error) return <p className="mt-2 text-sm text-accent">{s.error}</p>
  if (s.applied) return <p className="mt-2 text-sm font-semibold text-green-800">Applied to "{s.applied}". Run the check again to see the effect. <button type="button" className="text-accent underline" onClick={() => onGoto(s.key ?? '')}>Go to section</button></p>
  const d = s.data
  if (!d) return null
  const target = sections.find((x) => x.key === s.key)
  const before = words(target?.text ?? '')
  const after = words(s.text ?? '')
  return (
    <div className="mt-3 rounded-card border border-accent/40 bg-card p-3">
      <p className="text-xs font-semibold tracking-wide text-accent uppercase">AI suggestion</p>
      {d.rationale && <p className="mt-1 text-sm">{d.rationale}</p>}
      {d.steps.length > 0 && <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm">{d.steps.map((x, i) => <li key={i}>{x}</li>)}</ol>}
      {d.text ? (
        <>
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <label className="block text-xs font-semibold">Section of your application
              <select className={`mt-1 w-full rounded-lg border bg-white px-2 py-2 text-sm ${s.key ? 'border-line' : 'border-red-500'}`} value={s.key ?? ''} disabled={s.mode === 'replace' && !!s.key} onChange={(e) => onChange({ key: e.target.value || undefined })}>
                {!s.key && <option value="">Choose a section...</option>}
                {sections.map((x, i) => <option key={x.key} value={x.key}>{String(i + 1).padStart(2, '0')}. {x.title}</option>)}
              </select>
              {!s.key && <span className="mt-1 block font-normal text-red-800">The AI could not tell which section this belongs to. Choose one.</span>}
            </label>
            <div className="text-xs font-semibold">What happens
              <p className="mt-1 rounded-lg border border-line bg-white px-2 py-2 text-sm font-normal">{s.mode === 'replace' ? `Replaces the section: ${before} words become ${after}.` : `Adds ${after} words to the end of the section.`}</p>
            </div>
          </div>
          <label className="mt-3 block text-xs font-semibold">Suggested text (you can edit it)
            <textarea rows={s.mode === 'replace' ? 12 : 7} className="mt-1 w-full rounded-lg border border-line bg-white px-3 py-2 text-sm font-normal" value={s.text ?? ''} onChange={(e) => onChange({ text: e.target.value })} />
          </label>
          {render && (s.text ?? '').includes('|') && (
            <div className="mt-3 rounded-lg border border-line bg-white p-3">
              <p className="text-xs font-semibold">How the text will look, with its tables</p>
              <div className="mt-1 max-h-72 overflow-auto text-sm">{render(s.text ?? '')}</div>
            </div>
          )}
        </>
      ) : null}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {d.text && <button type="button" className={primary} disabled={!(s.text ?? '').trim() || !s.key} onClick={onApply}>Reflect in the section</button>}
        {extra}
        <button type="button" className={ghost} onClick={onDiscard}>Discard</button>
      </div>
    </div>
  )
}

export default function ReviewModal(p: Props) {
  const [tab, setTab] = useState<Tab>('review')
  const [busy, setBusy] = useState('')
  const [note, setNote] = useState('')
  const [review, setReview] = useState<ReviewResult | null>(null)
  const [issues, setIssues] = useState<ConsistencyIssue[] | null>(null)
  const [comp, setComp] = useState<ComplianceResult | null>(null)
  const [sug, setSug] = useState<Record<string, Sug>>({})
  const patchSug = (id: string, v: Partial<Sug>) => setSug((c) => ({ ...c, [id]: { ...(c[id] ?? {}), ...v } }))
  const titles = p.sections.map((s) => s.title)
  const keyOfTitle = (t?: string) => { const m = matchTitle(titles, t); return m ? p.sections.find((s) => s.title === m)?.key : undefined }
  const guessSection = (area: string) => matchTitle(titles, area) || undefined
  async function ask(id: string, kind: string, finding: string, hint?: string, wordLimit?: number) {
    patchSug(id, { busy: true, error: undefined, data: undefined, applied: undefined, discarded: false })
    try {
      const r = await suggestFix({ data: { kind, finding, hint, wordLimit, sections: p.sections.map((s) => ({ title: s.title, text: s.text })), profile: p.profile, summary: p.summary, framework: p.framework, amount: p.amount, months: p.months } })
      if (r.ok) patchSug(id, { busy: false, data: r.suggestion, key: keyOfTitle(r.suggestion.section), mode: r.suggestion.mode, text: r.suggestion.text })
      else patchSug(id, { busy: false, error: r.reason })
    } catch { patchSug(id, { busy: false, error: 'Something went wrong. Please try again.' }) }
  }
  const panel = (id: string, extra?: React.ReactNode) => sug[id] ? (
    <SuggestionPanel
      s={sug[id]} sections={p.sections} extra={extra} render={p.renderText}
      onChange={(v) => patchSug(id, v)}
      onDiscard={() => patchSug(id, { discarded: true, data: undefined })}
      onGoto={(k) => { p.onGoto(k); p.onClose() }}
      onApply={() => { const x = sug[id]; if (!x.key || !x.text?.trim()) return; p.onApplyText(x.key, x.mode ?? 'append', x.text); patchSug(id, { applied: p.sections.find((s) => s.key === x.key)?.title ?? 'the section' }) }}
    />
  ) : null
  const askBtn = (id: string, kind: string, finding: string, hint?: string, wordLimit?: number, label = 'Suggest an improvement') => (
    <button type="button" className="text-sm font-semibold text-accent underline disabled:opacity-50" disabled={!!sug[id]?.busy} onClick={() => ask(id, kind, finding, hint, wordLimit)}>{sug[id]?.busy ? 'Working...' : sug[id]?.data || sug[id]?.applied ? 'Suggest another' : label}</button>
  )

  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') p.onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [p])

  const written = p.sections.filter((s) => s.text.trim().length > 20)

  async function runReview() {
    if (!written.length) { setNote('Write at least one section first.'); return }
    setBusy('review'); setNote('')
    try {
      const r = await reviewDraft({ data: { sections: p.sections.map((s) => ({ title: s.title, text: s.text })), criteria: p.criteria, summary: p.summary, framework: p.framework, titles: p.sections.map((s) => s.title) } })
      if (r.ok) { setReview(r.result); p.onReviewed(r.result.overall) } else setNote(r.reason)
    } catch { setNote('Something went wrong. Please try again.') }
    setBusy('')
  }
  async function runConsistency() {
    if (!written.length) { setNote('Write at least one section first.'); return }
    setBusy('consistency'); setNote('')
    try {
      const r = await consistencyCheck({ data: { sections: p.sections.map((s) => ({ title: s.title, text: s.text })), amount: p.amount, months: p.months, framework: p.framework, rules: p.rules, titles: p.sections.map((s) => s.title) } })
      if (r.ok) setIssues(r.issues); else setNote(r.reason)
    } catch { setNote('Something went wrong. Please try again.') }
    setBusy('')
  }
  async function runCompliance() {
    if (!written.length) { setNote('Write at least one section first.'); return }
    setBusy('compliance'); setNote('')
    try {
      const r = await complianceReport({ data: { titles: p.sections.map((s) => s.title), sections: p.sections.map((s) => ({ title: s.title, text: s.text })), guidanceText: p.guidanceText, templateSpec: p.templateSpec, framework: p.framework, amount: p.amount, months: p.months, profile: p.profile } })
      if (r.ok) setComp(r.result); else setNote(r.reason)
    } catch { setNote('Something went wrong. Please try again.') }
    setBusy('')
  }
  function downloadCompliance() {
    if (!comp) return
    const cell = (t: string) => t.replace(/\|/g, '/').replace(/\n/g, ' ')
    const md = [
      `# Compliance report: ${p.title}`, '', `Prepared ${new Date().toLocaleDateString('en-GB')}`, '',
      '## Compliance matrix', '', '| Requirement | Source | Where addressed | Status | Note |', '|---|---|---|---|---|',
      ...comp.matrix.map((m) => `| ${cell(m.requirement)} | ${m.source} | ${cell(m.section)} | ${m.status} | ${cell(m.note)} |`), '',
      '## Flagged issues', '', ...(comp.conflicts.length ? comp.conflicts.flatMap((c) => [`- **${c.issue}**`, `  - Template: ${c.template}`, `  - Guidance: ${c.guidance}`, `  - Decision needed: ${c.decision}`]) : ['No conflicts between the template and the guidance were found.']), '',
      '## Assumptions and gaps', '', ...(comp.gaps.length ? comp.gaps.map((g) => `- ${g.item} (${g.section})`) : ['No open gaps.']), '',
      '## Questions to resolve before submission', '', ...(comp.questions.length ? comp.questions.map((q, i) => `${i + 1}. ${q}`) : ['None.']), '',
      '## Quality checks', '', '| Check | Result | Note |', '|---|---|---|', ...comp.checks.map((c) => `| ${cell(c.check)} | ${c.result === 'pass' ? 'Pass' : 'Needs attention'} | ${cell(c.note)} |`), '',
    ].join('\n')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob([md], { type: 'text/markdown;charset=utf-8' }))
    a.download = 'compliance-report.md'
    a.click()
  }

  const sevTone: Record<string, string> = { high: 'bg-red-100 text-red-900', medium: 'bg-amber-100 text-amber-900', low: 'bg-card text-ink' }
  const scoreTone = (n: number) => (n >= 7 ? 'bg-green-100 text-green-900' : n >= 4 ? 'bg-amber-100 text-amber-900' : 'bg-red-100 text-red-900')

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="review-title" onClick={(e) => { if (e.target === e.currentTarget) p.onClose() }}>
      <div className="flex max-h-[92vh] w-full max-w-4xl flex-col rounded-card bg-paper shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 md:px-6">
          <div className="min-w-0">
            <h2 id="review-title" className="font-display text-2xl font-semibold">Review before you submit</h2>
            <p className="mt-1 truncate text-sm text-muted">{p.title}</p>
          </div>
          <button type="button" aria-label="Close" className="shrink-0 rounded-full px-3 py-1 text-xl leading-none text-muted hover:text-ink" onClick={p.onClose}>×</button>
        </div>
        <div role="tablist" aria-label="Review tools" className="flex flex-wrap gap-2 border-b border-line px-5 py-3 md:px-6">
          {TABS.map(([k, t]) => (
            <button key={k} role="tab" type="button" aria-selected={tab === k} onClick={() => { setTab(k); setNote('') }}
              className={`rounded-full border px-4 py-1.5 text-sm font-semibold ${tab === k ? 'border-accent bg-accent text-accent-ink' : 'border-line bg-card hover:border-accent/60'}`}>
              {t}
            </button>
          ))}
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 md:px-6">
          {note && <p className="mb-3 text-sm text-accent" aria-live="polite">{note}</p>}

          {tab === 'review' && (
            <div>
              <p className="text-sm text-muted">AI scores your draft like a funder's reviewer, criterion by criterion, and quotes the evidence it found. {p.criteria.length ? 'It uses the assessment criteria from your imported grant guidance.' : 'No guidance is imported, so it uses standard criteria.'}</p>
              <button type="button" className={`${primary} mt-3`} disabled={!!busy} onClick={runReview}>{busy === 'review' ? 'AI is reviewing...' : review ? 'Review again' : 'Run reviewer pass'}</button>
              {review && (
                <div className="mt-4">
                  <div className="flex flex-wrap items-center gap-4 rounded-card border border-line bg-white p-4">
                    <p className="font-display text-3xl font-semibold tabular-nums">{review.overall}<span className="text-lg text-muted">/100</span></p>
                    <p className="min-w-0 flex-1 text-sm text-muted">Overall estimate from this review. It is a guide to what to strengthen, not a prediction of the funder's decision.</p>
                  </div>
                  {review.fixes.length > 0 && (
                    <div className="mt-4"><p className="text-sm font-semibold">Most valuable fixes</p>
                      <ol className="mt-1 list-decimal space-y-3 pl-5 text-sm">{review.fixes.map((f, i) => <li key={i}><span className="font-semibold">{f.section === 'General' ? 'Whole proposal' : f.section}:</span> {f.fix}<div className="mt-1">{askBtn('fix' + i, 'reviewer priority fix', f.fix, f.section === 'General' ? undefined : f.section)}</div>{panel('fix' + i)}</li>)}</ol></div>
                  )}
                  <ul className="mt-4 space-y-3">
                    {review.criteria.map((c, i) => (
                      <li key={i} className="rounded-card border border-line bg-white p-4">
                        <div className="flex items-start justify-between gap-3"><p className="min-w-0 font-semibold">{c.criterion}</p><span className={`shrink-0 rounded-full px-3 py-1 text-xs font-bold tabular-nums ${scoreTone(c.score)}`}>{c.score}/10</span></div>
                        {c.evidence && <p className="mt-1 text-sm italic text-muted">"{c.evidence}"</p>}
                        {c.gaps && <p className="mt-1 text-sm"><span className="font-semibold">Gap:</span> {c.gaps}</p>}
                        {c.suggestion && <p className="mt-1 text-sm"><span className="font-semibold">Fix:</span> {c.suggestion}</p>}
                        {c.score < 9 && (c.gaps || c.suggestion) && <div className="mt-2">{askBtn('crit' + i, 'reviewer criterion', `${c.criterion} scored ${c.score}/10. Gap: ${c.gaps} Suggested fix: ${c.suggestion}`)}</div>}
                        {panel('crit' + i)}
                      </li>
                    ))}
                  </ul>
                  {review.strengths.length > 0 && <div className="mt-4"><p className="text-sm font-semibold">Strengths</p><ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-muted">{review.strengths.map((s, i) => <li key={i}>{s}</li>)}</ul></div>}
                </div>
              )}
            </div>
          )}

          {tab === 'consistency' && (
            <div>
              <p className="text-sm text-muted">AI checks that the narrative, activities, timeline, indicators and budget agree with each other, and that numbers match across sections.</p>
              <button type="button" className={`${primary} mt-3`} disabled={!!busy} onClick={runConsistency}>{busy === 'consistency' ? 'AI is checking...' : issues ? 'Check again' : 'Run consistency check'}</button>
              {issues && (issues.length === 0
                ? <p className="mt-4 rounded-card border border-line bg-white p-4 text-sm">No inconsistencies found. Still read the proposal once from start to finish.</p>
                : <ul className="mt-4 space-y-3">{issues.map((x, i) => (
                  <li key={i} className="rounded-card border border-line bg-white p-4">
                    <div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-2.5 py-0.5 text-xs font-bold uppercase ${sevTone[x.severity]}`}>{x.severity}</span><span className="text-sm font-semibold">{x.area}</span></div>
                    <p className="mt-1 text-sm">{x.issue}</p>
                    {x.fix && <p className="mt-1 text-sm"><span className="font-semibold">Fix:</span> {x.fix}</p>}
                    <div className="mt-2">{askBtn('iss' + i, 'consistency issue', `${x.issue} Suggested fix: ${x.fix}`, x.area === 'Across sections' ? undefined : guessSection(x.area))}</div>
                    {panel('iss' + i)}
                  </li>))}</ul>)}
            </div>
          )}

          {tab === 'compliance' && (
            <div>
              <p className="text-sm text-muted">Checks your draft against the funder's template and guidance. It maps each template and guidance requirement to the section that answers it, flags conflicts between the two (the guidance wins), lists the facts still missing, and runs quality checks.</p>
              {!p.guidanceText && <p className="mt-2 text-sm text-amber-900">No grant guidance is imported for this application, so only the template and general quality checks apply. Import the guidance in the application for a full check.</p>}
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <button type="button" className={primary} disabled={!!busy} onClick={runCompliance}>{busy === 'compliance' ? 'AI is checking compliance...' : comp ? 'Check again' : 'Build the compliance matrix'}</button>
                {comp && <button type="button" className={ghost} onClick={downloadCompliance}>Download report (.md)</button>}
              </div>
              {comp && (
                <div className="mt-4 space-y-5">
                  <section><h3 className="font-display text-xl font-semibold">Compliance matrix</h3>
                    <div className="mt-2 overflow-x-auto rounded-card border border-line bg-white"><table className="w-full min-w-[40rem] border-collapse text-sm">
                      <thead><tr className="bg-ink text-left text-xs uppercase tracking-wide text-paper"><th className="px-3 py-2">Requirement</th><th className="px-3 py-2">Source</th><th className="px-3 py-2">Where addressed</th><th className="px-3 py-2">Status</th></tr></thead>
                      <tbody className="divide-y divide-line">{comp.matrix.map((m, i) => (
                        <tr key={i} className="align-top"><td className="px-3 py-2"><p className="font-semibold">{m.requirement}</p>{m.note && <p className="text-xs text-muted">{m.note}</p>}</td><td className="px-3 py-2">{m.source}</td>
                          <td className="px-3 py-2">{(() => { const sec = p.sections.find((x) => x.title === m.section); return sec ? <button type="button" className="text-left font-semibold text-accent underline" onClick={() => { p.onGoto(sec.key); p.onClose() }}>{m.section}</button> : <span className="text-muted">{m.section}</span> })()}</td>
                          <td className="px-3 py-2"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${m.status === 'covered' ? 'bg-green-100 text-green-900' : m.status === 'partial' ? 'bg-amber-100 text-amber-900' : 'bg-red-100 text-red-900'}`}>{m.status === 'covered' ? 'Covered' : m.status === 'partial' ? 'Partly' : 'Missing'}</span></td></tr>))}</tbody>
                    </table></div>
                    <p className="mt-1 text-xs text-muted">{comp.matrix.filter((m) => m.status === 'covered').length} of {comp.matrix.length} requirements covered.</p>
                  </section>
                  <section><h3 className="font-display text-xl font-semibold">Flagged issues</h3>
                    {comp.conflicts.length === 0 ? <p className="mt-1 text-sm text-muted">No conflicts between the template and the guidance were found.</p> : <ul className="mt-2 space-y-3">{comp.conflicts.map((c, i) => <li key={i} className="rounded-card border border-line bg-white p-3 text-sm"><p className="font-semibold">{c.issue}</p><p className="mt-1"><span className="font-semibold">Template:</span> {c.template}</p><p><span className="font-semibold">Guidance:</span> {c.guidance}</p><p><span className="font-semibold">Decision needed:</span> {c.decision}</p></li>)}</ul>}
                  </section>
                  <section><h3 className="font-display text-xl font-semibold">Assumptions and gaps</h3>
                    {comp.gaps.length === 0 ? <p className="mt-1 text-sm text-muted">No open gaps.</p> : <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">{comp.gaps.map((g, i) => <li key={i}>{g.item} <span className="text-muted">({g.section})</span></li>)}</ul>}
                  </section>
                  {comp.questions.length > 0 && <section><h3 className="font-display text-xl font-semibold">Questions to resolve</h3><ol className="mt-2 list-decimal space-y-1 pl-5 text-sm">{comp.questions.map((q, i) => <li key={i}>{q}</li>)}</ol></section>}
                  <section><h3 className="font-display text-xl font-semibold">Quality checks</h3>
                    <ul className="mt-2 space-y-2">{comp.checks.map((c, i) => <li key={i} className="flex items-start gap-3 rounded-card border border-line bg-white p-3 text-sm"><span className={`mt-0.5 shrink-0 rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.result === 'pass' ? 'bg-green-100 text-green-900' : 'bg-amber-100 text-amber-900'}`}>{c.result === 'pass' ? 'Pass' : 'Attention'}</span><div><p className="font-semibold">{c.check}</p>{c.note && <p className="text-muted">{c.note}</p>}</div></li>)}</ul>
                  </section>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="flex items-center justify-end gap-3 border-t border-line bg-paper px-5 py-4 md:px-6">
          <button type="button" className={ghost} onClick={p.onClose}>Close</button>
        </div>
      </div>
    </div>
  )
}
