import { useEffect, useRef } from 'react'

// The blinking cursor at the end of text that is being written. It keeps the newest words in view.
export default function LiveEnd() {
  const ref = useRef<HTMLSpanElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    if (r.bottom > window.innerHeight - 24 && r.top < window.innerHeight + 900) el.scrollIntoView({ block: 'end', behavior: 'smooth' })
  })
  return <span ref={ref} aria-hidden className="ml-0.5 inline-block h-4 w-[3px] animate-pulse rounded-sm bg-accent align-middle" />
}
