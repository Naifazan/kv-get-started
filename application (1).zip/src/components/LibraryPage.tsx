import { useEffect, useMemo, useState } from 'react'
import { askConfirm } from '../lib/confirm'
import { delFile, getFile, putFile } from '../lib/filestore'
import { detectLibraryDoc } from '../server/grants'

export type LibDoc = { id: string; name: string; type: string; issued: string; expiry: string; link: string; notes: string; facts?: string; text?: string; file?: { name: string; size: number; mime: string } }
export type Snippet = { id: string; title: string; category: string; text: string; tags: string; updated: number }
export type Library = { docs: LibDoc[]; snippets: Snippet[] }
export const emptyLibrary: Library = { docs: [], snippets: [] }

export const DOC_TYPES = ['Registration certificate', 'Tax exemption letter', 'Audited accounts', 'Annual report', 'Safeguarding policy', 'Anti-fraud and anti-corruption policy', 'Financial management policy', 'Bank details letter', 'Board list', 'Staff CVs', 'Letter of support', 'Partnership agreement', 'Other']
export const SNIPPET_CATEGORIES = ['Organization overview', 'Mission and vision', 'Track record', 'Case study', 'Team and expertise', 'Methodology', 'Monitoring and evaluation', 'Sustainability', 'Partnerships', 'Safeguarding and gender', 'Other']

export const docState = (d: LibDoc): 'none' | 'valid' | 'soon' | 'expired' => {
  if (!d.expiry) return 'none'
  const t = new Date(d.expiry).getTime()
  if (Number.isNaN(t)) return 'none'
  const days = Math.ceil((t - Date.now()) / 864e5)
  return days < 0 ? 'expired' : days <= 60 ? 'soon' : 'valid'
}
const STATE_LABEL = { none: 'No expiry', valid: 'Valid', soon: 'Expires soon', expired: 'Expired' } as const
const STATE_TONE = { none: 'bg-card text-muted', valid: 'bg-green-100 text-green-900', soon: 'bg-amber-100 text-amber-900', expired: 'bg-red-100 text-red-900' } as const

const field = 'mt-1 w-full rounded-card border border-line bg-white px-3 py-2.5 text-base outline-none focus:border-accent'
const label = 'block text-sm font-semibold'
const primary = 'inline-flex min-h-11 items-center justify-center rounded-full bg-accent px-6 font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'
const ghost = 'inline-flex min-h-11 items-center justify-center rounded-full border border-accent/60 px-5 font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const fmt = (iso: string) => (/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso.slice(8)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : iso)
const uid = () => Math.random().toString(36).slice(2, 10)

export default function LibraryPage({ lib, setLib, signedIn, readFile }: { lib: Library; setLib: (f: (c: Library) => Library) => void; signedIn: boolean; readFile: (f: File) => Promise<string>; fileError?: (e: unknown) => string }) {
  const [dq, setDq] = useState('')
  const [docName, setDocName] = useState('')
  const [docType, setDocType] = useState('')
  const [note, setNote] = useState('')
  const counts = useMemo(() => ({ valid: lib.docs.filter((d) => docState(d) === 'valid' || docState(d) === 'none').length, soon: lib.docs.filter((d) => docState(d) === 'soon').length, expired: lib.docs.filter((d) => docState(d) === 'expired').length }), [lib.docs])
  const docs = lib.docs.filter((d) => !dq.trim() || `${d.name} ${d.type} ${d.notes}`.toLowerCase().includes(dq.toLowerCase()))
  const [importing, setImporting] = useState(false)
  const guessType = (name: string) => {
    const n = name.toLowerCase()
    const rules: [RegExp, string][] = [[/regist|incorporat|certificate/, 'Registration certificate'], [/tax|exempt|501/, 'Tax exemption letter'], [/audit|financial statement/, 'Audited accounts'], [/annual|report/, 'Annual report'], [/safeguard|child protect|psea/, 'Safeguarding policy'], [/fraud|corrupt|bribe/, 'Anti-fraud and anti-corruption policy'], [/financ|procure/, 'Financial management policy']]
    return rules.find(([re]) => re.test(n))?.[1] ?? DOC_TYPES[0]
  }
  const openStored = async (d: LibDoc) => {
    const blob = await getFile(d.id)
    if (!blob) { setNote('The file is stored on the device where you imported it. It is not on this device.'); return }
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = d.file?.name ?? d.name
    a.click()
    setTimeout(() => URL.revokeObjectURL(url), 30000)
  }
  const importDocs = async (files: File[]) => {
    if (!files.length) return
    setImporting(true)
    setNote('')
    const added: LibDoc[] = []
    const problems: string[] = []
    for (const f of files.slice(0, 10)) {
      if (f.size > 12 * 1024 * 1024) { problems.push(`${f.name} is larger than 12 MB`); continue }
      const id = uid()
      let text = ''
      try { text = await readFile(f) } catch { /* the file is still kept, only the details cannot be read */ }
      let det: { type: string; issued: string; expiry: string; notes: string; facts?: string } = { type: '', issued: '', expiry: '', notes: '' }
      if (text.trim().length > 40) {
        try { const r = await detectLibraryDoc({ data: { name: f.name, text, types: DOC_TYPES } }); if (r.ok) det = r } catch { /* keep the guess from the file name */ }
      }
      const kept = await putFile(id, f)
      added.push({ id, name: (files.length === 1 && docName.trim()) || f.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ').trim() || f.name, type: docType || det.type || guessType(f.name), issued: det.issued, expiry: det.expiry, link: '', notes: det.notes, facts: det.facts || undefined, text: text.trim().length > 40 ? text.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, 8000) : undefined, ...(kept ? { file: { name: f.name, size: f.size, mime: f.type } } : {}) })
      if (!kept) problems.push(`${f.name} could not be stored in this browser, only its record was added`)
    }
    if (added.length) setLib((c) => ({ ...c, docs: [...added, ...c.docs] }))
    setNote(`${added.length ? `Imported ${added.length} document${added.length === 1 ? '' : 's'}. The portal now uses what it read in them.` : 'Nothing was imported.'}${problems.length ? ' ' + problems.join('. ') + '.' : ''}`)
    setDocName('')
    setImporting(false)
  }
  return (
    <div>
      <div className="mb-5 border-b border-line pb-4">
        <h1 className="font-display text-3xl font-semibold tracking-tight md:text-3xl">Library</h1>
        <p className="mt-2 max-w-2xl text-muted">Your organization's documents with their expiry dates. {signedIn ? 'Kept in this browser and in your online account.' : 'Kept in this browser. Sign in to keep it online too.'}</p>
      </div>
      {note && <p className="mb-4 text-sm text-accent" aria-live="polite">{note}</p>}

        <div>
          <div className="grid gap-3 sm:grid-cols-3">
            {([['Valid or no expiry', counts.valid, 'bg-green-100 text-green-900'], ['Expiring within 60 days', counts.soon, 'bg-amber-100 text-amber-900'], ['Expired', counts.expired, 'bg-red-100 text-red-900']] as const).map(([l, n, tone]) => <div key={l} className="rounded-card border border-line bg-card p-4"><p className="text-xs font-semibold tracking-wide text-muted uppercase">{l}</p><p className={`mt-1 inline-block rounded-full px-3 font-display text-2xl font-semibold tabular-nums ${tone}`}>{n}</p></div>)}
          </div>
          <section className="mt-4 rounded-card border border-dashed border-accent/50 bg-card p-5">
            <h2 className="font-display text-2xl font-semibold">Import from your device</h2>
            <p className="mt-1 text-sm text-muted">Choose one or more Word, Excel or PDF files. The AI reads each one and fills in its type, issue date and expiry date when it finds them. It also keeps the key facts so the portal can use them to update your profile, find better grants and write stronger applications. The file is kept in this browser so you can open it again here. Only the record, not the file, is saved online.</p>
            <div className="mt-4 rounded-card border border-line bg-white p-4">
              <h3 className="font-display text-xl font-semibold">Add a document</h3>
              <p className="mt-1 text-sm text-muted">Choose the name and type, then import the file. The portal tracks the expiry date and warns you before you apply.</p>
              <div className="mt-3 grid gap-4 md:grid-cols-2">
                <label className={label}>Name<input className={field} value={docName} onChange={(e) => setDocName(e.target.value)} placeholder="e.g. Certificate of registration" /></label>
                <label className={label}>Type<select className={field} value={docType} onChange={(e) => setDocType(e.target.value)}><option value="">Detect automatically</option>{DOC_TYPES.map((t) => <option key={t}>{t}</option>)}</select></label>
              </div>
              <label className={`${primary} mt-4 cursor-pointer ${importing ? 'opacity-60' : ''}`}>
                {importing ? 'Importing...' : 'Import documents'}
                <input type="file" multiple className="hidden" disabled={importing} accept=".pdf,.docx,.xlsx,.csv,.txt,.md,.rtf,application/pdf" onChange={(e) => { const fl = Array.from(e.target.files ?? []); e.target.value = ''; importDocs(fl) }} />
              </label>
              <p className="mt-2 text-xs text-muted">The name is used when you import a single file. With several files, each keeps its own file name.</p>
            </div>
          </section>
          <label className="mt-4 block max-w-sm text-sm font-semibold">Search documents<input className={field} value={dq} onChange={(e) => setDq(e.target.value)} placeholder="Name, type or note" /></label>
          {docs.length === 0 ? <p className="mt-4 rounded-card border border-dashed border-ink/30 p-6 text-center text-muted">No documents yet.</p> : (
            <div className="mt-3 overflow-hidden rounded-card border border-line bg-white">
              <ul className="divide-y divide-line">
                {docs.map((d) => { const st = docState(d); return (
                  <li key={d.id} className="flex flex-wrap items-start justify-between gap-3 px-4 py-3">
                    <div className="min-w-0">
                      <p className="font-semibold">{d.link ? <a href={d.link} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4">{d.name}</a> : d.name}</p>
                      <p className="text-xs text-muted">{d.type}{d.issued ? ` · Issued ${fmt(d.issued)}` : ''}{d.expiry ? ` · Expires ${fmt(d.expiry)}` : ''}{d.notes ? ` · ${d.notes}` : ''}</p>
                    </div>
                    <div className="flex items-center gap-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${STATE_TONE[st]}`}>{STATE_LABEL[st]}</span>
                      {d.file && <button type="button" className="text-sm font-semibold text-accent underline" onClick={() => openStored(d)}>Open file</button>}
                      <button type="button" className="text-sm text-muted underline" onClick={() => askConfirm(d.file ? 'Delete this document record and its stored file?' : 'Delete this document record?', { title: 'Delete document?' }).then((ok) => { if (!ok) return; if (d.file) delFile(d.id); setLib((c) => ({ ...c, docs: c.docs.filter((x) => x.id !== d.id) })) })}>Delete</button></div>
                  </li>) })}
              </ul>
            </div>
          )}
          <p className="mt-3 text-xs text-muted">Imported files stay in this browser. Online, the portal saves only the record and the link. Documents show up in each application's submission checklist.</p>
        </div>
    </div>
  )
}

/** Pop-up to pick reusable text and insert it into a proposal section. */
export function SnippetPicker({ snippets, section, onPick, onClose }: { snippets: Snippet[]; section: string; onPick: (text: string) => void; onClose: () => void }) {
  const [q, setQ] = useState('')
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [onClose])
  const list = snippets.filter((s) => !q.trim() || `${s.title} ${s.text} ${s.tags} ${s.category}`.toLowerCase().includes(q.toLowerCase()))
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="pick-title" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="flex max-h-[88vh] w-full max-w-2xl flex-col rounded-card bg-paper shadow-2xl">
        <div className="border-b border-line px-5 py-4"><h2 id="pick-title" className="font-display text-2xl font-semibold">Insert from your library</h2><p className="mt-1 text-sm text-muted">Into: {section}. The text is added at the end of the section.</p></div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          <input autoFocus className={field} placeholder="Search your reusable text" value={q} onChange={(e) => setQ(e.target.value)} />
          {snippets.length === 0 ? <p className="mt-4 text-sm text-muted">Your library is empty. Add text on the Library page first.</p> : (
            <ul className="mt-3 space-y-2">{list.map((s) => (
              <li key={s.id} className="rounded-card border border-line bg-white p-3"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="text-sm font-semibold">{s.title}</p><p className="text-xs text-muted">{s.category}</p></div><button type="button" className={`${primary} !min-h-9 !px-4 text-sm`} onClick={() => { onPick(s.text); onClose() }}>Insert</button></div><p className="mt-1 line-clamp-2 text-sm text-muted">{s.text}</p></li>
            ))}</ul>
          )}
        </div>
        <div className="flex justify-end border-t border-line px-5 py-4"><button type="button" className={ghost} onClick={onClose}>Cancel</button></div>
      </div>
    </div>
  )
}
