import { useEffect } from 'react'
import { showDate } from '../lib/options'
import type { Grant } from '../server/grants'

export type CompareRow = { g: Grant; match: { score: number; reasons: string[]; flags: string[] }; status: string; days: number | null; award: string; saved: boolean; hasApp: boolean }
type Props = { rows: CompareRow[]; onClose: () => void; onSave: (g: Grant) => void; onApply: (g: Grant) => void; onDetails: (g: Grant) => void }
const ghost = 'inline-flex min-h-9 items-center justify-center rounded-full border border-accent/60 px-3 text-xs font-semibold text-accent hover:border-accent hover:bg-accent/10'
const primary = 'inline-flex min-h-9 items-center justify-center rounded-full bg-accent px-4 text-xs font-semibold text-accent-ink hover:brightness-110'

export default function CompareModal({ rows, onClose, onSave, onApply, onDetails }: Props) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [onClose])
  const bestMatch = Math.max(...rows.map((r) => r.match.score))
  const soonest = Math.min(...rows.map((r) => (r.days !== null && r.days >= 0 ? r.days : Infinity)))
  const lines: [string, (r: CompareRow) => React.ReactNode][] = [
    ['Funder', (r) => r.g.funder],
    ['Source', (r) => r.g.source],
    ['Type', (r) => r.g.gtype || 'Not stated'],
    ['Status', (r) => <span className="capitalize">{r.status === 'forthcoming' ? 'upcoming' : r.status}</span>],
    ['Deadline', (r) => <span className={r.days !== null && r.days >= 0 && r.days === soonest ? 'font-semibold text-accent' : ''}>{showDate(r.g.deadline)}{r.days !== null ? ` (${r.days < 0 ? 'closed' : r.days === 0 ? 'due today' : r.days + ' days left'})` : ''}</span>],
    ['Award', (r) => r.award || 'Not stated'],
    ['Countries', (r) => (r.g.countries?.length ? r.g.countries.slice(0, 6).join(', ') : 'Not stated')],
    ['Sectors', (r) => (r.g.sectors?.length ? r.g.sectors.join(', ') : 'Not stated')],
    ['Profile match', (r) => <span className={`rounded-full px-2.5 py-0.5 font-bold ${r.match.score >= 65 ? 'bg-green-100 text-green-900' : r.match.score >= 40 ? 'bg-amber-100 text-amber-900' : 'bg-card text-muted'} ${r.match.score === bestMatch ? 'ring-2 ring-accent' : ''}`}>{r.match.score}%{r.match.score === bestMatch && rows.length > 1 ? ' best' : ''}</span>],
    ['Why it fits', (r) => (r.match.reasons.length ? r.match.reasons.join('. ') : 'No clear overlap yet')],
    ['Check before applying', (r) => (r.match.flags.length ? <span className="text-amber-900">{r.match.flags.join('. ')}</span> : <span className="text-green-800">Nothing flagged</span>)],
    ['Summary', (r) => <span className="text-muted">{(r.g.summary ?? '').slice(0, 280) || 'Not stated'}</span>],
  ]
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="cmp-title" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="flex max-h-[92vh] w-full max-w-6xl flex-col rounded-card bg-paper shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 md:px-6">
          <div><h2 id="cmp-title" className="font-display text-2xl font-semibold">Compare grants</h2><p className="mt-1 text-sm text-muted">Side by side, against your organization profile. The best match and the nearest deadline are highlighted.</p></div>
          <button type="button" aria-label="Close" className="shrink-0 rounded-full px-3 py-1 text-xl leading-none text-muted hover:text-ink" onClick={onClose}>×</button>
        </div>
        <div className="min-h-0 flex-1 overflow-auto px-5 py-4 md:px-6">
          <table className="w-full min-w-[40rem] border-collapse text-sm">
            <thead>
              <tr>
                <th className="w-36 border-b-2 border-ink bg-card px-3 py-2.5 text-left text-xs uppercase tracking-wide">Detail</th>
                {rows.map((r) => <th key={r.g.id} className="border-b-2 border-ink bg-card px-3 py-2.5 text-left align-top text-sm font-semibold">{r.g.url ? <a href={r.g.url} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4">{r.g.title}</a> : r.g.title}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-line bg-white">
              {lines.map(([label, fn]) => (
                <tr key={label} className="align-top">
                  <th scope="row" className="bg-card px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">{label}</th>
                  {rows.map((r) => <td key={r.g.id} className="px-3 py-2.5">{fn(r)}</td>)}
                </tr>
              ))}
              <tr>
                <th scope="row" className="bg-card px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-muted">Actions</th>
                {rows.map((r) => (
                  <td key={r.g.id} className="px-3 py-2.5"><div className="flex flex-wrap gap-2">
                    <button type="button" className={ghost} onClick={() => onDetails(r.g)}>Details</button>
                    <button type="button" className={ghost} onClick={() => onSave(r.g)}>{r.saved ? 'Saved ✓' : 'Save'}</button>
                    <button type="button" className={primary} onClick={() => { onClose(); onApply(r.g) }}>{r.hasApp ? 'Open application' : 'Start application'}</button>
                  </div></td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
        <div className="flex justify-end border-t border-line px-5 py-4 md:px-6"><button type="button" className={ghost} onClick={onClose}>Close</button></div>
      </div>
    </div>
  )
}
