import { useEffect, useState } from 'react'
import { askConfirm } from '../lib/confirm'
import { deleteAllMyData, exportAllMyData } from '../server/saved'

const ghost = 'inline-flex min-h-10 items-center justify-center rounded-full border border-accent/60 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const primary = 'inline-flex min-h-10 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'

export default function PrivacyModal({ signedIn, onClose }: { signedIn: boolean; onClose: () => void }) {
  const [busy, setBusy] = useState('')
  const [note, setNote] = useState('')
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [onClose])
  const localKeys = () => Object.keys(localStorage).filter((k) => k.startsWith('ngw_'))
  async function exportAll() {
    setBusy('export'); setNote('')
    const local: Record<string, unknown> = {}
    for (const k of localKeys()) { try { local[k] = JSON.parse(localStorage.getItem(k) ?? 'null') } catch { local[k] = localStorage.getItem(k) } }
    let online: unknown = null
    if (signedIn) { const r = await exportAllMyData().catch(() => null); if (r && r.ok) online = r.items }
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), thisBrowser: local, onlineAccount: online }, null, 2)], { type: 'application/json' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'my-grants-portal-data.json'; a.click()
    setNote(signedIn && !online ? 'Downloaded the data from this browser. Your online copy could not be reached.' : 'Downloaded everything the portal holds for you.')
    setBusy('')
  }
  async function deleteOnline() {
    if (!(await askConfirm('Delete everything saved online for your account: applications, profile, library, awards and shared links? This cannot be undone.', { title: 'Delete all online data?', yes: 'Yes, delete' }))) return
    setBusy('online'); setNote('')
    const r = await deleteAllMyData().catch(() => null)
    setNote(r && r.ok ? 'Your online data is deleted. Data in this browser is untouched.' : 'Could not delete the online data. Try again.')
    setBusy('')
  }
  async function deleteLocal() {
    if (!(await askConfirm('Delete everything the portal keeps in this browser: profile, applications, saved grants, library and settings? Your online copy, if any, is not touched.', { title: 'Delete all data in this browser?', yes: 'Yes, delete' }))) return
    for (const k of localKeys()) localStorage.removeItem(k)
    try { indexedDB.deleteDatabase('ngw_files') } catch {}
    window.location.reload()
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="priv-title" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="flex max-h-[92vh] w-full max-w-xl flex-col rounded-card bg-paper shadow-2xl">
        <div className="border-b border-line px-5 py-4"><h2 id="priv-title" className="font-display text-2xl font-semibold">Privacy and your data</h2></div>
        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto px-5 py-4 text-sm">
          <section><h3 className="font-semibold">Where your data lives</h3>
            <ul className="mt-1 list-disc space-y-1 pl-5 text-muted">
              <li>In this browser: your profile, saved grants, applications, library and settings.</li>
              <li>Online, only when you are signed in: applications you save, your profile, library and awards, and any share links you create. Only you can read them.</li>
              <li>The text you ask AI to read or write is sent to the AI service to produce the answer. Do not paste anything you are not allowed to share.</li>
            </ul></section>
          <section><h3 className="font-semibold">Your choices</h3>
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" className={primary} disabled={!!busy} onClick={exportAll}>{busy === 'export' ? 'Preparing...' : 'Download all my data'}</button>
              <button type="button" className={ghost} disabled={!!busy} onClick={deleteLocal}>Delete data in this browser</button>
              {signedIn && <button type="button" className={ghost} disabled={!!busy} onClick={deleteOnline}>{busy === 'online' ? 'Deleting...' : 'Delete my online data'}</button>}
            </div>
            {!signedIn && <p className="mt-2 text-xs text-muted">Sign in to also export or delete your online copy.</p>}
          </section>
          {note && <p className="text-accent" aria-live="polite">{note}</p>}
        </div>
        <div className="flex justify-end border-t border-line px-5 py-4"><button type="button" className={ghost} onClick={onClose}>Close</button></div>
      </div>
    </div>
  )
}
