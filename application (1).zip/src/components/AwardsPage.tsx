import { useEffect, useState } from 'react'

export type Report = { id: string; title: string; type: 'Narrative' | 'Financial' | 'Both'; due: string; done: boolean }
export type Milestone = { id: string; title: string; date: string; done: boolean }
export type SpendLine = { id: string; category: string; budget: number; actual: number }
export type Award = { amount: string; start: string; end: string; contact: string; reports: Report[]; milestones: Milestone[]; spend: SpendLine[] }
export type Awards = { items: Record<string, Award> }
export const emptyAwards: Awards = { items: {} }
const blankAward: Award = { amount: '', start: '', end: '', contact: '', reports: [], milestones: [], spend: [] }

export type AwardApp = { id: string; title: string; funder: string; requested: string }
type Props = { apps: AwardApp[]; awards: Awards; setAwards: (f: (c: Awards) => Awards) => void; budgetLines: (appId: string) => { category: string; amount: number }[]; onOpenApp: (id: string) => void; signedIn: boolean }

const field = 'mt-1 w-full rounded-card border border-line bg-white px-3 py-2.5 text-base outline-none focus:border-accent'
const label = 'block text-sm font-semibold'
const primary = 'inline-flex min-h-11 items-center justify-center rounded-full bg-accent px-6 font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'
const ghost = 'inline-flex min-h-11 items-center justify-center rounded-full border border-accent/60 px-5 font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const uid = () => Math.random().toString(36).slice(2, 10)
const num = (t: string) => Number((t ?? '').replace(/[^0-9.]/g, '')) || 0
const usd = (n: number) => '$' + Math.round(n).toLocaleString('en-US')
const daysTo = (d: string) => { const t = new Date(d).getTime(); return Number.isNaN(t) ? null : Math.ceil((t - Date.now()) / 864e5) }
const addMonths = (d: string, m: number) => { const x = new Date(d); x.setMonth(x.getMonth() + m); return x.toISOString().slice(0, 10) }

/** Reports and milestones due within the next `days` days across all awards. */
export function awardDueSoon(awards: Awards, titleOf: (id: string) => string, days = 14) {
  const out: { title: string; days: number }[] = []
  for (const [id, a] of Object.entries(awards.items)) {
    for (const r of a.reports) { const d = r.done ? null : daysTo(r.due); if (d !== null && d >= -30 && d <= days) out.push({ title: `${titleOf(id)}: ${r.title} report`, days: d }) }
  }
  return out
}

export default function AwardsPage({ apps, awards, setAwards, budgetLines, onOpenApp, signedIn }: Props) {
  const [sel, setSel] = useState(apps[0]?.id ?? '')
  const [note, setNote] = useState('')
  useEffect(() => { if (!apps.some((a) => a.id === sel)) setSel(apps[0]?.id ?? '') }, [apps, sel])
  const app = apps.find((a) => a.id === sel)
  const aw = (sel && awards.items[sel]) || blankAward
  const upd = (f: (a: Award) => Award) => setAwards((c) => ({ items: { ...c.items, [sel]: f(c.items[sel] ?? blankAward) } }))
  const [rep, setRep] = useState<{ title: string; type: Report['type']; due: string }>({ title: '', type: 'Narrative', due: '' })
  const [ms, setMs] = useState({ title: '', date: '' })
  const [sp, setSp] = useState({ category: '', budget: '' })

  if (!apps.length) {
    return (
      <div>
        <div className="mb-5 border-b border-line pb-4"><h1 className="font-display text-3xl font-semibold tracking-tight md:text-3xl">Awards</h1><p className="mt-2 max-w-2xl text-muted">After you win, track reports, milestones and spending against the budget.</p></div>
        <div className="rounded-card border border-dashed border-ink/30 p-8 text-center"><p className="font-display text-2xl font-semibold">No awarded grants yet</p><p className="mx-auto mt-2 max-w-md text-muted">When an application is marked Awarded in the Applications page, it appears here so you can plan its reporting and watch spending.</p></div>
      </div>
    )
  }
  const award = num(aw.amount) || num(app?.requested ?? '')
  const spent = aw.spend.reduce((t, s) => t + s.actual, 0)
  const budgeted = aw.spend.reduce((t, s) => t + s.budget, 0)
  const total = aw.start && aw.end ? Math.max(1, (new Date(aw.end).getTime() - new Date(aw.start).getTime()) / 864e5) : 0
  const elapsed = total ? Math.max(0, Math.min(total, (Date.now() - new Date(aw.start).getTime()) / 864e5)) : 0
  const timePct = total ? Math.round((elapsed / total) * 100) : null
  const burnPct = award ? Math.round((spent / award) * 100) : null
  const ahead = timePct !== null && burnPct !== null && burnPct > timePct + 15
  const daysLeft = aw.end ? daysTo(aw.end) : null
  const status = (d: string, done: boolean) => (done ? ['Done', 'bg-green-100 text-green-900'] : daysTo(d) === null ? ['No date', 'bg-card text-muted'] : (daysTo(d) as number) < 0 ? ['Overdue', 'bg-red-100 text-red-900'] : (daysTo(d) as number) <= 14 ? ['Due soon', 'bg-amber-100 text-amber-900'] : ['Upcoming', 'bg-card text-ink'])

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-4 border-b border-line pb-4">
        <div><h1 className="font-display text-3xl font-semibold tracking-tight md:text-3xl">Awards</h1><p className="mt-2 max-w-2xl text-muted">Reports, milestones and spending for each grant you won. {signedIn ? 'Kept in this browser and in your online account.' : 'Kept in this browser. Sign in to keep it online too.'}</p></div>
        <label className="block text-sm font-semibold">Award<select className={`${field} min-w-64`} value={sel} onChange={(e) => setSel(e.target.value)}>{apps.map((a) => <option key={a.id} value={a.id}>{a.title.slice(0, 60)}</option>)}</select></label>
      </div>
      {note && <p className="mb-4 text-sm text-accent" aria-live="polite">{note}</p>}
      <dl className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 [&>*]:min-w-0">
        {([['Awarded', award ? usd(award) : 'Not set', app?.funder ?? ''], ['Spent to date', usd(spent), burnPct === null ? '' : `${burnPct}% of the award`], ['Remaining', award ? usd(award - spent) : 'n/a', budgeted ? `Budgeted lines: ${usd(budgeted)}` : ''], ['Time left', daysLeft === null ? 'n/a' : daysLeft < 0 ? 'Ended' : `${daysLeft}d`, timePct === null ? 'Set the start and end dates' : `${timePct}% of the period used`]] as [string, string, string][]).map(([l, v, h]) => <div key={l} className="rounded-card border border-line bg-card p-4"><dt className="text-xs font-semibold tracking-wide text-muted uppercase">{l}</dt><dd className="mt-1 font-display text-2xl font-semibold tabular-nums">{v}</dd><dd className="mt-0.5 truncate text-xs text-muted">{h}</dd></div>)}
      </dl>
      {ahead && <p className="mt-3 rounded-card border border-amber-300 bg-amber-50 px-4 py-2.5 text-sm font-semibold text-amber-950">Spending ({burnPct}%) is running ahead of the time used ({timePct}%). Check the budget lines below.</p>}

      <section className="mt-4 rounded-card border border-line bg-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-display text-2xl font-semibold">Award details</h2><button type="button" className="text-sm font-semibold text-accent underline" onClick={() => app && onOpenApp(app.id)}>Open the application</button></div>
        <div className="mt-3 grid gap-4 md:grid-cols-4">
          <label className={label}>Award amount (USD)<input className={field} inputMode="numeric" value={aw.amount} placeholder={app?.requested || ''} onChange={(e) => upd((a) => ({ ...a, amount: e.target.value }))} /></label>
          <label className={label}>Start date<input type="date" className={field} value={aw.start} onChange={(e) => upd((a) => ({ ...a, start: e.target.value }))} /></label>
          <label className={label}>End date<input type="date" className={field} value={aw.end} onChange={(e) => upd((a) => ({ ...a, end: e.target.value }))} /></label>
          <label className={label}>Funder contact<input className={field} value={aw.contact} onChange={(e) => upd((a) => ({ ...a, contact: e.target.value }))} placeholder="Name and email" /></label>
        </div>
      </section>

      <section className="mt-4">
        <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-display text-2xl font-semibold">Reporting calendar</h2>
          <button type="button" className={ghost} disabled={!aw.start || !aw.end} title="Quarterly narrative and financial reports, plus a final report" onClick={() => {
            const rows: Report[] = []
            for (let m = 3; ; m += 3) { const d = addMonths(aw.start, m); if (new Date(d) >= new Date(aw.end)) break; rows.push({ id: uid(), title: `Quarter ${m / 3}`, type: 'Both', due: d, done: false }) }
            rows.push({ id: uid(), title: 'Final report', type: 'Both', due: addMonths(aw.end, 1), done: false })
            upd((a) => ({ ...a, reports: [...a.reports, ...rows] })); setNote(`Added ${rows.length} reports. Change the dates to match the funder's agreement.`)
          }}>Add a standard schedule</button></div>
        {!aw.start || !aw.end ? <p className="mt-1 text-xs text-muted">Set the start and end dates above to add a standard schedule.</p> : null}
        <div className="mt-3 overflow-hidden rounded-card border border-line bg-white">
          <ul className="divide-y divide-line">
            {aw.reports.length === 0 && <li className="px-4 py-6 text-center text-sm text-muted">No reports yet.</li>}
            {[...aw.reports].sort((a, b) => a.due.localeCompare(b.due)).map((r) => { const [lbl, tone] = status(r.due, r.done); return (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5">
                <label className="flex min-w-0 items-center gap-3 text-sm"><input type="checkbox" className="size-4" checked={r.done} onChange={(e) => upd((a) => ({ ...a, reports: a.reports.map((x) => (x.id === r.id ? { ...x, done: e.target.checked } : x)) }))} /><span className={r.done ? 'text-muted line-through' : 'font-semibold'}>{r.title}</span><span className="text-xs text-muted">{r.type} · due {r.due || 'no date'}</span></label>
                <div className="flex items-center gap-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${tone}`}>{lbl}</span><button type="button" className="text-sm text-muted underline" onClick={() => upd((a) => ({ ...a, reports: a.reports.filter((x) => x.id !== r.id) }))}>Remove</button></div>
              </li>) })}
          </ul>
        </div>
        <div className="mt-3 grid gap-3 md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)_auto] md:items-end">
          <label className={label}>Report<input className={field} value={rep.title} onChange={(e) => setRep({ ...rep, title: e.target.value })} placeholder="e.g. Interim narrative report" /></label>
          <label className={label}>Type<select className={field} value={rep.type} onChange={(e) => setRep({ ...rep, type: e.target.value as Report['type'] })}><option>Narrative</option><option>Financial</option><option>Both</option></select></label>
          <label className={label}>Due<input type="date" className={field} value={rep.due} onChange={(e) => setRep({ ...rep, due: e.target.value })} /></label>
          <button type="button" className={primary} disabled={!rep.title.trim()} onClick={() => { upd((a) => ({ ...a, reports: [...a.reports, { id: uid(), title: rep.title.trim(), type: rep.type, due: rep.due, done: false }] })); setRep({ title: '', type: 'Narrative', due: '' }) }}>Add</button>
        </div>
      </section>

      <section className="mt-4">
        <h2 className="font-display text-2xl font-semibold">Milestones</h2>
        <div className="mt-3 overflow-hidden rounded-card border border-line bg-white"><ul className="divide-y divide-line">
          {aw.milestones.length === 0 && <li className="px-4 py-6 text-center text-sm text-muted">No milestones yet.</li>}
          {[...aw.milestones].sort((a, b) => a.date.localeCompare(b.date)).map((m) => { const [lbl, tone] = status(m.date, m.done); return (
            <li key={m.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5">
              <label className="flex min-w-0 items-center gap-3 text-sm"><input type="checkbox" className="size-4" checked={m.done} onChange={(e) => upd((a) => ({ ...a, milestones: a.milestones.map((x) => (x.id === m.id ? { ...x, done: e.target.checked } : x)) }))} /><span className={m.done ? 'text-muted line-through' : 'font-semibold'}>{m.title}</span><span className="text-xs text-muted">{m.date || 'no date'}</span></label>
              <div className="flex items-center gap-3"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${tone}`}>{lbl}</span><button type="button" className="text-sm text-muted underline" onClick={() => upd((a) => ({ ...a, milestones: a.milestones.filter((x) => x.id !== m.id) }))}>Remove</button></div>
            </li>) })}
        </ul></div>
        <div className="mt-3 grid gap-3 md:grid-cols-[minmax(0,3fr)_minmax(0,1fr)_auto] md:items-end">
          <label className={label}>Milestone<input className={field} value={ms.title} onChange={(e) => setMs({ ...ms, title: e.target.value })} placeholder="e.g. 4 water tanks installed" /></label>
          <label className={label}>Date<input type="date" className={field} value={ms.date} onChange={(e) => setMs({ ...ms, date: e.target.value })} /></label>
          <button type="button" className={primary} disabled={!ms.title.trim()} onClick={() => { upd((a) => ({ ...a, milestones: [...a.milestones, { id: uid(), title: ms.title.trim(), date: ms.date, done: false }] })); setMs({ title: '', date: '' }) }}>Add</button>
        </div>
      </section>

      <section className="mt-4">
        <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="font-display text-2xl font-semibold">Budget against actual spending</h2>
          <button type="button" className={ghost} disabled={!app} onClick={() => { const lines = budgetLines(sel); if (!lines.length) { setNote('The application has no budget table to copy from.'); return } upd((a) => ({ ...a, spend: [...a.spend, ...lines.filter((l) => !a.spend.some((s) => s.category === l.category)).map((l) => ({ id: uid(), category: l.category, budget: l.amount, actual: 0 }))] })); setNote('Copied the budget categories from the application.') }}>Copy categories from the application budget</button></div>
        <div className="mt-3 overflow-x-auto rounded-card border border-line bg-white">
          <table className="w-full min-w-[34rem] border-collapse text-sm">
            <thead><tr className="bg-ink text-left text-xs tracking-wide text-paper uppercase"><th className="px-3 py-2.5">Category</th><th className="px-3 py-2.5 text-right">Budget</th><th className="px-3 py-2.5 text-right">Actual</th><th className="px-3 py-2.5 text-right">Variance</th><th className="px-3 py-2.5">Used</th><th /></tr></thead>
            <tbody className="divide-y divide-line">
              {aw.spend.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-muted">No budget lines yet.</td></tr>}
              {aw.spend.map((s) => { const v = s.budget - s.actual; const pct = s.budget ? Math.round((s.actual / s.budget) * 100) : 0; return (
                <tr key={s.id}>
                  <td className="px-3 py-2 font-semibold">{s.category}</td>
                  <td className="px-3 py-2 text-right"><input aria-label={`Budget for ${s.category}`} inputMode="numeric" className="w-24 rounded-md border border-line px-2 py-1 text-right tabular-nums" value={s.budget || ''} onChange={(e) => upd((a) => ({ ...a, spend: a.spend.map((x) => (x.id === s.id ? { ...x, budget: num(e.target.value) } : x)) }))} /></td>
                  <td className="px-3 py-2 text-right"><input aria-label={`Actual spending for ${s.category}`} inputMode="numeric" className="w-24 rounded-md border border-line px-2 py-1 text-right tabular-nums" value={s.actual || ''} onChange={(e) => upd((a) => ({ ...a, spend: a.spend.map((x) => (x.id === s.id ? { ...x, actual: num(e.target.value) } : x)) }))} /></td>
                  <td className={`px-3 py-2 text-right tabular-nums ${v < 0 ? 'font-semibold text-red-800' : ''}`}>{v < 0 ? '-' : ''}{usd(Math.abs(v))}</td>
                  <td className="px-3 py-2"><div className="h-2 w-24 overflow-hidden rounded-full bg-line"><div className={`h-full ${pct > 100 ? 'bg-red-600' : 'bg-accent'}`} style={{ width: `${Math.min(100, pct)}%` }} /></div><span className="text-xs text-muted">{pct}%</span></td>
                  <td className="px-3 py-2 text-right"><button type="button" className="text-sm text-muted underline" onClick={() => upd((a) => ({ ...a, spend: a.spend.filter((x) => x.id !== s.id) }))}>Remove</button></td>
                </tr>) })}
            </tbody>
            {aw.spend.length > 0 && <tfoot><tr className="bg-card font-semibold"><td className="border-t-2 border-ink px-3 py-2.5">Total</td><td className="border-t-2 border-ink px-3 py-2.5 text-right tabular-nums">{usd(budgeted)}</td><td className="border-t-2 border-ink px-3 py-2.5 text-right tabular-nums">{usd(spent)}</td><td className="border-t-2 border-ink px-3 py-2.5 text-right tabular-nums">{budgeted - spent < 0 ? '-' : ''}{usd(Math.abs(budgeted - spent))}</td><td colSpan={2} className="border-t-2 border-ink" /></tr></tfoot>}
          </table>
        </div>
        <div className="mt-3 grid gap-3 md:grid-cols-[minmax(0,3fr)_minmax(0,1fr)_auto] md:items-end">
          <label className={label}>Category<input className={field} value={sp.category} onChange={(e) => setSp({ ...sp, category: e.target.value })} placeholder="e.g. Personnel" /></label>
          <label className={label}>Budget (USD)<input className={field} inputMode="numeric" value={sp.budget} onChange={(e) => setSp({ ...sp, budget: e.target.value })} /></label>
          <button type="button" className={primary} disabled={!sp.category.trim()} onClick={() => { upd((a) => ({ ...a, spend: [...a.spend, { id: uid(), category: sp.category.trim(), budget: num(sp.budget), actual: 0 }] })); setSp({ category: '', budget: '' }) }}>Add</button>
        </div>
      </section>
    </div>
  )
}
