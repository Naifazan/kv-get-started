import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import type { Grant, GrantDetail } from '../server/grants'
import { clean, docLines, ganttFrom, num, parseBlocks } from '../lib/text'
import { type Fit, type SortState } from '../lib/types'
import { amountLabel, normStatus, showDate } from '../lib/options'

export type Opt = string | readonly [string, string]

export function MultiSelect({ options, value, onChange, placeholder = 'Any', label: ariaLabel, search }: { options: readonly Opt[]; value: string[]; onChange: (v: string[]) => void; placeholder?: string; label: string; search?: boolean }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef<HTMLDivElement>(null)
  const panel = useRef<HTMLDivElement>(null)
  const [pos, setPos] = useState<{ left: number; width: number; top?: number; bottom?: number; maxH: number } | null>(null)
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : { value: o[0], label: o[1] }))
  // The list is drawn on top of the whole page, so no section below or above it can hide it. It opens upward when there is more room above.
  const place = () => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const vw = window.innerWidth
    const vh = window.innerHeight
    const width = Math.min(Math.max(r.width, 224), vw - 16)
    const left = Math.min(Math.max(8, r.left), vw - width - 8)
    const below = vh - r.bottom - 12
    const above = r.top - 12
    const up = below < 300 && above > below
    setPos(up ? { left, width, bottom: vh - r.top + 4, maxH: Math.max(180, above) } : { left, width, top: r.bottom + 4, maxH: Math.max(180, below) })
  }
  useLayoutEffect(() => {
    if (!open) return
    place()
    const on = () => place()
    window.addEventListener('resize', on)
    window.addEventListener('scroll', on, true)
    return () => { window.removeEventListener('resize', on); window.removeEventListener('scroll', on, true) }
  }, [open])
  useEffect(() => {
    if (!open) return
    const down = (e: MouseEvent) => { const t = e.target as Node; if (ref.current && !ref.current.contains(t) && !(panel.current && panel.current.contains(t))) setOpen(false) }
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', down)
    document.addEventListener('keydown', key)
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('keydown', key) }
  }, [open])
  const shown = opts.filter((o) => !q.trim() || o.label.toLowerCase().includes(q.toLowerCase()))
  const names = value.map((v) => opts.find((o) => o.value === v)?.label ?? v)
  const summary = names.length === 0 ? placeholder : names.length <= 2 ? names.join(', ') : `${names.length} selected`
  return (
    <div ref={ref} className="relative mt-1">
      <button type="button" aria-haspopup="listbox" aria-expanded={open} aria-label={ariaLabel} onClick={() => setOpen(!open)}
        className={`flex min-h-10 w-full items-center justify-between gap-2 rounded-card border bg-white px-3 py-2 text-left text-sm font-normal ${open ? 'border-accent' : 'border-line'} ${names.length ? 'text-ink' : 'text-muted'}`}>
        <span className="truncate">{summary}</span>
        <span className="flex shrink-0 items-center gap-2">
          {names.length > 0 && <span className="rounded-full bg-accent px-2 py-0.5 text-xs font-semibold text-accent-ink">{names.length}</span>}
          <span aria-hidden className="text-xs">▾</span>
        </span>
      </button>
      {open && pos && createPortal(
        <div
          ref={panel}
          role="listbox"
          aria-multiselectable="true"
          style={{ position: 'fixed', left: pos.left, width: pos.width, top: pos.top, bottom: pos.bottom, maxHeight: pos.maxH }}
          className="z-[2000] flex flex-col rounded-card border border-line bg-white p-2 shadow-xl"
        >
          {(search ?? opts.length > 8) && (
            <input autoFocus className="mb-2 w-full rounded-lg border border-line px-3 py-2 text-sm font-normal outline-none focus:border-accent" placeholder="Search..." value={q} onChange={(e) => setQ(e.target.value)} />
          )}
          <div className="mb-1 flex items-center justify-between px-1 text-xs font-semibold">
            <button type="button" className="underline" onClick={() => onChange([...new Set([...value, ...shown.map((o) => o.value)])])}>Select all{q ? ' shown' : ''}</button>
            <button type="button" className="underline" onClick={() => onChange([])}>Clear</button>
          </div>
          <ul className="min-h-0 max-h-60 flex-1 overflow-y-auto">
            {shown.length === 0 && <li className="px-2 py-3 text-sm font-normal text-muted">No matches</li>}
            {shown.map((o) => {
              const on = value.includes(o.value)
              return (
                <li key={o.value}>
                  <label className="flex min-h-9 cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm font-normal hover:bg-card">
                    <input type="checkbox" checked={on} onChange={() => onChange(on ? value.filter((x) => x !== o.value) : [...value, o.value])} />
                    <span>{o.label}</span>
                  </label>
                </li>
              )
            })}
          </ul>
        </div>,
        document.body,
      )}
    </div>
  )
}


export function Hint({ children }: { children: React.ReactNode }) {
  return <span className="mt-0.5 block text-xs font-normal text-muted">{children}</span>
}


// A section that opens and closes with an arrow, and folds back by itself when you leave it.
export function Fold({ title, hint, badge, keepOpen = false, className = '', boxClass = 'border-line bg-card', children }: { title: string; hint?: string; badge?: string; keepOpen?: boolean; className?: string; boxClass?: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLElement>(null)
  const last = useRef(Date.now())
  const hover = useRef(false)
  const keep = useRef(keepOpen)
  keep.current = keepOpen
  const touch = () => { last.current = Date.now() }
  useEffect(() => {
    if (!open) return
    touch()
    const t = setInterval(() => {
      if (hover.current || keep.current || ref.current?.contains(document.activeElement)) return
      if (Date.now() - last.current > 40000) setOpen(false)
    }, 4000)
    return () => clearInterval(t)
  }, [open])
  return (
    <section
      ref={ref}
      className={`rounded-card border p-4 md:p-5 ${boxClass} ${className}`}
      onPointerEnter={() => { hover.current = true; touch() }}
      onPointerLeave={() => { hover.current = false; touch() }}
      onPointerDown={touch}
      onKeyDown={touch}
      onInput={touch}
      onFocus={touch}
      onBlur={(e) => {
        if (!open) return
        const next = e.relatedTarget as Node | null
        if (next && e.currentTarget.contains(next)) return
        // A file chooser or another window takes focus away from the page: stay open then.
        setTimeout(() => { if (document.hasFocus() && !hover.current && !keep.current && !ref.current?.contains(document.activeElement)) setOpen(false) }, 200)
      }}
    >
      <button type="button" aria-expanded={open} onClick={() => setOpen((o) => !o)} className="flex w-full items-start justify-between gap-3 text-left">
        <span>
          <span className="block font-display text-2xl font-semibold">{title}</span>
          {hint && <span className="mt-1 block text-sm font-normal text-muted">{hint}</span>}
        </span>
        <span className="mt-1 flex shrink-0 items-center gap-3">
          {badge && <span className="rounded-full bg-white/70 px-2.5 py-0.5 text-xs font-semibold text-muted">{badge}</span>}
          <span aria-hidden className="text-lg text-muted">{open ? '▾' : '▸'}</span>
        </span>
      </button>
      {open && <div className="mt-4">{children}</div>}
    </section>
  )
}


export function Section({ n, title, hint, children, open, onToggle }: { n: number; title: string; hint: string; children: React.ReactNode; open: boolean; onToggle: () => void }) {
  const ref = useRef<HTMLElement>(null)
  const last = useRef(Date.now())
  const hover = useRef(false)
  const toggleRef = useRef(onToggle)
  toggleRef.current = onToggle
  const touch = () => { last.current = Date.now() }
  // An open section folds back to its mini view when you move on: when focus leaves it, or after 40 seconds with no activity in it.
  useEffect(() => {
    if (!open) return
    touch()
    const t = setInterval(() => {
      if (hover.current || ref.current?.contains(document.activeElement)) return
      if (Date.now() - last.current > 40000) toggleRef.current()
    }, 4000)
    return () => clearInterval(t)
  }, [open])
  return (
    <section
      ref={ref}
      className="rounded-card border border-line bg-card p-4 md:p-5"
      onPointerEnter={() => { hover.current = true; touch() }}
      onPointerLeave={() => { hover.current = false; touch() }}
      onPointerDown={touch}
      onKeyDown={touch}
      onInput={touch}
      onFocus={touch}
      onBlur={(e) => {
        if (!open) return
        const next = e.relatedTarget as Node | null
        if (next && e.currentTarget.contains(next)) return
        setTimeout(() => { if (!hover.current && !ref.current?.contains(document.activeElement)) toggleRef.current() }, 150)
      }}
    >
      <button type="button" aria-expanded={open} onClick={onToggle} className="flex w-full items-start justify-between gap-3 text-left">
        <span>
          <span className="block font-display text-2xl font-semibold"><span className="mr-3 text-accent tabular-nums">{String(n).padStart(2, '0')}</span>{title}</span>
          <span className="mt-1 block text-sm text-muted">{hint}</span>
        </span>
        <span aria-hidden className="mt-1 shrink-0 text-lg text-muted">{open ? '▾' : '▸'}</span>
      </button>
      {open && <div className="mt-5 grid gap-4 md:grid-cols-2">{children}</div>}
    </section>
  )
}


export function Gantt({ text, months }: { text: string; months: number }) {
  const g = ganttFrom(text, months)
  if (!g) return null
  return (
    <div className="mt-4 overflow-x-auto">
      <p className="mb-2 text-sm font-semibold">Gantt view</p>
      <table className="border-collapse text-xs">
        <thead>
          <tr>
            <th className="sticky left-0 border border-line bg-ink px-2 py-1 text-left text-paper">Activity</th>
            {Array.from({ length: g.max }, (_, i) => <th key={i} className="min-w-6 border border-line bg-ink px-1 py-1 text-center font-normal text-paper">{i + 1}</th>)}
          </tr>
        </thead>
        <tbody>
          {g.rows.map((r, ri) => (
            <tr key={ri}>
              <td className="sticky left-0 max-w-56 truncate border border-line bg-white px-2 py-1">{r.name}</td>
              {Array.from({ length: g.max }, (_, i) => <td key={i} className={`border border-line ${i + 1 >= r.s && i + 1 <= r.e ? 'bg-accent' : 'bg-white'}`} />)}
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-1 text-xs text-muted">Columns are months.</p>
    </div>
  )
}


export function RenderBlocks({ text }: { text: string }) {
  return (
    <>
      {parseBlocks(text).map((b, i) =>
        b.type === 'text' ? (
          <div key={i}>{docLines(b.text).map((l, j) => l.sub ? <h4 key={j} className="mt-4 font-semibold">{l.text}</h4> : <p key={j} className="mt-2 whitespace-pre-wrap">{l.text}</p>)}</div>
        ) : (
          <div key={i} className="mt-4 overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr>{b.rows[0].map((c, j) => <th key={j} className="border border-line bg-ink px-3 py-2 text-left font-semibold text-paper">{clean(c)}</th>)}</tr>
              </thead>
              <tbody>
                {b.rows.slice(1).map((r, ri) => (
                  <tr key={ri} className={/total/i.test(r.join(' ')) ? 'bg-card font-semibold' : ''}>
                    {r.map((c, j) => <td key={j} className={`border border-line px-3 py-2 align-top ${num(c) !== null ? 'text-right tabular-nums' : ''}`}>{clean(c)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ),
      )}
    </>
  )
}


// The new text with its tables drawn as tables. New or changed lines and table rows are highlighted.
export function DiffBlocks({ oldText, newText }: { oldText: string; newText: string }) {
  const norm = (t: string) => t.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()
  const oldBlocks = parseBlocks(oldText)
  const newBlocks = parseBlocks(newText)
  const oldLines = new Set(oldBlocks.flatMap((b) => (b.type === 'text' ? b.text.split('\n').map(norm) : [])).filter(Boolean))
  const oldRows = new Set(oldBlocks.flatMap((b) => (b.type === 'table' ? b.rows.map((r) => norm(r.join(' '))) : [])))
  const newLines = new Set(newBlocks.flatMap((b) => (b.type === 'text' ? b.text.split('\n').map(norm) : [])).filter(Boolean))
  const newRows = new Set(newBlocks.flatMap((b) => (b.type === 'table' ? b.rows.map((r) => norm(r.join(' '))) : [])))
  const removed = [
    ...oldBlocks.flatMap((b) => (b.type === 'text' ? b.text.split('\n').filter((l) => l.trim() && !newLines.has(norm(l))) : [])),
    ...oldBlocks.flatMap((b) => (b.type === 'table' ? b.rows.filter((r) => !newRows.has(norm(r.join(' ')))).map((r) => r.map(clean).join(' | ')) : [])),
  ]
  return (
    <>
      {newBlocks.map((b, i) =>
        b.type === 'text' ? (
          <div key={i}>
            {docLines(b.text).map((l, j) => <p key={j} className={`mt-2 whitespace-pre-wrap ${l.sub ? 'font-semibold' : ''} ${oldLines.has(norm(l.text)) ? '' : 'rounded bg-green-100 px-1 text-green-950'}`}>{l.text}</p>)}
          </div>
        ) : (
          <div key={i} className="mt-3 overflow-x-auto">
            <table className="w-full border-collapse text-xs">
              <thead><tr>{b.rows[0].map((c, j) => <th key={j} className="border border-line bg-ink px-2 py-1.5 text-left font-semibold text-paper">{clean(c)}</th>)}</tr></thead>
              <tbody>
                {b.rows.slice(1).map((r, ri) => (
                  <tr key={ri} className={oldRows.has(norm(r.join(' '))) ? '' : 'bg-green-100 text-green-950'}>
                    {r.map((c, j) => <td key={j} className={`border border-line px-2 py-1.5 align-top ${num(c) !== null ? 'text-right tabular-nums' : ''}`}>{clean(c)}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ),
      )}
      {removed.length > 0 && (
        <details className="mt-3">
          <summary className="cursor-pointer font-semibold text-red-800">Removed ({removed.length})</summary>
          {removed.slice(0, 40).map((l, n) => <p key={n} className="mt-1 whitespace-pre-wrap text-red-900 line-through">{l}</p>)}
        </details>
      )}
    </>
  )
}


export const field =
  'mt-2 w-full rounded-card border border-line bg-white px-4 py-3 text-base outline-none focus:border-accent focus-visible:ring-2 focus-visible:ring-accent/30'

export const label = 'block text-sm font-semibold'

export const primary =
  'inline-flex min-h-11 items-center justify-center rounded-full bg-accent px-6 font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'

export const ghost =
  'inline-flex min-h-11 items-center justify-center rounded-full border border-accent/60 px-5 font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'


export const NS = 'Not stated on the page'

export function DRow({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-line py-5">
      <h3 className="text-xs font-semibold tracking-wide text-muted uppercase">{title}</h3>
      <div className="mt-2 space-y-2 text-[15px] leading-relaxed">{children}</div>
    </section>
  )
}

export function Bullets({ items }: { items: string[] }) {
  if (!items.length) return <p className="text-muted">{NS}</p>
  return <ul className="list-disc space-y-1.5 pl-5">{items.map((i, k) => <li key={k}>{i}</li>)}</ul>
}

export function Steps({ items }: { items: string[] }) {
  if (!items.length) return <p className="text-muted">{NS}</p>
  return <ol className="list-decimal space-y-1.5 pl-5">{items.map((i, k) => <li key={k}>{i}</li>)}</ol>
}

export function Pills({ items }: { items: string[] }) {
  if (!items.length) return <p className="text-muted">{NS}</p>
  return <div className="flex flex-wrap gap-2">{items.map((i) => <span key={i} className="rounded-full border border-line bg-card px-3 py-1 text-sm">{i}</span>)}</div>
}

export const known = (v: string) => v && v !== NS

export function KV({ k, v }: { k: string; v: string }) {
  return <p><span className="font-semibold">{k}: </span><span className={known(v) ? '' : 'text-muted'}>{v}</span></p>
}


export function DetailsPanel(props: {
  g: Grant
  detail: GrantDetail | null
  loading: boolean
  error: string
  saved: boolean
  hasApp: boolean
  onClose: () => void
  onRefresh: () => void
  onSave: () => void
  onApply: () => void
  invite: boolean
}) {
  const { g, detail: d } = props
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={props.onClose} role="dialog" aria-modal="true" aria-label="Grant details">
      <div className="h-full w-full max-w-3xl overflow-y-auto bg-paper shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-line bg-paper px-6 py-4">
          <div className="min-w-0">
            <p className="text-xs font-semibold tracking-wide text-muted uppercase">{g.source}</p>
            <h2 className="font-display text-2xl leading-tight font-semibold">{g.title}</h2>
          </div>
          <button onClick={props.onClose} className="min-h-10 shrink-0 rounded-full border border-accent/50 px-4 font-semibold text-accent hover:border-accent hover:bg-accent/10">Close</button>
        </div>
        <div className="px-6 pb-16">
          <div className="flex flex-wrap gap-3 py-5">
            <button className={ghost} onClick={props.onSave}>{props.saved ? 'Saved ✓' : 'Save'}</button>
            {!props.invite && <button className={primary} onClick={props.onApply}>{props.hasApp ? 'Open application' : 'Start application'}</button>}
            {g.url && <a className={ghost} href={g.url} target="_blank" rel="noreferrer">Official page</a>}
            <button className={ghost} onClick={props.onRefresh} disabled={props.loading}>{props.loading ? 'Reading...' : 'Refresh brief'}</button>
          </div>

          {props.loading && !d && (
            <div className="rounded-card border border-line bg-card p-6">
              <p className="font-semibold">Reading the funder's page and building the brief...</p>
              <p className="mt-1 text-sm text-muted">This takes about 10 to 20 seconds.</p>
            </div>
          )}
          {props.error && <p className="rounded-card border border-line bg-card p-4 text-sm text-accent">{props.error}</p>}

          {d && (
            <div>
              {d.sourceNote && <p className="mb-4 rounded-card bg-card p-3 text-sm">{d.sourceNote}</p>}
              <DRow title="Funder"><p className="font-semibold">{d.funder}</p></DRow>
              <DRow title="Deadline"><p className="capitalize">{showDate(d.deadline)}</p></DRow>
              <DRow title="Amount"><p className="font-semibold">{d.amount}</p>{known(d.amountNote) && <p className="text-muted">{d.amountNote}</p>}</DRow>
              <DRow title="Geographic eligibility"><Pills items={d.countries} /></DRow>
              <DRow title="Sectors"><Pills items={d.sectors} /></DRow>
              <DRow title="Eligibility criteria"><Bullets items={d.eligibility} /></DRow>
              <DRow title="Application process">
                <p>{d.applicationSummary}</p>
                <p><span className="font-semibold">Effort: </span><span className="capitalize">{d.effort}</span></p>
                <p className="pt-1 text-sm font-semibold">Steps</p>
                <Steps items={d.steps} />
              </DRow>
              <DRow title="Required documents"><Bullets items={d.requiredDocuments} /><KV k="Contact" v={d.contact} /></DRow>
              <DRow title="Reporting and compliance"><p className={known(d.reporting) ? '' : 'text-muted'}>{d.reporting}</p></DRow>
              <DRow title="Execution burden">
                <KV k="Required staffing" v={d.execution.staffing} />
                <KV k="Required expertise" v={d.execution.expertise} />
                <KV k="Required facilities" v={d.execution.facilities} />
                <KV k="Required partners" v={d.execution.partners} />
                <KV k="Delivery scale" v={d.execution.scale} />
              </DRow>
              <DRow title="Capacity gaps versus your organization">
                <Bullets items={d.capacityGaps} />
                {d.addToProfile.length > 0 && (
                  <div>
                    <p className="pt-1 text-sm font-semibold">Add to your org profile to confirm fit</p>
                    <Pills items={d.addToProfile} />
                  </div>
                )}
                {d.fitSummary && <p className="rounded-card bg-card p-3">{d.fitSummary}</p>}
              </DRow>
              <DRow title="Funder contact information">
                <KV k="Email" v={d.funderContact.email} />
                <KV k="Phone" v={d.funderContact.phone} />
                <KV k="Address" v={d.funderContact.address} />
                <KV k="Website" v={d.funderContact.website} />
                <KV k="Registration" v={d.funderContact.registration} />
                {d.leadership.length > 0 && (<div><p className="pt-1 text-sm font-semibold">Board and leadership</p><Bullets items={d.leadership} /></div>)}
              </DRow>
              <DRow title="Requirements"><Bullets items={d.requirements} /></DRow>
              <DRow title="Detailed overview">
                <p className="text-sm font-semibold">How to apply</p><Bullets items={d.howToApply} />
                <p className="pt-2 text-sm font-semibold">Important dates</p><Bullets items={d.importantDates} />
                <p className="pt-2 text-sm font-semibold">Additional notes</p><Bullets items={d.additionalNotes} />
              </DRow>
              <DRow title="Source and links">
                <ul className="space-y-1.5">
                  {g.url && <li><a className="font-semibold underline" href={g.url} target="_blank" rel="noreferrer">Official grant page</a></li>}
                  {d.links.filter((l) => l.url !== g.url).map((l) => <li key={l.url}><a className="underline" href={l.url} target="_blank" rel="noreferrer">{l.label || l.url}</a></li>)}
                </ul>
                <p className="pt-3 text-xs text-muted">This brief is compiled by AI from the funder's page and your profile. Confirm every requirement and date with the funder before you apply.</p>
              </DRow>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}


export function GrantRow(props: {
  g: Grant
  saved: boolean
  onSave: () => void
  fit?: Fit
  open: boolean
  loading: boolean
  onFit: () => void
  onWrite: () => void
  days?: number | null
  hasApp?: boolean
  match?: { score: number; reasons: string[]; flags: string[] }
  onDetails?: () => void
  compact?: boolean
  children?: React.ReactNode
}) {
  const { g, fit } = props
  const tone = fit ? (fit.score >= 70 ? 'text-green-700' : fit.score >= 45 ? 'text-accent' : 'text-muted') : ''
  return (
    <li className="py-6">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">
        {g.source} · {g.funder}
      </p>
      <h3 className="mt-1 text-lg font-semibold">
        <a href={g.url} target="_blank" rel="noreferrer" className="underline decoration-line underline-offset-4 hover:decoration-ink">
          {g.title}
        </a>
      </h3>
      {g.summary && !props.compact && <p className="mt-1 max-w-prose text-muted">{g.summary}</p>}
      {props.match && (
        <div className="mt-3 flex flex-wrap items-center gap-3">
          {(() => { const sc = props.fit ? props.fit.score : props.match.score; return <span title={props.fit ? 'AI fit analysis, out of 100' : 'Estimate from your profile. Run the fit analysis for a detailed score'} className={`rounded-full px-3 py-1 text-sm font-bold ${sc >= 65 ? 'bg-green-100 text-green-900' : sc >= 40 ? 'bg-amber-100 text-amber-900' : 'bg-card text-muted'}`}>{props.fit ? `Fit ${props.fit.score}/100` : `Estimated fit ${props.match.score}%`}</span> })()}
          {!props.compact && props.match.reasons.length > 0 && <span className="text-xs text-muted">{props.match.reasons.join(' · ')}</span>}
          {!props.compact && props.match.flags.length > 0 && <span className="text-xs font-semibold text-accent">Check: {props.match.flags.join(' · ')}</span>}
        </div>
      )}
      <div className="mt-2 flex flex-wrap gap-2 text-xs font-semibold">
        <span className="rounded-full bg-card px-2.5 py-1 capitalize">{normStatus(g)}</span>
        {g.gtype && <span className="rounded-full bg-card px-2.5 py-1">{g.gtype}</span>}
        {amountLabel(g) && <span className="rounded-full bg-accent/15 px-2.5 py-1 text-accent">{amountLabel(g)}</span>}
        {(g.countries ?? []).slice(0, 2).map((c) => <span key={c} className="rounded-full border border-line px-2.5 py-1">{c}</span>)}
        {(g.sectors ?? []).slice(0, 3).map((c) => <span key={c} className="rounded-full border border-line px-2.5 py-1 text-muted">{c}</span>)}
      </div>
      <p className="mt-2 text-sm text-muted">
        Deadline: {showDate(g.deadline)}
        {props.days !== undefined && props.days !== null && (
          <span className={`ml-2 rounded-full px-2 py-0.5 text-xs font-semibold ${props.days < 0 ? 'bg-card text-muted' : props.days <= 14 ? 'bg-red-100 text-red-900' : props.days <= 45 ? 'bg-amber-100 text-amber-900' : 'bg-green-100 text-green-900'}`}>
            {props.days < 0 ? 'Closed' : props.days === 0 ? 'Due today' : `${props.days} days left`}
          </span>
        )}
      </p>
      <div className="mt-4 flex flex-wrap gap-3">
        {props.onDetails && <button className={ghost} onClick={props.onDetails}>Details</button>}
        <button className={ghost} onClick={props.onSave}>
          {props.saved ? 'Saved ✓' : 'Save'}
        </button>
        <button className={ghost} onClick={props.onFit} disabled={props.loading}>
          {props.loading ? 'Analyzing...' : fit ? (props.compact && !props.open ? 'Show fit' : 'Re-run fit') : 'Fit analysis'}
        </button>
        <button className={primary} onClick={props.onWrite}>
          {props.hasApp ? 'Open application' : 'Start application'}
        </button>
      </div>
      {props.children}
      {fit && (!props.compact || props.open) && (
        <div className="mt-4 rounded-card border border-line bg-card p-5">
          <p className={`font-display text-3xl font-semibold ${tone}`}>
            {fit.score}/100 <span className="text-base font-normal text-muted">fit ({fit.mode === 'ai' ? 'AI analysis' : 'keyword match'})</span>
          </p>
          {fit.strengths.length > 0 && <List title="Strengths" items={fit.strengths} />}
          {fit.gaps.length > 0 && <List title="Gaps to check" items={fit.gaps} />}
          {fit.tips.length > 0 && <List title="Next steps" items={fit.tips} />}
        </div>
      )}
    </li>
  )
}

export function SortTh({ k, label, sort, onSort, right, className = '' }: { k: string; label: string; sort: SortState; onSort: (k: string) => void; right?: boolean; className?: string }) {
  const on = sort?.k === k
  return (
    <th scope="col" aria-sort={on ? (sort!.dir === 1 ? 'ascending' : 'descending') : 'none'} className={`px-3 py-3 text-xs font-semibold tracking-wide uppercase ${right ? 'text-right' : 'text-left'} ${className}`}>
      <button type="button" onClick={() => onSort(k)} className="inline-flex items-center gap-1 uppercase hover:underline" title={`Sort by ${label.toLowerCase()}`}>
        {label}<span aria-hidden className="text-[10px]">{on ? (sort!.dir === 1 ? '▲' : '▼') : '↕'}</span>
      </button>
    </th>
  )
}


export function List({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="mt-3">
      <p className="text-sm font-semibold">{title}</p>
      <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-muted">
        {items.map((i) => (
          <li key={i}>{i}</li>
        ))}
      </ul>
    </div>
  )
}

// Shows how a fit score is built from its parts, so the number can be checked.
export function FitBreakdown({ parts }: { parts?: { label: string; points: number; max: number; note: string }[] }) {
  if (!parts?.length) return null
  return (
    <div className="mt-3">
      <p className="text-sm font-semibold">How the score is built</p>
      <ul className="mt-1 space-y-1.5 text-sm">
        {parts.map((x) => (
          <li key={x.label} className="grid grid-cols-[6.5rem_3.2rem_1fr] items-baseline gap-2">
            <span className="font-semibold">{x.label}</span>
            <span className="tabular-nums text-muted">{x.points}/{x.max}</span>
            <span className="text-muted">{x.note}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
