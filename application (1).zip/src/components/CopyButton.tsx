import { useState } from 'react'
import { ghost } from './ui'

// Copies a field's text. The caller shows it only once the text exists.
export async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text)
  } catch {
    const t = document.createElement('textarea')
    t.value = text
    t.style.position = 'fixed'
    t.style.opacity = '0'
    document.body.appendChild(t)
    t.select()
    try { document.execCommand('copy') } catch {}
    t.remove()
  }
}

export default function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [done, setDone] = useState(false)
  async function copy() {
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      const t = document.createElement('textarea')
      t.value = text
      t.style.position = 'fixed'
      t.style.opacity = '0'
      document.body.appendChild(t)
      t.select()
      try { document.execCommand('copy') } catch {}
      t.remove()
    }
    setDone(true)
    setTimeout(() => setDone(false), 1800)
  }
  return (
    <button type="button" className={ghost} onClick={copy} aria-label={done ? 'Copied' : `${label} this text`} title="Copy this text to the clipboard">
      <span role="status">{done ? 'Copied ✓' : label}</span>
    </button>
  )
}
