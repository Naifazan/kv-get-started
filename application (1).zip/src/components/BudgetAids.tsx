import { useState } from 'react'
import { costBenchmarks, fxRates } from '../server/aids'
import type { Benchmark } from '../server/aids'
import { ALL_COUNTRIES } from '../lib/countries'

const field = 'mt-1 w-full rounded-card border border-line bg-white px-3 py-2 text-sm outline-none focus:border-accent'
const primary = 'inline-flex min-h-10 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'
const NAMES: Record<string, string> = { USD: 'US dollar', EUR: 'Euro', GBP: 'British pound', KES: 'Kenyan shilling', UGX: 'Ugandan shilling', TZS: 'Tanzanian shilling', NGN: 'Nigerian naira', GHS: 'Ghanaian cedi', ZAR: 'South African rand', INR: 'Indian rupee', PKR: 'Pakistani rupee', BDT: 'Bangladeshi taka', PHP: 'Philippine peso', IDR: 'Indonesian rupiah', BRL: 'Brazilian real', MXN: 'Mexican peso', TRY: 'Turkish lira', CAD: 'Canadian dollar', AUD: 'Australian dollar', CHF: 'Swiss franc', JPY: 'Japanese yen', CNY: 'Chinese yuan', PLN: 'Polish zloty', CZK: 'Czech koruna', HUF: 'Hungarian forint', RON: 'Romanian leu', SEK: 'Swedish krona', NOK: 'Norwegian krone', DKK: 'Danish krone', THB: 'Thai baht', MYR: 'Malaysian ringgit', SGD: 'Singapore dollar', NZD: 'New Zealand dollar', ILS: 'Israeli shekel', HKD: 'Hong Kong dollar', KRW: 'South Korean won' }

export default function BudgetAids({ country, items }: { country: string; items: string[] }) {
  const [open, setOpen] = useState(false)
  const [rates, setRates] = useState<{ date: string; rates: Record<string, number> } | null>(null)
  const [fxNote, setFxNote] = useState('')
  const [amount, setAmount] = useState('1')
  const [cur, setCur] = useState('EUR')
  const [direction, setDirection] = useState<'toUsd' | 'fromUsd'>('toUsd')
  const [bCountry, setBCountry] = useState(country)
  const [bItems, setBItems] = useState(items.join('\n'))
  const [rows, setRows] = useState<Benchmark[] | null>(null)
  const [busy, setBusy] = useState(false)
  const [bNote, setBNote] = useState('')

  async function toggle() {
    const next = !open
    setOpen(next)
    if (next && !rates) {
      const r = await fxRates().catch(() => null)
      if (r && r.ok) setRates({ date: r.date, rates: r.rates })
      else setFxNote(r && !r.ok ? r.reason : 'Could not load exchange rates.')
    }
    if (next) { setBCountry((c) => c || country); setBItems((t) => t || items.join('\n')) }
  }
  const n = Number(amount.replace(/[^0-9.]/g, '')) || 0
  const rate = rates?.rates[cur]
  const result = rate ? (direction === 'toUsd' ? n / rate : n * rate) : null
  async function estimate() {
    setBusy(true); setBNote(''); setRows(null)
    try {
      const r = await costBenchmarks({ data: { country: bCountry, items: bItems.split('\n') } })
      if (r.ok) setRows(r.rows); else setBNote(r.reason)
    } catch { setBNote('Something went wrong. Please try again.') }
    setBusy(false)
  }
  return (
    <div className="mt-3 rounded-card border border-line bg-card p-4">
      <button type="button" className="flex w-full items-center justify-between text-left text-sm font-semibold" aria-expanded={open} onClick={toggle}>
        <span>Budget aids: currency converter and typical costs</span><span aria-hidden>{open ? '▴' : '▾'}</span>
      </button>
      {open && (
        <div className="mt-4 grid gap-6 lg:grid-cols-2">
          <section aria-label="Currency converter">
            <h4 className="text-sm font-semibold">Currency converter</h4>
            <p className="text-xs text-muted">Daily reference rates. Funders usually state which rate to use, so check their rule.</p>
            {rates ? (
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                <label className="block text-xs font-semibold">Amount<input className={field} inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
                <label className="block text-xs font-semibold">Currency<select className={field} value={cur} onChange={(e) => setCur(e.target.value)}>{Object.keys(rates.rates).sort().map((c) => <option key={c} value={c}>{c}{NAMES[c] ? ` · ${NAMES[c]}` : ''}</option>)}</select></label>
                <div className="sm:col-span-2" role="group" aria-label="Direction">
                  <div className="inline-flex overflow-hidden rounded-full border border-accent/60 text-xs font-semibold">{([['toUsd', `${cur} to USD`], ['fromUsd', `USD to ${cur}`]] as const).map(([k, t]) => <button key={k} type="button" aria-pressed={direction === k} onClick={() => setDirection(k)} className={`px-3 py-1.5 ${direction === k ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{t}</button>)}</div>
                </div>
                <p className="sm:col-span-2 font-display text-2xl font-semibold tabular-nums">{result === null ? '' : direction === 'toUsd' ? `$${result.toLocaleString('en-US', { maximumFractionDigits: 2 })} USD` : `${result.toLocaleString('en-US', { maximumFractionDigits: 2 })} ${cur}`}</p>
                <p className="sm:col-span-2 text-xs text-muted">1 {cur} = {rate ? (1 / rate).toLocaleString('en-US', { maximumFractionDigits: 4 }) : ''} USD. 1 USD = {rate?.toLocaleString('en-US', { maximumFractionDigits: 4 })} {cur}. Rates dated {rates.date}.</p>
              </div>
            ) : <p className="mt-2 text-sm text-muted">{fxNote || 'Loading rates...'}</p>}
          </section>
          <section aria-label="Typical costs">
            <h4 className="text-sm font-semibold">Typical local costs (AI estimate)</h4>
            <p className="text-xs text-muted">Rough planning ranges in USD. Replace them with real quotes before you submit.</p>
            <label className="mt-2 block text-xs font-semibold">Country<select className={field} value={bCountry} onChange={(e) => setBCountry(e.target.value)}><option value="">Select a country</option>{bCountry && !ALL_COUNTRIES.includes(bCountry) && <option value={bCountry}>{bCountry}</option>}{ALL_COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}</select></label>
            <label className="mt-2 block text-xs font-semibold">Cost items, one per line<textarea rows={4} className={field} value={bItems} onChange={(e) => setBItems(e.target.value)} placeholder={'Project coordinator salary\nTraining venue per day\nTransport to field sites'} /></label>
            <button type="button" className={`${primary} mt-2`} disabled={busy || !bItems.trim()} onClick={estimate}>{busy ? 'AI is estimating...' : 'Estimate typical costs'}</button>
            {bNote && <p className="mt-2 text-sm text-accent">{bNote}</p>}
            {rows && (
              <div className="mt-3 overflow-x-auto rounded-card border border-line bg-white"><table className="w-full min-w-[24rem] border-collapse text-xs">
                <thead><tr className="bg-ink text-left uppercase tracking-wide text-paper"><th className="px-2 py-2">Item</th><th className="px-2 py-2">Unit</th><th className="px-2 py-2 text-right">Typical range (USD)</th></tr></thead>
                <tbody className="divide-y divide-line">{rows.map((r, i) => <tr key={i} className="align-top"><td className="px-2 py-2"><p className="font-semibold">{r.item}</p>{r.note && <p className="text-muted">{r.note}</p>}</td><td className="px-2 py-2">{r.unit}</td><td className="px-2 py-2 text-right tabular-nums">${Math.round(r.low).toLocaleString('en-US')} to ${Math.round(r.high).toLocaleString('en-US')}</td></tr>)}</tbody>
              </table></div>
            )}
          </section>
        </div>
      )}
    </div>
  )
}
