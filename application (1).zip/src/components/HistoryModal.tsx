import { useEffect } from 'react'
import { askConfirm } from '../lib/confirm'

export type Snapshot = { at: number; label: string; doc: Record<string, string> }
type Props = {
  entries: Snapshot[]
  current: Record<string, string>
  titles: Record<string, string>
  onRestore: (i: number) => void
  onSnapshot: () => void
  onClose: () => void
}
const ghost = 'inline-flex min-h-10 items-center justify-center rounded-full border border-accent/60 px-4 text-sm font-semibold text-accent hover:border-accent hover:bg-accent/10 disabled:opacity-50'
const primary = 'inline-flex min-h-10 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink hover:brightness-110 disabled:opacity-50'
const wc = (t: string) => (t.trim() ? t.trim().split(/\s+/).length : 0)

export default function HistoryModal(p: Props) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') p.onClose() }
    document.addEventListener('keydown', k)
    return () => document.removeEventListener('keydown', k)
  }, [p])
  const diff = (d: Record<string, string>) => {
    const keys = new Set([...Object.keys(d), ...Object.keys(p.current)])
    return [...keys].filter((k) => (d[k] ?? '') !== (p.current[k] ?? '')).map((k) => ({ k, title: p.titles[k] ?? k, then: wc(d[k] ?? ''), now: wc(p.current[k] ?? '') }))
  }
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-3 md:p-6" role="dialog" aria-modal="true" aria-labelledby="hist-title" onClick={(e) => { if (e.target === e.currentTarget) p.onClose() }}>
      <div className="flex max-h-[92vh] w-full max-w-2xl flex-col rounded-card bg-paper shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-line px-5 py-4 md:px-6">
          <div><h2 id="hist-title" className="font-display text-2xl font-semibold">Version history</h2><p className="mt-1 text-sm text-muted">The portal keeps a snapshot before each AI rewrite. Restore any version. Your current draft is saved first, so nothing is lost.</p></div>
          <button type="button" aria-label="Close" className="shrink-0 rounded-full px-3 py-1 text-xl leading-none text-muted hover:text-ink" onClick={p.onClose}>×</button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 md:px-6">
          <button type="button" className={primary} onClick={p.onSnapshot}>Save a version now</button>
          {p.entries.length === 0 ? <p className="mt-4 text-sm text-muted">No versions yet. One is saved automatically before AI rewrites a section, or when you press the button above.</p> : (
            <ul className="mt-4 space-y-3">
              {p.entries.map((e, i) => {
                const d = diff(e.doc)
                return (
                  <li key={e.at + '-' + i} className="rounded-card border border-line bg-white p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0"><p className="font-semibold">{e.label}</p><p className="text-xs text-muted">{new Date(e.at).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</p></div>
                      <button type="button" className={ghost} onClick={() => askConfirm('Restore this version? Your current draft is saved as a version first.', { title: 'Restore this version?', yes: 'Yes, restore', danger: false }).then((ok) => { if (ok) p.onRestore(i) })}>Restore</button>
                    </div>
                    <p className="mt-2 text-sm text-muted">{d.length ? `Differs from your current draft in ${d.length} section${d.length === 1 ? '' : 's'}:` : 'Same as your current draft.'}</p>
                    {d.length > 0 && <ul className="mt-1 list-disc space-y-0.5 pl-5 text-sm">{d.slice(0, 6).map((x) => <li key={x.k}>{x.title}: {x.then} words then, {x.now} now</li>)}{d.length > 6 && <li className="text-muted">and {d.length - 6} more</li>}</ul>}
                  </li>
                )
              })}
            </ul>
          )}
        </div>
        <div className="flex justify-end border-t border-line px-5 py-4 md:px-6"><button type="button" className={ghost} onClick={p.onClose}>Close</button></div>
      </div>
    </div>
  )
}
