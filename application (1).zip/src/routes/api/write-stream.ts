import { createFileRoute } from '@tanstack/react-router'
import { buildAutoPrompt, finishAutoText, guardAi, llmStream, type CompleteInput } from '../../server/grants'

// Writes or improves one section and sends the text to the page piece by piece as it is written.
export const Route = createFileRoute('/api/write-stream')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json' } })
        let data: CompleteInput
        try {
          const raw = await request.text()
          if (raw.length > 400_000) return json({ ok: false, reason: 'This request is too large.' }, 413)
          data = JSON.parse(raw)
        } catch {
          return json({ ok: false, reason: 'Bad request.' }, 400)
        }
        if (!data || typeof data.section !== 'string' || typeof data.profile !== 'object' || data.profile === null) return json({ ok: false, reason: 'Bad request.' }, 400)
        try {
          await guardAi()
        } catch (e: any) {
          return json({ ok: false, reason: String(e?.message ?? 'The AI is not available right now.') })
        }
        const { system, user, tokens } = buildAutoPrompt(data)
        const enc = new TextEncoder()
        const stream = new ReadableStream({
          async start(controller) {
            const send = (o: unknown) => { try { controller.enqueue(enc.encode('data: ' + JSON.stringify(o) + '\n\n')) } catch {} }
            try {
              send({ t: 'status', s: 'Thinking about the section...' })
              const full = await llmStream(system, user, tokens, { delta: (s) => send({ t: 'd', s }), reset: () => send({ t: 'reset' }), status: (s) => send({ t: 'status', s }) }, request.signal)
              send({ t: 'done', text: finishAutoText(full, data) })
            } catch (e: any) {
              send({ t: 'error', reason: String(e?.message ?? 'The AI service returned an error.') })
            }
            try { controller.close() } catch {}
          },
        })
        return new Response(stream, { headers: { 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-cache, no-transform', 'x-accel-buffering': 'no' } })
      },
    },
  },
})
