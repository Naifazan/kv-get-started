import { createFileRoute } from '@tanstack/react-router'
import { sql } from '../../../db.server'
import { deferFindings, refreshFindings } from '../../../findings.server'
import type { Profile } from '../../../server/grants'

// Called on a schedule. Refreshes matched grants for a few signed-in users whose matches are over 6 hours old.
// Safe to call publicly: it does nothing if it ran in the last 50 minutes and handles at most 3 users per call.
export const Route = createFileRoute('/api/cron/refresh')({
  server: {
    handlers: {
      GET: async () => {
        const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'content-type': 'application/json' } })
        if (!process.env.DATABASE_URL) return json({ ok: false, reason: 'no_database' }, 503)
        try {
          const db = sql()
          const gate = await db`insert into saved_applications (user_id, app_id, title, data, updated_at)
            values ('__system__', '__cron__', 'cron', '{}'::jsonb, now())
            on conflict (user_id, app_id) do update set updated_at = now()
            where saved_applications.updated_at < now() - interval '50 minutes'
            returning user_id`
          if (!gate.length) return json({ ok: true, skipped: true })
          const rows = await db`select p.user_id, p.data from saved_applications p
            left join saved_applications f on f.user_id = p.user_id and f.app_id = '__findings__'
            where p.app_id = '__profile__' and p.user_id <> '__system__' and (f.updated_at is null or f.updated_at < now() - interval '6 hours')
            order by f.updated_at asc nulls first limit 3`
          let done = 0
          let failed = 0
          for (const r of rows) {
            try {
              await refreshFindings(String(r.user_id), r.data as Profile)
              done++
            } catch {
              failed++
              try { await deferFindings(String(r.user_id)) } catch {}
            }
          }
          return json({ ok: true, refreshed: done, failed })
        } catch {
          return json({ ok: false }, 500)
        }
      },
    },
  },
})
