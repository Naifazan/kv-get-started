import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { Suspense, lazy } from 'react'

import appCss from '../styles.css?url'

const Devtools = import.meta.env.DEV ? lazy(() => import('../devtools')) : null
const ICON = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%23c2570c'/%3E%3Ctext x='32' y='45' font-family='Georgia,serif' font-size='40' font-weight='700' text-anchor='middle' fill='white'%3EG%3C/text%3E%3C/svg%3E"

export const Route = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: 'Global NGO Grants Writer: free grant proposal portal',
      },
      {
        name: 'description',
        content:
          'A free portal for NGOs and nonprofits anywhere in the world to draft a complete grant proposal in minutes.',
      },
      { name: 'theme-color', content: '#14403c' },
      { name: 'color-scheme', content: 'light dark' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Global NGO Grants Writer' },
      { property: 'og:description', content: 'Find grants, write the proposal, build the budget and MEAL documents, and check quality before you submit. Free for NGOs worldwide.' },
      { name: 'twitter:card', content: 'summary' },
    ],
    links: [
      { rel: 'icon', type: 'image/svg+xml', href: ICON },
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Lora:wght@600&family=Source+Sans+3:wght@400;600;700&display=swap',
      },
      {
        rel: 'stylesheet',
        href: appCss,
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        {Devtools && (
          <Suspense fallback={null}>
            <Devtools />
          </Suspense>
        )}
        <Scripts />
      </body>
    </html>
  )
}
