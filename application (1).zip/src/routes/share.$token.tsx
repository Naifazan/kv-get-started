import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { getShare } from '../server/saved'
import type { SharedProposal } from '../server/saved'

export const Route = createFileRoute('/share/$token')({
  head: () => ({ meta: [{ title: 'Shared grant proposal' }, { name: 'robots', content: 'noindex' }] }),
  component: SharedView,
})

const clean = (t: string) => t.replace(/\*/g, '')
function Block({ text }: { text: string }) {
  const lines = clean(text).split('\n')
  const out: React.ReactNode[] = []
  for (let i = 0; i < lines.length; ) {
    if (/^\s*\|.*\|\s*$/.test(lines[i])) {
      const rows: string[][] = []
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
        const cells = lines[i].trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim())
        if (!cells.every((c) => /^:?-{2,}:?$/.test(c) || c === '')) rows.push(cells)
        i++
      }
      out.push(
        <div key={'t' + i} className="my-3 overflow-x-auto"><table className="w-full border-collapse text-sm"><thead><tr>{rows[0]?.map((c, j) => <th key={j} className="border border-line bg-ink px-2 py-1.5 text-left text-paper">{c}</th>)}</tr></thead><tbody>{rows.slice(1).map((r, ri) => <tr key={ri}>{r.map((c, j) => <td key={j} className="border border-line px-2 py-1.5 align-top">{c}</td>)}</tr>)}</tbody></table></div>,
      )
    } else {
      const raw = lines[i].trim()
      i++
      if (!raw) continue
      const hash = /^#{1,4}\s+/.test(raw)
      const txt = raw.replace(/^#{1,4}\s+/, '')
      const isSub = hash || (txt.length <= 70 && txt.split(/\s+/).length <= 9 && !/[.,;:!?)\]]$/.test(txt) && !/^[-•|\d]/.test(txt) && (lines[i - 2] === undefined || !lines[i - 2].trim()) && !!(lines[i] ?? '').trim() && (lines[i] ?? '').trim().length > txt.length)
      out.push(isSub ? <h3 key={'h' + i} className="mt-5 font-semibold">{txt}</h3> : <p key={'p' + i} className="mt-2 whitespace-pre-wrap">{txt}</p>)
    }
  }
  return <>{out}</>
}

function SharedView() {
  const { token } = Route.useParams()
  const [state, setState] = useState<'loading' | 'ok' | 'gone' | 'expired'>('loading')
  const [p, setP] = useState<SharedProposal | null>(null)
  useEffect(() => {
    getShare({ data: { token } }).then((r) => {
      if (r.ok) { setP(r.proposal); setState('ok') } else setState('expired' in r && r.expired ? 'expired' : 'gone')
    }).catch(() => setState('gone'))
  }, [token])
  if (state === 'loading') return <main className="mx-auto max-w-3xl px-5 py-16 text-muted">Loading the shared proposal...</main>
  if (state !== 'ok' || !p) return <main className="mx-auto max-w-xl px-5 py-20 text-center"><h1 className="font-display text-3xl font-semibold">{state === 'expired' ? 'This link has expired' : 'This link is not available'}</h1><p className="mt-3 text-muted">{state === 'expired' ? 'Share links last 30 days. Ask the author for a new one.' : 'It may have been turned off by the author, or the address is wrong.'}</p></main>
  return (
    <main className="mx-auto max-w-3xl px-5 py-6 md:py-14">
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">Shared for review. Read only.</p>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">{p.title}</h1>
      <p className="mt-2 text-muted">{[p.org, p.funder && `Prepared for ${p.funder}`, p.amount && `Amount requested: $${p.amount} USD`, p.months && `Duration: ${p.months} months`].filter(Boolean).join(' · ')}</p>
      <p className="mt-1 text-xs text-muted">Shared {new Date(p.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}. Link expires {new Date(p.expiresAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })}.</p>
      <div className="mt-5 space-y-5">
        {p.sections.map((s, i) => (
          <section key={i}><h2 className="border-b border-line pb-1 font-display text-2xl font-semibold"><span className="mr-3 text-accent tabular-nums">{String(i + 1).padStart(2, '0')}</span>{s.title}</h2><div className="mt-2"><Block text={s.text || '[not written yet]'} /></div></section>
        ))}
      </div>
      <p className="mt-12 text-xs text-muted">Made with Global NGO Grants Writer. Designed by Naif Azan.</p>
      <p className="mt-4"><a className="inline-flex min-h-11 items-center rounded-full bg-accent px-6 font-semibold text-accent-ink" href="https://whop.com/checkout/ch_m7dvzb8WxH3ZUbq/">Start writing grants for $29/mo</a></p>
    </main>
  )
}
