import { createFileRoute } from '@tanstack/react-router'
import ErrorBoundary from '../components/ErrorBoundary'
import LibraryPage from '../components/LibraryPage'
import { fileErrorText, readAnyFile } from '../lib/files'
import { DetailsPanel, RenderBlocks, ghost, primary } from '../components/ui'
import { ConfirmHost } from '../lib/confirm'
import ShareModal from '../components/ShareModal'
import { createShare, revokeShare } from '../server/saved'
import { guidanceText, sectionPlain, tidy } from '../lib/text'
import PrivacyModal from '../components/PrivacyModal'
import CompareModal from '../components/CompareModal'
import ReviewModal from '../components/ReviewModal'
import HistoryModal from '../components/HistoryModal'
import { isInvite } from '../lib/options'
import { useHome } from '../pages/use-home'
import { FindView } from '../pages/FindPage'
import { PipelineView } from '../pages/PipelinePage'
import { DashboardView } from '../pages/DashboardPage'
import { ApplicationsView } from '../pages/ApplicationsPage'
import { EditorView } from '../pages/EditorPage'
import { ProfileView } from '../pages/ProfilePage'
import { TrackerView } from '../pages/TrackerPage'
import { PlansPage } from '../pages/PlansPage'
import { AdminPage } from '../pages/AdminPage'
import ActivityPill from '../components/ActivityPill'
import { PLAN_LIMITS } from '../plans'
import PricingSection from '../components/PricingSection'
import ChatBot from '../components/ChatBot'

export const Route = createFileRoute('/')({ component: Home })



declare global {
  interface Window {
    whop?: { track?: (name: string, props?: Record<string, unknown>) => void }
  }
}
function Home() {
  const h = useHome()
  const {
    NAV,
    accent,
    accentOk,
    activeId,
    app,
    appOpen,
    apps,
    billing,
    busy,
    allProg,
    qFlow,
    live,
    liveStatus,
    budgetRules,
    cmpIds,
    cmpOpen,
    cmpRows,
    detailBusy,
    detailErr,
    detailGrant,
    detailsCache,
    doc,
    historyOpen,
    isSaved,
    lib,
    loadDetails,
    online,
    openDetails,
    patch,
    pipeMode,
    privacyOpen,
    profile,
    project,
    remDismissed,
    reminders,
    restoreVersion,
    reviewOpen,
    reviewSections,
    secs,
    selectedFramework,
    setAccent,
    setAppOpen,
    setCmpIds,
    setCmpOpen,
    setDetailGrant,
    setDoc,
    setHistoryOpen,
    setLib,
    setMsg,
    setPipeMode,
    setPrivacyOpen,
    setRemDismissed,
    setReviewOpen,
    setShareOpen,
    setStorageFull,
    setTheme,
    setView,
    shareOpen,
    snapshotDoc,
    startApplication,
    storageFull,
    theme,
    todayKey,
    toggleSave,
    view,
  } = h
  const findView = () => FindView(h)
  const pipelineView = () => PipelineView(h)
  const dashboardView = () => DashboardView(h)
  const applicationsList = () => ApplicationsView(h)
  const editorView = () => EditorView(h)
  const profileView = () => ProfileView(h)
  const trackerView = () => TrackerView(h)

  return (
    <div className="min-h-screen bg-paper text-ink md:grid md:grid-cols-[16.5rem_minmax(0,1fr)]">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[2000] focus:rounded-lg focus:bg-paper focus:px-4 focus:py-2 focus:font-semibold focus:text-ink focus:shadow-xl">Skip to the content</a>
      <aside className="bg-ink text-paper md:sticky md:top-0 md:h-screen md:overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 md:block md:py-7">
          <a href="#dashboard" onClick={() => setView('dashboard')} className="font-display text-xl leading-tight font-semibold">
            Global NGO<br className="hidden md:block" /> Grants Writer
          </a>
          <span className="text-xs text-paper/60 md:mt-2 md:block">Grant writing for NGOs worldwide</span>
        </div>
        <nav aria-label="Main" className="flex flex-wrap gap-1 px-3 pb-3 md:block md:space-y-1 md:px-3">
          {NAV.map(([v, text, icon]) => (
            <button
              key={v}
              onClick={() => { setView(v); if (v === 'applications') setAppOpen(false) }}
              aria-current={view === v ? 'page' : undefined}
              className={`flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm font-semibold whitespace-nowrap md:w-full ${view === v ? 'bg-accent text-accent-ink' : 'text-paper/80 hover:bg-paper/10'}`}
            >
              <span aria-hidden className="w-4 text-center">{icon}</span>
              {text}
            </button>
          ))}
        </nav>
        <div className="hidden px-5 py-6 text-xs text-paper/60 md:block">
          <p className="font-semibold text-paper/80">{profile.org || 'Your organization'}</p>
          <button type="button" onClick={() => setView('plans')} className="mt-3 block w-full rounded-lg border border-paper/20 p-3 text-left hover:bg-paper/10" aria-label="Open plans">
            <span className="block font-semibold text-paper/90">{billing?.signedIn ? PLAN_LIMITS[billing.plan].name + ' plan' : 'Free plan'}</span>
            {billing?.signedIn && billing.plan !== 'owner'
              ? <><span className="mt-1 block">{Math.max(0, billing.limit - billing.used)} of {billing.limit} AI credits left</span><span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-paper/20"><span className="block h-full rounded-full bg-accent" style={{ width: Math.min(100, Math.round((billing.used / billing.limit) * 100)) + '%' }} /></span></>
              : <span className="mt-1 block">{billing?.signedIn ? 'Unlimited AI credits' : 'Sign in to use the AI tools'}</span>}
          </button>
        </div>
      </aside>
      <div className="min-w-0">
        <main id="main-content" tabIndex={-1} className={`outline-none mx-auto w-full min-w-0 px-5 py-5 md:px-10 md:py-7 ${view === 'pipeline' && pipeMode === 'table' ? 'max-w-none' : 'max-w-5xl'}`}>
          {storageFull && (
            <div role="alert" className="mb-4 flex flex-wrap items-start justify-between gap-3 rounded-card border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-950">
              <p><span className="font-semibold">Your browser storage is full.</span> Recent changes may not be saved on this device. Sign in to keep your work online, download your data from Privacy and data, and delete documents you no longer need from the Library.</p>
              <button type="button" className="font-semibold underline" onClick={() => setStorageFull(false)}>Dismiss</button>
            </div>
          )}
          {billing?.signedIn && billing.plan !== 'owner' && billing.used >= billing.limit && (
            <div role="alert" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-card border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-950">
              <p><span className="font-semibold">You have used all {billing.limit} AI credits on the {PLAN_LIMITS[billing.plan].name} plan this month.</span> Your work is safe and the non-AI tools still work. Credits reset on the 1st.</p>
              {billing.plan !== 'pro' && <button type="button" className="font-semibold underline" onClick={() => setView('plans')}>See plans</button>}
            </div>
          )}
          {billing && !billing.signedIn && view !== 'plans' && (
            <div role="status" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-card border border-line bg-card px-4 py-3 text-sm">
              <p><span className="font-semibold">Sign in to use the AI tools.</span> The Free plan includes 30 AI credits a month, and everything else works without signing in.</p>
              <a className="font-semibold text-accent underline" href={'/api/oauth/login?redirect_to=' + encodeURIComponent('/')}>Sign in</a>
            </div>
          )}
          {reminders.length > 0 && !remDismissed && (
            <div role="status" className="mb-4 flex flex-wrap items-start justify-between gap-3 rounded-card border border-amber-300 bg-amber-50 px-4 py-3 text-sm">
              <div className="min-w-0">
                <p className="font-semibold text-amber-950">{reminders.length} deadline{reminders.length === 1 ? '' : 's'} coming up</p>
                <ul className="mt-1 space-y-0.5 text-amber-950">{reminders.slice(0, 3).map((r, i) => <li key={i} className="truncate">{r.title}: {r.days === 0 ? 'due today' : `${r.days} day${r.days === 1 ? '' : 's'} left`}</li>)}{reminders.length > 3 && <li>and {reminders.length - 3} more</li>}</ul>
              </div>
              <div className="flex items-center gap-4">
                <button type="button" className="font-semibold text-accent underline" onClick={() => setView('tracker')}>Open full table</button>
                <button type="button" className="text-amber-900 underline" onClick={() => { setRemDismissed(true); try { sessionStorage.setItem('ngw_rem', todayKey) } catch {} }}>Dismiss for today</button>
              </div>
            </div>
          )}
          <ErrorBoundary resetKey={view + (appOpen ? activeId ?? '' : '')}>
          {view === 'dashboard' && <>{dashboardView()}<PricingSection /></>}
          {view === 'pipeline' && (
            <>
              <div role="tablist" aria-label="Pipeline view" className="mb-4 inline-flex overflow-hidden rounded-full border border-accent/60 text-sm font-semibold">
                {([['stages', 'Stages'], ['table', 'Full table']] as const).map(([k, t]) => (
                  <button key={k} type="button" role="tab" aria-selected={pipeMode === k} onClick={() => setPipeMode(k)} className={`px-5 py-1.5 ${pipeMode === k ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{t}</button>
                ))}
              </div>
              {pipeMode === 'stages' ? pipelineView() : trackerView()}
            </>
          )}
          {view === 'find' && findView()}
          {view === 'applications' && (appOpen && app ? editorView() : applicationsList())}
          {view === 'library' && <LibraryPage lib={lib} setLib={setLib} signedIn={!!online?.signedIn} readFile={readAnyFile} fileError={fileErrorText} />}
          {view === 'profile' && profileView()}
          {view === 'plans' && <PlansPage h={h} />}
          {view === 'admin' && <AdminPage h={h} />}
          </ErrorBoundary>
          <div className="mt-4 flex justify-center print:hidden">
            <button type="button" className={ghost} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>↑ Back to top</button>
          </div>
        </main>
        <ConfirmHost />
        <ActivityPill force={busy.startsWith('ai-') || !!allProg || !!qFlow.prog} label={allProg || qFlow.prog || (Object.keys(live).length ? (Object.values(live).some(Boolean) ? 'Writing live...' : liveStatus) : '') || (busy.startsWith('ai-') ? 'The AI is working on your section...' : '')} />
        <footer className="mx-auto max-w-5xl px-5 py-6 text-sm text-muted md:px-10">
          © {new Date().getFullYear()} Global NGO Grants Writer. Grant data comes from Grants.gov, the EU Funding &amp; Tenders portal and a curated funder list. Always confirm eligibility and deadlines on the funder's own page.
          <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs">
            <span role="group" aria-label="Theme" className="inline-flex items-center gap-1">Theme:
              {(['auto', 'light', 'dark'] as const).map((t) => <button key={t} type="button" aria-pressed={theme === t} onClick={() => setTheme(t)} className={`rounded-full px-2.5 py-1 font-semibold capitalize ${theme === t ? 'bg-accent text-accent-ink' : 'text-accent hover:bg-accent/10'}`}>{t}</button>)}
            </span>
            <label className="inline-flex cursor-pointer items-center gap-2" title="Your brand colour. It recolours the portal and the headings in exported Word and PDF files">
              <span aria-hidden className="h-4 w-4 rounded-full border border-ink/30" style={{ background: accentOk ? accent : '#c2570c' }} />
              Brand colour
              <input type="color" className="sr-only" value={accentOk ? accent : '#c2570c'} onChange={(e) => setAccent(e.target.value)} />
              {accentOk && <button type="button" className="font-semibold text-accent underline" onClick={(e) => { e.preventDefault(); setAccent('') }}>Reset</button>}
            </label>
            <button type="button" className="font-semibold text-accent underline" onClick={() => setPrivacyOpen(true)}>Privacy and data</button>
            {!online?.signedIn && <a className="font-semibold text-accent underline" href={'/api/oauth/login?redirect_to=' + encodeURIComponent('/')}>Sign in</a>}
          </div>
          <span className="mt-3 block text-xs">Designed by Naif Azan</span>
        </footer>
      </div>
      {shareOpen && app && (
        <ShareModal
          token={app.share?.token}
          at={app.share?.at}
          signedIn={!!online?.signedIn}
          onSignIn={() => { window.location.href = '/api/oauth/login?redirect_to=' + encodeURIComponent('/#applications') }}
          onClose={() => setShareOpen(false)}
          onCreate={async (token) => {
            try {
              const r = await createShare({ data: { token, snapshot: { title: app.grant?.title ?? (app.project.title || 'Grant proposal'), funder: app.grant?.funder ?? '', org: profile.org, amount: project.amount, months: project.months, sections: secs.map(([k, t]) => ({ title: t, text: sectionPlain(doc[k] ?? '') })) } } })
              if (!r.ok) return r.reason === 'signed_out' ? 'Your sign-in expired. Sign in again.' : r.reason === 'too_big' ? 'This proposal is too large to share.' : 'Sharing is not available right now. Try again in a moment.'
              patch((a) => ({ ...a, share: { token: r.token, at: Date.now() } }))
              return { token: r.token, expiresAt: r.expiresAt }
            } catch { return 'Something went wrong. Please try again.' }
          }}
          onRevoke={async (token) => { try { const r = await revokeShare({ data: { token } }); if (r.ok) patch((a) => ({ ...a, share: null })); return r.ok } catch { return false } }}
        />
      )}
      {view === 'applications' && appOpen && app && <ChatBot key={app.id} h={h} />}
      {privacyOpen && <PrivacyModal signedIn={!!online?.signedIn} onClose={() => setPrivacyOpen(false)} />}
      {view === 'find' && cmpIds.length > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 px-4 py-3 shadow-2xl backdrop-blur md:left-[16.5rem]">
          <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3">
            <p className="text-sm font-semibold">{cmpIds.length} grant{cmpIds.length === 1 ? '' : 's'} selected to compare <span className="font-normal text-muted">(up to 4)</span></p>
            <div className="flex gap-3"><button type="button" className={ghost} onClick={() => setCmpIds([])}>Clear</button><button type="button" className={primary} disabled={cmpIds.length < 2} onClick={() => setCmpOpen(true)}>Compare</button></div>
          </div>
        </div>
      )}
      {cmpOpen && (
        <CompareModal rows={cmpRows()} onClose={() => setCmpOpen(false)} onSave={toggleSave} onApply={(g) => startApplication(g)} onDetails={(g) => openDetails(g)} />
      )}
      {reviewOpen && app && (
        <ReviewModal
          title={app.grant?.title ?? (app.project.title || 'This application')}
          sections={reviewSections()}
          criteria={app.guidance?.criteria ?? []}
          summary={app.guidance ? guidanceText(app.guidance) : ''}
          framework={selectedFramework()}
          amount={project.amount}
          months={project.months}
          rules={budgetRules() || undefined}
          onGoto={(key) => { setReviewOpen(false); setTimeout(() => document.getElementById('sec-' + key)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }}
          onClose={() => setReviewOpen(false)}
          onReviewed={(overall) => patch((a) => ({ ...a, review: { at: Date.now(), overall } }))}
          profile={profile as unknown as Record<string, any>}
          guidanceText={app.guidanceText || (app.guidance ? guidanceText(app.guidance) : '')}
          templateSpec={app.tpl ? app.tpl.sections.map((x, i) => `${i + 1}. ${x.title}${x.wordLimit ? ` (limit ${x.wordLimit} words)` : ''}${x.guidance ? `: ${x.guidance}` : ''}`).join('\n') : `No funder template imported. Default sections:\n${secs.map(([, t], i) => `${i + 1}. ${t}`).join('\n')}`}
          renderText={(t) => <RenderBlocks text={t} />}
          onApplyText={(key, mode, text) => {
            snapshotDoc('Before applying a review suggestion')
            setDoc((d) => ({ ...d, [key]: mode === 'replace' ? tidy(text) : d[key]?.trim() ? `${d[key].trim()}\n\n${tidy(text)}` : tidy(text) }))
            setMsg('Applied a review suggestion.')
          }}
        />
      )}
      {historyOpen && app && (
        <HistoryModal
          entries={app.history ?? []}
          current={app.doc}
          titles={Object.fromEntries(secs.map(([k, t]) => [k, t]))}
          onRestore={restoreVersion}
          onSnapshot={() => snapshotDoc('Saved by you')}
          onClose={() => setHistoryOpen(false)}
        />
      )}
      {detailGrant && (
        <DetailsPanel
          g={detailGrant}
          detail={detailsCache[detailGrant.id] ?? null}
          loading={detailBusy}
          error={detailErr}
          saved={isSaved(detailGrant.id)}
          hasApp={apps.some((a) => a.grant?.id === detailGrant.id)}
          invite={isInvite(detailGrant)}
          onClose={() => setDetailGrant(null)}
          onRefresh={() => loadDetails(detailGrant)}
          onSave={() => toggleSave(detailGrant)}
          onApply={() => { const g = detailGrant; setDetailGrant(null); startApplication(g) }}
        />
      )}
    </div>
  )
}
