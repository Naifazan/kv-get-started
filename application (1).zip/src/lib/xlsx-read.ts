import { unzipSync, zipSync, strFromU8 } from 'fflate'

export type Sheet = { name: string; rows: string[][] }

const decode = (s: string) =>
  s
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&')

const attr = (tag: string, name: string) => {
  const m = tag.match(new RegExp(`\\b${name}="([^"]*)"`))
  return m ? decode(m[1]) : ''
}

const textOf = (xml: string) => {
  const clean = xml.replace(/<rPh\b[\s\S]*?<\/rPh>/g, '')
  const parts: string[] = []
  const re = /<t\b[^>]*>([\s\S]*?)<\/t>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(clean))) parts.push(decode(m[1]))
  return parts.join('')
}

const colIndex = (ref: string) => {
  const letters = (ref.match(/^[A-Z]+/i) ?? [''])[0].toUpperCase()
  let n = 0
  for (const ch of letters) n = n * 26 + (ch.charCodeAt(0) - 64)
  return Math.max(0, n - 1)
}

/** Reads every sheet of an .xlsx file as rows of text, without any spreadsheet library. */
export function readXlsx(buf: ArrayBuffer): Sheet[] {
  const files = unzipSync(new Uint8Array(buf))
  const get = (path: string) => (files[path] ? strFromU8(files[path]) : '')
  const shared: string[] = []
  const sst = get('xl/sharedStrings.xml')
  if (sst) {
    const re = /<si\b[^>]*>([\s\S]*?)<\/si>/g
    let m: RegExpExecArray | null
    while ((m = re.exec(sst))) shared.push(textOf(m[1]))
  }
  const wb = get('xl/workbook.xml')
  const rels = get('xl/_rels/workbook.xml.rels')
  const target = new Map<string, string>()
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    const t = attr(m[0], 'Target')
    target.set(attr(m[0], 'Id'), t.startsWith('/') ? t.slice(1) : 'xl/' + t.replace(/^\.\//, ''))
  }
  const sheets: { name: string; path: string }[] = []
  for (const m of wb.matchAll(/<sheet\b[^>]*>/g)) {
    const path = target.get(attr(m[0], 'r:id'))
    if (path) sheets.push({ name: attr(m[0], 'name'), path })
  }
  if (!sheets.length) {
    Object.keys(files).filter((f) => /^xl\/worksheets\/sheet\d+\.xml$/.test(f)).sort().forEach((p, i) => sheets.push({ name: `Sheet ${i + 1}`, path: p }))
  }
  const out: Sheet[] = []
  for (const sh of sheets) {
    const xml = get(sh.path)
    if (!xml) continue
    const rows: string[][] = []
    for (const rm of xml.matchAll(/<row\b[^>]*?(?:\/>|>([\s\S]*?)<\/row>)/g)) {
      const body = rm[1] ?? ''
      const row: string[] = []
      for (const cm of body.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
        const tag = cm[1]
        const inner = cm[2] ?? ''
        const type = attr(tag, 't')
        const idx = colIndex(attr(tag, 'r'))
        const v = (inner.match(/<v\b[^>]*>([\s\S]*?)<\/v>/) ?? [])[1]
        let text = ''
        if (type === 's') text = shared[Number(v)] ?? ''
        else if (type === 'inlineStr') text = textOf(inner)
        else if (type === 'b') text = v === '1' ? 'TRUE' : 'FALSE'
        else if (v !== undefined) text = decode(v)
        text = text.trim()
        if (text) { while (row.length < idx) row.push(''); row[idx] = text }
      }
      if (row.some((x) => x)) rows.push(row.map((x) => x ?? ''))
    }
    out.push({ name: sh.name, rows })
  }
  return out
}

// ---------- Describe and fill an existing workbook, keeping every sheet, style and layout ----------

export type CellInfo = { ref: string; text: string; formula: string; blank: boolean }
export type SheetInfo = { name: string; path: string; cells: CellInfo[]; merges: string[] }

const sheetList = (files: Record<string, Uint8Array>) => {
  const get = (path: string) => (files[path] ? strFromU8(files[path]) : '')
  const wb = get('xl/workbook.xml')
  const rels = get('xl/_rels/workbook.xml.rels')
  const target = new Map<string, string>()
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    const t = attr(m[0], 'Target')
    target.set(attr(m[0], 'Id'), t.startsWith('/') ? t.slice(1) : 'xl/' + t.replace(/^\.\//, ''))
  }
  const sheets: { name: string; path: string }[] = []
  for (const m of wb.matchAll(/<sheet\b[^>]*>/g)) {
    const path = target.get(attr(m[0], 'r:id'))
    if (path) sheets.push({ name: attr(m[0], 'name'), path })
  }
  return sheets
}

const sharedStrings = (files: Record<string, Uint8Array>) => {
  const shared: string[] = []
  const sst = files['xl/sharedStrings.xml'] ? strFromU8(files['xl/sharedStrings.xml']) : ''
  const re = /<si\b[^>]*>([\s\S]*?)<\/si>/g
  let m: RegExpExecArray | null
  while ((m = re.exec(sst))) shared.push(textOf(m[1]))
  return shared
}

export const cellRef = (col: number, row: number) => {
  let n = col + 1
  let s = ''
  while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26) }
  return s + row
}

/** Lists each sheet's cells: text, formulas, and styled blank cells (the likely input cells). */
export function describeXlsx(buf: ArrayBuffer): SheetInfo[] {
  const files = unzipSync(new Uint8Array(buf))
  const shared = sharedStrings(files)
  const out: SheetInfo[] = []
  for (const sh of sheetList(files)) {
    const xml = files[sh.path] ? strFromU8(files[sh.path]) : ''
    const cells: CellInfo[] = []
    for (const cm of xml.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const tag = cm[1]
      const inner = cm[2] ?? ''
      const ref = attr(tag, 'r')
      const type = attr(tag, 't')
      const v = (inner.match(/<v\b[^>]*>([\s\S]*?)<\/v>/) ?? [])[1]
      const f = (inner.match(/<f\b[^>]*>([\s\S]*?)<\/f>/) ?? [])[1]
      const hasShared = /<f\b[^>]*t="shared"[^>]*\/>/.test(inner)
      let text = ''
      if (type === 's') text = shared[Number(v)] ?? ''
      else if (type === 'inlineStr') text = textOf(inner)
      else if (type === 'b') text = v === '1' ? 'TRUE' : 'FALSE'
      else if (v !== undefined) text = decode(v)
      cells.push({ ref, text: text.trim(), formula: f ? decode(f) : hasShared ? '(shared formula)' : '', blank: !text.trim() && !f && !hasShared })
    }
    const merges = [...xml.matchAll(/<mergeCell\b[^>]*>/g)].map((m) => attr(m[0], 'ref'))
    out.push({ name: sh.name, path: sh.path, cells, merges })
  }
  return out
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
const refParts = (ref: string) => {
  const m = ref.match(/^([A-Z]+)(\d+)$/i)
  return m ? { col: colIndex(m[1]), row: Number(m[2]) } : null
}
const inMergeNotTopLeft = (ref: string, merges: string[]) => {
  const p = refParts(ref)
  if (!p) return false
  for (const mg of merges) {
    const [a, b] = mg.split(':')
    const pa = refParts(a), pb = pb_(b)
    if (pa && pb && p.col >= pa.col && p.col <= pb.col && p.row >= pa.row && p.row <= pb.row) return !(p.col === pa.col && p.row === pa.row)
  }
  return false
}
const pb_ = (b: string | undefined) => (b ? refParts(b) : null)

export type Fill = { sheet: string; cell: string; value: string | number }

/** Writes values into an .xlsx file and returns the new file. Everything else in the workbook stays as it was. */
export function fillXlsx(buf: ArrayBuffer, fills: Fill[], overwrite?: (sheet: string, formula: string) => boolean): { bytes: Uint8Array; written: number } {
  const files = unzipSync(new Uint8Array(buf))
  const sheets = sheetList(files)
  let written = 0
  for (const sh of sheets) {
    const mine = fills.filter((f) => f.sheet === sh.name)
    if (!mine.length || !files[sh.path]) continue
    let xml = strFromU8(files[sh.path])
    const merges = [...xml.matchAll(/<mergeCell\b[^>]*>/g)].map((m) => attr(m[0], 'ref'))
    for (const fl of mine) {
      const ref = fl.cell.toUpperCase()
      const rp = refParts(ref)
      if (!rp || inMergeNotTopLeft(ref, merges)) continue
      const isNum = typeof fl.value === 'number' && Number.isFinite(fl.value)
      const build = (style: string) =>
        `<c r="${ref}"${style ? ` s="${style}"` : ''}${isNum ? '' : ' t="inlineStr"'}>${isNum ? `<v>${fl.value}</v>` : `<is><t xml:space="preserve">${esc(String(fl.value))}</t></is>`}</c>`
      // 1. the cell already exists
      const cellRe = new RegExp(`<c\\b[^>]*\\br="${ref}"[^>]*?(?:/>|>[\\s\\S]*?</c>)`)
      const cm = xml.match(cellRe)
      if (cm) {
        if (/<f\b/.test(cm[0])) {
          const ft = decode((cm[0].match(/<f\b[^>]*>([\s\S]*?)<\/f>/) ?? [])[1] ?? '')
          if (!overwrite || !overwrite(sh.name, ft)) continue // formulas are kept unless the caller says this one must become a fixed value
        }
        const style = attr(cm[0].slice(0, cm[0].indexOf('>') + 1), 's')
        xml = xml.replace(cellRe, () => build(style))
        written++
        continue
      }
      // 2. the row exists: add the cell in column order
      const rowRe = new RegExp(`<row\\b[^>]*\\br="${rp.row}"[^>]*?(?:/>|>[\\s\\S]*?</row>)`)
      const rm = xml.match(rowRe)
      if (rm) {
        let rowXml = rm[0]
        if (rowXml.endsWith('/>')) rowXml = rowXml.replace(/\/>$/, '></row>')
        rowXml = rowXml.replace(/\sspans="[^"]*"/, '')
        let inserted = false
        for (const c of rowXml.matchAll(/<c\b[^>]*\br="([A-Z]+)\d+"/g)) {
          if (colIndex(c[1]) > rp.col) {
            rowXml = rowXml.replace(c[0], () => build('') + c[0])
            inserted = true
            break
          }
        }
        if (!inserted) rowXml = rowXml.replace(/<\/row>$/, () => build('') + '</row>')
        xml = xml.replace(rowRe, () => rowXml)
        written++
        continue
      }
      // 3. the row is missing: add it in row order
      const newRow = `<row r="${rp.row}">${build('')}</row>`
      let placed = false
      for (const r of xml.matchAll(/<row\b[^>]*\br="(\d+)"/g)) {
        if (Number(r[1]) > rp.row) { xml = xml.replace(r[0], () => newRow + r[0]); placed = true; break }
      }
      if (!placed) xml = xml.replace(/<\/sheetData>/, () => newRow + '</sheetData>')
      written++
    }
    files[sh.path] = new TextEncoder().encode(xml)
  }
  // Ask Excel to recalculate every formula when the file opens.
  if (files['xl/workbook.xml']) {
    let wb = strFromU8(files['xl/workbook.xml'])
    if (/<calcPr\b/.test(wb)) wb = wb.replace(/<calcPr\b([^>]*?)(\/?)>/, (_m, a, s) => `<calcPr${a.replace(/\sfullCalcOnLoad="[^"]*"/, '')} fullCalcOnLoad="1"${s}>`)
    else if (/<\/definedNames>/.test(wb)) wb = wb.replace(/<\/definedNames>/, '</definedNames><calcPr fullCalcOnLoad="1"/>')
    else wb = wb.replace(/<\/sheets>/, '</sheets><calcPr fullCalcOnLoad="1"/>')
    files['xl/workbook.xml'] = new TextEncoder().encode(wb)
  }
  delete files['xl/calcChain.xml']
  if (files['[Content_Types].xml']) files['[Content_Types].xml'] = new TextEncoder().encode(strFromU8(files['[Content_Types].xml']).replace(/<Override\b[^>]*calcChain[^>]*\/>/, ''))
  if (files['xl/_rels/workbook.xml.rels']) files['xl/_rels/workbook.xml.rels'] = new TextEncoder().encode(strFromU8(files['xl/_rels/workbook.xml.rels']).replace(/<Relationship\b[^>]*calcChain[^>]*\/>/, ''))
  return { bytes: zipSync(files, { level: 6 }), written }
}

/** Adds a new sheet of plain values to an .xlsx file. Every existing sheet, style and formula is left as it was. */
export function appendSheet(buf: ArrayBuffer, wanted: string, rows: (string | number)[][]): { bytes: Uint8Array; name: string } {
  const files = unzipSync(new Uint8Array(buf))
  const wbPath = 'xl/workbook.xml'
  const relsPath = 'xl/_rels/workbook.xml.rels'
  let wb = strFromU8(files[wbPath])
  let rels = strFromU8(files[relsPath])
  const taken = new Set([...wb.matchAll(/<sheet\b[^>]*>/g)].map((m) => attr(m[0], 'name').toLowerCase()))
  let name = wanted.replace(/[\[\]:*?/\\]/g, ' ').trim().slice(0, 31) || 'Prepared budget'
  for (let i = 2; taken.has(name.toLowerCase()); i++) name = `${wanted.slice(0, 27)} ${i}`
  const sheetId = Math.max(0, ...[...wb.matchAll(/<sheet\b[^>]*>/g)].map((m) => Number(attr(m[0], 'sheetId')) || 0)) + 1
  let n = 1
  while (files[`xl/worksheets/sheet${n}.xml`]) n++
  const ids = new Set([...rels.matchAll(/<Relationship\b[^>]*>/g)].map((m) => attr(m[0], 'Id')))
  let k = 1
  while (ids.has('rId' + k)) k++
  const rid = 'rId' + k
  const colName = (i: number) => cellRef(i, 1).replace(/\d+/g, '')
  const body = rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => {
    if (v === '' || v === null || v === undefined) return ''
    const ref = colName(ci) + (ri + 1)
    return typeof v === 'number' && Number.isFinite(v) ? `<c r="${ref}"><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${esc(String(v))}</t></is></c>`
  }).join('')}</row>`).join('')
  const widths = rows[0]?.map((_, i) => `<col min="${i + 1}" max="${i + 1}" width="${i === 0 ? 34 : i === 1 ? 30 : 18}" customWidth="1"/>`).join('') ?? ''
  files[`xl/worksheets/sheet${n}.xml`] = new TextEncoder().encode(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>${widths}</cols><sheetData>${body}</sheetData></worksheet>`)
  wb = wb.replace('</sheets>', `<sheet name="${esc(name)}" sheetId="${sheetId}" r:id="${rid}"/></sheets>`)
  rels = rels.replace('</Relationships>', `<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${n}.xml"/></Relationships>`)
  files[wbPath] = new TextEncoder().encode(wb)
  files[relsPath] = new TextEncoder().encode(rels)
  if (files['[Content_Types].xml']) {
    files['[Content_Types].xml'] = new TextEncoder().encode(strFromU8(files['[Content_Types].xml']).replace('</Types>', `<Override PartName="/xl/worksheets/sheet${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>`))
  }
  return { bytes: zipSync(files, { level: 6 }), name }
}

/** Picks the main (face) budget sheet: a summary or overview sheet if there is one, otherwise the sheet that holds the most budget inputs. */
export function pickMainSheet(sheets: SheetInfo[]): string {
  if (sheets.length <= 1) return sheets[0]?.name ?? ''
  let best = sheets[0].name
  let bestScore = -Infinity
  sheets.forEach((sh, idx) => {
    const inputs = sh.cells.filter((c) => c.blank).length
    const formulas = sh.cells.filter((c) => c.formula).length
    const linked = sh.cells.filter((c) => c.formula.includes('!')).length
    const text = sh.cells.filter((c) => c.text).length
    let score = Math.min(inputs, 150) * 0.5 + Math.min(formulas, 80) * 0.4 + Math.min(linked, 40) * 2 + Math.min(text, 80) * 0.15
    if (/summary|overview|cover|face|front|main|overall|total|recap|synthes|consolidat/i.test(sh.name)) score += 70
    if (/budget|cost|financ|expens/i.test(sh.name)) score += 25
    if (/personal|personnel|staff|travel|equipment|consumable|subcontract|annex|detail|work ?package|partner|other cost/i.test(sh.name)) score -= 18
    if (/instruction|guid|note|read ?me|help|list|lookup|data|validation|rate|definition|about|checklist|declar|history|version/i.test(sh.name)) score -= 70
    if (!inputs && !formulas) score -= 40
    if (idx === 0) score += 6
    if (score > bestScore) { bestScore = score; best = sh.name }
  })
  return best
}

/** Keeps only one sheet in an .xlsx file, with its formatting. Formulas that pulled from removed sheets become fixed values. */
export function keepOnlySheet(bytes: Uint8Array, keep: string): { bytes: Uint8Array; converted: number; removed: string[] } {
  const files = unzipSync(bytes)
  const sheets = sheetList(files)
  const main = sheets.find((s) => s.name === keep)
  if (!main || sheets.length <= 1) return { bytes, converted: 0, removed: [] }
  const removed = sheets.filter((s) => s !== main)
  const removedNames = removed.map((s) => s.name)
  const enc = (t: string) => new TextEncoder().encode(t)
  // 1. workbook.xml: drop the other sheets and anything that points at them
  let wb = strFromU8(files['xl/workbook.xml'])
  const rmIds = new Set<string>()
  const rels0 = strFromU8(files['xl/_rels/workbook.xml.rels'])
  const relOf = new Map<string, string>()
  for (const m of rels0.matchAll(/<Relationship\b[^>]*>/g)) relOf.set(attr(m[0], 'Id'), attr(m[0], 'Target'))
  for (const m of [...wb.matchAll(/<sheet\b[^>]*>/g)]) {
    if (attr(m[0], 'name') !== keep) { rmIds.add(attr(m[0], 'r:id')); wb = wb.replace(m[0], '') }
  }
  const refsRemoved = (t: string) => removedNames.some((n) => t.includes(`'${n}'!`) || t.includes(`${n}!`))
  wb = wb.replace(/<definedName\b[^>]*>[\s\S]*?<\/definedName>/g, (d) => (/localSheetId="/.test(d) || refsRemoved(d) ? '' : d))
  wb = wb.replace(/<definedNames>\s*<\/definedNames>/, '')
  wb = wb.replace(/\sactiveTab="\d+"/, ' activeTab="0"').replace(/\sfirstSheet="\d+"/, ' firstSheet="0"')
  files['xl/workbook.xml'] = enc(wb)
  // 2. relationships and content types
  let rels = rels0
  for (const id of rmIds) rels = rels.replace(new RegExp(`<Relationship\\b[^>]*\\bId="${id}"[^>]*/>`), '')
  files['xl/_rels/workbook.xml.rels'] = enc(rels)
  let ct = strFromU8(files['[Content_Types].xml'])
  for (const r of removed) {
    delete files[r.path]
    const relFile = r.path.replace('worksheets/', 'worksheets/_rels/') + '.rels'
    delete files[relFile]
    ct = ct.replace(new RegExp(`<Override\\b[^>]*PartName="/${r.path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"[^>]*/>`), '')
  }
  files['[Content_Types].xml'] = enc(ct)
  // 3. the kept sheet: fix cross-sheet formulas, validations and conditional formats
  let xml = strFromU8(files[main.path])
  let converted = 0
  xml = xml.replace(/<f\b[^>]*>([\s\S]*?)<\/f>/g, (m, f) => { if (refsRemoved(decode(f))) { converted++; return '' } return m })
  xml = xml.replace(/<dataValidation\b[\s\S]*?<\/dataValidation>/g, (d) => (/!/.test(d) ? '' : d))
  xml = xml.replace(/<dataValidations\b[^>]*>\s*<\/dataValidations>/, '')
  xml = xml.replace(/<conditionalFormatting\b[\s\S]*?<\/conditionalFormatting>/g, (d) => (/!/.test(d) ? '' : d))
  files[main.path] = enc(xml)
  // 4. the app properties still list the old sheets, which Excel does not need
  delete files['docProps/app.xml']
  if (files['_rels/.rels']) files['_rels/.rels'] = enc(strFromU8(files['_rels/.rels']).replace(/<Relationship\b[^>]*extended-properties[^>]*\/>/, ''))
  files['[Content_Types].xml'] = enc(strFromU8(files['[Content_Types].xml']).replace(/<Override\b[^>]*PartName="\/docProps\/app.xml"[^>]*\/>/, ''))
  return { bytes: zipSync(files, { level: 6 }), converted, removed: removedNames }
}
