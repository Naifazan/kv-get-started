// Project documents the AI can prepare from a written proposal.
export type DocKind = 'meal' | 'tool' | 'logframe' | 'implementation' | 'matrix' | 'report'

export const MEAL_TOOLS: { id: string; label: string }[] = [
  { id: 'household-survey', label: 'Household survey questionnaire' },
  { id: 'baseline-endline', label: 'Baseline and endline survey' },
  { id: 'kii-guide', label: 'Key informant interview guide' },
  { id: 'fgd-guide', label: 'Focus group discussion guide' },
  { id: 'pre-post-test', label: 'Pre-test and post-test (knowledge)' },
  { id: 'attendance', label: 'Activity attendance and registration sheet' },
  { id: 'observation', label: 'Observation checklist' },
  { id: 'feedback', label: 'Beneficiary feedback and complaints form' },
  { id: 'satisfaction', label: 'Participant satisfaction survey' },
  { id: 'indicator-tracker', label: 'Indicator tracking table' },
  { id: 'most-significant-change', label: 'Most significant change story guide' },
]

export const REPORT_TEMPLATES: { id: string; label: string }[] = [
  { id: 'monthly', label: 'Monthly progress report' },
  { id: 'quarterly', label: 'Quarterly narrative report' },
  { id: 'interim', label: 'Interim narrative report' },
  { id: 'final', label: 'Final narrative report' },
  { id: 'financial', label: 'Financial report' },
  { id: 'activity', label: 'Activity report' },
  { id: 'case-study', label: 'Success story and case study' },
  { id: 'lessons', label: 'Lessons learned report' },
  { id: 'donor-update', label: 'Short donor update' },
]
