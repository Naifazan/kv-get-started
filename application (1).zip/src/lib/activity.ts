import { useSyncExternalStore } from 'react'

// Tracks whether the portal is waiting on the server, so a small "working" note can show on every page.
type S = { n: number; since: number; label: string }
let state: S = { n: 0, since: 0, label: '' }
const subs = new Set<() => void>()
const emit = () => subs.forEach((f) => f())
const set = (p: Partial<S>) => { state = { ...state, ...p }; emit() }

export function setActivityLabel(label: string) { set({ label }) }
export function useActivity(): S {
  return useSyncExternalStore((f) => { subs.add(f); return () => { subs.delete(f) } }, () => state, () => state)
}

let patched = false
export function trackRequests() {
  if (patched || typeof window === 'undefined') return
  patched = true
  const orig = window.fetch.bind(window)
  window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url
    if (!url.includes('/_serverFn') && !url.includes('/api/write-stream')) return orig(input, init)
    set({ n: state.n + 1, since: state.n === 0 ? Date.now() : state.since })
    try {
      return await orig(input, init)
    } finally {
      set({ n: Math.max(0, state.n - 1), label: state.n <= 1 ? '' : state.label })
    }
  }
}
