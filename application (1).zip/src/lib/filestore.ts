// Keeps imported files in this browser (IndexedDB). Only the record is synced online, never the file itself.
const DB = 'ngw_files'
const STORE = 'files'

function open(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') { reject(new Error('no-idb')); return }
    const req = indexedDB.open(DB, 1)
    req.onupgradeneeded = () => req.result.createObjectStore(STORE)
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export async function putFile(id: string, blob: Blob): Promise<boolean> {
  try {
    const db = await open()
    return await new Promise((resolve) => {
      const tx = db.transaction(STORE, 'readwrite')
      tx.objectStore(STORE).put(blob, id)
      tx.oncomplete = () => resolve(true)
      tx.onerror = () => resolve(false)
      tx.onabort = () => resolve(false)
    })
  } catch { return false }
}

export async function getFile(id: string): Promise<Blob | null> {
  try {
    const db = await open()
    return await new Promise((resolve) => {
      const r = db.transaction(STORE).objectStore(STORE).get(id)
      r.onsuccess = () => resolve((r.result as Blob) ?? null)
      r.onerror = () => resolve(null)
    })
  } catch { return null }
}

export async function delFile(id: string): Promise<void> {
  try {
    const db = await open()
    await new Promise<void>((resolve) => {
      const tx = db.transaction(STORE, 'readwrite')
      tx.objectStore(STORE).delete(id)
      tx.oncomplete = () => resolve()
      tx.onerror = () => resolve()
    })
  } catch {}
}
