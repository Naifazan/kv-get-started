// The places the portal searches for grants. Shared by the server (what to search) and the page (the Sources lists).
export type Src = 'us' | 'eu' | 'directory' | 'mena' | 'un' | 'fundsforngos' | 'opportunitydesk' | 'irs'

export const SOURCE_OPTIONS: [Src, string][] = [
  ['us', 'US federal (Grants.gov)'],
  ['eu', 'European Union'],
  ['directory', 'Global funders directory'],
  ['mena', 'Middle East and Arab donors'],
  ['un', 'UN and multilateral funds'],
  ['fundsforngos', 'fundsforNGOs listings (live)'],
  ['opportunitydesk', 'Opportunity Desk calls (live)'],
  ['irs', 'US private foundations (IRS records)'],
]

// What a search uses when no source is picked. The IRS foundation records are opt-in: they cover US private foundations,
// and many of them only fund US organizations, so they are searched only when the person picks them.
export const ALL_SOURCES: Src[] = SOURCE_OPTIONS.map(([k]) => k).filter((k) => k !== 'irs')
