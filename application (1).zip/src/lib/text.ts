import type { GrantGuidance } from '../server/grants'
import { type SortState } from './types'

// Which lines of the new text are new, and which old lines are gone.
export function lineDiff(oldT: string, newT: string) {
  const oldLines = oldT.split('\n').map((l) => l.trim()).filter(Boolean)
  const newLines = newT.split('\n').map((l) => l.trim()).filter(Boolean)
  const oldSet = new Set(oldLines)
  const newSet = new Set(newLines)
  return { lines: newLines.map((t) => ({ t, add: !oldSet.has(t) })), removed: oldLines.filter((l) => !newSet.has(l)) }
}


export type Block = { type: 'text'; text: string } | { type: 'table'; rows: string[][] }


export function parseBlocks(src: string): Block[] {
  const lines = src.replace(/\r/g, '').split('\n')
  const out: Block[] = []
  let buf: string[] = []
  const flush = () => {
    const t = buf.join('\n').trim()
    if (t) out.push({ type: 'text', text: t })
    buf = []
  }
  for (let i = 0; i < lines.length; ) {
    if (/^\s*\|.*\|\s*$/.test(lines[i])) {
      const rows: string[][] = []
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) {
        const cells = lines[i].trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim())
        if (!cells.every((c) => /^:?-{2,}:?$/.test(c) || c === '')) rows.push(cells)
        else if (cells.every((c) => c === '')) rows.push(cells)
        i++
      }
      flush()
      for (let r = rows.length - 1; r > 0; r--) {
        const key = rows[r].join('|').toLowerCase()
        if (key === rows[0].join('|').toLowerCase() || rows.slice(0, r).some((x) => x.join('|').toLowerCase() === key && key.replace(/\|/g, '').trim())) rows.splice(r, 1)
      }
      if (rows.length) {
        const w = Math.max(...rows.map((r) => r.length))
        out.push({ type: 'table', rows: rows.map((r) => [...r, ...Array(w - r.length).fill('')]) })
      }
    } else buf.push(lines[i++])
  }
  flush()
  return out
}


export const clean = (t: string) => t.replace(/\*\*(.+?)\*\*/g, '$1').replace(/^#+\s*/gm, '')

// Cleans generated or typed proposal text: no asterisks, short placeholders.
export const tidy = (t: string) =>
  t
    .replace(/\[\s*(?:percentage|percent|pct|x{1,3})\s*%\s*\]/gi, '[%]')
    .replace(/\[\s*percentage\s*\]/gi, '[%]')
    .replace(/\[\s*x{1,3}(?:[,.\s]x{3})+\s*\]/gi, '[XXX]')
    .replace(/\[\s*x{1,2},?x{3}\s*\]/gi, '[XXX]')
    .replace(/^(\s*)\*\s+/gm, '$1- ')
    .replace(/\*/g, '')


export type DocLine = { sub: boolean; text: string }

// Splits plain text into subtitles and paragraphs. A subtitle is a "## " line, or a short line with no end punctuation that sits above a paragraph.
export function docLines(t: string): DocLine[] {
  const lines = tidy(t).replace(/\r/g, '').split('\n')
  const out: DocLine[] = []
  lines.forEach((l, i) => {
    const raw = l.trim()
    if (!raw) return
    const hash = /^#{1,4}\s+/.test(raw)
    const text = raw.replace(/^#{1,4}\s+/, '')
    let sub = hash
    if (!sub && text.length <= 70 && text.split(/\s+/).length <= 9 && !/[.,;:!?)\]]$/.test(text) && !/^[-•|\d]/.test(text) && (i === 0 || !lines[i - 1].trim())) {
      const next = lines.slice(i + 1).find((x) => x.trim())
      sub = !!next && !/^\s*[-•|]/.test(next) && next.trim().length > text.length
    }
    out.push({ sub, text })
  })
  return out
}


// Plain-text version of a section: subtitles on their own line, tables as simple rows.
export function sectionPlain(text: string): string {
  const parts: string[] = []
  for (const b of parseBlocks(tidy(text))) {
    if (b.type === 'table') parts.push(b.rows.map((r) => r.join(' | ')).join('\n'))
    else parts.push(docLines(b.text).map((l) => (l.sub ? `\n${l.text}` : l.text)).join('\n').trim())
  }
  return parts.join('\n\n').trim()
}


export const escHtml = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')

export const num = (t: string) => {
  const m = t.replace(/[,\s$]/g, '').match(/^-?\d+(\.\d+)?$/)
  return m ? Number(m[0]) : null
}


export function budgetCheck(blocks: Block[], requested: string) {
  for (const b of blocks) {
    if (b.type !== 'table') continue
    const head = b.rows[0].map((c) => c.toLowerCase())
    const tot = head.findIndex((c) => /total/.test(c))
    const qty = head.findIndex((c) => /^qty|quantity/.test(c))
    const uc = head.findIndex((c) => /unit cost/.test(c))
    if (tot < 0) continue
    const body = b.rows.slice(1)
    const isSum = (r: string[]) => /\b(sub)?total\b|direct costs|indirect/i.test(r.join(' '))
    const items = body.filter((r) => !isSum(r))
    const grand = body.find((r) => /\btotal\b/i.test(r.join(' ')) && !/sub/i.test(r.join(' ')))
    if (!grand) return null
    const vals = items.map((r) => num(r[tot] ?? ''))
    if (vals.some((x) => x === null)) return null
    const issues: string[] = []
    if (qty >= 0 && uc >= 0) {
      items.forEach((r, i) => {
        const q = num(r[qty] ?? '')
        const u = num(r[uc] ?? '')
        if (q !== null && u !== null && Math.abs(q * u - (vals[i] as number)) > 0.5) issues.push(`Line "${clean(r[2] ?? r[1] ?? '')}": ${q} x ${u} is not ${vals[i]}.`)
      })
    }
    const extras = body.filter((r) => isSum(r) && /indirect/i.test(r.join(' '))).map((r) => num(r[tot] ?? '') ?? 0)
    const sum = (vals as number[]).reduce((a, x) => a + x, 0) + extras.reduce((a, x) => a + x, 0)
    const total = num(grand[tot] ?? '')
    const asked = Number(requested.replace(/[^0-9.]/g, '')) || null
    if (total !== null && Math.abs(sum - total) > 0.5) issues.push(`Line items add up to ${sum.toLocaleString('en-US')} but the Total row says ${total.toLocaleString('en-US')}.`)
    if (asked && total !== null && Math.abs(asked - total) > 0.5) issues.push(`The Total (${total.toLocaleString('en-US')}) differs from the amount requested (${asked.toLocaleString('en-US')}).`)
    return issues
  }
  return null
}


export function ganttFrom(text: string, months: number) {
  for (const b of parseBlocks(text)) {
    if (b.type !== 'table') continue
    const h = b.rows[0].map((c) => c.toLowerCase())
    const si = h.findIndex((c) => /start/.test(c))
    const ei = h.findIndex((c) => /end/.test(c))
    const ai = h.findIndex((c) => /activity/.test(c))
    if (si < 0 || ei < 0 || ai < 0) continue
    const rows = b.rows.slice(1).map((r) => ({ name: clean(r[ai] ?? ''), s: num(r[si] ?? ''), e: num(r[ei] ?? '') })).filter((r) => r.s !== null && r.e !== null)
    if (!rows.length) return null
    const max = Math.max(months, ...rows.map((r) => r.e as number))
    return { rows: rows as { name: string; s: number; e: number }[], max: Math.min(max, 60) }
  }
  return null
}


export const guidanceText = (g: GrantGuidance) =>
  [['Summary', g.summary ? [g.summary] : []], ['Priorities', g.priorities], ['Eligibility', g.eligibility], ['Assessment criteria', g.criteria], ['Budget rules', g.budget], ['Format rules', g.format], ['Key dates', g.dates]]
    .filter(([, v]) => (v as string[]).length)
    .map(([k, v]) => `${k}: ${(v as string[]).join('; ')}`)
    .join('\n')
    .slice(0, 1800)


/** 20/10/2026 */
export const fmtDate = (t: number) => { const d = new Date(t); return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` }


export const toB64 = (u8: Uint8Array) => {
  let s = ''
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000))
  return btoa(s)
}

export const fromB64 = (b: string) => Uint8Array.from(atob(b), (c) => c.charCodeAt(0))

export const cmpVal = (a: number | string, b: number | string) => (a < b ? -1 : a > b ? 1 : 0)

// Sorts a list by a column. Rows with no value in that column (no deadline, no amount) always go last, whichever way you sort.
// Text sorts the way people read it (Grant 2 before Grant 10, accents ignored) and equal rows keep their order.
export function sortList<T>(list: T[], val: (x: T) => number | string | null | undefined, dir: 1 | -1): T[] {
  const empty = (v: unknown) => v === null || v === undefined || v === '' || (typeof v === 'number' && !Number.isFinite(v))
  return list
    .map((x, i) => ({ x, i, v: val(x) }))
    .sort((a, b) => {
      const ae = empty(a.v), be = empty(b.v)
      if (ae && be) return a.i - b.i
      if (ae) return 1
      if (be) return -1
      const c = typeof a.v === 'string' && typeof b.v === 'string' ? a.v.localeCompare(b.v, 'en', { numeric: true, sensitivity: 'base' }) : (a.v as number) < (b.v as number) ? -1 : (a.v as number) > (b.v as number) ? 1 : 0
      return c * dir || a.i - b.i
    })
    .map((w) => w.x)
}

export const toggleSort = (cur: SortState, k: string): SortState => (cur?.k === k ? { k, dir: (cur.dir * -1) as 1 | -1 } : { k, dir: 1 })
