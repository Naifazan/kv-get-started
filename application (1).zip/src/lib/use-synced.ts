import { useCallback, useEffect, useRef, useState } from 'react'
import { loadUserBlob, saveUserBlob } from '../server/saved'

/** Like useState, but kept in this browser and, when signed in, in your online account. The newer copy wins. */
export function useSynced<T extends Record<string, any>>(key: string, initial: T, signedIn: boolean) {
  const [v, setV] = useState<T>(initial)
  const [ready, setReady] = useState(false)
  const tRef = useRef(0)
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null)
  const latest = useRef<T>(initial)
  const inRef = useRef(signedIn)
  inRef.current = signedIn
  const lsKey = 'ngw_' + key

  useEffect(() => {
    try {
      const raw = localStorage.getItem(lsKey)
      if (raw) {
        const j = JSON.parse(raw)
        if (j && typeof j === 'object' && j.__t) { setV(j.d as T); latest.current = j.d as T; tRef.current = j.__t }
      }
    } catch {}
    setReady(true)
  }, [lsKey])

  useEffect(() => {
    if (!ready || !signedIn) return
    let off = false
    loadUserBlob({ data: { key } })
      .then((r) => {
        if (off || !r.ok || !r.blob) return
        if (r.blob.t > tRef.current) {
          tRef.current = r.blob.t
          latest.current = r.blob.d as T
          setV(r.blob.d as T)
          try { localStorage.setItem(lsKey, JSON.stringify({ __t: r.blob.t, d: r.blob.d })) } catch {}
        } else if (tRef.current > r.blob.t) {
          saveUserBlob({ data: { key, t: tRef.current, data: latest.current } }).catch(() => {})
        }
      })
      .catch(() => {})
    return () => { off = true }
  }, [ready, signedIn, key, lsKey])

  const set = useCallback((next: T | ((c: T) => T)) => {
    setV((cur) => {
      const n = typeof next === 'function' ? (next as (c: T) => T)(cur) : next
      const t = Date.now()
      tRef.current = t
      latest.current = n
      try { localStorage.setItem(lsKey, JSON.stringify({ __t: t, d: n })) } catch {}
      if (inRef.current) {
        if (timer.current) clearTimeout(timer.current)
        timer.current = setTimeout(() => { saveUserBlob({ data: { key, t, data: latest.current } }).catch(() => {}) }, 2500)
      }
      return n
    })
  }, [key, lsKey])

  return [v, set] as const
}
