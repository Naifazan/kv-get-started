const words = (t: string) => [...new Set(t.toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').split(/\s+/).filter((w) => w.length > 3))]

/** Finds the real section title that a name refers to, or '' if none fits well enough. */
export function matchTitle(titles: string[], value?: string): string {
  const v = (value ?? '').trim().toLowerCase()
  if (!v) return ''
  const exact = titles.find((t) => t.toLowerCase() === v)
  if (exact) return exact
  const inc = titles.find((t) => v.length > 3 && (t.toLowerCase().includes(v) || v.includes(t.toLowerCase())))
  if (inc) return inc
  const vw = words(v)
  if (!vw.length) return ''
  let best = ''
  let bestScore = 0
  for (const t of titles) {
    const tw = words(t)
    if (!tw.length) continue
    const hit = tw.filter((w) => vw.some((x) => x === w || x.startsWith(w.slice(0, 5)) || w.startsWith(x.slice(0, 5)))).length
    const score = hit / Math.max(tw.length, vw.length)
    if (score > bestScore) { bestScore = score; best = t }
  }
  return bestScore >= 0.4 ? best : ''
}
