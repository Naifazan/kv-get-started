import { useEffect, useRef, useState } from 'react'

type Opts = { title?: string; yes?: string; no?: string; danger?: boolean }
type Req = Opts & { message: string; resolve: (v: boolean) => void }

let show: ((r: Req | null) => void) | null = null

// A Yes / No question that opens in the middle of the screen, on every page.
export function askConfirm(message: string, opts: Opts = {}): Promise<boolean> {
  return new Promise((resolve) => {
    if (!show) { resolve(window.confirm(message)); return }
    show({ message, resolve, ...opts })
  })
}

export function ConfirmHost() {
  const [req, setReq] = useState<Req | null>(null)
  const noRef = useRef<HTMLButtonElement>(null)
  useEffect(() => {
    show = setReq
    return () => { show = null }
  }, [])
  const close = (v: boolean) => { req?.resolve(v); setReq(null) }
  useEffect(() => {
    if (!req) return
    noRef.current?.focus()
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); req.resolve(false); setReq(null) } }
    document.addEventListener('keydown', k, true)
    return () => document.removeEventListener('keydown', k, true)
  }, [req])
  if (!req) return null
  const danger = req.danger !== false
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4" onClick={(e) => { if (e.target === e.currentTarget) close(false) }}>
      <div role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-msg" className="w-full max-w-sm rounded-card border border-line bg-paper p-5 shadow-2xl">
        <div className="flex items-start gap-3">
          <span aria-hidden className={`mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-full text-lg font-bold ${danger ? 'bg-red-100 text-red-800' : 'bg-accent/15 text-accent'}`}>{danger ? '!' : '?'}</span>
          <div className="min-w-0">
            <h2 id="confirm-title" className="font-display text-lg font-semibold">{req.title ?? 'Are you sure?'}</h2>
            <p id="confirm-msg" className="mt-1 text-sm text-muted">{req.message}</p>
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-3">
          <button ref={noRef} type="button" className="inline-flex min-h-10 items-center justify-center rounded-full border border-ink/30 px-5 text-sm font-semibold hover:border-ink" onClick={() => close(false)}>{req.no ?? 'No'}</button>
          <button type="button" className={`inline-flex min-h-10 items-center justify-center rounded-full px-5 text-sm font-semibold text-white hover:brightness-110 ${danger ? 'bg-red-700' : 'bg-accent'}`} onClick={() => close(true)}>{req.yes ?? 'Yes'}</button>
        </div>
      </div>
    </div>
  )
}
