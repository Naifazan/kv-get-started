// Plain checks on the written proposal: acronyms, readability and spelling. No AI is needed for these.
export type Sec = { key: string; title: string; text: string }

const KNOWN = new Set(['NGO', 'NGOS', 'USD', 'EU', 'UN', 'US', 'UK', 'USA', 'UAE', 'PDF', 'CV', 'ID', 'AI', 'HIV', 'AIDS', 'COVID', 'SDG', 'SDGS', 'GDP', 'WHO', 'UNICEF', 'FAO', 'UNDP', 'UNHCR', 'ICT', 'SMS', 'GPS', 'OK', 'FAQ', 'IT', 'TV', 'PM', 'AM'])

// Text without table rows and markdown marks, for counting sentences and words.
export const prose = (t: string) => t.split('\n').filter((l) => !/^\s*\|/.test(l)).join('\n').replace(/[*#]/g, '')

export type AcronymItem = { acr: string; section: string; sectionKey: string; count: number; defined: boolean; redefined: boolean }

export function acronymReport(sections: Sec[]): AcronymItem[] {
  const seen = new Map<string, AcronymItem>()
  for (const s of sections) {
    const text = prose(s.text)
    for (const m of text.matchAll(/\b[A-Z][A-Z0-9]{1,5}s?\b/g)) {
      const raw = m[0]
      const acr = raw.replace(/s$/, '')
      if (acr.length < 2 || KNOWN.has(acr) || /^\d/.test(acr) || KNOWN.has(raw)) continue
      const idx = m.index ?? 0
      const after = text.slice(idx + raw.length, idx + raw.length + 140)
      const isDef = (text[idx - 1] === '(' && text[idx + raw.length] === ')') || /^\s*\([^)]{6,}\)/.test(after)
      const prev = seen.get(acr)
      if (!prev) seen.set(acr, { acr, section: s.title, sectionKey: s.key, count: 1, defined: isDef, redefined: false })
      else { prev.count++; if (isDef && prev.defined) prev.redefined = true }
    }
  }
  return [...seen.values()]
}

const stems = ['organi', 'recogni', 'prioriti', 'minimi', 'maximi', 'utili', 'emphasi', 'summari', 'finali', 'realiz', 'standardi', 'mobili', 'capitali', 'initiali', 'digiti', 'formali', 'generali', 'localis', 'specialis', 'sensiti', 'categori', 'harmoni', 'visuali', 'optimi']
const US_FORMS = [new RegExp(`\\b(?:${stems.join('|')})z(?:e|es|ed|ing|ation|ations|er|ers)\\b`, 'gi'), /\banalyze[sd]?\b|\banalyzing\b/gi, /\bcolor(?:s|ed)?\b/gi, /\bbehavior(?:s|al)?\b/gi, /\blabor\b/gi, /\bcenter(?:s|ed)?\b/gi, /\bprogram\b/gi, /\bdefense\b/gi, /\bneighbor(?:s|hood|hoods)?\b/gi, /\bfavor(?:s|ed)?\b/gi, /\bcatalog\b/gi]
const UK_FORMS = [new RegExp(`\\b(?:${stems.join('|')})s(?:e|es|ed|ing|ation|ations|er|ers)\\b`, 'gi'), /\banalyse[sd]?\b|\banalysing\b/gi, /\bcolour(?:s|ed)?\b/gi, /\bbehaviour(?:s|al)?\b/gi, /\blabour\b/gi, /\bcentre(?:s|d)?\b/gi, /\bprogramme(?:s)?\b/gi, /\bdefence\b/gi, /\bneighbour(?:s|hood|hoods)?\b/gi, /\bfavour(?:s|ed)?\b/gi, /\bcatalogue\b/gi]
const count = (t: string, res: RegExp[]) => res.reduce((n, re) => n + (t.match(re)?.length ?? 0), 0)

const FILLER = ['in order to', 'a number of', 'due to the fact that', 'at this point in time', 'it is important to note that', 'needless to say', 'very', 'really', 'basically', 'in terms of', 'on a daily basis', 'with regard to']
const JARGON = ['leverage', 'synergy', 'synergies', 'holistic', 'paradigm', 'game-changer', 'cutting-edge', 'best-in-class', 'state-of-the-art', 'move the needle', 'low-hanging fruit', 'deep dive', 'impactful', 'utilize', 'utilise', 'stakeholder buy-in']

const syllables = (w: string) => { const x = w.toLowerCase().replace(/[^a-z]/g, ''); if (x.length <= 3) return 1; const m = x.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, '').match(/[aeiouy]{1,2}/g); return Math.max(1, m?.length ?? 1) }

export type SectionLang = { key: string; title: string; words: number; sentences: number; avgLen: number; longCount: number; longest: number; passivePct: number; grade: number; filler: string[]; jargon: string[]; flags: string[] }
export type LangReport = { sections: SectionLang[]; spelling: { dominant: 'US' | 'UK' | 'none'; us: number; uk: number; mixed: boolean; minority: { title: string; found: string[] }[] } }

export function languageReport(sections: Sec[]): LangReport {
  const out: SectionLang[] = []
  let us = 0
  let uk = 0
  const perSection: { title: string; usN: number; ukN: number; usWords: string[]; ukWords: string[] }[] = []
  for (const s of sections) {
    const text = prose(s.text).trim()
    if (text.split(/\s+/).length < 25) continue
    const sentences = text.split(/(?<=[.!?])\s+(?=[A-Z0-9\[(])|\n+/).map((x) => x.trim()).filter((x) => x.split(/\s+/).length >= 3)
    const words = text.split(/\s+/).filter(Boolean)
    const lens = sentences.map((x) => x.split(/\s+/).length)
    const passive = sentences.filter((x) => /\b(is|are|was|were|be|been|being)\s+(?:\w+ly\s+)?(\w+ed|built|made|done|given|shown|held|run|taught|known|seen|chosen|written)\b/i.test(x)).length
    const syl = words.reduce((n, w) => n + syllables(w), 0)
    const avg = lens.length ? words.length / lens.length : 0
    const grade = lens.length ? 0.39 * avg + 11.8 * (syl / words.length) - 15.59 : 0
    const lower = text.toLowerCase()
    const filler = FILLER.filter((f) => new RegExp(`\\b${f}\\b`).test(lower))
    const jargon = JARGON.filter((j) => lower.includes(j))
    const longCount = lens.filter((n) => n > 30).length
    const passivePct = sentences.length ? Math.round((passive / sentences.length) * 100) : 0
    const flags: string[] = []
    if (avg > 24) flags.push(`Sentences average ${Math.round(avg)} words`)
    if (longCount >= 2) flags.push(`${longCount} sentences over 30 words`)
    if (passivePct > 25) flags.push(`${passivePct}% passive sentences`)
    if (grade > 14) flags.push(`Hard to read (grade ${Math.round(grade)})`)
    if (filler.length) flags.push(`Filler: ${filler.slice(0, 3).join(', ')}`)
    if (jargon.length) flags.push(`Jargon: ${jargon.slice(0, 3).join(', ')}`)
    out.push({ key: s.key, title: s.title, words: words.length, sentences: sentences.length, avgLen: Math.round(avg), longCount, longest: Math.max(0, ...lens), passivePct, grade: Math.round(grade), filler, jargon, flags })
    const usN = count(text, US_FORMS)
    const ukN = count(text, UK_FORMS)
    us += usN
    uk += ukN
    perSection.push({ title: s.title, usN, ukN, usWords: [...new Set(US_FORMS.flatMap((re) => text.match(re) ?? []).map((x) => x.toLowerCase()))].slice(0, 4), ukWords: [...new Set(UK_FORMS.flatMap((re) => text.match(re) ?? []).map((x) => x.toLowerCase()))].slice(0, 4) })
  }
  const dominant = us === 0 && uk === 0 ? 'none' : us >= uk ? 'US' : 'UK'
  const mixed = us > 0 && uk > 0
  const minority = mixed ? perSection.filter((p) => (dominant === 'US' ? p.ukN : p.usN) > 0).map((p) => ({ title: p.title, found: dominant === 'US' ? p.ukWords : p.usWords })) : []
  return { sections: out, spelling: { dominant, us, uk, mixed, minority } }
}
