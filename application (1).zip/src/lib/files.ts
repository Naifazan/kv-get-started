import { readXlsx } from '../lib/xlsx-read'
import type { Grant } from '../server/grants'
import { SECTORS, parseDate } from './options'
import { type Application } from './types'

export async function readNeedsFile(f: File): Promise<string> {
  const n = f.name.toLowerCase()
  if (n.endsWith('.xlsx')) {
    const sheets = readXlsx(await f.arrayBuffer())
    return sheets
      .filter((sh) => sh.rows.length)
      .map((sh) => `Sheet: ${sh.name}\n` + sh.rows.map((r) => r.join(' | ')).join('\n'))
      .join('\n\n')
  }
  if (n.endsWith('.csv')) {
    const rows = await readGrantTable(f)
    if (rows.length < 2) return rows.map((r) => r.join(' | ')).join('\n')
    const head = rows[0]
    return rows.slice(1).map((r) => r.map((c, i) => (c ? `${head[i] || 'Column ' + (i + 1)}: ${c}` : '')).filter(Boolean).join('; ')).filter(Boolean).join('\n')
  }
  return readFileText(f)
}


export async function readFileText(f: File): Promise<string> {
  const name = f.name.toLowerCase()
  if (name.endsWith('.pdf')) {
    const pdfjs: any = await import('pdfjs-dist')
    const worker: any = await import('pdfjs-dist/build/pdf.worker.min.mjs?url')
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default
    const pdf = await pdfjs.getDocument({ data: await f.arrayBuffer() }).promise
    let out = ''
    for (let i = 1; i <= Math.min(pdf.numPages, 25); i++) {
      const c = await (await pdf.getPage(i)).getTextContent()
      out += c.items.map((it: any) => it.str).join(' ') + '\n'
    }
    return out
  }
  if (name.endsWith('.docx')) {
    const mammoth: any = await import('mammoth')
    return (await mammoth.extractRawText({ arrayBuffer: await f.arrayBuffer() })).value
  }
  return f.text()
}


// Reads text from nearly any file: PDF, DOCX, spreadsheets, HTML, JSON, CSV, plain text and other text-based formats.
// Reads a file as text and reports why it could not: 'xls' and 'doc' (old formats), 'binary' (not text) or 'parse' (damaged or protected).
export async function readAnyFile(f: File): Promise<string> {
  const n = f.name.toLowerCase()
  if (n.endsWith('.xls')) throw new Error('xls')
  if (n.endsWith('.doc')) throw new Error('doc')
  try {
    return await readAnyFileRaw(f)
  } catch (e: any) {
    throw new Error(e?.message === 'binary' ? 'binary' : 'parse')
  }
}

export const fileErrorText = (e: any) =>
  e?.message === 'xls' ? 'That is an old Excel (.xls) file. Open it in Excel, choose Save As, pick Excel Workbook (.xlsx), then import it again.'
    : e?.message === 'doc' ? 'That is an old Word (.doc) file. Open it in Word, choose Save As, pick Word Document (.docx), then import it again.'
      : e?.message === 'binary' ? 'I could not read text from that file type. Use Excel (.xlsx), Word (.docx), PDF, CSV or a plain text file.'
        : e?.message === 'parse' ? 'The file could not be opened. It may be damaged, password protected or scanned. Remove any protection, or save a copy as .xlsx, .docx or PDF with selectable text, and try again.'
          : 'Something went wrong while reading the file. Please try again.'

export async function readAnyFileRaw(f: File): Promise<string> {
  const n = f.name.toLowerCase()
  if (n.endsWith('.xlsx') || n.endsWith('.csv')) return readNeedsFile(f)
  if (n.endsWith('.pdf') || n.endsWith('.docx')) return readFileText(f)
  const buf = await f.arrayBuffer()
  const bytes = new Uint8Array(buf)
  let raw = ''
  if (bytes[0] === 0xff && bytes[1] === 0xfe) raw = new TextDecoder('utf-16le').decode(bytes)
  else if (bytes[0] === 0xfe && bytes[1] === 0xff) raw = new TextDecoder('utf-16be').decode(bytes)
  else raw = new TextDecoder('utf-8').decode(bytes)
  const sample = raw.slice(0, 4000)
  const bad = (sample.match(/[\u0000-\u0008\u000E-\u001F\uFFFD]/g) ?? []).length
  if (sample.length && bad / sample.length > 0.05) throw new Error('binary')
  if (/\.(html?|xml|svg)$/.test(n) || /^\s*<(!doctype|html|\?xml)/i.test(sample)) {
    return raw.replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/[ \t]+/g, ' ')
  }
  if (n.endsWith('.rtf')) return raw.replace(/\\par[d]?/g, '\n').replace(/\{\\[^{}]*\}|\\[a-z]+-?\d* ?|[{}]/gi, '')
  return raw
}


// ---------- Import grants from CSV / Excel ----------
export const IMPORT_FIELDS: [string, string, RegExp][] = [
  ['title', 'Grant name', /^(grant|program|programme|opportunity|call|fund|project)?\s*(name|title)$|^title$|^grant$|^program(me)?$|^opportunity$/i],
  ['funder', 'Funder', /funder|organi[sz]ation|agency|donor|foundation|sponsor|provider|institution/i],
  ['deadline', 'Deadline', /deadline|due|close|closing|end date|apply by/i],
  ['amountMin', 'Amount min', /(min|from|floor|lower).*(amount|award|grant|usd|\$)|^(min|minimum)$|amount min|award floor/i],
  ['amountMax', 'Amount max', /(max|\bto\b|ceiling|upper|up to).*(amount|award|grant|usd|\$)|^(max|maximum)$|amount max|award ceiling/i],
  ['amount', 'Amount (text or range)', /amount|award|funding|size|value|budget|grant size/i],
  ['status', 'Status', /status|stage|state/i],
  ['gtype', 'Grant type', /type|instrument|kind|category of funding|funding type/i],
  ['countries', 'Countries', /countr|geograph|region|eligible (location|area)|location/i],
  ['sectors', 'Sectors', /sector|theme|focus|topic|thematic|categor|area/i],
  ['url', 'Link', /url|link|website|web|href/i],
  ['summary', 'Description', /descri|summary|about|overview|purpose|notes?/i],
  ['eligibility', 'Eligibility', /eligib|who can apply|applicant/i],
]


export function parseCsv(text: string): string[][] {
  const t = text.replace(/^\uFEFF/, '')
  const first = t.split(/\r?\n/, 1)[0] ?? ''
  const delim = [',', ';', '\t'].map((d) => [d, first.split(d).length] as const).sort((a, b) => b[1] - a[1])[0][0]
  const rows: string[][] = []
  let row: string[] = []
  let cur = ''
  let q = false
  for (let i = 0; i < t.length; i++) {
    const c = t[i]
    if (q) {
      if (c === '"' && t[i + 1] === '"') { cur += '"'; i++ }
      else if (c === '"') q = false
      else cur += c
    } else if (c === '"') q = true
    else if (c === delim) { row.push(cur); cur = '' }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && t[i + 1] === '\n') i++
      row.push(cur); cur = ''
      if (row.some((x) => x.trim())) rows.push(row)
      row = []
    } else cur += c
  }
  row.push(cur)
  if (row.some((x) => x.trim())) rows.push(row)
  return rows
}


export async function readGrantTable(f: File): Promise<string[][]> {
  const name = f.name.toLowerCase()
  if (name.endsWith('.xlsx')) {
    const first = readXlsx(await f.arrayBuffer()).find((sh) => sh.rows.length)
    if (!first) return []
    const w = Math.max(...first.rows.map((r) => r.length))
    return first.rows.map((r) => [...r, ...Array(w - r.length).fill('')])
  }
  if (name.endsWith('.xls')) throw new Error('xls')
  return parseCsv(await f.text())
}


export function detectMapping(headers: string[]): Record<string, number> {
  const map: Record<string, number> = {}
  const used = new Set<number>()
  for (const [key, , re] of IMPORT_FIELDS) {
    const idx = headers.findIndex((h, i) => !used.has(i) && re.test(h.trim()))
    map[key] = idx
    if (idx >= 0) used.add(idx)
  }
  return map
}


export function parseMoney(t: string): number {
  const m = t.replace(/,/g, '').match(/(\d+(?:\.\d+)?)\s*([kKmMbB]|thousand|million)?/)
  if (!m) return 0
  const n = Number(m[1])
  const u = (m[2] ?? '').toLowerCase()
  return Math.round(n * (u.startsWith('k') || u === 'thousand' ? 1e3 : u.startsWith('m') ? 1e6 : u === 'b' ? 1e9 : 1))
}

export function parseAmountText(t: string): { min?: number; max?: number } {
  if (!t.trim()) return {}
  const parts = t.split(/\s(?:-|to|–|—)\s|–|—|\s-\s|(?<=[\dkKmM])\s*-\s*(?=[\d$€£])/i).filter((x) => /\d/.test(x))
  if (parts.length >= 2) return { min: parseMoney(parts[0]) || undefined, max: parseMoney(parts[parts.length - 1]) || undefined }
  const v = parseMoney(t)
  if (!v) return {}
  return /up to|max|ceiling|to \$/i.test(t) ? { max: v } : /from|min|at least/i.test(t) ? { min: v } : { max: v }
}

export function cleanDeadline(t: string) {
  const v = t.trim()
  if (!v) return 'Not stated'
  if (/^\d{4}-\d{2}-\d{2}/.test(v)) return v.slice(0, 10)
  const d = parseDate(v)
  if (d && /\d/.test(v) && /\d{4}/.test(v)) return d.toISOString().slice(0, 10)
  return v
}

export function buildImported(rows: string[][], map: Record<string, number>) {
  const g = (r: string[], k: string) => (map[k] >= 0 ? (r[map[k]] ?? '').trim() : '')
  const out: Grant[] = []
  let skipped = 0
  const seenIds = new Set<string>()
  for (const r of rows) {
    const title = g(r, 'title')
    if (!title) { skipped++; continue }
    const funder = g(r, 'funder') || 'Not stated'
    let h = 0
    for (const ch of `${title}|${funder}`) h = (h * 31 + ch.charCodeAt(0)) | 0
    const id = 'imp-' + Math.abs(h).toString(36)
    if (seenIds.has(id)) { skipped++; continue }
    seenIds.add(id)
    const st = g(r, 'status').toLowerCase()
    const am = parseAmountText(g(r, 'amount'))
    const min = parseMoney(g(r, 'amountMin')) || am.min
    const max = parseMoney(g(r, 'amountMax')) || am.max
    const secRaw = g(r, 'sectors').split(/[,;|/]+/).map((x) => x.trim()).filter(Boolean)
    const sectors = [...new Set(secRaw.map((x) => SECTORS.find((s0) => s0.toLowerCase() === x.toLowerCase()) ?? SECTORS.find((s0) => s0.toLowerCase().includes(x.toLowerCase()) && x.length > 3)).filter(Boolean) as string[])]
    const countries = g(r, 'countries').split(/[,;|]+/).map((x) => x.trim()).filter(Boolean).map((x) => (/^(global|worldwide|all countries|international|any)$/i.test(x) ? 'Global' : x))
    const eligibility = g(r, 'eligibility')
    const summary = [g(r, 'summary'), eligibility && 'Eligibility: ' + eligibility].filter(Boolean).join(' ')
    const url = g(r, 'url')
    out.push({
      id,
      title: title.slice(0, 200),
      funder: funder.slice(0, 120),
      source: 'Imported file',
      deadline: cleanDeadline(g(r, 'deadline')),
      status: /forecast|forthcoming|upcoming|planned|coming/.test(st) ? 'forthcoming' : /closed|expired|archiv|past/.test(st) ? 'closed' : /rolling|ongoing|continuous/.test(st) ? 'ongoing' : /open|posted|active|accepting/.test(st) ? 'open' : /invit/.test(st) ? 'ongoing' : 'unknown',
      url: /^https?:\/\//i.test(url) ? url : url ? 'https://' + url.replace(/^\/+/, '') : '',
      summary: summary.slice(0, 900) || undefined,
      countries: countries.length ? countries : undefined,
      gtype: g(r, 'gtype').slice(0, 40) || undefined,
      sectors: sectors.length ? sectors : undefined,
      amountMin: min || undefined,
      amountMax: max || undefined,
      inviteOnly: /invit/.test(st) || undefined,
    })
  }
  return { grants: out, skipped }
}


export function downloadTemplateCsv() {
  const head = ['Grant name', 'Funder', 'Deadline', 'Amount min (USD)', 'Amount max (USD)', 'Status', 'Type', 'Countries', 'Sectors', 'Link', 'Description', 'Eligibility']
  const rows = [
    ['Community Water Fund', 'Example Foundation', '2026-12-15', '10000', '50000', 'Open', 'Grant', 'Kenya; Uganda', 'Water & sanitation; Health', 'https://example.org/water', 'Supports community water projects.', 'Registered nonprofits'],
    ['Girls Education Prize', 'Sample Trust', 'Rolling', '', '25000', 'Open', 'Prize', 'Global', 'Education; Women & girls', 'https://example.org/prize', 'Annual prize for girls education programs.', ''],
  ]
  const esc = (v: string) => (/[",\n;]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v)
  const csvText = [head, ...rows].map((r) => r.map(esc).join(',')).join('\n')
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([csvText], { type: 'text/csv' }))
  a.download = 'grants-import-template.csv'
  a.click()
}


// Merges applications saved online into the local list: a newer saved copy wins.
export function mergeRemoteApps(cur: Application[], items: { id: string; updated: number; data: Record<string, any> }[]): Application[] {
  const next = [...cur]
  for (const it of items) {
    const remote = it.data as unknown as Application
    if (!remote || typeof remote !== 'object') continue
    const i = next.findIndex((a) => a.id === it.id)
    if (i < 0) next.push({ ...remote, id: it.id, updated: it.updated })
    else if (it.updated > (next[i].updated ?? 0)) next[i] = { ...remote, id: it.id, updated: it.updated }
  }
  return next
}
