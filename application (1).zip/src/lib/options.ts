import type { Grant, Profile } from '../server/grants'
import type { LibDoc } from '../components/LibraryPage'
import { docIsValid } from '../lib/library-digest'

export const US_ELIG: [string, string][] = [['12', 'Nonprofits (501(c)(3))'], ['13', 'Nonprofits (other)'], ['20', 'Private universities'], ['06', 'Public universities'], ['11', 'Tribal organizations'], ['22', 'For-profit organizations'], ['21', 'Individuals'], ['25', 'Others'], ['99', 'Unrestricted']]

export const US_CATS: [string, string][] = [['ED', 'Education'], ['HL', 'Health'], ['ENV', 'Environment'], ['AG', 'Agriculture'], ['CD', 'Community development'], ['ELT', 'Employment and training'], ['DPR', 'Disaster relief'], ['EN', 'Energy'], ['NR', 'Natural resources'], ['ST', 'Science and technology'], ['RT', 'Recreation and tourism'], ['BC', 'Business and commerce'], ['T', 'Transportation']]

export const SECTORS = ['Education', 'Health', 'Water & sanitation', 'Climate & environment', 'Women & girls', 'Youth', 'Human rights', 'Food security & agriculture', 'Livelihoods & economic development', 'Refugees & migration', 'Disability', 'Arts & culture', 'Technology & research', 'Humanitarian & disaster relief', 'Energy', 'Community development']

export const EU_LABEL = 'European Union & associated countries'

export const EU27 = ['Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus', 'Czechia', 'Denmark', 'Estonia', 'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy', 'Latvia', 'Lithuania', 'Luxembourg', 'Malta', 'Netherlands', 'Poland', 'Portugal', 'Romania', 'Slovakia', 'Slovenia', 'Spain', 'Sweden']

export const OTHER_COUNTRIES = ['Afghanistan', 'Argentina', 'Australia', 'Bangladesh', 'Brazil', 'Cambodia', 'Cameroon', 'Canada', 'Chile', 'China', 'Colombia', 'Democratic Republic of the Congo', 'Egypt', 'Ethiopia', 'Ghana', 'Guatemala', 'Haiti', 'India', 'Indonesia', 'Iraq', 'Israel', 'Japan', 'Jordan', 'Kenya', 'Lebanon', 'Liberia', 'Malawi', 'Mali', 'Mexico', 'Morocco', 'Mozambique', 'Myanmar', 'Nepal', 'New Zealand', 'Nigeria', 'Norway', 'Pakistan', 'Peru', 'Philippines', 'Rwanda', 'Senegal', 'Sierra Leone', 'Somalia', 'South Africa', 'South Sudan', 'Sri Lanka', 'Sudan', 'Switzerland', 'Syria', 'Tanzania', 'Thailand', 'Turkey', 'Uganda', 'Ukraine', 'United Kingdom', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe']

export const COUNTRY_OPTIONS = ['United States', EU_LABEL, ...[...EU27, ...OTHER_COUNTRIES].sort()]

// International filters for the country field in Find grants.
export const GLOBAL_LABEL = 'Global (open to all countries)'

export const MIDDLE_EAST_LABEL = 'Middle East'

export const MENA_LABEL = 'MENA (Middle East and North Africa)'

export const MIDDLE_EAST = ['Bahrain', 'Iran', 'Iraq', 'Israel', 'Jordan', 'Kuwait', 'Lebanon', 'Oman', 'Palestine', 'Qatar', 'Saudi Arabia', 'Syria', 'Turkey', 'United Arab Emirates', 'Yemen']

export const NORTH_AFRICA = ['Algeria', 'Djibouti', 'Egypt', 'Libya', 'Morocco', 'Tunisia']

export const REGION_ALIASES: Record<string, string[]> = { Palestine: ['palestin', 'west bank', 'gaza'], 'United Arab Emirates': ['uae', 'emirates'], Turkey: ['turkey', 'türkiye', 'turkiye'], Syria: ['syria'], 'Saudi Arabia': ['saudi'] }

export const REGION_OPTIONS = [GLOBAL_LABEL, MIDDLE_EAST_LABEL, MENA_LABEL]

export const FILTER_COUNTRY_OPTIONS = [...REGION_OPTIONS, ...COUNTRY_OPTIONS]

export const TYPE_OPTIONS = ['Grant', 'Cooperative agreement', 'Grant (EU call)', 'Funder program', 'Small grants program', 'Crowdfunding', 'Fellowship', 'Prize', 'Loan', 'Listings', 'Funder database']


export function normStatus(g: Grant): 'open' | 'forthcoming' | 'closed' | 'rolling' | 'unknown' {
  const st = g.status.toLowerCase()
  const d = parseDate(g.deadline)
  if (/closed|archived/.test(st)) return 'closed'
  if (d && d.getTime() < Date.now() - 864e5) return 'closed'
  if (/forecast|forthcoming|upcoming/.test(st)) return 'forthcoming'
  if (/ongoing|rolling/.test(st) || /rolling|varies/i.test(g.deadline)) return 'rolling'
  if (/posted|open/.test(st)) return 'open'
  return 'unknown'
}

export function isInvite(g: Grant) {
  if (g.inviteOnly) return true
  return /by invitation|invitation[- ]only|invite[- ]only|invited applicants|(does not|do not|not) accept unsolicited|unsolicited (proposals|applications) (are )?not accepted/i.test(`${g.summary ?? ''} ${(g.details ?? '').slice(0, 3000)}`)
}

export function fmtMoney(n: number) {
  return n >= 1e6 ? `$${+(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `$${Math.round(n / 1e3)}k` : `$${n}`
}

export function amountLabel(g: Grant) {
  const lo = g.amountMin ?? 0
  const hi = g.amountMax ?? 0
  if (hi && lo && lo !== hi) return `${fmtMoney(lo)} to ${fmtMoney(hi)}`
  if (hi) return `Up to ${fmtMoney(hi)}`
  if (lo) return `From ${fmtMoney(lo)}`
  return ''
}

export function matchesCountry(g: Grant, c: string) {
  const cs = g.countries ?? []
  const isGlobal = cs.some((x) => /global|worldwide|all countries|any country/i.test(x))
  if (c === GLOBAL_LABEL) return isGlobal
  if (c === MIDDLE_EAST_LABEL || c === MENA_LABEL) {
    if (!cs.length || isGlobal) return true
    const members = c === MENA_LABEL ? [...MIDDLE_EAST, ...NORTH_AFRICA] : MIDDLE_EAST
    const text = `${cs.join(' | ')} ${g.title} ${g.summary ?? ''}`.toLowerCase()
    if (/middle east|\bmena\b|\bmenas\b|arab states|arab region|levant|gulf (?:states|cooperation)/.test(text) && !(c === MIDDLE_EAST_LABEL && /north africa/.test(text) && !/middle east/.test(text))) return true
    if (c === MENA_LABEL && /north africa/.test(text)) return true
    const lc = cs.map((x) => x.toLowerCase())
    return members.some((m) => lc.some((x) => x === m.toLowerCase() || (REGION_ALIASES[m] ?? []).some((a) => x.includes(a))))
  }
  if (!cs.length) return true
  if (cs.some((x) => /global|worldwide|all countries|any country/i.test(x))) return true
  if (cs.includes(c)) return true
  if (EU27.includes(c) && cs.includes(EU_LABEL)) return true
  return false
}


export const SECTIONS = [
  ['summary', 'Executive summary'],
  ['background', 'Organization background'],
  ['need', 'Statement of need'],
  ['beneficiaries', 'Target beneficiaries'],
  ['objectives', 'Goals and SMART objectives'],
  ['activities', 'Project activities'],
  ['outcomes', 'Expected outcomes and evaluation'],
  ['timeline', 'Timeline'],
  ['budget', 'Budget summary and justification'],
  ['capacity', 'Organizational capacity and partnerships'],
  ['sustainability', 'Sustainability and dissemination'],
] as const


export const emptyProfile: Profile = {
  fundingNeed: '',
  org: '', country: '', mission: '', focus: '', size: '', orgType: '', founded: '', registered: '',
  budget: '', regions: '', beneficiaries: '', pastFunding: '', website: '',
}


export const POPULATIONS = ['Women', 'Girls', 'Youth', 'Children', 'Refugees and displaced people', 'Persons with disabilities', 'Indigenous peoples', 'Smallholder farmers', 'Rural communities', 'Urban poor', 'Elderly', 'LGBTQ+ people', 'Survivors of violence', 'Unemployed people']

export const SDGS = ['SDG 1 No poverty', 'SDG 2 Zero hunger', 'SDG 3 Good health', 'SDG 4 Quality education', 'SDG 5 Gender equality', 'SDG 6 Clean water', 'SDG 7 Clean energy', 'SDG 8 Decent work', 'SDG 9 Innovation', 'SDG 10 Reduced inequalities', 'SDG 11 Sustainable communities', 'SDG 12 Responsible consumption', 'SDG 13 Climate action', 'SDG 14 Life below water', 'SDG 15 Life on land', 'SDG 16 Peace and justice', 'SDG 17 Partnerships']

export const GRANT_TYPES_SOUGHT = ['Project grant', 'Core / unrestricted funding', 'Capacity building', 'Emergency / humanitarian', 'Research', 'Fellowship', 'Prize / competition', 'Loan / impact investment', 'Small grant (under $25k)']

export const PURPOSES = ['Program delivery', 'Salaries and staffing', 'Equipment', 'Infrastructure / construction', 'Training', 'Research and evaluation', 'Advocacy', 'Organizational development']

export const COMPLIANCE = ['Audited financial statements', 'Dedicated bank account in the organization name', 'Anti-fraud and anti-corruption policy', 'Safeguarding / child protection policy', 'Monitoring and evaluation system', 'Board of directors', 'US SAM.gov registration (UEI)', 'EU Participant Identification Code (PIC)', 'Published annual reports']

export const SCOPES = ['Local', 'National', 'Regional', 'International']

export const LANGS = ['English', 'French', 'Spanish', 'Arabic', 'Portuguese', 'Swahili', 'Hindi', 'Russian', 'German']


export const csv = (v?: string) => (v ?? '').split(',').map((x) => x.trim()).filter(Boolean)


// Which checklist items the AI can judge from the text, and which section to fix when one fails.
export const Q_META: Record<string, { ai?: boolean; sec?: RegExp }> = {
  a4: { ai: true, sec: /goal|objective/i }, c1: { ai: true, sec: /need|problem/i }, c2: { ai: true, sec: /need|problem/i }, d1: { ai: true }, d3: { ai: true },
  e1: { ai: true, sec: /executive|abstract|^(?!.*budget).*summary/i }, e2: { ai: true, sec: /organi[sz]ation(?!al)|background|introduction/i }, e3: { ai: true, sec: /need|problem/i },
  e4: { ai: true, sec: /goal|objective/i }, e5: { ai: true, sec: /activit|description|method/i }, e6: { ai: true, sec: /timeline|work ?plan|schedule/i }, e7: { ai: true, sec: /evaluation|outcome|monitor/i },
  e8: { ai: true, sec: /budget/i }, e9: { ai: true, sec: /capacity|governance|management/i }, e10: { ai: true, sec: /sustainab|dissemination/i }, e11: { ai: true, sec: /activit|description|method/i },
  f1: { ai: true }, f2: { ai: true }, f4: { ai: true }, f5: { ai: true }, g1: { ai: true, sec: /need|problem/i }, g2: { ai: true }, h1: { ai: true }, h2: { ai: true }, h3: { ai: true },
}


// A quick, local estimate of how well a grant fits the saved profile. No AI call needed.
export function quickMatch(g: Grant, pr: Profile) {
  const reasons: string[] = []
  const flags: string[] = []
  const mySectors = csv(pr.focus)
  let score = 0
  const gs = g.sectors ?? []
  if (gs.length && mySectors.length) {
    const shared = gs.filter((x) => mySectors.includes(x))
    if (shared.length) { score += Math.min(40, 22 + shared.length * 9); reasons.push(`Sector: ${shared.join(', ')}`) }
  } else score += 12
  const mine = [pr.country, ...csv(pr.regCountry), ...csv(pr.opCountries)].filter(Boolean) as string[]
  if (!(g.countries ?? []).length || !mine.length) score += 12
  else if (mine.some((c) => matchesCountry(g, c))) { score += 25; reasons.push('Country eligible') }
  else flags.push(`Lists ${(g.countries ?? []).slice(0, 2).join(', ')}`)
  const lo = Number((pr.amountMin ?? '').replace(/[^0-9.]/g, '')) || 0
  const hi = Number((pr.amountMax ?? '').replace(/[^0-9.]/g, '')) || Infinity
  const top = g.amountMax || g.amountMin || 0
  const bottom = g.amountMin || 0
  if (!top || (!lo && hi === Infinity)) score += 7
  else if (top >= lo && bottom <= hi) { score += 15; reasons.push('Award size fits') }
  else flags.push('Award size outside your range')
  const st = normStatus(g)
  score += st === 'open' || st === 'rolling' ? 10 : st === 'forthcoming' ? 8 : st === 'closed' ? 0 : 4
  const wanted = csv(pr.grantTypes)
  const gt = (g.gtype ?? '').toLowerCase()
  if (!wanted.length || !gt) score += 5
  else if (wanted.some((w) => gt.includes(w.toLowerCase().split(' ')[0]))) { score += 10; reasons.push('Type fits') }
  const comp = csv(pr.compliance)
  if (/us federal/i.test(g.source) && !comp.some((c) => /sam/i.test(c))) flags.push('Needs SAM.gov / UEI')
  if (/eu funding/i.test(g.source) && !comp.some((c) => /pic/i.test(c))) flags.push('Needs EU PIC')
  if (pr.registered === 'no' && !/crowdfunding/i.test(g.source)) flags.push('Needs a registered organization')
  return { score: Math.max(0, Math.min(100, Math.round(score))), reasons, flags }
}



// A realistic view of a grant: is there time, does the award size suit the organization, and can it really apply?
// The priority score ranks grants by how sensible they are to apply for now, not only by topic.
export function orgBudgetCeiling(b: string | undefined): number {
  const t = (b ?? '').toLowerCase()
  const nums = [...t.matchAll(/\$?\s*(\d+(?:\.\d+)?)\s*([km])?/g)].map((m) => Number(m[1]) * (m[2] === 'm' ? 1e6 : m[2] === 'k' ? 1e3 : 1)).filter((n) => n > 0)
  if (!nums.length) return 0
  return /over|more than|above/.test(t) ? Math.max(...nums) * 1.5 : Math.max(...nums)
}

export function realism(g: Grant, pr: Profile, docs: LibDoc[] = []) {
  const m = quickMatch(g, pr)
  const flags: { text: string; tone: 'bad' | 'warn' | 'good' }[] = []
  let p = m.score
  const st = normStatus(g)
  const d = parseDate(g.deadline)
  const days = d ? Math.ceil((d.getTime() - Date.now()) / 864e5) : null
  if (st === 'closed' || (days !== null && days < 0)) { p -= 60; flags.push({ text: 'Closed', tone: 'bad' }) }
  else if (days !== null && days <= 7) { p -= 25; flags.push({ text: `Only ${days} day${days === 1 ? '' : 's'} left`, tone: 'bad' }) }
  else if (days !== null && days <= 14) { p -= 10; flags.push({ text: `${days} days left, tight`, tone: 'warn' }) }
  else if (days !== null && days <= 120) { p += 5; flags.push({ text: `${days} days to prepare`, tone: 'good' }) }
  else if (st === 'rolling') { p += 5; flags.push({ text: 'Rolling, no rush', tone: 'good' }) }
  else if (st === 'forthcoming') flags.push({ text: 'Opens later, time to prepare', tone: 'good' })
  if (g.inviteOnly) { p -= 40; flags.push({ text: 'Invitation only', tone: 'bad' }) }
  const ceiling = orgBudgetCeiling(pr.budget)
  const top = g.amountMax || g.amountMin || 0
  if (ceiling && top) {
    const r = top / ceiling
    if (r > 1) { p -= 20; flags.push({ text: `Award is about ${Math.round(r)}x your yearly budget. Funders rarely grant that much`, tone: 'bad' }) }
    else if (r > 0.6) { p -= 8; flags.push({ text: 'Large for your budget. Expect strict capacity checks', tone: 'warn' }) }
    else if (r >= 0.05) { p += 8; flags.push({ text: 'Award size suits your budget', tone: 'good' }) }
    else if (r < 0.03) { p -= 5; flags.push({ text: 'Small award for the effort', tone: 'warn' }) }
  }
  // What the grant asks for, compared with the documents in the library.
  const need = `${g.title} ${g.summary ?? ''} ${g.details ?? ''}`.toLowerCase()
  const checks: [RegExp, string, string][] = [
    [/audited|audit report|financial statements/, 'Audited accounts', 'audited accounts'],
    [/safeguarding|child protection|psea|sexual exploitation/, 'Safeguarding policy', 'a safeguarding policy'],
    [/anti-?fraud|anti-?corruption|anti-?bribery/, 'Anti-fraud and anti-corruption policy', 'an anti-fraud policy'],
    [/registration certificate|certificate of registration|legal registration|registered (?:as|in|with)|legal status/, 'Registration certificate', 'a registration certificate'],
    [/tax[- ]exempt|501\(c\)/, 'Tax exemption letter', 'a tax exemption letter'],
  ]
  for (const [re, type, label] of checks) {
    if (!re.test(need)) continue
    const have = docs.filter((d) => d.type === type)
    if (have.some(docIsValid)) { p += 3; flags.push({ text: `You have ${label}`, tone: 'good' }) }
    else if (have.length) { p -= 6; flags.push({ text: `Asks for ${label}: yours has expired`, tone: 'warn' }) }
    else if (docs.length) { p -= 6; flags.push({ text: `Asks for ${label}: none in your library`, tone: 'warn' }) }
  }
  for (const f of m.flags) flags.push({ text: f, tone: /Lists|registered/i.test(f) ? 'bad' : 'warn' })
  if (m.flags.some((f) => /^Lists /.test(f))) p -= 25
  return { priority: Math.max(0, Math.min(100, Math.round(p))), flags }
}


export const PROFILE_KEYS: (keyof Profile)[] = ['org', 'country', 'regCountry', 'orgType', 'registered', 'founded', 'budget', 'size', 'mission', 'focus', 'populations', 'opCountries', 'scope', 'amountMin', 'amountMax', 'grantTypes', 'pastFunding']

export const missingKeys = (p: Profile) => PROFILE_KEYS.filter((k) => !(p[k] ?? '').toString().trim())

export function completeness(p: Profile) {
  return Math.round(((PROFILE_KEYS.length - missingKeys(p).length) / PROFILE_KEYS.length) * 100)
}


export const FIELD_LABELS: Record<string, string> = {
  org: 'Name', country: 'Country', orgType: 'Type', founded: 'Founded', registered: 'Registered', budget: 'Budget',
  size: 'Team', website: 'Website', focus: 'Focus areas', regions: 'Regions', beneficiaries: 'Who you serve',
  mission: 'Mission', pastFunding: 'Past funding and results',
  regCountry: 'Registered in', amountMin: 'Smallest grant sought', amountMax: 'Largest grant sought', grantTypes: 'Grant types sought', purposes: 'Funding purposes', compliance: 'Systems and registrations', taxStatus: 'Tax status', populations: 'Populations served', sdgs: 'SDGs', opCountries: 'Works in', scope: 'Scope', languages: 'Languages', largestGrant: 'Largest grant managed',
}


export function parseDate(s: string) {
  const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  const d = m ? new Date(`${m[3]}-${m[1]}-${m[2]}`) : new Date(s)
  return isNaN(d.getTime()) ? null : d
}

// A deadline as people read it, for example 30 Oct 2026. Text such as Rolling or Varies is shown as it is.
export function showDate(s: string) {
  const d = parseDate(String(s ?? ''))
  return d ? d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }) : s
}

// Library documents that prove an item of the profile's compliance list.
const DOC_TO_COMPLIANCE: Record<string, string> = {
  'Audited accounts': 'Audited financial statements',
  'Annual report': 'Published annual reports',
  'Safeguarding policy': 'Safeguarding / child protection policy',
  'Anti-fraud and anti-corruption policy': 'Anti-fraud and anti-corruption policy',
  'Bank details letter': 'Dedicated bank account in the organization name',
  'Board list': 'Board of directors',
}
export function libraryCompliance(docs: { type: string; expiry: string }[]) {
  const ok = (d: { expiry: string }) => { if (!d.expiry) return true; const t = new Date(d.expiry).getTime(); return Number.isNaN(t) || t >= Date.now() }
  const valid = new Set<string>()
  const expired = new Set<string>()
  for (const d of docs) { const c = DOC_TO_COMPLIANCE[d.type]; if (!c) continue; if (ok(d)) valid.add(c); else expired.add(c) }
  for (const v of valid) expired.delete(v)
  return { valid: [...valid], expired: [...expired] }
}
