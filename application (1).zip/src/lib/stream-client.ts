// Reads the live writing stream from /api/write-stream.
export type StreamResult = { ok: true; text: string } | { ok: false; reason: string; network?: boolean }

export async function streamWrite(
  data: unknown,
  on: { delta: (s: string) => void; reset: () => void; status: (s: string) => void },
  signal?: AbortSignal,
): Promise<StreamResult> {
  let res: Response
  try {
    res = await fetch('/api/write-stream', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(data), signal })
  } catch {
    return signal?.aborted ? { ok: false, reason: 'Stopped.' } : { ok: false, reason: 'Could not reach the server.', network: true }
  }
  const type = res.headers.get('content-type') ?? ''
  if (!res.ok && !type.includes('json')) return { ok: false, reason: 'The live writing service is not available.', network: true }
  if (type.includes('json')) {
    try { const j = await res.json(); return { ok: false, reason: String(j?.reason ?? 'The AI is not available right now.') } } catch { return { ok: false, reason: 'The AI is not available right now.', network: true } }
  }
  if (!res.body) return { ok: false, reason: 'Live writing is not supported here.', network: true }
  const reader = res.body.getReader()
  const dec = new TextDecoder()
  let buf = ''
  let result: StreamResult | null = null
  try {
    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      buf += dec.decode(value, { stream: true })
      let i: number
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const ev = buf.slice(0, i)
        buf = buf.slice(i + 2)
        if (!ev.startsWith('data:')) continue
        let o: any
        try { o = JSON.parse(ev.slice(5).trim()) } catch { continue }
        if (o.t === 'd') on.delta(String(o.s ?? ''))
        else if (o.t === 'reset') on.reset()
        else if (o.t === 'status') on.status(String(o.s ?? ''))
        else if (o.t === 'done') result = { ok: true, text: String(o.text ?? '') }
        else if (o.t === 'error') result = { ok: false, reason: String(o.reason ?? 'The AI service returned an error.') }
      }
    }
  } catch {
    if (signal?.aborted) return { ok: false, reason: 'Stopped.' }
  }
  return result ?? { ok: false, reason: 'The connection closed before the text was finished. Please try again.' }
}
