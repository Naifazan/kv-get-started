import type { AuditVerdict, SourceItem, EligibilityItem, FrameworkOptions, Grant, GrantGuidance } from '../server/grants'
import type { Snapshot } from '../components/HistoryModal'

export type Fit = { score: number; strengths: string[]; gaps: string[]; tips: string[]; mode: 'ai' | 'keyword'; pk?: string; breakdown?: { label: string; points: number; max: number; note: string }[] }

export type View = 'dashboard' | 'pipeline' | 'tracker' | 'find' | 'applications' | 'library' | 'profile' | 'plans' | 'admin'

export const VIEWS: View[] = ['dashboard', 'pipeline', 'tracker', 'find', 'applications', 'library', 'profile', 'plans', 'admin']

export type PipeTab = 'open' | 'upcoming' | 'invite' | 'saved' | 'applying'

export type AppStatus = 'Drafting' | 'In review' | 'Submitted' | 'Awarded' | 'Declined'

export const STATUSES: AppStatus[] = ['Drafting', 'In review', 'Submitted', 'Awarded', 'Declined']

export type Project = { title: string; amount: string; months: string }

export type Area = { name: string; country: string; governorate?: string; district?: string; beneficiaries: string }

// A planned area reads country, governorate, district. Areas saved before these boxes existed keep their old name as the governorate.
export const areaGov = (a: Area) => a.governorate ?? (a.district === undefined ? a.name : '')

export const areaLabel = (a: Area) => [a.district, areaGov(a), a.country].map((x) => (x ?? '').trim()).filter(Boolean).join(', ')

export const areaFilled = (a: Area) => areaLabel(a).length > 0

export type Inputs = { needs: string; areas: Area[]; primary: string }

export const emptyInputs: Inputs = { needs: '', areas: [], primary: '' }

export type Application = {
  id: string
  inputs?: Inputs
  plan?: string
  planDocs?: { id: string; name: string; at: number; summary: string; chars: number; ai: boolean }[]
  docNotes?: string
  lineNotes?: string
  fixedAt?: Record<string, number>
  chat?: { role: 'user' | 'assistant'; content: string; at: number }[]
  experience?: { id: string; name: string; at: number; summary: string; chars: number; ai: boolean }[]
  areasSnap?: string
  quality?: Record<string, boolean>
  facts?: { direct: string; indirect: string; partners: string; targets: string }
  sources?: SourceItem[]
  sourcesAt?: number
  ready?: { at: number; hash: string; n: number }
  audit?: { at: number; hash: string; results: Record<string, AuditVerdict> }
  grant: Grant | null
  status: AppStatus
  project: Project
  doc: Record<string, string>
  tpl: Tpl | null
  notes: string
  created: number
  updated: number
  versions?: Record<string, number>
  guidance?: GrantGuidance | null
  budgetFile?: { name: string; b64: string; sheets: number } | null
  guidanceText?: string
  grantLink?: string
  extras?: Record<string, { title: string; text: string; at: number; data?: string }>
  linkText?: string
  linkFetched?: string
  review?: { at: number; overall: number } | null
  probability?: number
  share?: { token: string; at: number } | null
  checklist?: Record<string, boolean>
  history?: Snapshot[]
  eligibility?: (EligibilityItem & { note?: string })[] | null
  framework?: { options: FrameworkOptions; selected: Partial<Record<keyof FrameworkOptions, string[]>> } | null
}

export const STAGE_PROB: Record<string, number> = { Drafting: 10, 'In review': 20, Submitted: 30, Awarded: 100, Declined: 0 }

export const FRAME_FIELDS: [keyof FrameworkOptions, string, string][] = [
  ['priorities', 'Grant priorities', 'Pick the funding priorities your project responds to.'],
  ['objectives', 'Objectives', 'The funder\'s objectives your project supports.'],
  ['subObjectives', 'Sub-objectives', 'Result areas under those objectives.'],
  ['outcomes', 'Outcomes', 'The outcomes your project will contribute to.'],
  ['outputs', 'Outputs', 'The outputs and deliverables you will produce.'],
  ['activities', 'Activities', 'Activities the funder names or accepts.'],
  ['indicators', 'Indicators', 'Indicators you will report against.'],
  ['budgetCeilings', 'Budget ceilings', 'Limits that apply to your budget.'],
]

export const ELIG_LABEL: Record<string, string> = { met: 'Met', not_met: 'Not met', document: 'Needs a document', unclear: 'Unclear' }

export const ELIG_TONE: Record<string, string> = { met: 'bg-green-100 text-green-900', not_met: 'bg-red-100 text-red-900', document: 'bg-amber-100 text-amber-900', unclear: 'bg-card text-ink' }

export const emptyProject: Project = { title: '', amount: '', months: '12' }


export type QType = 'text' | 'yesno' | 'select' | 'multiselect' | 'number' | 'date' | 'table'
export type TplSection = { key: string; title: string; guidance: string; wordLimit: number; limit?: number; limitUnit?: 'words' | 'characters' | 'characters_nospace'; group?: string; type?: QType; options?: string[]; explain?: boolean; required?: boolean; unit?: string }
export type Tpl = { name: string; overview?: string; sections: TplSection[] }


export type SortState = { k: string; dir: 1 | -1 } | null

export type QItem = { id: string; group: string; sub?: string; text: string; auto: boolean | null; note?: string; ai?: boolean; sec?: RegExp }

export type TRow = {
  key: string
  g: Grant | null
  a: Application | null
  title: string
  funder: string
  source: string
  gtype: string
  gStatus: string
  aStatus: string
  deadline: string
  days: number | null
  award: string
  requested: number
  prob: number | null
  exp: number
  fit: number | null
  fitAi: boolean
  prog: { done: number; total: number; pct: number } | null
  updated: number
}
