import type { Library, LibDoc } from '../components/LibraryPage'

const words = (t: string) => new Set(t.toLowerCase().split(/[^a-z]+/).filter((w) => w.length > 3))

export function docIsValid(d: LibDoc) {
  if (!d.expiry) return true
  const t = new Date(d.expiry).getTime()
  return Number.isNaN(t) || t >= Date.now()
}

/** A short text about the organization's own documents, for the AI. Documents that match `query` come first. */
export function libraryDigest(lib: Library, max = 1800, query = ''): string {
  const q = words(query)
  const rel = (t: string) => (q.size ? [...words(t)].filter((w) => q.has(w)).length : 0)
  const parts: string[] = []
  if (lib.docs.length) {
    parts.push('Documents on file: ' + lib.docs.map((d) => `${d.type}${d.expiry ? (docIsValid(d) ? ` (valid to ${d.expiry})` : ` (EXPIRED ${d.expiry})`) : ''}`).slice(0, 14).join('; ') + '.')
  }
  const rich = [
    ...lib.docs.filter((d) => d.facts || d.text).map((d) => ({ head: `${d.name} [${d.type}]`, body: d.facts || '', text: d.text ?? '' })),
    ...lib.snippets.filter((s) => s.text).map((s) => ({ head: `${s.title} [${s.category}]`, body: '', text: s.text })),
  ]
    .map((x) => ({ ...x, r: rel(`${x.head} ${x.body} ${x.text.slice(0, 2500)}`) }))
    .sort((a, b) => b.r - a.r)
  for (const x of rich.slice(0, 6)) {
    const body = (x.body ? x.body + ' ' : '') + x.text.replace(/\s+/g, ' ').slice(0, x.r ? 600 : 300)
    parts.push(`- ${x.head}: ${body.trim()}`)
  }
  return parts.join('\n').slice(0, max)
}

/** The text of the library for reading profile facts: past reports, registration papers, policies. */
export function libraryTextForProfile(lib: Library, max = 9000): string {
  const chunks: string[] = []
  for (const d of lib.docs) if (d.text) chunks.push(`DOCUMENT "${d.name}" (${d.type}${d.issued ? ', issued ' + d.issued : ''}${d.expiry ? ', expires ' + d.expiry : ''}):\n${d.text.slice(0, 3500)}`)
  for (const s of lib.snippets) chunks.push(`TEXT "${s.title}" (${s.category}):\n${s.text.slice(0, 2500)}`)
  return chunks.join('\n\n').slice(0, max)
}
