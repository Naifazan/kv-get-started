import { sectionPlain } from './text'

export type LimitUnit = 'words' | 'characters' | 'characters_nospace'
export type Limit = { n: number; unit: LimitUnit }

export const unitName = (u: LimitUnit) => (u === 'words' ? 'words' : u === 'characters' ? 'characters (with spaces)' : 'characters (without spaces)')
export const unitShort = (u: LimitUnit) => (u === 'words' ? 'words' : u === 'characters' ? 'characters' : 'characters without spaces')

// How long a text is, in the unit the funder uses.
export function measure(text: string, unit: LimitUnit): number {
  const plain = sectionPlain(text || '')
  if (unit === 'words') return plain.trim() ? plain.trim().split(/\s+/).length : 0
  if (unit === 'characters') return plain.length
  return plain.replace(/\s/g, '').length
}

// Last resort when the AI cannot shorten a text enough: whole sentences are removed from the end until it fits. Tables are never cut.
export function hardTrim(text: string, limit: Limit): string {
  if (measure(text, limit.unit) <= limit.n || text.includes('|')) return text
  const parts = text.split(/(\n+)/)
  let out = ''
  for (const part of parts) {
    if (/^\n+$/.test(part)) { out += part; continue }
    const sentences = part.split(/(?<=[.!?])\s+/)
    for (const s of sentences) {
      const next = out ? `${out}${out.endsWith('\n') ? '' : ' '}${s}` : s
      if (measure(next, limit.unit) > limit.n) return out.trim()
      out = next
    }
  }
  return out.trim()
}
