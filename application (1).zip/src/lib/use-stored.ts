import { useEffect, useState } from 'react'

export function useStored<T>(key: string, initial: T) {
  const [v, setV] = useState<T>(initial)
  const [ready, setReady] = useState(false)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(key)
      if (raw) setV(JSON.parse(raw))
    } catch {}
    setReady(true)
  }, [key])
  // Writes are batched, so typing in long drafts stays smooth.
  useEffect(() => {
    if (!ready) return
    const write = () => { try { localStorage.setItem(key, JSON.stringify(v)) } catch { window.dispatchEvent(new Event('ngw-storage-error')) } }
    const t = setTimeout(write, 350)
    window.addEventListener('pagehide', write)
    return () => { clearTimeout(t); window.removeEventListener('pagehide', write) }
  }, [key, v, ready])
  return [v, setV] as const
}
