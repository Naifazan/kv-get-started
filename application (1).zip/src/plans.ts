// Plans, limits and checkout links. Shared by the server (limits) and the page (Plans screen).
export type PlanKey = 'free' | 'starter' | 'pro' | 'owner'

export const PLAN_LIMITS: Record<PlanKey, { name: string; credits: number; projects: number }> = {
  free: { name: 'Free', credits: 30, projects: 1 },
  starter: { name: 'Starter', credits: 300, projects: 3 },
  pro: { name: 'Pro', credits: 1500, projects: 1000 },
  owner: { name: 'Owner', credits: 1_000_000, projects: 1000 },
}

// The portal's own key belongs to this business, so its products are the ones the portal can check. Starter and Pro are separate products on purpose:
// the free sign-up plan lives on another product, so a free member is never mistaken for a paying one.
export const PRODUCT_IDS = { starter: 'prod_ruICLWQ28N9yl', pro: 'prod_IHcuaKvUMKXUs' } as const
export const COMPANY_ID = 'biz_i4pajUuqhCtNQM'

export const CHECKOUT = {
  free: 'https://whop.com/checkout/ch_auuYzJQ3I3oIU4K/',
  starter: { month: 'https://whop.com/checkout/ch_dDspD1UcJAMwzQw/', year: 'https://whop.com/checkout/ch_8ceWbICeSEMJyap/' },
  pro: { month: 'https://whop.com/checkout/ch_PViTuCeXSjGjJ/', year: 'https://whop.com/checkout/ch_HR09PHXjhg6dAcd/' },
} as const

// Which paid plans can be bought, with their trial and what is charged at sign-up. Each has its own checkout above.
export const AVAILABLE = { starter: { month: true, year: true }, pro: { month: true, year: true } } as const
export const TRIAL_DAYS = { starter: { month: 7, year: 7 }, pro: { month: 0, year: 7 } } as const
export const DUE_TODAY = { starter: { month: 0, year: 0 }, pro: { month: 0, year: 0 } } as const

export const PRICES = { starter: { month: 12, year: 120 }, pro: { month: 29, year: 290 } } as const

export type Billing = {
  signedIn: boolean
  plan: PlanKey
  used: number
  limit: number
  projects: number
  resetsAt: number
}

// Direct checkout links for the landing pricing section.
export const PRICING_LINKS = {
  free: 'https://whop.com/checkout/ch_hXSJc3fVA1aJxQt/',
  pro: 'https://whop.com/checkout/ch_uO2cFGi5YOjkSjJ/',
} as const
