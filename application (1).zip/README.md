# Global NGO Grants Writer

A free portal for NGOs: find grants, write the proposal, build the budget, generate MEAL and reporting documents, and check quality before submitting.

## Run and build

```bash
bun install
bun --bun run dev        # local development
bun run typecheck        # TypeScript check
bun test                 # unit tests (tests/)
bun --bun run build      # production build
```

## Structure

- `src/routes/index.tsx` the portal: pages (dashboard, pipeline, find, applications, library, profile) and the application editor.
- `src/routes/share.$token.tsx` public read-only share page. `src/routes/api/` OAuth sign-in and the scheduled refresh.
- `src/server/grants.ts` grant search, AI calls (`llm`, with key and model fallback), writing, budget, documents, checks.
- `src/server/review.ts` reviewer score, consistency, compliance and fix suggestions. `src/server/saved.ts` saving online, sharing, data export and deletion.
- `src/limits.server.ts` per-visitor limit on AI calls. `src/db.server.ts` database access.
- `src/components/` shared UI (menus, date field, review window, library, budget aids). `src/lib/` pure helpers (spreadsheets, library digest, titles, countries, file store).
- `tests/` unit tests for the pure helpers.

## Secrets (set on the hosting app, never in code)

`OPENAI_API_KEY` (Groq `gsk_`, Google `AIza` or `AQ.`, or OpenAI key), optional `GEMINI_API_KEY` as a second provider, `DATABASE_URL`, optional `TAVILY_API_KEY`.

## Plans and AI credits

- Plans (Free, Starter, Pro) are Whop products, listed in `src/plans.ts` with their limits and checkout links. The site owner (admin of the company) is unlimited.
- `src/usage.server.ts` looks up the plan with the Whop access check (cached 2 minutes per person) and counts AI calls in the `ai_usage` table (created on first use). `llm()` in `src/server/grants.ts` takes one credit per call; the scheduled refresh is not counted.
- Online saved projects are capped per plan in `saveApplication`. Local browser storage is never capped.
- To change a limit or price, edit `src/plans.ts` (limits) and the plan price in Whop, then publish.
